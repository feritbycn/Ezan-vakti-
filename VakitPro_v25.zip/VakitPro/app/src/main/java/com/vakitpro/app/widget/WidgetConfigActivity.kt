package com.vakitpro.app.widget

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.vakitpro.app.data.Prefs

/** Widget eklenirken arka plan (koyu cam / saydam) ve yazi rengi secimi. */
class WidgetConfigActivity : Activity() {
    private var choice = "dark"
    private var textChoice = "auto"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_CANCELED)
        val id = intent?.extras?.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
            ?: AppWidgetManager.INVALID_APPWIDGET_ID
        if (id == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish()
            return
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            val p = (24 * resources.displayMetrics.density).toInt()
            setPadding(p, p, p, p)
        }
        val title = TextView(this).apply {
            text = "Widget arka planı"
            textSize = 18f
            gravity = Gravity.CENTER
        }
        val dark = Button(this)
        val clear = Button(this)
        val textTitle = TextView(this).apply {
            text = "Yazı rengi"
            textSize = 18f
            gravity = Gravity.CENTER
            val m = (16 * resources.displayMetrics.density).toInt()
            setPadding(0, m, 0, 0)
        }
        val tAuto = Button(this)
        val tCream = Button(this)
        val tWhite = Button(this)
        val tBlack = Button(this)
        val save = Button(this).apply { text = "Ekle" }

        fun paint() {
            dark.text = (if (choice == "dark") "✓ " else "") + "Koyu cam"
            clear.text = (if (choice == "clear") "✓ " else "") + "Saydam"
            tAuto.text = (if (textChoice == "auto") "✓ " else "") + "Otomatik"
            tCream.text = (if (textChoice == "cream") "✓ " else "") + "Krem"
            tWhite.text = (if (textChoice == "white") "✓ " else "") + "Beyaz"
            tBlack.text = (if (textChoice == "black") "✓ " else "") + "Siyah"
        }
        dark.setOnClickListener { choice = "dark"; paint() }
        clear.setOnClickListener { choice = "clear"; paint() }
        tAuto.setOnClickListener { textChoice = "auto"; paint() }
        tCream.setOnClickListener { textChoice = "cream"; paint() }
        tWhite.setOnClickListener { textChoice = "white"; paint() }
        tBlack.setOnClickListener { textChoice = "black"; paint() }
        save.setOnClickListener {
            Prefs.putStr(this, "wbg_$id", choice)
            Prefs.putStr(this, "wtxt_$id", textChoice)
            WidgetUpdater.updateAll(this)
            setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id))
            finish()
        }
        paint()

        root.addView(title)
        root.addView(dark)
        root.addView(clear)
        root.addView(textTitle)
        root.addView(tAuto)
        root.addView(tCream)
        root.addView(tWhite)
        root.addView(tBlack)
        root.addView(save)
        setContentView(root)
    }
}
