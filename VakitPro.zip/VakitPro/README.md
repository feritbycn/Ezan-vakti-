# Vakit Pro

Modern, çevrimdışı çalışan namaz vakti uygulaması. Kotlin + Jetpack Compose (Material 3).

## Özellikler

| | |
|---|---|
| ⏱ **Canlı geri sayım** | Ana ekranda halka + saniye saniye kalan süre |
| 📱 **3 ana ekran widget'ı** | Geri sayım (2x2), Günlük vakitler (4x2), Şerit (4x1). Geri sayım Chronometer ile **canlı** akar, pil yemez |
| 🔔 **Bildirim çubuğunda geri sayım** | Kalıcı bildirim: kalan süre canlı, genişletince 6 vakit. Üst çubukta **kalan dakikayı gösteren ikon** |
| 🕌 **Vakit bildirimleri** | Tam dakikasında (exact alarm), vakit başına aç/kapa, X dk önce hatırlatma, titreşim, özel ses |
| 🧭 **Kıble pusulası** | Rotasyon sensörü + manyetik sapma düzeltmesi, hizalanınca titreşim, Kabe'ye mesafe |
| 📿 **Zikirmatik** | Modern dokunmatik daire, hedef seçimi (33/99/100/500/1000/∞), günlük/toplam/tur sayacı, titreşim aç-kapa, ekran açık kalır |
| 📖 **Kur'an-ı Kerim** | 114 sure, Arapça (Osmani) + Türkçe meal, çevrimdışı, yazı boyutu, kaldığın yerden devam |
| 🔕 **Otomatik sessize alma** | Vakit girince telefon sessize/titreşime geçer; her vakit için ayrı dakika; süre dolunca eski moda döner |
| ⏰ **Vakitten önce hatırlat** | Her vakit için ayrı dakika (5-60) |
| 🧪 **60 dk testi** | Ayarlar'dan aç: durum çubuğunda hemen "60, 59, 58…" dakika ikonu görünür |
| 💠 **Esmâü'l-Hüsnâ** | 99 isim, Arapça, anlam, arama, günün esması |
| 🌙 **Dini günler** | Kandiller, bayramlar, Ramazan; kaç gün kaldığı |
| 🗓 **Aylık imsakiye** | Ay ay tüm vakitler |
| ✅ **Namaz takibi** | Seri (streak), haftalık grafik, Kur'an/zikir/sadaka/oruç |
| 🧮 **Zekât hesabı** | Nisab (80,18 gr altın) ve %2,5 |
| 🤲 **Sure ve dualar** | Fâtiha, İhlâs, Felâk, Nâs, Kevser, Asr, Âyetel Kürsî — Arapça + okunuş + anlam |
| 📍 **Yakındaki camiler** | Haritada aç |
| 🎨 **Tema** | Sistem / Açık / Koyu / AMOLED, 6 vurgu rengi, Android 12+ dinamik renk |

Vakitler **internet gerekmeden** cihazda hesaplanır (Diyanet, MWL, Ümmü'l-Kurâ, Mısır, Karaçi, ISNA).
81 il dahili, ayrıca GPS ile konum bulma. Reklam, hesap, sunucu yok.

## APK'yı GitHub ile derleme (bilgisayarda hiçbir şey kurmadan)

1. GitHub'da yeni bir **boş repo** aç (ör. `vakit-pro`).
2. Zip'i bilgisayarında **çıkar**. Çıkan klasörün **içindeki her şeyi** repoya yükle:
   *Add file → Upload files* ile sürükle-bırak (`app`, `gradle.properties`, `build.gradle.kts`, `settings.gradle.kts`, `.github` ...).
   - ⚠️ `.github` klasörü gizli klasördür. Dosya gezgininde **gizli dosyaları göster** seçeneğini aç, yoksa yüklenmez.
   - `.github` yüklenmediyse: repoda *Add file → Create new file*, dosya adına `.github/workflows/build.yml` yaz ve `build.yml` içeriğini yapıştır (kökteki `github-workflow-kopya.yml` dosyasının içeriği aynısıdır).
3. Yükleme bitince **Actions** sekmesine git. "APK Derle" otomatik başlar (≈ 4-6 dk). Başlamazsa *APK Derle → Run workflow*.
4. Yeşil ✅ olunca çalıştırmaya tıkla, en alttaki **Artifacts** bölümünden `VakitPro-release-apk` dosyasını indir (zip içinden `.apk` çıkar).
5. APK'yı telefona at, aç → "Bilinmeyen kaynaklardan kuruluma izin ver" → kur.

> İmza: release APK da debug anahtarıyla imzalanır, bu yüzden doğrudan kurulabilir. Google Play'e yüklemek için kendi keystore'unu tanımlaman gerekir.

## İlk açılışta yap

1. Bildirim iznini **ver**.
2. Ayarlar → İzinler: **Tam zamanlı alarm** ve **Pil optimizasyonunu kapat** (ezan bildirimi tam vaktinde gelsin diye).
3. Ayarlar → **GPS ile konumumu bul** (ya da şehir seç).
4. Ana ekrana widget ekle: boş yere uzun bas → Widget'lar → **Vakit Pro**.

## Ezan sesi eklemek

Uygulamaya ezan kaydı **dahil değildir** (telif). Kendi hakkı sende olan bir kaydı `app/src/main/res/raw/ezan.mp3` olarak eklersen
Ayarlar → Bildirim sesi → **Ezan sesi** seçeneği otomatik belirir. Ya da *Özel ses seç…* ile telefondaki herhangi bir sesi seç.

## Notlar

- Hesaplanan vakitler Diyanet takviminden 1-2 dk sapabilir. Ayarlar → Dakika ayarları ile her vakti ± ince ayarlayabilirsin.
- Hicrî tarih/kandiller Umm al-Qura takvimine göredir; Diyanet ile ±1 gün fark olabilir → Ayarlar → Hicrî tarih düzeltmesi.
- Xiaomi/Huawei/Samsung'da uygulamayı "otomatik başlat" ve "pil kısıtlaması yok" listesine eklemek bildirimlerin kesintisiz gelmesini sağlar.

## Yerelde derleme (isteğe bağlı)

Android Studio ile klasörü aç → Sync → Run. Ya da Gradle 8.9 + JDK 17 ile: `gradle assembleRelease`.

## Kaynaklar / lisans
- Arapça Kur'an metni: Tanzil Project (tanzil.net), Osmani yazım.
- Türkçe meal: Kuran Ansiklopedisi (quranenc.com), Rowwad Çeviri Merkezi.
- Veriler `risan/quran-json` deposundan (CC BY-SA 4.0) alınmıştır; metinleri paylaşırken kaynak belirtin.

## Güncelleme / imza
APK artık projedeki sabit anahtarla (`app/vakitpro.jks`) imzalanır; her derleme aynı imzayı taşır ve yeni APK eskisinin **üstüne güncellenir**.
Not: Daha önce başka imzayla kurulmuş sürüm varsa bir kez kaldırıp yeniden kurman gerekir.

## Yeni (v1.2)
- Kur'an sesli okuma: ayet ayet, 15 hafız seçilebilir (sesler everyayah.com'dan internetten akar).
- İlk açılışta bildirim ve pil optimizasyonu izinleri istenir.
- Bildirim görünümü: modern kart; arka plan rengi, saydamlık, vurgu ve yazı rengi Ayarlar > Bildirim görünümü.
- Durum çubuğu dakikası artık aşağı yuvarlanır (sayaçla birebir).
- Yeni widgetlar: Halka (2x2) ve Gün kadranı (4x2).
- Bildirim simgesi olarak kendi resmini seçebilme.

## v1.3
- Vakitten önce hatırlatma: resimli bildirim (ayet/hadis), ses + kısa titreşim, "10 dk Ertele", test butonu.
- Vakit girince: resimli bildirim + ana ekranda açılan pencere (izin: "Diğer uygulamaların üzerinde göster"), test butonu.
- Keşfet > Hikâyeler: dikey kaydırmalı ayet/hadis/dua/söz kartları; Paylaş, WhatsApp, İndir (Pictures/VakitPro).
- Kartlar `notif/CardArt.kt` ile çizilir; içerik `data/Inspire.kt` içinde.
