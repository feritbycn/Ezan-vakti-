# Uygulamaya ozel R8 kurallari.
# Manifest'te taninan bilesenler (Activity, Receiver, Service, Widget) R8 tarafindan otomatik korunur.
# Uygulama reflection kullanmiyor; ek kural gerekirse buraya eklenir.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
