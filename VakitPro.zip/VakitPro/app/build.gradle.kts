plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.vakitpro.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.nurvakit.ezanvakti"
        minSdk = 26
        targetSdk = 36
        versionCode = 11
        versionName = "1.8.0"
    }

    // Imza anahtari repoda DURMAZ. GitHub Secrets'tan ortam degiskeni olarak gelir (KS_FILE, KS_PASS, KS_ALIAS, KEY_PASS).
    // Degisken yoksa (ornegin yerel deneme) debug anahtariyla imzalanir; bu surum Play'e yuklenemez.
    val ksFile = System.getenv("KS_FILE")
    val hasRelease = !ksFile.isNullOrBlank() && file(ksFile).exists()
    signingConfigs {
        if (hasRelease) {
            create("vakit") {
                storeFile = file(ksFile!!)
                storePassword = System.getenv("KS_PASS")
                keyAlias = System.getenv("KS_ALIAS") ?: "nurvakit"
                keyPassword = System.getenv("KEY_PASS") ?: System.getenv("KS_PASS")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = if (hasRelease) signingConfigs.getByName("vakit") else signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")

    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // Google Play Billing (Pro abonelik)
    implementation("com.android.billingclient:billing-ktx:9.1.0")
    // Google Mobile Ads (AdMob)
    implementation("com.google.android.gms:play-services-ads:25.5.0")
}
