package com.vakitpro.app.notif

import android.app.NotificationManager
import android.content.Context
import android.media.AudioManager
import android.os.Build
import com.vakitpro.app.data.Prefs

/**
 * Vakit girince telefonu gecici olarak sessize / titresime alir, sure bitince eski moda dondurur.
 * Sessiz modu icin "Rahatsiz Etme" erisimi gerekir; erisim yoksa titresim moduna duser.
 */
object Silencer {
    private const val K_PREV = "sil_prev"       // eski zil modu
    private const val K_SET = "sil_set"         // bizim ayarladigimiz mod
    private const val K_UNTIL = "sil_until"     // geri alma zamani (epoch ms), 0 = yok

    fun hasPolicyAccess(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT < 23) return true
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        return nm.isNotificationPolicyAccessGranted
    }

    fun restoreAt(ctx: Context): Long = Prefs.getLong(ctx, K_UNTIL, 0L)

    /** [minutes] dakika boyunca sessize al. Basarili olursa true. */
    fun start(ctx: Context, minutes: Int, vibrateOnly: Boolean): Boolean {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val cur = am.ringerMode
        var target = if (vibrateOnly) AudioManager.RINGER_MODE_VIBRATE else AudioManager.RINGER_MODE_SILENT
        if (target == AudioManager.RINGER_MODE_SILENT && !hasPolicyAccess(ctx)) {
            target = AudioManager.RINGER_MODE_VIBRATE
        }
        // Zaten bizim yuzumuzden degistirilmisse eski modu ezme
        val pending = restoreAt(ctx) > 0L
        if (!pending) Prefs.putInt(ctx, K_PREV, cur)
        return try {
            am.ringerMode = target
            Prefs.putInt(ctx, K_SET, target)
            Prefs.putLong(ctx, K_UNTIL, System.currentTimeMillis() + minutes * 60_000L)
            true
        } catch (e: SecurityException) {
            try {
                am.ringerMode = AudioManager.RINGER_MODE_VIBRATE
                Prefs.putInt(ctx, K_SET, AudioManager.RINGER_MODE_VIBRATE)
                Prefs.putLong(ctx, K_UNTIL, System.currentTimeMillis() + minutes * 60_000L)
                true
            } catch (e2: Exception) {
                if (!pending) Prefs.putLong(ctx, K_UNTIL, 0L)
                false
            }
        } catch (e: Exception) {
            false
        }
    }

    /** Sure dolduysa (ya da zorla) eski zil moduna don. Kullanici arada kendi degistirdiyse dokunma. */
    fun restoreIfDue(ctx: Context, force: Boolean = false) {
        val until = restoreAt(ctx)
        if (until == 0L) return
        if (!force && System.currentTimeMillis() < until - 1000L) return
        try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val set = Prefs.getInt(ctx, K_SET, -1)
            val prev = Prefs.getInt(ctx, K_PREV, AudioManager.RINGER_MODE_NORMAL)
            if (am.ringerMode == set) am.ringerMode = prev
        } catch (e: Exception) {
        }
        Prefs.putLong(ctx, K_UNTIL, 0L)
    }
}
