package com.vakitpro.app.notif

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.vakitpro.app.data.Inspire
import java.io.File

/**
 * Bildirimdeki "Göster": gorseli tam ekran acar.
 * Gorsel ekrani kaplar, altta Paylas / WhatsApp / Indir duguleri ve Kapat yer alir.
 * Paylasilan dosya logolu, 2160x3840 gorseldir.
 */
class SharePopupActivity : Activity() {

    private var shareFile: File? = null   // 2160x3840, logolu, onceden yazilmis (paylas / indir)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val kind = intent.getIntExtra("kind", Inspire.AYET)
        val quote = intent.getStringExtra("text") ?: ""
        val source = intent.getStringExtra("source") ?: ""
        val item = Inspire(kind, quote, source)
        // Goster / Evet / Hayir: bildirim cubugundan kaldir
        val nid = intent.getIntExtra("nid", -1)
        if (nid >= 0) (getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager).cancel(nid)
        val dp = resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()

        val root = FrameLayout(this).apply { setBackgroundColor(Color.rgb(5, 9, 15)) }

        // Arka plan: gorsel tam ekran
        val img = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        root.addView(img, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // Alt bolge okunabilirlik icin karartma
        val shade = View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0x00040C14, 0xC7040C14.toInt())
            )
        }
        root.addView(shade, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, px(300), Gravity.BOTTOM))

        // Sag ust: kapat (X)
        val closeX = TextView(this).apply {
            text = "✕"
            setTextColor(Color.WHITE)
            textSize = 16f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0x33FFFFFF)
            }
            setOnClickListener { finish() }
        }
        root.addView(closeX, FrameLayout.LayoutParams(px(40), px(40), Gravity.TOP or Gravity.END).apply {
            setMargins(0, px(32), px(16), 0)
        })

        fun button(label: String, bg: Int, fg: Int, onClick: () -> Unit): Button = Button(this).apply {
            text = label
            setTextColor(fg)
            isAllCaps = false
            textSize = 15f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            stateListAnimator = null
            background = GradientDrawable().apply {
                setColor(bg)
                cornerRadius = px(20).toFloat()
            }
            setOnClickListener { onClick() }
        }
        fun lp() = LinearLayout.LayoutParams(0, px(56), 1f).apply {
            setMargins(px(4), 0, px(4), 0)
        }

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        row.addView(button("Paylaş", Color.rgb(46, 54, 68), Color.WHITE) { withFile { shareBitmap(it, false) } }, lp())
        row.addView(button("WhatsApp", Color.rgb(37, 211, 102), Color.rgb(6, 33, 15)) { withFile { shareBitmap(it, true) } }, lp())
        row.addView(button("İndir", Color.rgb(46, 54, 68), Color.WHITE) { withFile { saveFile(it) } }, lp())

        val close = button("Kapat", 0x1AFFFFFF, Color.rgb(243, 234, 211)) { finish() }
        close.background = GradientDrawable().apply {
            setColor(0x1AFFFFFF)
            cornerRadius = px(20).toFloat()
            setStroke(px(1), 0x33FFFFFF)
        }

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(16), px(16), px(16), px(16))
            addView(row)
            addView(close, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, px(48)).apply {
                setMargins(0, px(12), 0, 0)
            })
        }
        // Alt sistem cubugunun ustunde kalmasi icin ek bosluk
        ViewCompat.setOnApplyWindowInsetsListener(bottom) { v, insets ->
            val navBottom = insets.getInsets(WindowInsetsCompat.Type.systemBars()).bottom
            v.setPadding(px(16), px(16), px(16), px(16) + navBottom)
            insets
        }
        root.addView(bottom, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))

        setContentView(root)

        Thread {
            val preview = try { CardArt.story(item, 0, 1080, 1920, this, false) } catch (e: Exception) { null }
            var file: File? = null
            try {
                val full = CardArt.story(item, 0, 2160, 3840, this, true)
                val dir = File(cacheDir, "stories").apply { mkdirs() }
                val f = File(dir, "paylasim_hazir.jpg")
                f.outputStream().use { full.compress(Bitmap.CompressFormat.JPEG, 95, it) }
                full.recycle()
                file = f
            } catch (e: Exception) {
            }
            runOnUiThread {
                if (preview != null) img.setImageBitmap(preview)
                shareFile = file
            }
        }.start()
    }

    private fun withFile(action: (File) -> Unit) {
        val f = shareFile
        if (f == null) Toast.makeText(this, "Görsel hazırlanıyor", Toast.LENGTH_SHORT).show() else action(f)
    }

    private fun shareBitmap(f: File, whatsapp: Boolean) {
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.files", f)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "image/jpeg"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            Toast.makeText(this, "Ezan Vakti Plus ile paylaşıldı", Toast.LENGTH_SHORT).show()
            if (whatsapp) {
                send.setPackage("com.whatsapp")
                try {
                    startActivity(send)
                } catch (e: Exception) {
                    send.setPackage(null)
                    Toast.makeText(this, "WhatsApp bulunamadı, paylaşma menüsü açılıyor", Toast.LENGTH_SHORT).show()
                    startActivity(Intent.createChooser(send, "Paylaş"))
                }
            } else {
                startActivity(Intent.createChooser(send, "Paylaş"))
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Paylaşılamadı", Toast.LENGTH_SHORT).show()
        }
    }

    private fun saveFile(src: File) {
        Thread {
            val name = "VakitPro_${System.currentTimeMillis()}.jpg"
            val ok = try {
                if (Build.VERSION.SDK_INT >= 29) {
                    val cv = ContentValues().apply {
                        put(MediaStore.Images.Media.DISPLAY_NAME, name)
                        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                        put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/VakitPro")
                    }
                    val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
                    if (uri == null) false
                    else {
                        contentResolver.openOutputStream(uri)?.use { o -> src.inputStream().use { it.copyTo(o) } }
                        true
                    }
                } else {
                    @Suppress("DEPRECATION")
                    val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "VakitPro")
                    dir.mkdirs()
                    src.copyTo(File(dir, name), overwrite = true)
                    true
                }
            } catch (e: Exception) {
                false
            }
            runOnUiThread {
                Toast.makeText(this, if (ok) "Ezan Vakti Plus ile indirildi" else "Kaydedilemedi", Toast.LENGTH_SHORT).show()
            }
        }.start()
    }
}
