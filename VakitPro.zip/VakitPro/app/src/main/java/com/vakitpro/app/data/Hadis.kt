package com.vakitpro.app.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.io.File

class HadisItem(
    val id: Long,
    val bookId: Int,
    val number: String,
    val arabic: String,
    val turkish: String
) {
    /** Sadece sayi ise numara gosterilir. */
    val numberLabel: String get() = if (number.isNotEmpty() && number.all { it.isDigit() }) "No $number" else ""
}

class HadisBook(val id: Int, val name: String, val count: Int)

/** Hadis veritabani (assets/hadis.db) + kullanici durumu (okundu / favori). */
object Hadis {
    private var db: SQLiteDatabase? = null
    private var user: SQLiteDatabase? = null

    private class UserHelper(ctx: Context) : SQLiteOpenHelper(ctx.applicationContext, "hadis_user.db", null, 1) {
        override fun onCreate(d: SQLiteDatabase) {
            d.execSQL("CREATE TABLE st(id INTEGER PRIMARY KEY, book_id INTEGER, rd INTEGER DEFAULT 0, fav INTEGER DEFAULT 0)")
        }
        override fun onUpgrade(d: SQLiteDatabase, o: Int, n: Int) {}
    }

    @Synchronized
    private fun open(ctx: Context): SQLiteDatabase {
        db?.let { return it }
        val app = ctx.applicationContext
        val f = File(app.filesDir, "hadis.db")
        val sig = try {
            app.packageManager.getPackageInfo(app.packageName, 0).lastUpdateTime.toString()
        } catch (e: Exception) { "0" }
        if (!f.exists() || Prefs.getStr(app, "hadis_sig", "") != sig) {
            app.assets.open("hadis.db").use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            Prefs.putStr(app, "hadis_sig", sig)
        }
        val d = SQLiteDatabase.openDatabase(f.path, null, SQLiteDatabase.OPEN_READONLY)
        db = d
        return d
    }

    @Synchronized
    private fun usr(ctx: Context): SQLiteDatabase {
        user?.let { return it }
        val d = UserHelper(ctx).writableDatabase
        user = d
        return d
    }

    private fun map(c: android.database.Cursor): HadisItem =
        HadisItem(c.getLong(0), c.getInt(1), c.getString(2) ?: "", c.getString(3) ?: "", c.getString(4) ?: "")

    private const val COLS = "id, book_id, hadith_number, text_arabic, text_turkish"

    fun books(ctx: Context): List<HadisBook> {
        val out = ArrayList<HadisBook>()
        open(ctx).rawQuery(
            "SELECT b.id, COALESCE(b.name_turkish, b.name), (SELECT COUNT(*) FROM hadiths h WHERE h.book_id=b.id) FROM books b ORDER BY b.id", null
        ).use { c -> while (c.moveToNext()) out.add(HadisBook(c.getInt(0), c.getString(1), c.getInt(2))) }
        return out
    }

    fun list(ctx: Context, bookId: Int, offset: Int, limit: Int): List<HadisItem> {
        val out = ArrayList<HadisItem>()
        open(ctx).rawQuery(
            "SELECT $COLS FROM hadiths WHERE book_id=? ORDER BY id LIMIT ? OFFSET ?",
            arrayOf(bookId.toString(), limit.toString(), offset.toString())
        ).use { c -> while (c.moveToNext()) out.add(map(c)) }
        return out
    }

    fun search(ctx: Context, q: String, bookId: Int, limit: Int): List<HadisItem> {
        val out = ArrayList<HadisItem>()
        val like = "%" + q.trim() + "%"
        val sql = if (bookId > 0)
            "SELECT $COLS FROM hadiths WHERE book_id=? AND text_turkish LIKE ? ORDER BY id LIMIT ?"
        else "SELECT $COLS FROM hadiths WHERE ?>=0 AND text_turkish LIKE ? ORDER BY id LIMIT ?"
        open(ctx).rawQuery(sql, arrayOf(bookId.toString(), like, limit.toString()))
            .use { c -> while (c.moveToNext()) out.add(map(c)) }
        return out
    }

    fun byIds(ctx: Context, ids: List<Long>): List<HadisItem> {
        if (ids.isEmpty()) return emptyList()
        val out = ArrayList<HadisItem>()
        ids.chunked(500).forEach { part ->
            open(ctx).rawQuery(
                "SELECT $COLS FROM hadiths WHERE id IN (${part.joinToString(",")}) ORDER BY id", null
            ).use { c -> while (c.moveToNext()) out.add(map(c)) }
        }
        return out
    }

    fun daily(ctx: Context, dayEpoch: Long): HadisItem? {
        val d = open(ctx)
        val n = d.rawQuery("SELECT COUNT(*) FROM hadiths", null).use { if (it.moveToFirst()) it.getInt(0) else 0 }
        if (n == 0) return null
        val off = Math.floorMod(dayEpoch * 7919L, n.toLong()).toInt()
        d.rawQuery("SELECT $COLS FROM hadiths ORDER BY id LIMIT 1 OFFSET ?", arrayOf(off.toString()))
            .use { return if (it.moveToFirst()) map(it) else null }
    }

    fun bookName(ctx: Context, id: Int): String = books(ctx).firstOrNull { it.id == id }?.name ?: ""

    // ---------------- kullanici durumu
    fun readIds(ctx: Context): Set<Long> = ids(ctx, "rd")
    fun favIds(ctx: Context): Set<Long> = ids(ctx, "fav")

    private fun ids(ctx: Context, col: String): Set<Long> {
        val s = HashSet<Long>()
        usr(ctx).rawQuery("SELECT id FROM st WHERE $col=1", null).use { while (it.moveToNext()) s.add(it.getLong(0)) }
        return s
    }

    /** Her kitap icin okunan sayisi. */
    fun readCounts(ctx: Context): Map<Int, Int> {
        val m = HashMap<Int, Int>()
        usr(ctx).rawQuery("SELECT book_id, COUNT(*) FROM st WHERE rd=1 GROUP BY book_id", null)
            .use { while (it.moveToNext()) m[it.getInt(0)] = it.getInt(1) }
        return m
    }

    fun setFlag(ctx: Context, h: HadisItem, col: String, v: Boolean) {
        val d = usr(ctx)
        d.execSQL("INSERT OR IGNORE INTO st(id, book_id) VALUES(?, ?)", arrayOf(h.id, h.bookId))
        val cv = ContentValues().apply { put(col, if (v) 1 else 0) }
        d.update("st", cv, "id=?", arrayOf(h.id.toString()))
    }
}
