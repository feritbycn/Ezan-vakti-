package com.vakitpro.app.notif

import android.content.Context
import com.vakitpro.app.data.Prefs
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Alarm / bildirim olaylarini saklayan kucuk gunluk (son 60 satir). Tanilama raporunda kullanilir. */
object DebugLog {
    private const val KEY = "dbg_log"

    fun add(ctx: Context, msg: String) {
        try {
            synchronized(this) {
                val ts = SimpleDateFormat("dd.MM HH:mm:ss.SSS", Locale.US).format(Date())
                val lines = Prefs.getStr(ctx, KEY, "").split("\n").filter { it.isNotBlank() }.takeLast(59)
                Prefs.putStr(ctx, KEY, (lines + "$ts  $msg").joinToString("\n"))
            }
        } catch (e: Exception) {
        }
    }

    fun all(ctx: Context): String = Prefs.getStr(ctx, KEY, "")

    fun clear(ctx: Context) = Prefs.putStr(ctx, KEY, "")
}
