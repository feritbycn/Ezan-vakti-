@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.vakitpro.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.RadioButton
import androidx.compose.material3.TextButton
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vakitpro.app.data.Prefs
import com.vakitpro.app.data.Quran
import com.vakitpro.app.data.QuranAudio
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun QuranScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme

    var data by remember { mutableStateOf<Quran.Data?>(null) }
    var failed by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        val d = withContext(Dispatchers.IO) { runCatching { Quran.load(ctx) }.getOrNull() }
        if (d == null) failed = true else data = d
    }

    var surah by rememberSaveable { mutableIntStateOf(-1) }      // 0..113, -1 = liste
    var startVerse by rememberSaveable { mutableIntStateOf(0) }   // acilista kaydirilacak ayet (0 tabanli)
    var query by rememberSaveable { mutableStateOf("") }
    var showMeal by remember { mutableStateOf(Prefs.getInt(ctx, "q_meal", 1) == 1) }
    var size by remember { mutableIntStateOf(Prefs.getInt(ctx, "q_size", 28)) }
    var mark by remember { mutableStateOf(Prefs.getStr(ctx, "q_last", "")) }

    BackHandler(enabled = surah >= 0) { surah = -1 }

    var reciterDlg by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { QuranAudio.init(ctx) }
    DisposableEffect(Unit) { onDispose { QuranAudio.stop() } }
    LaunchedEffect(surah) { if (surah < 0 || (QuranAudio.surah >= 0 && QuranAudio.surah != surah)) QuranAudio.stop() }

    val markS = mark.substringBefore(":", "").toIntOrNull() ?: -1   // 1 tabanli
    val markV = mark.substringAfter(":", "").toIntOrNull() ?: -1

    val d = data
    if (d == null) {
        Column(Modifier.fillMaxSize()) {
            ScreenHeader("Kur'an-ı Kerim", null, onBack)
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    if (failed) "Kur'an metni yüklenemedi." else "Yükleniyor…",
                    color = cs.onSurfaceVariant
                )
            }
        }
        return
    }

    if (surah < 0) {
        // ------------------------------------------------ Sure listesi
        val q = Quran.fold(query.trim())
        val list = (0 until 114).filter {
            q.isEmpty() || Quran.fold(Quran.NAMES[it]).contains(q) || (it + 1).toString() == q
        }
        Column(Modifier.fillMaxSize()) {
            ScreenHeader("Kur'an-ı Kerim", "114 sure • Arapça metin ve Türkçe meal", onBack)
            Column(Modifier.padding(horizontal = 16.dp)) {
                if (markS in 1..114 && markV >= 1) {
                    ProCard(
                        onClick = {
                            startVerse = (markV - 1).coerceAtLeast(0)
                            surah = markS - 1
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        GlyphLabel(Glyph.BOOKMARK, "Kaldığın yerden devam et", cs.primary, 16.dp)
                        Text(
                            "${Quran.NAMES[markS - 1]} sûresi • $markV. ayet",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(Modifier.size(8.dp))
                }
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    placeholder = { Text("Sure ara (ör. Yasin, 36)") }
                )
                Spacer(Modifier.size(8.dp))
            }
            LazyColumn(Modifier.weight(1f)) {
                items(list) { i ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable {
                                startVerse = 0
                                surah = i
                            }
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(cs.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                (i + 1).toString(),
                                color = cs.onPrimaryContainer,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(Quran.NAMES[i], style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            Text(
                                "${Quran.COUNTS[i]} ayet",
                                style = MaterialTheme.typography.bodySmall,
                                color = cs.onSurfaceVariant
                            )
                        }
                        if (markS == i + 1) GlyphIcon(Glyph.BOOKMARK, cs.primary, 18.dp)
                    }
                    HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.4f), modifier = Modifier.padding(start = 70.dp))
                }
                item {
                    Text(
                        "Arapça metin: Tanzil Project (Osmani). Türkçe meal: Kuran Ansiklopedisi (quranenc.com) – Rowwad Çeviri Merkezi.",
                        modifier = Modifier.padding(16.dp),
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant
                    )
                }
            }
        }
        return
    }

    // ------------------------------------------------ Okuma ekrani
    val ar = d.ar[surah]
    val tr = d.tr[surah]
    val listState = rememberLazyListState()
    LaunchedEffect(surah, startVerse) {
        // 0. oge = besmele basligi, ayetler 1'den baslar
        listState.scrollToItem(if (startVerse > 0) startVerse + 1 else 0)
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(
            "${surah + 1}. ${Quran.NAMES[surah]}",
            "${Quran.COUNTS[surah]} ayet",
            onBack = { surah = -1 }
        )
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(onClick = {
                size = (size - 2).coerceAtLeast(18)
                Prefs.putInt(ctx, "q_size", size)
            }) { Text("A−") }
            OutlinedButton(onClick = {
                size = (size + 2).coerceAtMost(48)
                Prefs.putInt(ctx, "q_size", size)
            }) { Text("A+") }
            FilterChip(
                selected = showMeal,
                onClick = {
                    showMeal = !showMeal
                    Prefs.putInt(ctx, "q_meal", if (showMeal) 1 else 0)
                },
                label = { Text("Türkçe meal") }
            )
        }
        Spacer(Modifier.size(6.dp))
        val audioHere = QuranAudio.surah == surah
        LaunchedEffect(QuranAudio.verse, QuranAudio.surah) {
            if (QuranAudio.surah == surah && QuranAudio.playing) listState.animateScrollToItem(QuranAudio.verse)
        }
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            OutlinedButton(onClick = { reciterDlg = true }, modifier = Modifier.weight(1f)) {
                GlyphLabel(Glyph.MIC, QuranAudio.RECITERS[QuranAudio.reciter].name, size = 16.dp)
            }
            OutlinedButton(onClick = { if (audioHere) QuranAudio.prev() }, enabled = audioHere) { Text("⏮") }
            Button(onClick = {
                if (audioHere) QuranAudio.toggle()
                else QuranAudio.play(surah, if (markS == surah + 1 && markV > 0) markV else 1)
            }) {
                Text(
                    if (audioHere && QuranAudio.loading) "…"
                    else if (audioHere && QuranAudio.playing) "⏸" else "▶"
                )
            }
            OutlinedButton(onClick = { if (audioHere) QuranAudio.next() }, enabled = audioHere) { Text("⏭") }
        }
        if (audioHere && QuranAudio.error != null) {
            Text(
                QuranAudio.error ?: "",
                modifier = Modifier.padding(horizontal = 16.dp),
                color = cs.error,
                style = MaterialTheme.typography.bodySmall
            )
        }
        HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))

        if (reciterDlg) {
            AlertDialog(
                onDismissRequest = { reciterDlg = false },
                confirmButton = { TextButton(onClick = { reciterDlg = false }) { Text("Tamam") } },
                title = { Text("Okuyan hafız") },
                text = {
                    LazyColumn {
                        items(QuranAudio.RECITERS.size) { i ->
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .clickable { QuranAudio.setReciter(ctx, i) },
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(selected = QuranAudio.reciter == i, onClick = { QuranAudio.setReciter(ctx, i) })
                                Text(QuranAudio.RECITERS[i].name)
                            }
                        }
                    }
                }
            )
        }

        LazyColumn(Modifier.weight(1f), state = listState) {
            item {
                if (surah != 0 && surah != 8) {
                    Text(
                        Quran.BASMALA,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 20.dp, horizontal = 16.dp),
                        textAlign = TextAlign.Center,
                        fontSize = (size + 2).sp,
                        color = cs.primary,
                        fontWeight = FontWeight.Bold
                    )
                } else {
                    Spacer(Modifier.size(8.dp))
                }
            }
            items(ar.size) { vi ->
                val marked = markS == surah + 1 && markV == vi + 1
                Column(
                    Modifier
                        .fillMaxWidth()
                        .background(
                            if (QuranAudio.surah == surah && QuranAudio.verse == vi + 1 && QuranAudio.playing) cs.tertiaryContainer.copy(alpha = 0.55f)
                            else if (marked) cs.primaryContainer.copy(alpha = 0.35f) else Color.Transparent
                        )
                        .clickable {
                            mark = "${surah + 1}:${vi + 1}"
                            Prefs.putStr(ctx, "q_last", mark)
                            if (QuranAudio.surah == surah && (QuranAudio.playing || QuranAudio.loading)) QuranAudio.play(surah, vi + 1)
                        }
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Pill("${surah + 1}:${vi + 1}")
                        if (marked) {
                            Spacer(Modifier.width(10.dp))
                            GlyphIcon(Glyph.BOOKMARK, cs.primary, 14.dp)
                            Spacer(Modifier.width(4.dp))
                            Text("Kaldığın yer", style = MaterialTheme.typography.labelMedium, color = cs.primary)
                        }
                    }
                    Spacer(Modifier.size(10.dp))
                    Text(
                        ar[vi] + " ﴿" + Quran.arabicNum(vi + 1) + "﴾",
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Right,
                        fontSize = size.sp,
                        lineHeight = (size * 1.9f).sp
                    )
                    if (showMeal) {
                        Spacer(Modifier.size(8.dp))
                        Text(
                            tr[vi],
                            fontSize = (size * 0.55f).coerceAtLeast(14f).sp,
                            lineHeight = (size * 0.8f).coerceAtLeast(20f).sp,
                            color = cs.onSurfaceVariant
                        )
                    }
                }
                HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.4f))
            }
            item {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (surah > 0) {
                        OutlinedButton(
                            onClick = {
                                startVerse = 0
                                surah -= 1
                            },
                            modifier = Modifier.weight(1f)
                        ) { Text("◀ ${Quran.NAMES[surah - 1]}") }
                    }
                    if (surah < 113) {
                        Button(
                            onClick = {
                                startVerse = 0
                                surah += 1
                            },
                            modifier = Modifier.weight(1f)
                        ) { Text("${Quran.NAMES[surah + 1]} ▶") }
                    }
                }
            }
        }
    }
}
