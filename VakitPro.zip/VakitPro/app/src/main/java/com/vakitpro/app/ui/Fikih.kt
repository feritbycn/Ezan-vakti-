package com.vakitpro.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private class Sec(val title: String, val intro: String, val items: List<String>, val source: String)

private val SECS = listOf(
    Sec(
        "32 Farz", "Hanefî ilmihallerinde “32 farz” şöyle sayılır: İman 6 + İslam 5 + Abdest 4 + Gusül 3 + Teyemmüm 2 + Namaz 12.",
        listOf(
            "İmanın 6 şartı: Allah'a, meleklerine, kitaplarına, peygamberlerine, ahiret gününe, kadere (hayrın ve şerrin Allah'tan olduğuna) inanmak.",
            "İslam'ın 5 şartı: Kelime-i şehâdet, namaz, oruç, zekât, hac.",
            "Abdestin 4 farzı: Yüzü yıkamak, kolları dirseklerle yıkamak, başın dörtte birini mesh etmek, ayakları topuklarla yıkamak.",
            "Gusülün 3 farzı: Ağıza su vermek, burna su vermek, bütün bedeni yıkamak.",
            "Teyemmümün 2 farzı: Niyet etmek, ellerle toprağa iki kez vurup yüzü ve kolları mesh etmek.",
            "Namazın 12 farzı: 7'si dışında (hadesten ve necasetten temizlik, setr-i avret, kıbleye dönmek, vakit, niyet, iftitah tekbiri), 5'i içinde (kıyam, kıraat, rükû, secde, son oturuş)."
        ),
        "Kaynak: Mâide 5/6 (abdest, gusül, teyemmüm); Nisâ 4/43; Bakara 2/43, 183, 196; Hac 22/77 (rükû ve secde); Müzzemmil 73/20 (kıraat); Buhârî, Îmân 37 (İslam'ın şartları)."
    ),
    Sec(
        "Sünnet namazlar", "Müekked: Peygamberimizin devamlı kıldığı, terk edilmemesi gereken sünnetler. Gayr-i müekked: bazen kıldığı, kılana sevap, kılmayana günah olmayan sünnetler.",
        listOf(
            "Sabah: Farzdan önce 2 rekât, müekked. En kuvvetli sünnettir; “dünya ve içindekilerden hayırlıdır” buyrulmuştur.",
            "Öğle: İlk sünnet 4 rekât (müekked), farzdan sonra 2 rekât son sünnet (müekked).",
            "İkindi: Farzdan önce 4 rekât, gayr-i müekked.",
            "Akşam: Farzdan sonra 2 rekât, müekked.",
            "Yatsı: Farzdan önce 4 rekât (gayr-i müekked), sonra 2 rekât son sünnet (müekked), ardından vitir 3 rekât (Hanefîde vâcip).",
            "Cuma: Farzdan önce 4, sonra 4 + 2 rekât sünnet kılınır.",
            "Teravih: Ramazan gecelerinde yatsıdan sonra 20 rekât, müekked sünnet.",
            "Nâfile (müstehap) namazlar: Teheccüd, kuşluk (duha, 2-8 rekât), evvâbin (akşamdan sonra 6 rekât), tahiyyetü'l-mescid (2 rekât), işrak, tövbe ve hâcet namazları."
        ),
        "Kaynak: Müslim, Salâtü'l-müsâfirîn (günde 12 rekât sünnet hadisi ve sabah sünneti hadisi); Tirmizî, Salât; Ebû Dâvûd, Salât ve Vitir; Buhârî, Teheccüd. Rekât sayıları Hanefî ilmihallerine göredir."
    ),
    Sec(
        "Abdestin farzları, sünnetleri, müstehapları", "Abdest namazın şartıdır.",
        listOf(
            "Farzlar (4): Yüz, kollar (dirsekler dahil), başın en az dörtte biri, ayaklar (topuklar dahil).",
            "Sünnetler: Niyet ve besmele, elleri bileğe kadar yıkamak, misvak, ağıza ve burna su vermek, sakal ve parmak aralarını hilâllemek, başın tamamını bir kez mesh, kulakları mesh, sıra gözetmek, organları peş peşe yıkamak, üçer kez yıkamak.",
            "Müstehaplar: Kıbleye dönüp yüksekçe yerde oturmak, sağdan başlamak, abdest sonrası şehâdet duası ve iki rekât namaz.",
            "Abdesti bozanlar: Ön ve arkadan bir şey çıkması, ağız dolusu kusmak, akan kan ve irin, uykuya dalmak, bayılmak, namazda kahkaha ile gülmek."
        ),
        "Kaynak: Mâide 5/6; Buhârî, Vudû (Hz. Osman'ın abdest tarifi); Müslim, Tahâret; Buhârî, Cum'a (“misvak olmasa” hadisi); Ebû Dâvûd, Tahâret."
    ),
    Sec(
        "Gusül (boy abdesti) nasıl alınır", "Cünüplük, hayız ve nifas hâllerinde gusül gerekir.",
        listOf(
            "Gerektiren haller: Cünüplük (şehvetle meninin gelmesi veya cinsel ilişki), hayız (âdet) ve nifas (lohusalık) bitişi.",
            "Farzlar (3): Ağıza su vermek, burna su vermek, bütün bedeni kuru yer kalmayacak şekilde yıkamak.",
            "Sünnetler: Niyet ve besmele, elleri ve avret yerini yıkamak, bedeni pislikten temizlemek, namaz abdesti almak, sırasıyla başa, sağ omuza, sol omuza üçer kez su dökmek, bedeni ovmak.",
            "Nasıl alınır: 1) Niyet edip besmele çek, elleri bileğe kadar yıka. 2) Avret yerini ve bedendeki kirleri yıka. 3) Ayakları hariç tam bir namaz abdesti al. 4) Önce başa, sonra sağ omuza, sonra sol omuza üçer kez su dök, bedenin her yerine ulaştır. 5) Ayakları yıka, gerekirse yer değiştirip yıka.",
            "Dikkat: Göbek çukuru, kulak delikleri, tırnak altı ve saç diplerine su ulaşmalı; su geçirmeyen oje vb. kaldırılmalıdır."
        ),
        "Kaynak: Mâide 5/6; Nisâ 4/43; Buhârî, Gusül (Hz. Âişe ve Meymûne'den Peygamberimizin gusül tarifi); Müslim, Hayız."
    ),
    Sec(
        "Teyemmüm", "Su bulunmadığında veya kullanılamadığında abdest ve gusül yerine geçer.",
        listOf(
            "Gerektiren durumlar: Su bulunamaması (yaklaşık 1 mil uzak), hastalık, aşırı soğuk veya susuzluk korkusu.",
            "Farzlar (2): Niyet; temiz toprak türü bir yere iki kez eller vurup birincisiyle yüzü, ikincisiyle kolları dirseklerle mesh etmek.",
            "Sünnetler: Besmele, elleri vurunca silkelemek, parmakları aralamak, sıra ve peş peşe yapmak."
        ),
        "Kaynak: Mâide 5/6; Nisâ 4/43; Buhârî, Teyemmüm (Ammar hadisi)."
    ),
    Sec(
        "Namazın vâcipleri ve bozanlar", "Hanefî fıkhına göre.",
        listOf(
            "Vâcipler: Fâtiha okumak, Fâtiha'dan sonra bir sure veya üç kısa ayet, vitir namazı, ta'dil-i erkân (rükû ve secdede sükûnet), ilk oturuş ve tahiyyat, kunut duası, bayram tekbirleri, imamın yüksek sesle okuması gereken yerler, selam vermek.",
            "Namazı bozanlar: Konuşmak, yemek-içmek, kıbleden dönmek, abdestin bozulması, ameli kesir (çok hareket), kahkaha, avret yerinin açılması, farzlardan birini terk etmek.",
            "Sehiv secdesi: Vâcip unutulursa namazın sonunda iki sehiv secdesi yapılır."
        ),
        "Kaynak: Buhârî, Ezân (“namazı benim kıldığım gibi kılın” ve müsîe's-salât hadisi); Müslim, Salât; Ebû Dâvûd, Salât."
    )
)

@Composable
fun FikihScreen(onBack: () -> Unit) {
    var open by remember { mutableStateOf(0) }
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenHeader("Sünnet ve fıkıh", "32 farz, sünnetler, abdest, gusül", onBack)
        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SECS.forEachIndexed { i, sec ->
                ProCard(onClick = { open = if (open == i) -1 else i }) {
                    Text(sec.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    if (open == i) {
                        Spacer(Modifier.size(6.dp))
                        Text(sec.intro, color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
                        sec.items.forEach {
                            Spacer(Modifier.size(8.dp))
                            Text(it, style = MaterialTheme.typography.bodyMedium)
                        }
                        Spacer(Modifier.size(10.dp))
                        Text(sec.source, color = cs.primary, style = MaterialTheme.typography.bodySmall)
                    } else {
                        Text(sec.intro, color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodySmall, maxLines = 2)
                    }
                }
            }
            Text(
                "Bilgiler Hanefî mezhebi ilmihallerine göredir. Hadis kaynakları kitap/bölüm olarak verilmiştir; ayrıntı için güvenilir bir ilmihale veya Diyanet'e danış.",
                style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant
            )
        }
        Spacer(Modifier.size(24.dp))
    }
}
