package com.vakitpro.app.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.android.billingclient.api.AcknowledgePurchaseParams
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingClientStateListener
import com.android.billingclient.api.BillingFlowParams
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.PendingPurchasesParams
import com.android.billingclient.api.ProductDetails
import com.android.billingclient.api.Purchase
import com.android.billingclient.api.QueryProductDetailsParams
import com.android.billingclient.api.QueryPurchasesParams
import com.android.billingclient.api.acknowledgePurchase
import com.android.billingclient.api.queryProductDetails
import com.android.billingclient.api.queryPurchasesAsync
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Google Play Billing: Pro abonelik satin alma, fiyat okuma, geri yukleme.
 * Pro'nun gercek durumu Play'den gelir; yerel "pro" bayragi sadece onbellektir.
 * Urun kimlikleri Play Console'da ayni isimlerle olusturulmali (abonelik olarak).
 */
object Billing {
    const val MONTHLY = "pro_monthly"
    const val YEARLY = "pro_yearly"
    private val IDS = listOf(MONTHLY, YEARLY)

    var details by mutableStateOf<Map<String, ProductDetails>>(emptyMap())
    var busy by mutableStateOf(false)
    var message by mutableStateOf<String?>(null)

    private var client: BillingClient? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private fun ensure(ctx: Context): BillingClient {
        client?.let { return it }
        val app = ctx.applicationContext
        val c = BillingClient.newBuilder(app)
            .setListener { result, purchases -> onUpdate(app, result, purchases) }
            .enablePendingPurchases(
                PendingPurchasesParams.newBuilder().enableOneTimeProducts().build()
            )
            .build()
        client = c
        return c
    }

    private fun connect(ctx: Context, then: (BillingClient) -> Unit) {
        val c = ensure(ctx)
        if (c.isReady) {
            then(c)
            return
        }
        c.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(result: BillingResult) {
                if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                    then(c)
                } else {
                    message = "Google Play bağlantısı kurulamadı."
                }
            }

            override fun onBillingServiceDisconnected() {
                // Bir sonraki cagrida yeniden baglanilir.
            }
        })
    }

    /** Fiyatlari Play'den ceker. */
    fun loadProducts(ctx: Context) {
        connect(ctx) { c ->
            scope.launch {
                val products = IDS.map {
                    QueryProductDetailsParams.Product.newBuilder()
                        .setProductId(it)
                        .setProductType(BillingClient.ProductType.SUBS)
                        .build()
                }
                val params = QueryProductDetailsParams.newBuilder().setProductList(products).build()
                val result = c.queryProductDetails(params)
                if (result.billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                    details = result.productDetailsList.associateBy { it.productId }
                }
            }
        }
    }

    /** Play'deki aktif abonelikleri okur, Pro durumunu buna gore gunceller. */
    fun refresh(ctx: Context) {
        connect(ctx) { c ->
            scope.launch {
                val params = QueryPurchasesParams.newBuilder()
                    .setProductType(BillingClient.ProductType.SUBS)
                    .build()
                val result = c.queryPurchasesAsync(params)
                if (result.billingResult.responseCode != BillingClient.BillingResponseCode.OK) return@launch
                val purchases = result.purchasesList
                purchases.filter { it.purchaseState == Purchase.PurchaseState.PURCHASED && !it.isAcknowledged }
                    .forEach { acknowledge(c, it) }
                val active = purchases.any {
                    it.purchaseState == Purchase.PurchaseState.PURCHASED && it.products.any { id -> id in IDS }
                }
                if (active != Pro.unlocked) Pro.setUnlocked(ctx.applicationContext, active)
            }
        }
    }

    fun buy(activity: Activity, productId: String) {
        val d = details[productId]
        val offer = d?.subscriptionOfferDetails?.firstOrNull()
        if (d == null || offer == null) {
            message = "Ürün bilgisi alınamadı, lütfen tekrar dene."
            loadProducts(activity)
            return
        }
        busy = true
        message = null
        connect(activity) { c ->
            val detailsParams = BillingFlowParams.ProductDetailsParams.newBuilder()
                .setProductDetails(d)
                .setOfferToken(offer.offerToken)
                .build()
            val params = BillingFlowParams.newBuilder()
                .setProductDetailsParamsList(listOf(detailsParams))
                .build()
            val result = c.launchBillingFlow(activity, params)
            if (result.responseCode != BillingClient.BillingResponseCode.OK) {
                busy = false
                message = "Satın alma başlatılamadı."
            }
        }
    }

    /** Ekranda gosterilecek fiyat metni (Play'den). Bilinmiyorsa null. */
    fun priceOf(productId: String): String? =
        details[productId]?.subscriptionOfferDetails?.firstOrNull()
            ?.pricingPhases?.pricingPhaseList?.firstOrNull()?.formattedPrice

    private fun onUpdate(ctx: Context, result: BillingResult, purchases: List<Purchase>?) {
        busy = false
        when (result.responseCode) {
            BillingClient.BillingResponseCode.OK -> {
                val c = client ?: return
                purchases?.forEach { p ->
                    if (p.purchaseState == Purchase.PurchaseState.PURCHASED) {
                        if (!p.isAcknowledged) acknowledge(c, p)
                        Pro.setUnlocked(ctx, true)
                        message = "Pro aktif edildi, teşekkürler!"
                    }
                }
            }
            BillingClient.BillingResponseCode.USER_CANCELED -> Unit
            else -> message = "Satın alma tamamlanamadı."
        }
    }

    private fun acknowledge(c: BillingClient, p: Purchase) {
        val params = AcknowledgePurchaseParams.newBuilder()
            .setPurchaseToken(p.purchaseToken)
            .build()
        scope.launch { c.acknowledgePurchase(params) }
    }
}

/** Compose baglamindan Activity'yi bulur (satin alma ekranini acmak icin gerekli). */
fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}
