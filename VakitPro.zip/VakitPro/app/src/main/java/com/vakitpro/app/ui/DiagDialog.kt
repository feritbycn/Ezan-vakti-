@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.vakitpro.app.ui

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.PowerManager
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.app.NotificationManagerCompat
import com.vakitpro.app.LocalHolder
import com.vakitpro.app.data.Prefs
import com.vakitpro.app.notif.AlarmScheduler
import com.vakitpro.app.notif.Notifier
import com.vakitpro.app.notif.TickLog
import kotlinx.coroutines.delay

/** Durum cubugu dakika ikonunun neden geride kaldigini bulmak icin tani ekrani. */
@Composable
fun DiagDialog(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val holder = LocalHolder.current
    val s = holder.s
    val cs = MaterialTheme.colorScheme

    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var logVer by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            logVer = now
            delay(1000L)
        }
    }

    val expected = Notifier.expectedIconMin(ctx, s, now)
    val shown = Prefs.getInt(ctx, "diag_icon_min", -2)
    val shownAt = Prefs.getLong(ctx, "diag_icon_at", 0L)
    val (rem, testing) = Notifier.remainInfo(ctx, s, now)
    val remTxt = "${rem / 60000}:${"%02d".format((rem / 1000) % 60)}"

    val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
    val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    val battOk = pm.isIgnoringBatteryOptimizations(ctx.packageName)
    val exact = AlarmScheduler.canExact(ctx)
    val notifOn = NotificationManagerCompat.from(ctx).areNotificationsEnabled()
    val importance = nm.getNotificationChannel(Notifier.CH_ONGOING)?.importance ?: -1

    val promoAllowed = remember(now / 5000) {
        try {
            val r = nm.javaClass.getMethod("canPostPromotedNotifications").invoke(nm)
            if (r == true) "evet" else "HAYIR"
        } catch (e: Exception) {
            "bilinmiyor"
        }
    }
    val promoted = remember(now / 5000) {
        try {
            val sbn = nm.activeNotifications.firstOrNull { it.id == Notifier.ONGOING_ID }
            if (sbn == null) "bildirim yok"
            else {
                val f = sbn.notification.flags
                (if ((f and 0x00040000) != 0) "EVET" else "hayır") + " (bayrak=0x" + Integer.toHexString(f) + ")"
            }
        } catch (e: Exception) {
            "bilinmiyor"
        }
    }

    val ok = shown == expected && shown != -2
    val verdict = when {
        shown == -2 -> "Henüz ikon çizilmedi. Önce testi başlat."
        ok -> "✅ İkon sayaçla eşit (${if (expected < 0) "hilal" else "$expected dk"})"
        else -> "⚠️ İkon ${if (shown < 0) "hilal" else "$shown dk"}, olması gereken ${if (expected < 0) "hilal" else "$expected dk"} " +
            "— son çizim ${(now - shownAt) / 1000} sn önce"
    }

    val info = listOf(
        "Cihaz: ${Build.MANUFACTURER} ${Build.MODEL} • Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
        "Tam zamanlı alarm izni: ${if (exact) "VAR" else "YOK  (alarmlar gecikebilir)"}",
        "Pil optimizasyonu kapalı: ${if (battOk) "EVET" else "HAYIR  (sistem uygulamayı uyutabilir)"}",
        "Bildirimler açık: ${if (notifOn) "evet" else "HAYIR"}",
        "Kalıcı bildirim kanalı önemi: $importance  (3 = normal, 2 = düşük)",
        "Kalıcı bildirim ayarı: ${if (s.ongoing) "açık" else "KAPALI"}  •  Durum çubuğu dakikası: ${if (s.statusMinutes) "açık" else "KAPALI"}",
        "Hassas dakika modu: ${if (s.preciseTick) "AÇIK" else "kapalı"}",
        "Canlı güncelleme ayarı: ${if (s.liveUpdate) "AÇIK" else "kapalı"}  •  Canlı güncelleme izni: $promoAllowed  •  Sistem yükseltti: $promoted",
        "Test modu: ${if (testing) "AKTİF" else "pasif"}  •  Sayaç: $remTxt"
    )
    val logs = TickLog.read(ctx).asReversed()

    fun report(): String {
        val sb = StringBuilder()
        sb.append("Vakit Pro tanı raporu\n").append(verdict).append("\n\n")
        info.forEach { sb.append(it).append("\n") }
        sb.append("\nGünlük (yeni -> eski):\n")
        logs.take(80).forEach { sb.append(it).append("\n") }
        return sb.toString()
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = cs.background) {
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("←", Modifier.clickable { onDismiss() }.padding(end = 14.dp), style = MaterialTheme.typography.titleLarge)
                        Column {
                            Text("Dakika ikonu tanı testi", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Text("İkon sayaçtan geri kalıyor mu, neden?", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                        }
                    }
                }
                item {
                    ProCard {
                        Text(verdict, fontWeight = FontWeight.Bold, color = if (ok) cs.primary else cs.error)
                        Spacer(Modifier.size(8.dp))
                        info.forEach {
                            Text(it, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                            Spacer(Modifier.size(3.dp))
                        }
                    }
                }
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                Prefs.putLong(ctx, "test_start", System.currentTimeMillis())
                                TickLog.add(ctx, "TEST başlatıldı (60 dk)")
                                holder.update { it.copy(testMinutes = true, ongoing = true, statusMinutes = true) }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("▶  60 dk testini başlat") }
                        OutlinedButton(
                            onClick = {
                                TickLog.source = "elle"
                                Notifier.updateOngoing(ctx)
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("🔄  Bildirimi şimdi yenile") }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = {
                                    val i = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(Intent.EXTRA_TEXT, report())
                                    }
                                    ctx.startActivity(Intent.createChooser(i, "Raporu paylaş").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                                },
                                modifier = Modifier.weight(1f)
                            ) { Text("📤 Raporu paylaş") }
                            OutlinedButton(
                                onClick = { TickLog.clear(ctx) },
                                modifier = Modifier.weight(1f)
                            ) { Text("🗑 Temizle") }
                        }
                    }
                }
                item {
                    Text(
                        "Olay günlüğü (en yeni üstte)  [$logVer]".substringBefore("  ["),
                        style = MaterialTheme.typography.labelLarge,
                        color = cs.primary
                    )
                }
                items(logs) { line ->
                    Text(line, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = cs.onSurface)
                }
            }
        }
    }
}
