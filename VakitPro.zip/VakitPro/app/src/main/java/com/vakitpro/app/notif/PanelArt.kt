package com.vakitpro.app.notif

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.vakitpro.app.R
import com.vakitpro.app.data.Inspire

/** Hazir cerceveli (mihrap panelli) arka planlarin icine ortali yazi. Koordinatlar kaynak resim pikselidir. */
object PanelArt {
    fun res(kind: Int): Int = when (kind) {
        Inspire.AYET -> R.drawable.panel_ayet
        Inspire.HADIS -> R.drawable.panel_hadis
        Inspire.DUA -> R.drawable.panel_dua
        else -> R.drawable.panel_soz
    }

    fun size(ctx: Context, resId: Int): Pair<Int, Int> {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeResource(ctx.resources, resId, o)
        return Pair(o.outWidth, o.outHeight)
    }

    fun draw(ctx: Context, c: Canvas, w: Int, h: Int, resId: Int, arabic: String?, text: String, source: String, sign: Boolean) {
        val (bw, bh) = size(ctx, resId)
        var sample = 1
        while (bw / (sample * 2) >= w && bh / (sample * 2) >= h) sample *= 2
        val src = BitmapFactory.decodeResource(ctx.resources, resId, BitmapFactory.Options().apply { inSampleSize = sample })
        val sc = maxOf(w / src.width.toFloat(), h / src.height.toFloat())
        val s = sc * src.width / 1080f
        val ox = (w - src.width * sc) / 2f
        val oy = (h - src.height * sc) / 2f
        c.drawBitmap(src, null, RectF(ox, oy, ox + src.width * sc, oy + src.height * sc), Paint(Paint.FILTER_BITMAP_FLAG))

        val gold = Color.rgb(236, 200, 120)
        val white = Color.rgb(250, 247, 238)
        val latin = try { Typeface.createFromAsset(ctx.assets, "fonts/nv_amaranth_bold.ttf") } catch (e: Exception) { Typeface.SERIF }
        val arab = try { Typeface.createFromAsset(ctx.assets, "fonts/amiri_regular.ttf") } catch (e: Exception) { Typeface.DEFAULT }
        fun tp(size: Float, color: Int, face: Typeface = latin) = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size; this.color = color; typeface = face
        }
        val tw = (740 * s).toInt()
        val left = ox + (557 - 370) * s
        val top = oy + 895 * s
        val maxH = 425 * s
        fun lay(t: CharSequence, p: TextPaint, sp: Float, maxLines: Int = Int.MAX_VALUE) =
            StaticLayout.Builder.obtain(t, 0, t.length, p, tw)
                .setAlignment(Layout.Alignment.ALIGN_CENTER).setLineSpacing(0f, sp)
                .setMaxLines(maxLines).setEllipsize(android.text.TextUtils.TruncateAt.END).build()

        val body = "“" + text.trim().replace(Regex("\\s*\n+\\s*"), " ") + "”"
        val srcTxt = if (source.isNotBlank()) "— $source" else ""
        val gap = 22f * s
        var k = 1f
        var al: StaticLayout?; var bl: StaticLayout; var sl: StaticLayout?
        while (true) {
            al = arabic?.takeIf { it.isNotBlank() }?.replace(Regex("\\s*\n+\\s*"), " ")?.let { lay(it, tp(50f * s * k, white, arab), 1.35f) }
            bl = lay(body, tp(54f * s * k, white), 1.18f)
            sl = if (srcTxt.isNotEmpty()) lay(srcTxt, tp(40f * s * k, gold), 1.0f) else null
            val tot = (al?.let { it.height + gap } ?: 0f) + bl.height + (sl?.let { gap + it.height } ?: 0f)
            if (tot <= maxH || k <= 0.35f) break
            k -= 0.04f
        }
        val used = (al?.let { it.height + gap } ?: 0f) + (sl?.let { gap + it.height } ?: 0f)
        if (bl.height + used > maxH) {
            val lh = bl.height / bl.lineCount.toFloat()
            bl = lay(body, tp(54f * s * k, white), 1.18f, maxOf(2, ((maxH - used) / lh).toInt()))
        }
        val tot = (al?.let { it.height + gap } ?: 0f) + bl.height + (sl?.let { gap + it.height } ?: 0f)
        var y = top + (maxH - tot) / 2f
        fun put(l: StaticLayout, g: Float) { c.save(); c.translate(left, y); l.draw(c); c.restore(); y += l.height + g }
        al?.let { put(it, gap) }
        put(bl, gap)
        sl?.let { put(it, 0f) }

        if (sign) {
            val label = "Ezan Vakti \u2013 NurVakit ile paylaşıldı"
            val f = tp(30f * s, Color.argb(215, 250, 247, 238), Typeface.create("sans-serif", Typeface.NORMAL))
            f.textAlign = Paint.Align.CENTER
            val ls = 100f * s
            val cx = ox + 557 * s
            val ly = oy + 1335 * s
            try {
                val logo = BitmapFactory.decodeResource(ctx.resources, R.drawable.ic_launcher_logo)
                val r = RectF(cx - ls / 2f, ly, cx + ls / 2f, ly + ls)
                val clip = android.graphics.Path().apply { addRoundRect(r, ls * 0.22f, ls * 0.22f, android.graphics.Path.Direction.CW) }
                c.save(); c.clipPath(clip)
                c.drawBitmap(logo, null, r, Paint(Paint.FILTER_BITMAP_FLAG))
                c.restore()
            } catch (e: Exception) {
            }
            c.drawText(label, cx, ly + ls + 6f * s + f.textSize * 0.85f, f)
        }
    }
}
