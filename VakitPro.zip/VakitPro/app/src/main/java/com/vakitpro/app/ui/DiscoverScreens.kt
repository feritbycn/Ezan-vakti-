@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.vakitpro.app.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vakitpro.app.data.DuaData
import com.vakitpro.app.data.EsmaData
import com.vakitpro.app.data.EventKind
import com.vakitpro.app.data.Fmt
import com.vakitpro.app.data.PrayerRepo
import com.vakitpro.app.data.ReligiousDays
import com.vakitpro.app.data.Settings
import java.time.temporal.ChronoUnit

@Composable
fun DiscoverScreen(s: Settings, onOpen: (String) -> Unit) {
    val ctx = LocalContext.current
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        ScreenHeader("Keşfet", "İbadet ve bilgi araçları")
        Column(
            Modifier.padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                DiscoverTile("💠", "Esmâü'l-Hüsnâ", "99 isim ve anlamları", Modifier.weight(1f)) { onOpen("esma") }
                DiscoverTile("🌙", "Dini günler", "Kandil ve bayramlar", Modifier.weight(1f)) { onOpen("days") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                DiscoverTile("🗓️", "Aylık vakitler", "İmsakiye tablosu", Modifier.weight(1f)) { onOpen("monthly") }
                DiscoverTile("✅", "Namaz takibi", "Seri ve haftalık grafik", Modifier.weight(1f)) { onOpen("tracker") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                DiscoverTile("🧮", "Zekât hesabı", "Nisab ve %2,5", Modifier.weight(1f)) { onOpen("zakat") }
                DiscoverTile("🤲", "Sure ve dualar", "Arapça, okunuş, anlam", Modifier.weight(1f)) { onOpen("duas") }
            }
            DiscoverTile("📍", "Yakındaki camiler", "Haritada aç", Modifier.fillMaxWidth()) {
                val geo = Uri.parse("geo:${s.lat},${s.lng}?q=" + Uri.encode("cami"))
                val i = Intent(Intent.ACTION_VIEW, geo).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try {
                    ctx.startActivity(i)
                } catch (e: Exception) {
                    val web = Uri.parse("https://www.google.com/maps/search/cami/@${s.lat},${s.lng},14z")
                    try {
                        ctx.startActivity(Intent(Intent.ACTION_VIEW, web).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (e2: Exception) {
                    }
                }
            }
        }
        Spacer(Modifier.size(24.dp))
    }
}

@Composable
private fun DiscoverTile(
    emoji: String,
    title: String,
    sub: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    ProCard(modifier = modifier, onClick = onClick) {
        Text(emoji, fontSize = 30.sp)
        Spacer(Modifier.size(8.dp))
        Text(title, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleSmall)
        Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

// ---------------------------------------------------------------- Esma
@Composable
fun EsmaScreen(onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var query by rememberSaveable { mutableStateOf("") }
    var openNo by rememberSaveable { mutableStateOf(-1) }
    val list = remember(query) {
        val q = query.trim().lowercase()
        if (q.isEmpty()) EsmaData.ALL
        else EsmaData.ALL.filter {
            it.name.lowercase().contains(q) || it.meaning.lowercase().contains(q) || it.no.toString() == q
        }
    }
    val dayIdx = remember { (java.time.LocalDate.now().dayOfYear - 1) % 99 }
    val today = EsmaData.ALL[dayIdx]

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Esmâü'l-Hüsnâ", "Allah'ın 99 güzel ismi", onBack)
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            singleLine = true,
            placeholder = { Text("İsim, anlam veya numara ara") },
            shape = RoundedCornerShape(16.dp)
        )
        LazyColumn(
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (query.isBlank()) {
                item {
                    ProCard {
                        Text("Günün esması", style = MaterialTheme.typography.labelLarge, color = cs.primary)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(today.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                Text(today.meaning, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
                            }
                            Text(today.arabic, fontSize = 34.sp, color = Gold, textAlign = TextAlign.End)
                        }
                    }
                }
            }
            items(list, key = { it.no }) { e ->
                val open = openNo == e.no
                ProCard(onClick = { openNo = if (open) -1 else e.no }, corner = 18.dp) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Pill(e.no.toString())
                        Spacer(Modifier.width(12.dp))
                        Text(
                            e.name,
                            Modifier.weight(1f),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(e.arabic, fontSize = 26.sp, color = cs.primary)
                    }
                    if (open) {
                        Spacer(Modifier.size(8.dp))
                        Text(e.meaning, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Dualar
@Composable
fun DuasScreen(onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var open by rememberSaveable { mutableStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Sure ve dualar", "Arapça, okunuş ve anlam", onBack)
        LazyColumn(
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(DuaData.ALL.size) { idx ->
                val d = DuaData.ALL[idx]
                val isOpen = open == idx
                ProCard(onClick = { open = if (isOpen) -1 else idx }, corner = 20.dp) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("🤲", fontSize = 20.sp)
                        Spacer(Modifier.width(10.dp))
                        Text(
                            d.title,
                            Modifier.weight(1f),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(if (isOpen) "▲" else "▼", color = cs.onSurfaceVariant)
                    }
                    if (isOpen) {
                        Spacer(Modifier.size(12.dp))
                        Text(
                            d.arabic,
                            Modifier.fillMaxWidth(),
                            fontSize = 24.sp,
                            lineHeight = 44.sp,
                            textAlign = TextAlign.Center,
                            color = cs.onSurface
                        )
                        Spacer(Modifier.size(12.dp))
                        Text("Okunuşu", style = MaterialTheme.typography.labelLarge, color = cs.primary)
                        Text(d.okunus, style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.size(8.dp))
                        Text("Anlamı", style = MaterialTheme.typography.labelLarge, color = cs.primary)
                        Text(d.anlam, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Dini gunler
@Composable
fun ReligiousDaysScreen(s: Settings, onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val today = remember { PrayerRepo.today(System.currentTimeMillis()) }
    val events = remember(s.hijriAdj) { ReligiousDays.upcoming(today, s.hijriAdj, 420) }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Dini günler ve geceler", "Önümüzdeki 14 ay", onBack)
        LazyColumn(
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(events.size) { idx ->
                val e = events[idx]
                val days = ChronoUnit.DAYS.between(today, e.date)
                ProCard(corner = 20.dp) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(
                            Modifier
                                .width(56.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(e.date.dayOfMonth.toString(), fontSize = 26.sp, fontWeight = FontWeight.Bold, color = cs.primary)
                            Text(
                                Fmt.dayShort(e.date).substringAfter(' '),
                                style = MaterialTheme.typography.labelMedium,
                                color = cs.onSurfaceVariant
                            )
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                (when (e.kind) {
                                    EventKind.BAYRAM -> "🎉 "
                                    EventKind.KANDIL -> "🌙 "
                                    EventKind.OZEL -> "📅 "
                                }) + e.name,
                                fontWeight = FontWeight.SemiBold,
                                style = MaterialTheme.typography.titleSmall
                            )
                            Text(
                                Fmt.dayWeek(e.date) + (if (e.night) " akşamı • " else " • ") + e.info,
                                style = MaterialTheme.typography.bodySmall,
                                color = cs.onSurfaceVariant
                            )
                        }
                        Pill(if (days <= 0L) "Bugün" else "$days gün", strong = days in 0L..7L)
                    }
                }
            }
            item {
                Text(
                    "Tarihler Hicrî takvim hesabına göredir ve Diyanet takviminden ±1 gün farklı olabilir. " +
                        "Ayarlar → Hicrî tarih düzeltmesi ile ayarlayabilirsin.",
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                    modifier = Modifier.padding(4.dp)
                )
            }
        }
    }
}
