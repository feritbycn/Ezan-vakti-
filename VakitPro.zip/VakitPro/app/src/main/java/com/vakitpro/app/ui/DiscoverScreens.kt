@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.vakitpro.app.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vakitpro.app.data.DuaData
import com.vakitpro.app.data.EsmaData
import com.vakitpro.app.data.EventKind
import com.vakitpro.app.data.Fmt
import com.vakitpro.app.data.PrayerRepo
import com.vakitpro.app.data.ReligiousDays
import com.vakitpro.app.data.Settings
import java.time.temporal.ChronoUnit

private class Entry(val icon: Int, val title: String, val sub: String, val route: String)

private val GROUPS: List<Pair<String, List<Entry>>> = listOf(
    "İbadet" to listOf(
        Entry(10, "Namaz rehberi", "Namaz ve abdest, adım adım", "namaz"),
        Entry(1, "Sünnet ve fıkıh", "32 farz, sünnetler, gusül • kaynaklı", "fikih"),
        Entry(9, "Kaza namazı", "Borç takibi", "kaza"),
        Entry(5, "Namaz takibi", "Seri ve haftalık grafik", "tracker"),
        Entry(15, "Namaz modu", "Namaz boyunca telefon sussun", "mode"),
        Entry(8, "Pro özellikleri", "Reklamsız deneyim ve daha fazlası", "pro"),
        Entry(6, "Zekât hesabı", "Nisab ve %2,5", "zakat")
    ),
    "Kur'an ve dua" to listOf(
        Entry(1, "Kur'an-ı Kerim", "114 sure, Arapça ve meal", "quran"),
        Entry(24, "Hadisler", "Kütüb-i Sitte • okundu ve favori", "hadis"),
        Entry(24, "Günün ayeti, hadisi, duası", "Tek pencerede, paylaşılabilir", "daily"),
        Entry(7, "Sure ve dualar", "Arapça, okunuş, anlam", "duas"),
        Entry(2, "Esmâü'l-Hüsnâ", "99 isim ve anlamları", "esma"),
        Entry(12, "Elif-Ba", "28 harf, dokun ve dinle", "letters"),
        Entry(0, "Hikâyeler", "Ayet, hadis, dua ve güzel sözler", "stories")
    ),
    "Öğren" to listOf(
        Entry(17, "Siyer ve Sahabe", "Peygamberimiz ve sahabe hayatı • sesli okuma", "siyer"),
        Entry(11, "Bilgi yarışması", "843 soru, yanlışlarını tekrar gör", "quiz"),
        Entry(13, "Kelime bulmaca", "Harfleri sırala", "word")
    ),
    "Takvim" to listOf(
        Entry(3, "Dini günler", "Kandil ve bayramlar", "days"),
        Entry(4, "Aylık vakitler", "İmsakiye tablosu", "monthly")
    ),
    "Diğer" to listOf(
        Entry(14, "Niyet ve notlar", "Kendine not bırak", "notes"),
        Entry(15, "Ayarlar", "Bildirim, hesaplama ve görünüm", "@settings"),
        Entry(8, "Yakındaki camiler", "Haritada aç", "@mosque"),
        Entry(16, "Uygulamayı değerlendir", "Puan ver veya arkadaşınla paylaş", "@rate")
    )
)

@Composable
fun DiscoverScreen(s: Settings, scroll: androidx.compose.foundation.ScrollState, onOpen: (String) -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    fun go(route: String) {
        when (route) {
            "@mosque" -> {
                val geo = Uri.parse("geo:${s.lat},${s.lng}?q=" + Uri.encode("cami"))
                try {
                    ctx.startActivity(Intent(Intent.ACTION_VIEW, geo).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) {
                    try {
                        val web = Uri.parse("https://www.google.com/maps/search/cami/@${s.lat},${s.lng},14z")
                        ctx.startActivity(Intent(Intent.ACTION_VIEW, web).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (e2: Exception) {
                    }
                }
            }
            "@rate" -> {
                // Paket adi uygulamadan otomatik alinir: Play Store'da kendi sayfasi acilir
                val pkg = ctx.packageName
                val flags = Intent.FLAG_ACTIVITY_NEW_TASK
                try {
                    ctx.startActivity(
                        Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg"))
                            .setPackage("com.android.vending").addFlags(flags)
                    )
                } catch (e: Exception) {
                    try {
                        ctx.startActivity(
                            Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$pkg"))
                                .addFlags(flags)
                        )
                    } catch (e2: Exception) {
                        try {
                            ctx.startActivity(
                                Intent.createChooser(
                                    Intent(Intent.ACTION_SEND).setType("text/plain")
                                        .putExtra(Intent.EXTRA_TEXT, "NurVakit: https://play.google.com/store/apps/details?id=$pkg"),
                                    "Paylaş"
                                ).addFlags(flags)
                            )
                        } catch (e3: Exception) {
                        }
                    }
                }
            }
            else -> onOpen(route)
        }
    }
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(scroll)
    ) {
        ScreenHeader("Keşfet", "İbadet, öğrenme ve araçlar")
        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            GROUPS.forEach { (title, entries) ->
                SectionTitle(title)
                androidx.compose.material3.Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = cs.surfaceContainerHigh,
                    border = androidx.compose.foundation.BorderStroke(1.dp, cs.outlineVariant)
                ) {
                    Column {
                        entries.forEachIndexed { i, e ->
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .androidx_clickable { go(e.route) }
                                    .padding(horizontal = 14.dp, vertical = 11.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (e.route == "pro") RoseIcon(44.dp) else if (e.icon >= 9) ToolIcon(e.icon - 9, 44.dp) else DiscoverIcon(e.icon, 44.dp)
                                Spacer(Modifier.width(14.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(Lang.tr(e.title), fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleSmall)
                                    Text(Lang.tr(e.sub), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                                }
                                if (e.route == "pro") ProBadge()
                                Text("›", fontSize = 22.sp, color = cs.onSurfaceVariant)
                            }
                            if (i < entries.size - 1) {
                                androidx.compose.material3.HorizontalDivider(
                                    Modifier.padding(start = 72.dp, end = 14.dp), color = cs.outlineVariant.copy(alpha = 0.5f)
                                )
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.size(24.dp))
    }
}

private fun Modifier.androidx_clickable(onClick: () -> Unit): Modifier =
    this.then(Modifier.clickable(onClick = onClick))

// ---------------------------------------------------------------- Esma
@Composable
fun EsmaScreen(onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var query by rememberSaveable { mutableStateOf("") }
    var openNo by rememberSaveable { mutableStateOf(-1) }
    val list = remember(query) {
        val q = query.trim().lowercase()
        if (q.isEmpty()) EsmaData.ALL
        else EsmaData.ALL.filter {
            it.name.lowercase().contains(q) || it.meaning.lowercase().contains(q) || it.no.toString() == q
        }
    }
    val dayIdx = remember { (java.time.LocalDate.now().dayOfYear - 1) % 99 }
    val today = EsmaData.ALL[dayIdx]

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Esmâü'l-Hüsnâ", "Allah'ın 99 güzel ismi", onBack)
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            singleLine = true,
            placeholder = { Text("İsim, anlam veya numara ara") },
            shape = RoundedCornerShape(16.dp)
        )
        LazyColumn(
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (query.isBlank()) {
                item {
                    ProCard {
                        Text("Günün esması", style = MaterialTheme.typography.labelLarge, color = cs.primary)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(today.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                Text(today.meaning, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
                            }
                            Text(today.arabic, fontSize = 34.sp, color = Gold, textAlign = TextAlign.End)
                        }
                    }
                }
            }
            items(list, key = { it.no }) { e ->
                val open = openNo == e.no
                ProCard(onClick = { openNo = if (open) -1 else e.no }, corner = 18.dp) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Pill(e.no.toString())
                        Spacer(Modifier.width(12.dp))
                        Text(
                            e.name,
                            Modifier.weight(1f),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(e.arabic, fontSize = 26.sp, color = cs.primary)
                    }
                    if (open) {
                        Spacer(Modifier.size(8.dp))
                        Text(e.meaning, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Dualar
@Composable
fun DuasScreen(onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var open by rememberSaveable { mutableStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Sure ve dualar", "Arapça, okunuş ve anlam", onBack)
        LazyColumn(
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(DuaData.ALL.size) { idx ->
                val d = DuaData.ALL[idx]
                val isOpen = open == idx
                ProCard(onClick = { open = if (isOpen) -1 else idx }, corner = 20.dp) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        DiscoverIcon(7, 34.dp)
                        Spacer(Modifier.width(10.dp))
                        Text(
                            d.title,
                            Modifier.weight(1f),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(if (isOpen) "▲" else "▼", color = cs.onSurfaceVariant)
                    }
                    if (isOpen) {
                        Spacer(Modifier.size(12.dp))
                        Text(
                            d.arabic,
                            Modifier.fillMaxWidth(),
                            fontSize = 24.sp,
                            lineHeight = 44.sp,
                            textAlign = TextAlign.Center,
                            color = cs.onSurface
                        )
                        Spacer(Modifier.size(12.dp))
                        Text("Okunuşu", style = MaterialTheme.typography.labelLarge, color = cs.primary)
                        Text(d.okunus, style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.size(8.dp))
                        Text("Anlamı", style = MaterialTheme.typography.labelLarge, color = cs.primary)
                        Text(d.anlam, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Dini gunler
@Composable
fun ReligiousDaysScreen(s: Settings, onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val today = remember { PrayerRepo.today(System.currentTimeMillis()) }
    val events = remember(s.hijriAdj) { ReligiousDays.upcoming(today, s.hijriAdj, 420) }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Dini günler ve geceler", "Önümüzdeki 14 ay", onBack)
        LazyColumn(
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(events.size) { idx ->
                val e = events[idx]
                val days = ChronoUnit.DAYS.between(today, e.date)
                ProCard(corner = 20.dp) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(
                            Modifier
                                .width(56.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(e.date.dayOfMonth.toString(), fontSize = 26.sp, fontWeight = FontWeight.Bold, color = cs.primary)
                            Text(
                                Fmt.dayShort(e.date).substringAfter(' '),
                                style = MaterialTheme.typography.labelMedium,
                                color = cs.onSurfaceVariant
                            )
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                GlyphIcon(
                                    when (e.kind) {
                                        EventKind.BAYRAM -> Glyph.PARTY
                                        EventKind.KANDIL -> Glyph.CRESCENT
                                        EventKind.OZEL -> Glyph.CALENDAR
                                    },
                                    when (e.kind) {
                                        EventKind.BAYRAM -> Color(0xFFF59E0B)
                                        EventKind.KANDIL -> cs.primary
                                        EventKind.OZEL -> Color(0xFFEC4899)
                                    },
                                    18.dp
                                )
                                Spacer(Modifier.width(6.dp))
                                Text(
                                    e.name,
                                    fontWeight = FontWeight.SemiBold,
                                    style = MaterialTheme.typography.titleSmall
                                )
                            }
                            Text(
                                Fmt.dayWeek(e.date) + (if (e.night) " akşamı • " else " • ") + e.info,
                                style = MaterialTheme.typography.bodySmall,
                                color = cs.onSurfaceVariant
                            )
                            Text(
                                "Hicrî " + e.hijri,
                                style = MaterialTheme.typography.labelMedium,
                                color = cs.primary
                            )
                        }
                        Pill(if (days <= 0L) "Bugün" else "$days gün", strong = days in 0L..7L)
                    }
                }
            }
            item {
                Text(
                    "Tarihler Hicrî takvim hesabına göredir ve Diyanet takviminden ±1 gün farklı olabilir. " +
                        "Ayarlar → Hicrî tarih düzeltmesi ile ayarlayabilirsin.",
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                    modifier = Modifier.padding(4.dp)
                )
            }
        }
    }
}
