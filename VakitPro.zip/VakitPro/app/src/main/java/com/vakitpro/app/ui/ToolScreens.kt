@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.vakitpro.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vakitpro.app.data.Fmt
import com.vakitpro.app.data.Names
import com.vakitpro.app.data.PrayerRepo
import com.vakitpro.app.data.Prefs
import com.vakitpro.app.data.Settings
import java.text.NumberFormat
import java.time.LocalDate
import java.time.YearMonth
import java.util.Locale

// ---------------------------------------------------------------- Aylik imsakiye
@Composable
fun MonthlyScreen(s: Settings, onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val today = remember { PrayerRepo.today(System.currentTimeMillis()) }
    var month by remember { mutableStateOf(YearMonth.from(today)) }
    val days = remember(month, s.lat, s.lng, s.method, s.hanafi, s.adj) {
        (1..month.lengthOfMonth()).map { d ->
            val date = month.atDay(d)
            Pair(date, PrayerRepo.times(s, date))
        }
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Aylık vakitler", "${s.cityName} • imsakiye", onBack)
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "◀",
                Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { month = month.minusMonths(1) }
                    .padding(12.dp),
                color = cs.primary
            )
            Text(
                Fmt.monthYear(month.atDay(1)),
                Modifier.weight(1f),
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                "▶",
                Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { month = month.plusMonths(1) }
                    .padding(12.dp),
                color = cs.primary
            )
        }
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
            Text("Gün", Modifier.weight(1.3f), style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
            for (i in 0 until 6) {
                Text(
                    Names.SHORT[i],
                    Modifier.weight(1f),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.labelSmall,
                    color = cs.onSurfaceVariant
                )
            }
        }
        LazyColumn(
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp)
        ) {
            items(days) { (date, t) ->
                val isToday = date == today
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isToday) cs.primaryContainer else Color.Transparent)
                        .padding(horizontal = 4.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "${date.dayOfMonth} ${Fmt.dayWeek(date)}",
                        Modifier.weight(1.3f).padding(start = 4.dp),
                        fontSize = 12.sp,
                        fontWeight = if (isToday) FontWeight.Bold else FontWeight.Medium,
                        color = if (isToday) cs.onPrimaryContainer else cs.onSurface
                    )
                    for (i in 0 until 6) {
                        Text(
                            Fmt.hm(t[i]),
                            Modifier.weight(1f),
                            textAlign = TextAlign.Center,
                            fontSize = 12.sp,
                            fontWeight = if (isToday) FontWeight.Bold else FontWeight.Normal,
                            color = if (isToday) cs.onPrimaryContainer else cs.onSurface
                        )
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Namaz / amel takibi
private val PRAYER_LABELS = listOf(
    0 to "Sabah",
    2 to "Öğle",
    3 to "İkindi",
    4 to "Akşam",
    5 to "Yatsı"
)
private val EXTRA_LABELS = listOf(
    Glyph.BOOK to "Kur'an okudum",
    Glyph.BEADS to "Zikir / tesbih",
    Glyph.HEART to "Sadaka verdim",
    Glyph.BOWL to "Oruç tuttum"
)

@Composable
fun TrackerScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val realToday = remember { LocalDate.now() }
    var date by remember { mutableStateOf(realToday) }
    var mask by remember(date) { mutableIntStateOf(Prefs.getDone(ctx, date)) }

    fun toggle(bit: Int) {
        mask = mask xor (1 shl bit)
        Prefs.setDone(ctx, date, mask)
    }

    // Seri (ust uste tum 5 vakti kildigin gun sayisi)
    val streak = run {
        var count = 0
        var d = realToday
        val todayMask = if (date == realToday) mask else Prefs.getDone(ctx, realToday)
        val todayFull = (todayMask and 31) == 31
        if (!todayFull) d = d.minusDays(1)
        while (count < 730) {
            val m = if (d == date) mask else Prefs.getDone(ctx, d)
            if ((m and 31) == 31) {
                count++
                d = d.minusDays(1)
            } else break
        }
        count
    }
    val week = (6 downTo 0).map { off ->
        val d = realToday.minusDays(off.toLong())
        val m = if (d == date) mask else Prefs.getDone(ctx, d)
        Pair(d, Integer.bitCount(m and 31))
    }
    val monthTotal = run {
        var sum = 0
        val ym = YearMonth.from(realToday)
        for (day in 1..realToday.dayOfMonth) {
            val d = ym.atDay(day)
            val m = if (d == date) mask else Prefs.getDone(ctx, d)
            sum += Integer.bitCount(m and 31)
        }
        sum
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        ScreenHeader("Namaz takibi", "Amel defterin", onBack)
        Column(
            Modifier.padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "◀",
                    Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { date = date.minusDays(1) }
                        .padding(12.dp),
                    color = cs.primary
                )
                Text(
                    if (date == realToday) "Bugün • ${Fmt.dayShort(date)}" else Fmt.dayLong(date),
                    Modifier.weight(1f),
                    textAlign = TextAlign.Center,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "▶",
                    Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { if (date.isBefore(realToday)) date = date.plusDays(1) }
                        .padding(12.dp),
                    color = if (date.isBefore(realToday)) cs.primary else cs.outline
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                InfoTile("Seri", "$streak gün", Modifier.weight(1f))
                InfoTile("Bugün", "${Integer.bitCount(mask and 31)} / 5", Modifier.weight(1f))
                InfoTile("Bu ay", "$monthTotal vakit", Modifier.weight(1f))
            }

            ProCard {
                PRAYER_LABELS.forEachIndexed { i, (emoji, label) ->
                    TrackRow({ PrayerIcon(emoji, 34.dp) }, label, ((mask shr i) and 1) == 1) { toggle(i) }
                }
            }

            SectionTitle("Diğer ibadetler")
            ProCard {
                EXTRA_LABELS.forEachIndexed { i, (emoji, label) ->
                    TrackRow({ GlyphTile(emoji) }, label, ((mask shr (5 + i)) and 1) == 1) { toggle(5 + i) }
                }
            }

            SectionTitle("Son 7 gün")
            ProCard {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .height(120.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.Bottom
                ) {
                    for ((d, c) in week) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("$c", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                            Box(
                                Modifier
                                    .padding(vertical = 3.dp)
                                    .width(26.dp)
                                    .height((6 + c * 15).dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (c == 5) Gold else cs.primary.copy(alpha = if (c == 0) 0.18f else 0.85f))
                            )
                            Text(Fmt.dayWeek(d), style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                        }
                    }
                }
            }
            Spacer(Modifier.size(24.dp))
        }
    }
}

@Composable
private fun TrackRow(icon: @Composable () -> Unit, label: String, checked: Boolean, onToggle: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable { onToggle() }
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        icon()
        Spacer(Modifier.width(12.dp))
        Text(
            label,
            Modifier.weight(1f),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = if (checked) FontWeight.Bold else FontWeight.Normal
        )
        Checkbox(checked = checked, onCheckedChange = { onToggle() })
    }
}

// ---------------------------------------------------------------- Zekat
private fun parseNum(t: String): Double = t.trim().replace(',', '.').toDoubleOrNull() ?: 0.0

@Composable
fun ZakatScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    var cash by rememberSaveable { mutableStateOf("") }
    var goldGr by rememberSaveable { mutableStateOf("") }
    var goods by rememberSaveable { mutableStateOf("") }
    var debts by rememberSaveable { mutableStateOf("") }
    var goldPrice by rememberSaveable { mutableStateOf(Prefs.getStr(ctx, "gold_price", "")) }

    val gp = parseNum(goldPrice)
    val assets = parseNum(cash) + parseNum(goldGr) * gp + parseNum(goods)
    val net = (assets - parseNum(debts)).coerceAtLeast(0.0)
    val nisab = 80.18 * gp
    val due = gp > 0 && net >= nisab && net > 0
    val zakat = if (due) net * 0.025 else 0.0
    val money = NumberFormat.getCurrencyInstance(Locale.forLanguageTag("tr-TR"))

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        ScreenHeader("Zekât hesabı", "Nisab: 80,18 gr altın", onBack)
        Column(
            Modifier.padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            ZField("Gram altın fiyatı (₺)", goldPrice) {
                goldPrice = it
                Prefs.putStr(ctx, "gold_price", it)
            }
            ZField("Nakit ve banka hesapları (₺)", cash) { cash = it }
            ZField("Altın (gram)", goldGr) { goldGr = it }
            ZField("Ticaret malı ve alacaklar (₺)", goods) { goods = it }
            ZField("Ödenecek borçlar (₺)", debts) { debts = it }

            ProCard {
                Text("Sonuç", style = MaterialTheme.typography.labelLarge, color = cs.primary)
                ResultLine("Toplam varlık", money.format(assets))
                ResultLine("Borç düşüldükten sonra", money.format(net))
                ResultLine("Nisab (80,18 gr altın)", if (gp > 0) money.format(nisab) else "—")
                Spacer(Modifier.size(8.dp))
                Text(
                    when {
                        gp <= 0 -> "Hesaplamak için güncel gram altın fiyatını gir."
                        due -> "Nisabı aştın. Vermen gereken zekât: ${money.format(zakat)}"
                        else -> "Net varlığın nisabın altında; zekât gerekmiyor."
                    },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = if (due) Gold else cs.onSurface
                )
            }
            Text(
                "Bu yaklaşık bir hesaptır (%2,5). Nisaba bir kamerî yıl sahip olma gibi şartlar için " +
                    "bir din görevlisine danışmanı öneririz.",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant
            )
            Spacer(Modifier.size(24.dp))
        }
    }
}

@Composable
private fun ZField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        modifier = Modifier.fillMaxWidth(),
        label = { Text(label) },
        singleLine = true,
        shape = RoundedCornerShape(16.dp),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
    )
}

@Composable
private fun ResultLine(label: String, value: String) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(top = 8.dp)
    ) {
        Text(label, Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontWeight = FontWeight.SemiBold)
    }
}


@Composable
private fun GlyphTile(g: Glyph) {
    Box(
        Modifier
            .size(34.dp)
            .clip(RoundedCornerShape(11.dp))
            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
        contentAlignment = Alignment.Center
    ) { GlyphIcon(g, MaterialTheme.colorScheme.primary, 20.dp) }
}
