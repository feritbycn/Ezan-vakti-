package com.vakitpro.app.ui

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings as AndroidSettings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.platform.LocalLifecycleOwner
import com.vakitpro.app.data.Fmt
import com.vakitpro.app.data.Names
import com.vakitpro.app.data.Prefs
import com.vakitpro.app.data.Settings
import com.vakitpro.app.notif.AlarmScheduler
import com.vakitpro.app.notif.Notifier

private class Check(val name: String, val ok: Boolean, val detail: String)

private fun open(ctx: Context, i: Intent) {
    try {
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        try {
            ctx.startActivity(
                Intent(AndroidSettings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e2: Exception) {
        }
    }
}

/** "Neden bildirim gelmedi?" tanilama kartı: izinleri ve son alarm kaydini gosterir. */
@Composable
fun NotifDiagCard(s: Settings) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    var tick by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val ob = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(ob)
        onDispose { owner.lifecycle.removeObserver(ob) }
    }

    val checks = remember(tick, s.channelVer, s.popup) { computeChecks(ctx, s) }

    val nextAt = Prefs.getLong(ctx, "dbg_next_at", 0L)
    val nextKind = Prefs.getInt(ctx, "dbg_next_kind", 0)
    val nextIdx = Prefs.getInt(ctx, "dbg_next_idx", 0).coerceIn(0, 5)
    val lastAt = Prefs.getLong(ctx, "dbg_last_at", 0L)
    val lastKind = Prefs.getInt(ctx, "dbg_last_kind", 0)
    val lastIdx = Prefs.getInt(ctx, "dbg_last_idx", 0).coerceIn(0, 5)
    val lastRes = Prefs.getStr(ctx, "dbg_last_res", "")

    ProCard {
        for (c in checks) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("●", color = if (c.ok) Color(0xFF22C55E) else Color(0xFFEF4444), fontSize = 12.sp)
                androidx.compose.foundation.layout.Column(Modifier.weight(1f)) {
                    Text(c.name, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Text(c.detail, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                }
            }
            Spacer(Modifier.size(6.dp))
        }
        Text(
            "Planlı sıradaki alarm: " + if (nextAt > 0L) {
                (if (nextKind == 1) "hatırlatma" else "vakit") + " • ${Names.SHORT[nextIdx]} • " +
                    Fmt.hm(nextAt) + ":" + "%02d".format((nextAt / 1000L) % 60L)
            } else "yok (henüz kurulmadı)",
            style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant
        )
        Text(
            "Son gelen alarm: " + if (lastAt > 0L) {
                (if (lastKind == 1) "hatırlatma" else "vakit") + " • ${Names.SHORT[lastIdx]} • " +
                    Fmt.hm(lastAt) + " • " + lastRes
            } else "hiç gelmedi",
            style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant
        )
        Spacer(Modifier.size(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                open(ctx, Intent(AndroidSettings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
                    .putExtra(AndroidSettings.EXTRA_APP_PACKAGE, ctx.packageName)
                    .putExtra(AndroidSettings.EXTRA_CHANNEL_ID, Notifier.alertChannelId(s)))
            }, modifier = Modifier.weight(1f)) { Text("Kanal ayarı", fontSize = 12.sp) }
            OutlinedButton(onClick = {
                open(ctx, Intent(AndroidSettings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")))
            }, modifier = Modifier.weight(1f)) { Text("Uygulama bilgisi", fontSize = 12.sp) }
        }
        Spacer(Modifier.size(6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (Build.VERSION.SDK_INT >= 34) {
                OutlinedButton(onClick = {
                    open(ctx, Intent(AndroidSettings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:${ctx.packageName}")))
                }, modifier = Modifier.weight(1f)) { Text("Tam ekran izni", fontSize = 12.sp) }
            }
            if (Build.VERSION.SDK_INT >= 31) {
                OutlinedButton(onClick = {
                    open(ctx, Intent(AndroidSettings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${ctx.packageName}")))
                }, modifier = Modifier.weight(1f)) { Text("Alarm izni", fontSize = 12.sp) }
            }
            OutlinedButton(onClick = { tick++ }, modifier = Modifier.weight(1f)) { Text("Yenile", fontSize = 12.sp) }
        }
        Spacer(Modifier.size(10.dp))
        androidx.compose.material3.Button(
            onClick = {
                val rep = buildReport(ctx, s)
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("Vakit Pro raporu", rep))
                android.widget.Toast.makeText(ctx, "Rapor kopyalandı — yapıştırıp gönder", android.widget.Toast.LENGTH_LONG).show()
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("📋  Raporu kopyala") }
        Spacer(Modifier.size(6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, buildReport(ctx, s))
                open(ctx, Intent.createChooser(send, "Raporu paylaş"))
            }, modifier = Modifier.weight(1f)) { Text("Paylaş", fontSize = 12.sp) }
            OutlinedButton(onClick = {
                com.vakitpro.app.notif.DebugLog.clear(ctx)
                tick++
            }, modifier = Modifier.weight(1f)) { Text("Günlüğü temizle", fontSize = 12.sp) }
        }
        Spacer(Modifier.size(6.dp))
        Text(
            "Xiaomi / Oppo / Realme: Uygulama bilgisi → Pil → “Kısıtlama yok”, Otomatik başlatma → açık, " +
                "“Arka planda açılır pencere” ve “Kilit ekranında göster” izinleri → açık olmalı.",
            style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant
        )
    }
}

private fun computeChecks(ctx: Context, s: Settings): List<Check> {
    val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val list = ArrayList<Check>()
        list += Check("Bildirim izni", NotificationManagerCompat.from(ctx).areNotificationsEnabled(),
            if (NotificationManagerCompat.from(ctx).areNotificationsEnabled()) "Açık" else "KAPALI — bildirim gelmez")
        val ch = nm.getNotificationChannel(Notifier.alertChannelId(s))
        val imp = ch?.importance ?: -1
        list += Check("Vakit bildirim kanalı", imp >= NotificationManager.IMPORTANCE_HIGH,
            when {
                ch == null -> "Henüz oluşmadı (test et)"
                imp == NotificationManager.IMPORTANCE_NONE -> "KAPALI — bildirim gelmez"
                imp >= NotificationManager.IMPORTANCE_HIGH -> "Üstten açılır (yüksek)"
                else -> "Önem düşük: üstten çıkmaz, sessiz olabilir"
            })
        val dnd = nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL &&
            nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_UNKNOWN
        list += Check("Rahatsız Etme", !dnd, if (dnd) "AÇIK — ses, üstten bildirim ve pencere engellenebilir" else "Kapalı")
        val exact = AlarmScheduler.canExact(ctx)
        list += Check("Tam zamanlı alarm", exact || s.reliableAlarm, if (exact) "İzinli" else if (s.reliableAlarm) "İzin yok, alarm saati modu kullanılıyor" else "İZİN YOK — vakit geç gelebilir")
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        val ign = pm.isIgnoringBatteryOptimizations(ctx.packageName)
        list += Check("Pil kısıtlaması", ign, if (ign) "Kısıtlama yok" else "Kısıtlı olabilir — arka planda geç kalabilir")
        if (Build.VERSION.SDK_INT >= 34) {
            val fs = nm.canUseFullScreenIntent()
            list += Check("Kilit ekranında pencere", fs, if (fs) "İzinli" else "İZİN YOK — kilitliyken pencere açılmaz")
        }
        val ov = Notifier.canOverlay(ctx)
        list += Check("Diğer uygulamaların üzerinde", ov, if (ov) "İzinli" else "İzin yok — açıkken pencere kendiliğinden açılmaz")
        list
}

private fun buildReport(ctx: Context, s: Settings): String {
    val sb = StringBuilder()
    sb.append("VAKIT PRO RAPORU\n")
    sb.append("Cihaz: ${Build.MANUFACTURER} ${Build.MODEL} • Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n")
    sb.append("Şimdi: ").append(java.text.SimpleDateFormat("dd.MM.yyyy HH:mm:ss", java.util.Locale.US).format(java.util.Date())).append("\n")
    sb.append("Ayarlar: alertMask=${s.alertMask} popup=${s.popup} alarmSaatiModu=${s.reliableAlarm} remind=${s.remind} ")
    sb.append("ses=${s.soundMode} titresim=${s.vibrate} sessize=${s.silenceOn} yontem=${s.method} hanefi=${s.hanafi}\n\n")
    sb.append("-- Kontroller --\n")
    for (c in computeChecks(ctx, s)) sb.append(if (c.ok) "[OK] " else "[SORUN] ").append(c.name).append(": ").append(c.detail).append("\n")
    val nextAt = Prefs.getLong(ctx, "dbg_next_at", 0L)
    sb.append("\nPlanlı alarm: ").append(
        if (nextAt > 0L) java.text.SimpleDateFormat("dd.MM HH:mm:ss", java.util.Locale.US).format(java.util.Date(nextAt)) +
            " kind=${Prefs.getInt(ctx, "dbg_next_kind", 0)} idx=${Prefs.getInt(ctx, "dbg_next_idx", 0)}" else "yok"
    ).append("\n")
    sb.append("Son alarm sonucu: ").append(Prefs.getStr(ctx, "dbg_last_res", "-")).append("\n\n")
    sb.append("-- Günlük --\n").append(com.vakitpro.app.notif.DebugLog.all(ctx).ifBlank { "(boş)" })
    return sb.toString()
}
