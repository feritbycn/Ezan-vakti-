package com.vakitpro.app.notif

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.vakitpro.app.MainActivity
import com.vakitpro.app.data.Fmt
import com.vakitpro.app.data.InspireData
import com.vakitpro.app.data.Names
import com.vakitpro.app.data.Prefs
import com.vakitpro.app.ui.VakitTheme

/** Vakit girince ana ekranda (kilit ekraninda da) acilan kart. */
class PrayerPopupActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        val idx = intent.getIntExtra("idx", 0).coerceIn(0, 5)
        val test = intent.getBooleanExtra("test", false)
        val s = Prefs.load(this)
        val now = System.currentTimeMillis()
        val tm = if (test) now else Notifier.timeOf(s, idx, now)
        val item = InspireData.pick(java.time.LocalDate.now().toEpochDay(), idx)
        setContent {
            VakitTheme(s) {
                val bmp = remember {
                    CardArt.prayerCard(
                        idx, Names.SHORT[idx], if (test) "Test bildirimi" else "Vakit girdi", Fmt.hm(tm), s.cityName
                    ).asImageBitmap()
                }
                CompositionLocalProvider(LocalContentColor provides MaterialTheme.colorScheme.onSurface) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(Color(0x99000000))
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { finish() },
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        Modifier
                            .padding(20.dp)
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(28.dp))
                            .background(MaterialTheme.colorScheme.surface)
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null
                            ) { }
                    ) {
                        Image(
                            bitmap = bmp,
                            contentDescription = null,
                            modifier = Modifier.fillMaxWidth(),
                            contentScale = ContentScale.FillWidth
                        )
                        Column(Modifier.padding(horizontal = 20.dp, vertical = 16.dp)) {
                            Text(
                                "${Names.EMOJI[idx]}  ${Names.EZAN[idx]}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(Modifier.size(10.dp))
                            Text(
                                item.text,
                                style = MaterialTheme.typography.bodyLarge,
                                textAlign = TextAlign.Start
                            )
                            Spacer(Modifier.size(4.dp))
                            Text(
                                if (item.source.isBlank()) "— ${item.kindName}" else "— ${item.kindName} • ${item.source}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(Modifier.size(14.dp))
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                TextButton(onClick = { finish() }) { Text("Kapat") }
                                Spacer(Modifier.size(8.dp))
                                Button(onClick = {
                                    startActivity(
                                        Intent(this@PrayerPopupActivity, MainActivity::class.java)
                                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                                            .putExtra("open", "stories")
                                    )
                                    finish()
                                }) { Text("Hikâyeler") }
                            }
                        }
                    }
                }
                }
            }
        }
    }
}
