package com.vakitpro.app.widget

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.vakitpro.app.data.Prefs

/**
 * Widget eklenirken ayar ekrani.
 * Arka plan: koyu cam / saydam (secim gecisinde isik taramasi).
 * Yazi rengi: halkali renk noktasi secici.
 */
class WidgetConfigActivity : Activity() {
    private var bg = "dark"
    private var tx = "auto"

    private val ink = Color.parseColor("#0F1F1F")
    private val muted = Color.parseColor("#5B6B6B")
    private val brand = Color.parseColor("#0E7C7B")
    private val brand2 = Color.parseColor("#14A39F")
    private val track = Color.parseColor("#E6EEED")
    private val line = Color.parseColor("#E3ECEA")
    private val cream = Color.parseColor("#F3EAD3")
    private val black = Color.parseColor("#0B1A1A")

    private class TxOpt(val col: LinearLayout, val ring: FrameLayout, val label: TextView)

    private val txOpts = mutableMapOf<String, TxOpt>()
    private lateinit var tabGlass: FrameLayout
    private lateinit var tabClear: FrameLayout
    private lateinit var previewText: TextView
    private lateinit var caption: TextView

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    private fun rounded(color: Int, radius: Int, stroke: Int = 0, strokeColor: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(radius).toFloat()
            setColor(color)
            if (stroke > 0) setStroke(dp(stroke), strokeColor)
        }

    private fun isNight(): Boolean =
        (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    private fun dotDrawable(key: String): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        when (key) {
            "auto" -> {
                orientation = GradientDrawable.Orientation.LEFT_RIGHT
                colors = intArrayOf(cream, black)
            }
            "cream" -> setColor(cream)
            "white" -> {
                setColor(Color.WHITE)
                setStroke(dp(1), line)
            }
            else -> setColor(black)
        }
    }

    private fun label(t: String): TextView = TextView(this).apply {
        text = t
        textSize = 11f
        setTextColor(muted)
        letterSpacing = 0.08f
        setTypeface(null, Typeface.BOLD)
        setPadding(dp(4), dp(18), 0, dp(8))
    }

    private fun makeTab(name: String): FrameLayout = FrameLayout(this).apply {
        clipToOutline = true
        addView(
            TextView(this@WidgetConfigActivity).apply {
                text = name
                textSize = 15f
                gravity = Gravity.CENTER
                setTypeface(null, Typeface.BOLD)
            },
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )
    }

    /** Secilen sekmeye soldan saga kayan kisa bir isik taramasi. */
    private fun sheen(tab: FrameLayout) {
        tab.post {
            val w = tab.width
            val ov = View(this).apply {
                background = GradientDrawable(
                    GradientDrawable.Orientation.LEFT_RIGHT,
                    intArrayOf(0x00FFFFFF, 0x59FFFFFF, 0x00FFFFFF)
                )
            }
            tab.addView(ov, FrameLayout.LayoutParams(w, FrameLayout.LayoutParams.MATCH_PARENT))
            ObjectAnimator.ofFloat(ov, "translationX", -w.toFloat(), w.toFloat()).apply {
                duration = 700
                addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: Animator) {
                        tab.removeView(ov)
                    }
                })
                start()
            }
        }
    }

    private fun styleTab(tab: FrameLayout, selected: Boolean) {
        tab.background = if (selected) rounded(Color.WHITE, 12) else null
        tab.elevation = if (selected) dp(2).toFloat() else 0f
        (tab.getChildAt(0) as TextView).setTextColor(if (selected) brand else muted)
    }

    private fun paint() {
        val clear = bg == "clear"
        styleTab(tabGlass, !clear)
        styleTab(tabClear, clear)

        for ((key, o) in txOpts) {
            val sel = key == tx
            o.col.background = rounded(Color.WHITE, 16, if (sel) 2 else 1, if (sel) brand else line)
            val s = if (sel) 1.08f else 1f
            o.ring.animate().scaleX(s).scaleY(s).setDuration(200).start()
            o.label.setTextColor(if (sel) brand else muted)
        }

        val resolved = when (tx) {
            "cream" -> cream
            "white" -> Color.WHITE
            "black" -> black
            else -> if (clear && !isNight()) black else cream
        }
        previewText.setTextColor(resolved)
        previewText.background = if (clear) null
        else rounded(Color.argb(158, 10, 22, 20), 18, 1, Color.argb(64, 231, 201, 122))

        caption.text = when {
            tx == "auto" && clear -> "Otomatik: saydamda sistem temasına göre"
            tx == "auto" -> "Otomatik: koyu camda krem yazı"
            tx == "cream" -> "Krem yazı"
            tx == "white" -> "Beyaz yazı"
            else -> if (!clear) "Siyah yazı · koyu camda krem olur" else "Siyah yazı"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_CANCELED)
        val id = intent?.extras?.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
            ?: AppWidgetManager.INVALID_APPWIDGET_ID
        if (id == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish()
            return
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
            setBackgroundColor(Color.parseColor("#F6F8F8"))
        }

        root.addView(TextView(this).apply {
            text = "Widget ayarları"
            textSize = 20f
            setTextColor(ink)
            setTypeface(null, Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "Arka planı ve yazı rengini seçin, sonucu aşağıda görün."
            textSize = 14f
            setTextColor(muted)
            setPadding(0, dp(2), 0, 0)
        })

        // Canli onizleme
        root.addView(label("ÖNİZLEME"))
        previewText = TextView(this).apply {
            text = "Günün ayeti\nŞüphesiz zorlukla beraber bir kolaylık vardır."
            textSize = 15f
            gravity = Gravity.CENTER
            typeface = Typeface.SERIF
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        root.addView(
            FrameLayout(this).apply {
                background = GradientDrawable(
                    GradientDrawable.Orientation.TL_BR,
                    intArrayOf(Color.parseColor("#137C7E"), Color.parseColor("#0A3D44"))
                ).apply { cornerRadius = dp(22).toFloat() }
                setPadding(dp(14), dp(14), dp(14), dp(14))
                addView(previewText, FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER
                ))
            }
        )
        caption = TextView(this).apply {
            textSize = 12f
            setTextColor(muted)
            setPadding(dp(4), dp(8), 0, 0)
        }
        root.addView(caption)

        // Arka plan segmenti
        root.addView(label("ARKA PLAN"))
        val seg = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(track, 16)
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        tabGlass = makeTab("Koyu cam")
        tabClear = makeTab("Saydam")
        tabGlass.setOnClickListener {
            if (bg != "dark") { bg = "dark"; paint(); sheen(tabGlass) }
        }
        tabClear.setOnClickListener {
            if (bg != "clear") { bg = "clear"; paint(); sheen(tabClear) }
        }
        seg.addView(tabGlass, LinearLayout.LayoutParams(0, dp(44), 1f))
        seg.addView(tabClear, LinearLayout.LayoutParams(0, dp(44), 1f))
        root.addView(seg)

        // Yazi rengi: halkali renk noktalari
        root.addView(label("YAZI RENGİ"))
        val txRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val keys = listOf("auto" to "Otomatik", "cream" to "Krem", "white" to "Beyaz", "black" to "Siyah")
        for ((key, name) in keys) {
            val ring = FrameLayout(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.WHITE)
                }
                addView(
                    View(this@WidgetConfigActivity).apply { background = dotDrawable(key) },
                    FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER)
                )
            }
            val lbl = TextView(this).apply {
                text = name
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(muted)
                setPadding(0, dp(6), 0, 0)
            }
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(4), dp(10), dp(4), dp(10))
                addView(ring, LinearLayout.LayoutParams(dp(40), dp(40)))
                addView(lbl)
                setOnClickListener { tx = key; paint() }
            }
            txOpts[key] = TxOpt(col, ring, lbl)
            txRow.addView(
                col,
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    setMargins(dp(3), 0, dp(3), 0)
                }
            )
        }
        root.addView(txRow)

        // Alt butonlar
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(24), 0, 0)
        }
        val cancel = Button(this).apply {
            text = "Vazgeç"
            isAllCaps = false
            setTextColor(muted)
            background = null
            setOnClickListener { finish() }
        }
        val save = Button(this).apply {
            text = "Ekle"
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(brand, brand2)
            ).apply { cornerRadius = dp(14).toFloat() }
            setOnClickListener {
                Prefs.putStr(this@WidgetConfigActivity, "wbg_$id", bg)
                // Koyu camda siyah yazi okunmaz: otomatik krem olur
                Prefs.putStr(this@WidgetConfigActivity, "wtxt_$id", if (bg != "clear" && tx == "black") "auto" else tx)
                WidgetUpdater.updateAll(this@WidgetConfigActivity)
                setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id))
                finish()
            }
        }
        actions.addView(cancel, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        actions.addView(save, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 2f))
        root.addView(actions)

        setContentView(ScrollView(this).apply { addView(root) })
        paint()
    }
}
