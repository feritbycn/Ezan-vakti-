package com.vakitpro.app.data

import android.content.Context

/** Kaza namazi sayaci: 0 Sabah, 1 Ogle, 2 Ikindi, 3 Aksam, 4 Yatsi, 5 Vitir. */
object Kaza {
    val NAMES = arrayOf("Sabah", "Öğle", "İkindi", "Akşam", "Yatsı", "Vitir")

    fun get(ctx: Context, i: Int): Int = Prefs.getInt(ctx, "kaza_$i", 0)

    fun set(ctx: Context, i: Int, v: Int) = Prefs.putInt(ctx, "kaza_$i", v.coerceIn(0, 99999))

    fun add(ctx: Context, i: Int, n: Int) = set(ctx, i, get(ctx, i) + n)

    fun total(ctx: Context): Int = (0..5).sumOf { get(ctx, it) }

    /** Vakit indeksine (0 Imsak..5 Yatsi) gore ondan onceki namazin indeksi (0..4) veya -1. */
    fun previousOf(vakitIdx: Int): Int = when (vakitIdx) {
        0 -> 4
        2 -> 0
        3 -> 1
        4 -> 2
        5 -> 3
        else -> -1
    }
}
