package com.vakitpro.app.data

/**
 * Gelistirici / test arac kapisi.
 * ENABLED = false iken Ayarlar'daki test butonlari, tani kaydi ve
 * "Ramazan testi" anahtari kullaniciya gosterilmez ve etkisiz kalir.
 * Test yapmak icin gecici olarak true yap.
 */
object DevTools {
    const val ENABLED = false
}
