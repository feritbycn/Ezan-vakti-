package com.vakitpro.app.notif

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import com.vakitpro.app.data.Kaza
import com.vakitpro.app.data.Prefs
import java.time.LocalDate

/** Bildirimdeki "Evet / Hayir" dugmeleri: onceki namaz kilindi mi? */
class PrayedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val bit = intent.getIntExtra("bit", -1)
        val yes = intent.getBooleanExtra("yes", true)
        val notifId = intent.getIntExtra("nid", -1)
        val yesterday = intent.getBooleanExtra("yesterday", false)
        val test = intent.getBooleanExtra("test", false)
        apply(context, bit, yes, yesterday, test)
        if (notifId >= 0) {
            (context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager).cancel(notifId)
        }
    }

    companion object {
        /** Cevabi isler ve kullaniciya mesaj gosterir. Test modunda veri degismez. */
        fun apply(context: Context, bit: Int, yes: Boolean, yesterday: Boolean, test: Boolean) {
            if (bit !in 0..4) return
            val msg: String
            if (test) {
                msg = "Test: ${Kaza.NAMES[bit]} için " + (if (yes) "\"Evet\"" else "\"Hayır\"") + " seçildi. Gerçek vakitte kayıt yapılır."
            } else {
                val d = if (yesterday) LocalDate.now().minusDays(1) else LocalDate.now()
                if (yes) {
                    Prefs.setDone(context, d, Prefs.getDone(context, d) or (1 shl bit))
                    msg = "${Kaza.NAMES[bit]} namazı kılındı olarak işaretlendi. Allah kabul etsin."
                } else {
                    val m = Prefs.getDone(context, d) and (1 shl bit).inv()
                    Prefs.setDone(context, d, m)
                    Kaza.add(context, bit, 1)
                    msg = "${Kaza.NAMES[bit]} kaza listesine eklendi. Geciktirmeden kaza et."
                }
            }
            Handler(Looper.getMainLooper()).post { Toast.makeText(context, msg, Toast.LENGTH_LONG).show() }
        }
    }
}
