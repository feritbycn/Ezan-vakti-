package com.vakitpro.app.notif

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import com.vakitpro.app.data.Kaza
import com.vakitpro.app.data.Prefs
import java.time.LocalDate

/** Bildirimdeki "Evet / Hayır" dugmeleri: onceki namaz kilindi mi? */
class PrayedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val bit = intent.getIntExtra("bit", -1)
        val yes = intent.getBooleanExtra("yes", true)
        val notifId = intent.getIntExtra("nid", -1)
        val yesterday = intent.getBooleanExtra("yesterday", false)
        if (bit in 0..4) {
            val d = if (yesterday) LocalDate.now().minusDays(1) else LocalDate.now()
            val msg: String
            if (yes) {
                Prefs.setDone(context, d, Prefs.getDone(context, d) or (1 shl bit))
                msg = "${Kaza.NAMES[bit]} namazı kılındı olarak işaretlendi. Allah kabul etsin."
            } else {
                val m = Prefs.getDone(context, d) and (1 shl bit).inv()
                Prefs.setDone(context, d, m)
                Kaza.add(context, bit, 1)
                msg = "${Kaza.NAMES[bit]} kaza listesine eklendi. Geciktirmeden kaza et."
            }
            Handler(Looper.getMainLooper()).post { Toast.makeText(context, msg, Toast.LENGTH_LONG).show() }
        }
        if (notifId >= 0) {
            (context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager).cancel(notifId)
        }
    }
}
