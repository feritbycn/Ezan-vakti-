package com.vakitpro.app.notif

import android.app.AlarmManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.vakitpro.app.data.PrayerRepo
import com.vakitpro.app.data.Prefs
import com.vakitpro.app.widget.WidgetUpdater

const val KIND_PRAYER = 0
const val KIND_REMINDER = 1

object AlarmScheduler {
    private const val REQ = 7001
    private const val ACTION = "com.vakitpro.app.ALARM"

    private fun pending(ctx: Context, kind: Int, idx: Int): PendingIntent {
        val i = Intent(ctx, AlarmReceiver::class.java).apply {
            action = ACTION
            putExtra("kind", kind)
            putExtra("idx", idx)
        }
        return PendingIntent.getBroadcast(
            ctx, REQ, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun canExact(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT < 31) return true
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        return am.canScheduleExactAlarms()
    }

    /** Siradaki tek olayi (vakit ya da on-hatirlatma) planlar; olay tetiklenince tekrar cagrilir. */
    fun scheduleNext(ctx: Context) {
        val s = Prefs.load(ctx)
        val now = System.currentTimeMillis()
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager

        var bestT = Long.MAX_VALUE
        var kind = KIND_PRAYER
        var idx = 0
        for ((t, i) in PrayerRepo.upcoming(s, now + 1000L, 12)) {
            if (t < bestT) {
                bestT = t
                kind = KIND_PRAYER
                idx = i
            }
            if (s.reminderMin > 0 && ((s.alertMask shr i) and 1) == 1) {
                val rt = t - s.reminderMin * 60_000L
                if (rt > now + 1000L && rt < bestT) {
                    bestT = rt
                    kind = KIND_REMINDER
                    idx = i
                }
            }
        }
        if (bestT == Long.MAX_VALUE) return

        val pi = pending(ctx, kind, idx)
        try {
            if (canExact(ctx)) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, bestT, pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, bestT, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, bestT, pi)
        }
    }
}

object Refresher {
    /** Alarm + widget + kalici bildirimi tazeler. */
    fun refreshAll(ctx: Context, withService: Boolean = false) {
        val app = ctx.applicationContext
        try {
            AlarmScheduler.scheduleNext(app)
        } catch (e: Exception) {
        }
        try {
            WidgetUpdater.updateAll(app)
        } catch (e: Exception) {
        }
        try {
            val s = Prefs.load(app)
            if (s.ongoing) {
                if (withService) startService(app) else Notifier.updateOngoing(app)
            } else {
                stopService(app)
            }
        } catch (e: Exception) {
        }
    }

    fun startService(ctx: Context) {
        try {
            ContextCompat.startForegroundService(ctx, Intent(ctx, OngoingService::class.java))
        } catch (e: Exception) {
            // Arka planda baslatma kisitlamasi: bildirimi servis olmadan guncelle
            try {
                Notifier.updateOngoing(ctx)
            } catch (e2: Exception) {
            }
        }
    }

    fun stopService(ctx: Context) {
        ctx.stopService(Intent(ctx, OngoingService::class.java))
        Notifier.cancelOngoing(ctx)
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val kind = intent.getIntExtra("kind", KIND_PRAYER)
        val idx = intent.getIntExtra("idx", 0).coerceIn(0, 5)
        val s = Prefs.load(context)
        if (((s.alertMask shr idx) and 1) == 1) {
            if (kind == KIND_PRAYER) Notifier.showPrayerAlert(context, s, idx)
            else Notifier.showReminder(context, s, idx)
        }
        Refresher.refreshAll(context, false)
    }
}

class SystemEventReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Refresher.refreshAll(context, true)
    }
}

class OngoingService : Service() {
    private var registered = false

    private val tick = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            try {
                Notifier.updateOngoing(context)
            } catch (e: Exception) {
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val s = Prefs.load(this)
        Notifier.ensureChannels(this, s)
        val n = Notifier.buildOngoing(this, s)
        // startForegroundService ile baslatildigi icin her durumda once startForeground cagrilmali
        ServiceCompat.startForeground(
            this, Notifier.ONGOING_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        )
        if (!s.ongoing) {
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        if (!registered) {
            ContextCompat.registerReceiver(
                this, tick, IntentFilter(Intent.ACTION_TIME_TICK), ContextCompat.RECEIVER_NOT_EXPORTED
            )
            registered = true
        }
        return START_STICKY
    }

    override fun onDestroy() {
        if (registered) {
            try {
                unregisterReceiver(tick)
            } catch (e: Exception) {
            }
            registered = false
        }
        super.onDestroy()
    }
}
