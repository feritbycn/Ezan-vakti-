package com.vakitpro.app.notif

import android.app.AlarmManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.IBinder
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.vakitpro.app.data.PrayerRepo
import com.vakitpro.app.data.Prefs
import com.vakitpro.app.widget.WidgetUpdater

const val KIND_PRAYER = 0
const val KIND_REMINDER = 1
const val KIND_RESTORE = 2
const val KIND_TICK = 3

object AlarmScheduler {
    private const val REQ = 7001
    private const val ACTION = "com.vakitpro.app.ALARM"

    private fun pending(ctx: Context, kind: Int, idx: Int): PendingIntent {
        val i = Intent(ctx, AlarmReceiver::class.java).apply {
            action = ACTION
            putExtra("kind", kind)
            putExtra("idx", idx)
        }
        return PendingIntent.getBroadcast(
            ctx, REQ, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun canExact(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT < 31) return true
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        return am.canScheduleExactAlarms()
    }

    /** Siradaki tek olayi (vakit ya da on-hatirlatma) planlar; olay tetiklenince tekrar cagrilir. */
    fun scheduleNext(ctx: Context) {
        val s = Prefs.load(ctx)
        val now = System.currentTimeMillis()
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager

        var bestT = Long.MAX_VALUE
        var kind = KIND_PRAYER
        var idx = 0
        for ((t, i) in PrayerRepo.upcoming(s, now + 1000L, 12)) {
            if (t < bestT) {
                bestT = t
                kind = KIND_PRAYER
                idx = i
            }
            if (s.remind[i] > 0) {
                val rt = t - s.remind[i] * 60_000L
                if (rt > now + 1000L && rt < bestT) {
                    bestT = rt
                    kind = KIND_REMINDER
                    idx = i
                }
            }
        }
        val restore = Silencer.restoreAt(ctx)
        if (restore > now + 1000L && restore < bestT) {
            bestT = restore
            kind = KIND_RESTORE
            idx = 0
        }
        // Durum cubugu dakika ikonu: son 60 dk'da her dakika basinda bildirimi yenile
        // (ikon sadece bildirim yenilenince degisir; servis/TIME_TICK uyutulabildigi icin alarmla garanti)
        if (s.ongoing && s.statusMinutes) {
            var targetT = PrayerRepo.next(s, now).timeMs
            if (s.testMinutes) {
                val st = Prefs.getLong(ctx, "test_start", 0L)
                if (st > 0L && now < st + 3_600_000L) targetT = st + 3_600_000L
            }
            val rem = targetT - now
            if (rem > 0L) {
                val tt = if (rem > 3_600_000L) targetT - 3_600_000L + 300L
                else {
                    val rm = (rem + 59_999L) / 60_000L
                    targetT - (rm - 1L) * 60_000L + 300L
                }
                if (tt > now + 500L && tt < bestT) {
                    bestT = tt
                    kind = KIND_TICK
                    idx = 0
                }
            }
        }
        if (bestT == Long.MAX_VALUE) return

        val pi = pending(ctx, kind, idx)
        Prefs.putLong(ctx, "diag_alarm_at", bestT)
        TickLog.add(
            ctx,
            "planlandı tür=${listOf("vakit", "hatırlat", "geri-al", "dakika")[kind]} " +
                "${java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date(bestT))} " +
                "kesin=${canExact(ctx)}"
        )
        try {
            if (canExact(ctx)) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, bestT, pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, bestT, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, bestT, pi)
        }
    }
}

object Refresher {
    /** Alarm + widget + kalici bildirimi tazeler. */
    fun refreshAll(ctx: Context, withService: Boolean = false) {
        val app = ctx.applicationContext
        try {
            Silencer.restoreIfDue(app)
        } catch (e: Exception) {
        }
        try {
            AlarmScheduler.scheduleNext(app)
        } catch (e: Exception) {
        }
        try {
            WidgetUpdater.updateAll(app)
        } catch (e: Exception) {
        }
        try {
            val s = Prefs.load(app)
            if (s.ongoing) {
                if (withService) startService(app) else Notifier.updateOngoing(app)
            } else {
                stopService(app)
            }
        } catch (e: Exception) {
        }
    }

    fun startService(ctx: Context) {
        try {
            ContextCompat.startForegroundService(ctx, Intent(ctx, OngoingService::class.java))
        } catch (e: Exception) {
            // Arka planda baslatma kisitlamasi: bildirimi servis olmadan guncelle
            try {
                Notifier.updateOngoing(ctx)
            } catch (e2: Exception) {
            }
        }
    }

    fun stopService(ctx: Context) {
        ctx.stopService(Intent(ctx, OngoingService::class.java))
        Notifier.cancelOngoing(ctx)
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val kind = intent.getIntExtra("kind", KIND_PRAYER)
        val idx = intent.getIntExtra("idx", 0).coerceIn(0, 5)
        val s = Prefs.load(context)
        val planned = Prefs.getLong(context, "diag_alarm_at", 0L)
        val late = if (planned > 0L) System.currentTimeMillis() - planned else 0L
        TickLog.add(context, "ALARM geldi tür=$kind gecikme=${late}ms")
        TickLog.source = "alarm"
        Silencer.restoreIfDue(context)
        if (kind == KIND_RESTORE || kind == KIND_TICK) {
            Refresher.refreshAll(context, false)
            return
        }
        if (kind == KIND_PRAYER) {
            if (((s.alertMask shr idx) and 1) == 1) Notifier.showPrayerAlert(context, s, idx)
        } else if (s.remind[idx] > 0) {
            Notifier.showReminder(context, s, idx)
        }
        val silence = kind == KIND_PRAYER && s.silenceOn && ((s.silenceMask shr idx) and 1) == 1 &&
            s.silenceMins[idx] > 0
        if (silence) {
            // Bildirim sesi calsin diye kisa bir gecikmeyle sessize al
            val pr = goAsync()
            Handler(Looper.getMainLooper()).postDelayed({
                try {
                    Silencer.start(context, s.silenceMins[idx], s.silenceVibrate)
                    Refresher.refreshAll(context, false)
                } finally {
                    pr.finish()
                }
            }, 4000L)
        } else {
            Refresher.refreshAll(context, false)
        }
    }
}

class SystemEventReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Refresher.refreshAll(context, true)
    }
}

class OngoingService : Service() {
    private var registered = false
    private val handler = Handler(Looper.getMainLooper())

    private val tick = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            try {
                TickLog.add(context, "${intent.action?.substringAfterLast('.')} geldi")
                TickLog.source = intent.action?.substringAfterLast('.') ?: "yayın"
                Notifier.updateOngoing(context)
                // Ekran acilinca saat/sayac ile ikonu hemen esitle; sonraki dakika dongusunu yeniden kur
                scheduleMinuteTick()
            } catch (e: Exception) {
            }
        }
    }

    // Ikon degisim anina hizali dakika dongusu (servis surecinde, izin gerektirmez)
    private val minuteRunnable = Runnable {
        try {
            TickLog.source = "servis-dongu"
            Notifier.updateOngoing(this)
        } catch (e: Exception) {
        }
        scheduleMinuteTick()
    }

    private fun scheduleMinuteTick() {
        handler.removeCallbacks(minuteRunnable)
        val s = Prefs.load(this)
        val d = Notifier.msToNextIconChange(this, s, System.currentTimeMillis()).coerceAtLeast(500L)
        handler.postDelayed(minuteRunnable, d)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val s = Prefs.load(this)
        Notifier.ensureChannels(this, s)
        val n = Notifier.buildOngoing(this, s)
        // startForegroundService ile baslatildigi icin her durumda once startForeground cagrilmali
        ServiceCompat.startForeground(
            this, Notifier.ONGOING_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        )
        if (!s.ongoing) {
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        if (!registered) {
            val f = IntentFilter(Intent.ACTION_TIME_TICK)
            f.addAction(Intent.ACTION_SCREEN_ON)
            f.addAction(Intent.ACTION_USER_PRESENT)
            f.addAction(Intent.ACTION_TIME_CHANGED)
            ContextCompat.registerReceiver(this, tick, f, ContextCompat.RECEIVER_NOT_EXPORTED)
            registered = true
        }
        TickLog.add(this, "servis başladı")
        scheduleMinuteTick()
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(minuteRunnable)
        TickLog.add(this, "servis durdu")
        if (registered) {
            try {
                unregisterReceiver(tick)
            } catch (e: Exception) {
            }
            registered = false
        }
        super.onDestroy()
    }
}
