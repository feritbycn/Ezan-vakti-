package com.vakitpro.app.notif

import android.app.AlarmManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.IBinder
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.vakitpro.app.data.PrayerRepo
import com.vakitpro.app.data.Prefs
import com.vakitpro.app.widget.WidgetUpdater

const val KIND_PRAYER = 0
const val KIND_REMINDER = 1
const val KIND_RESTORE = 2
const val KIND_TICK = 3
const val KIND_SNOOZE_FIRE = 4
const val KIND_SNOOZE_SET = 5

object AlarmScheduler {
    private const val REQ = 7001
    private const val ACTION = "com.vakitpro.app.ALARM"

    private fun pending(ctx: Context, kind: Int, idx: Int, at: Long = 0L, req: Int = REQ): PendingIntent {
        val i = Intent(ctx, AlarmReceiver::class.java).apply {
            action = ACTION
            putExtra("kind", kind)
            putExtra("idx", idx)
            putExtra("at", at)
        }
        return PendingIntent.getBroadcast(
            ctx, req, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun setExact(ctx: Context, am: AlarmManager, at: Long, pi: PendingIntent, clock: Boolean) {
        if (clock) {
            try {
                val show = PendingIntent.getActivity(
                    ctx, 7002, Intent(ctx, com.vakitpro.app.MainActivity::class.java),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                am.setAlarmClock(AlarmManager.AlarmClockInfo(at, show), pi)
                return
            } catch (e: Exception) {
            }
        }
        try {
            if (canExact(ctx)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    /** Test: [sec] saniye sonra gercek alarm (kilit ekrani / arka plan dahil) ile vakit bildirimi. */
    fun scheduleTest(ctx: Context, sec: Int, reminder: Boolean) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val at = System.currentTimeMillis() + sec * 1000L
        val i = Intent(ctx, AlarmReceiver::class.java).apply {
            action = "com.vakitpro.app.TEST"
            putExtra("kind", if (reminder) KIND_REMINDER else KIND_PRAYER)
            putExtra("idx", if (reminder) 2 else 3)
            putExtra("test", true)
        }
        val pi = PendingIntent.getBroadcast(
            ctx, 7090, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        setExact(ctx, am, at, pi, true)
    }

    fun canExact(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT < 31) return true
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        return am.canScheduleExactAlarms()
    }

    /** Siradaki tek olayi (vakit ya da on-hatirlatma) planlar; olay tetiklenince tekrar cagrilir. */
    fun scheduleNext(ctx: Context) {
        val s = Prefs.load(ctx)
        val now = System.currentTimeMillis()
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager

        var bestT = Long.MAX_VALUE
        var kind = KIND_PRAYER
        var idx = 0
        for ((t, i) in PrayerRepo.upcoming(s, now + 1000L, 12)) {
            if (t < bestT) {
                bestT = t
                kind = KIND_PRAYER
                idx = i
            }
            if (s.remind[i] > 0) {
                val rt = t - s.remind[i] * 60_000L
                if (rt > now + 1000L && rt < bestT) {
                    bestT = rt
                    kind = KIND_REMINDER
                    idx = i
                }
            }
        }
        val restore = Silencer.restoreAt(ctx)
        if (restore > now + 1000L && restore < bestT) {
            bestT = restore
            kind = KIND_RESTORE
            idx = 0
        }
        // Dakika ikonu yenilemesi (TICK) vakit alarmindan AYRI bir alarmdir; vakit alarmi ona bagli degildir.
        if (s.ongoing && s.statusMinutes) {
            var targetT = PrayerRepo.next(s, now).timeMs
            if (s.testMinutes) {
                val st = Prefs.getLong(ctx, "test_start", 0L)
                if (st > 0L && now < st + 3_600_000L) targetT = st + 3_600_000L
            }
            val rem = targetT - now
            if (rem > 0L) {
                val tt = if (rem > 3_600_000L) targetT - 3_600_000L + 300L
                else {
                    val rm = rem / 60_000L
                    targetT - rm * 60_000L + 300L
                }
                if (tt > now + 500L && tt < targetT) {
                    setExact(ctx, am, tt, pending(ctx, KIND_TICK, 0, tt, 7003), false)
                }
            }
        }

        if (Prefs.getLong(ctx, "dbg_next_at", 0L) != (if (bestT == Long.MAX_VALUE) 0L else bestT)) {
            DebugLog.add(
                ctx,
                "PLAN ${if (kind == KIND_REMINDER) "hatirlatma" else if (kind == KIND_RESTORE) "geri-al" else "vakit"} idx=$idx " +
                    "@${java.text.SimpleDateFormat("dd.MM HH:mm:ss", java.util.Locale.US).format(java.util.Date(bestT))} " +
                    "exactIzin=${canExact(ctx)} alarmSaati=${s.reliableAlarm}"
            )
        }
        Prefs.putLong(ctx, "dbg_next_at", if (bestT == Long.MAX_VALUE) 0L else bestT)
        Prefs.putInt(ctx, "dbg_next_kind", kind)
        Prefs.putInt(ctx, "dbg_next_idx", idx)
        if (bestT == Long.MAX_VALUE) return

        val pi = pending(ctx, kind, idx, bestT)
        setExact(ctx, am, bestT, pi, s.reliableAlarm && (kind == KIND_PRAYER || kind == KIND_REMINDER))
    }
}

object Refresher {
    /** Alarm + widget + kalici bildirimi tazeler. */
    fun refreshAll(ctx: Context, withService: Boolean = false) {
        val app = ctx.applicationContext
        try {
            Silencer.restoreIfDue(app)
        } catch (e: Exception) {
        }
        try {
            AlarmScheduler.scheduleNext(app)
        } catch (e: Exception) {
        }
        try {
            WidgetUpdater.updateAll(app)
        } catch (e: Exception) {
        }
        try {
            val s = Prefs.load(app)
            if (s.ongoing) {
                if (withService) startService(app) else Notifier.updateOngoing(app)
            } else {
                stopService(app)
            }
        } catch (e: Exception) {
        }
    }

    fun startService(ctx: Context) {
        try {
            ContextCompat.startForegroundService(ctx, Intent(ctx, OngoingService::class.java))
        } catch (e: Exception) {
            // Arka planda baslatma kisitlamasi: bildirimi servis olmadan guncelle
            try {
                Notifier.updateOngoing(ctx)
            } catch (e2: Exception) {
            }
        }
    }

    fun stopService(ctx: Context) {
        ctx.stopService(Intent(ctx, OngoingService::class.java))
        Notifier.cancelOngoing(ctx)
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val kind = intent.getIntExtra("kind", KIND_PRAYER)
        val idx = intent.getIntExtra("idx", 0).coerceIn(0, 5)
        val s = Prefs.load(context)
        if (kind != KIND_TICK) {
            val planned = intent.getLongExtra("at", 0L)
            DebugLog.add(
                context,
                "ALARM GELDI kind=$kind idx=$idx test=${intent.getBooleanExtra("test", false)}" +
                    (if (planned > 0L) " gecikme=${System.currentTimeMillis() - planned}ms" else "")
            )
        }
        if (kind == KIND_PRAYER || kind == KIND_REMINDER) {
            Prefs.putLong(context, "dbg_last_at", System.currentTimeMillis())
            Prefs.putInt(context, "dbg_last_kind", kind)
            Prefs.putInt(context, "dbg_last_idx", idx)
            Prefs.putStr(context, "dbg_last_res", "geldi")
        }
        if (intent.getBooleanExtra("test", false)) {
            try {
                if (kind == KIND_PRAYER) Notifier.showPrayerAlert(context, s, idx, true)
                else Notifier.showReminder(context, s, idx, true)
                Prefs.putStr(context, "dbg_last_res", "bildirim gönderildi (test)")
            } catch (e: Exception) {
                Prefs.putStr(context, "dbg_last_res", "HATA: ${e.javaClass.simpleName} ${e.message}")
            }
            return
        }
        Silencer.restoreIfDue(context)
        if (kind == KIND_SNOOZE_SET) {
            Notifier.snooze(context, idx, 10)
            return
        }
        if (kind == KIND_SNOOZE_FIRE) {
            Notifier.showReminder(context, s, idx)
            return
        }
        if (kind == KIND_RESTORE || kind == KIND_TICK) {
            Refresher.refreshAll(context, kind == KIND_TICK && s.preciseTick && s.ongoing)
            return
        }
        try {
            if (kind == KIND_PRAYER) {
                if (((s.alertMask shr idx) and 1) == 1) {
                    Notifier.showPrayerAlert(context, s, idx)
                    Prefs.putStr(context, "dbg_last_res", "bildirim gönderildi")
                } else Prefs.putStr(context, "dbg_last_res", "bu vakit için bildirim KAPALI")
            } else if (s.remind[idx] > 0) {
                Notifier.showReminder(context, s, idx)
                Prefs.putStr(context, "dbg_last_res", "hatırlatma gönderildi")
            }
        } catch (e: Exception) {
            Prefs.putStr(context, "dbg_last_res", "HATA: ${e.javaClass.simpleName} ${e.message}")
            DebugLog.add(context, "HATA bildirim: ${e.javaClass.simpleName} ${e.message}")
            try {
                Notifier.showPlain(context, s, idx, kind == KIND_PRAYER)
            } catch (e2: Exception) {
            }
        }
        val silence = kind == KIND_PRAYER && s.silenceOn && ((s.silenceMask shr idx) and 1) == 1 &&
            s.silenceMins[idx] > 0
        if (silence) {
            // Bildirim sesi calsin diye kisa bir gecikmeyle sessize al
            val pr = goAsync()
            Handler(Looper.getMainLooper()).postDelayed({
                try {
                    Silencer.start(context, s.silenceMins[idx], s.silenceVibrate)
                    Refresher.refreshAll(context, false)
                } finally {
                    pr.finish()
                }
            }, 4000L)
        } else {
            Refresher.refreshAll(context, false)
        }
    }
}

class SystemEventReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        DebugLog.add(context, "SISTEM olayi: ${intent.action}")
        Refresher.refreshAll(context, true)
    }
}

class OngoingService : Service() {
    private var registered = false
    private val handler = Handler(Looper.getMainLooper())

    private val tick = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            try {
                Notifier.updateOngoing(context)
                // Ekran acilinca saat/sayac ile ikonu hemen esitle; sonraki dakika dongusunu yeniden kur
                scheduleMinuteTick()
            } catch (e: Exception) {
            }
        }
    }

    // Ikon degisim anina hizali dakika dongusu (servis surecinde, izin gerektirmez)
    private val minuteRunnable = Runnable {
        try {
            Notifier.updateOngoing(this)
        } catch (e: Exception) {
        }
        scheduleMinuteTick()
    }

    private var wl: android.os.PowerManager.WakeLock? = null

    /** Hassas mod: son 60 dk'da CPU uyanik kalsin ki dakika dongusu donmadan calissin. */
    private fun updateWakeLock(s: com.vakitpro.app.data.Settings) {
        val rem = Notifier.remainInfo(this, s, System.currentTimeMillis()).first
        val want = s.preciseTick && s.ongoing && s.statusMinutes && rem in 0L..(3_600_000L + 30_000L)
        val cur = wl
        if (want && (cur == null || !cur.isHeld)) {
            try {
                val pm = getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
                val l = pm.newWakeLock(android.os.PowerManager.PARTIAL_WAKE_LOCK, "VakitPro:tick")
                l.setReferenceCounted(false)
                l.acquire(rem + 120_000L)
                wl = l
            } catch (e: Exception) {
            }
        } else if (!want && cur != null && cur.isHeld) {
            try {
                cur.release()
            } catch (e: Exception) {
            }
            wl = null
        }
    }

    private fun scheduleMinuteTick() {
        handler.removeCallbacks(minuteRunnable)
        val s = Prefs.load(this)
        updateWakeLock(s)
        val d = Notifier.msToNextIconChange(this, s, System.currentTimeMillis()).coerceAtLeast(500L)
        handler.postDelayed(minuteRunnable, d)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val s = Prefs.load(this)
        Notifier.ensureChannels(this, s)
        val n = Notifier.buildOngoing(this, s)
        // startForegroundService ile baslatildigi icin her durumda once startForeground cagrilmali
        ServiceCompat.startForeground(
            this, Notifier.ONGOING_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        )
        if (!s.ongoing) {
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        if (!registered) {
            val f = IntentFilter(Intent.ACTION_TIME_TICK)
            f.addAction(Intent.ACTION_SCREEN_ON)
            f.addAction(Intent.ACTION_USER_PRESENT)
            f.addAction(Intent.ACTION_TIME_CHANGED)
            ContextCompat.registerReceiver(this, tick, f, ContextCompat.RECEIVER_NOT_EXPORTED)
            registered = true
        }
        scheduleMinuteTick()
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(minuteRunnable)
        try {
            wl?.let { if (it.isHeld) it.release() }
        } catch (e: Exception) {
        }
        wl = null
        if (registered) {
            try {
                unregisterReceiver(tick)
            } catch (e: Exception) {
            }
            registered = false
        }
        super.onDestroy()
    }
}
