package com.vakitpro.app.data

/** Hikâye kartları ve bildirimlerde kullanılan kısa içerikler. */
data class Inspire(val kind: Int, val text: String, val source: String) {
    val kindName: String get() = KIND_NAMES[kind]

    companion object {
        const val AYET = 0
        const val HADIS = 1
        const val DUA = 2
        const val SOZ = 3
        val KIND_NAMES = arrayOf("Ayet", "Hadis-i Şerif", "Dua", "Güzel Söz")
    }
}

object InspireData {
    val ALL: List<Inspire> = listOf(
        // ---- Ayetler (anlam)
        Inspire(Inspire.AYET, "Allah kimseye gücünün yeteceğinden fazlasını yüklemez.", "Bakara, 286"),
        Inspire(Inspire.AYET, "Elbette zorluğun yanında bir kolaylık vardır. Gerçekten, zorluğun yanında bir kolaylık daha vardır.", "İnşirâh, 5-6"),
        Inspire(Inspire.AYET, "Biliniz ki kalpler ancak Allah'ı anmakla huzur bulur.", "Ra'd, 28"),
        Inspire(Inspire.AYET, "Beni anın ki ben de sizi anayım. Bana şükredin, nankörlük etmeyin.", "Bakara, 152"),
        Inspire(Inspire.AYET, "Kim Allah'a tevekkül ederse, O ona yeter.", "Talâk, 3"),
        Inspire(Inspire.AYET, "Ey iman edenler! Sabır ve namazla yardım dileyin. Şüphesiz Allah sabredenlerle beraberdir.", "Bakara, 153"),
        Inspire(Inspire.AYET, "Allah'ın rahmetinden ümidinizi kesmeyin. Şüphesiz Allah bütün günahları bağışlar.", "Zümer, 53"),
        Inspire(Inspire.AYET, "Kullarım sana beni sorarsa, şüphesiz ben çok yakınım. Bana dua edince, dua edenin duasına karşılık veririm.", "Bakara, 186"),
        Inspire(Inspire.AYET, "Rabbin seni terk etmedi ve sana darılmadı.", "Duhâ, 3"),
        Inspire(Inspire.AYET, "Biz ona şah damarından daha yakınız.", "Kâf, 16"),
        Inspire(Inspire.AYET, "Gevşemeyin, hüzünlenmeyin. Eğer gerçekten inanmışsanız en üstün olan sizlersiniz.", "Âl-i İmrân, 139"),
        Inspire(Inspire.AYET, "Namaz, hayâsızlıktan ve kötülükten alıkoyar. Allah'ı anmak ise elbette en büyük ibadettir.", "Ankebût, 45"),

        // ---- Hadisler
        Inspire(Inspire.HADIS, "Ameller niyetlere göredir.", "Buhârî, Bed'ü'l-vahy, 1"),
        Inspire(Inspire.HADIS, "Sizin en hayırlınız, Kur'an'ı öğrenen ve öğretendir.", "Buhârî, Fezâilü'l-Kur'ân, 21"),
        Inspire(Inspire.HADIS, "Kolaylaştırınız, zorlaştırmayınız; müjdeleyiniz, nefret ettirmeyiniz.", "Buhârî, İlim, 11"),
        Inspire(Inspire.HADIS, "Temizlik imanın yarısıdır.", "Müslim, Tahâret, 1"),
        Inspire(Inspire.HADIS, "Müslüman, elinden ve dilinden diğer Müslümanların emin olduğu kimsedir.", "Buhârî, Îmân, 4"),
        Inspire(Inspire.HADIS, "Hiçbiriniz, kendisi için istediğini kardeşi için de istemedikçe gerçek anlamda iman etmiş olmaz.", "Buhârî, Îmân, 7"),
        Inspire(Inspire.HADIS, "Güzel söz sadakadır.", "Buhârî, Cihâd, 128"),
        Inspire(Inspire.HADIS, "Allah sizin suretlerinize ve mallarınıza bakmaz; kalplerinize ve amellerinize bakar.", "Müslim, Birr, 34"),
        Inspire(Inspire.HADIS, "Mü'min mü'mine karşı, parçaları birbirini destekleyen bir bina gibidir.", "Buhârî, Salât, 88"),
        Inspire(Inspire.HADIS, "Kardeşine tebessüm etmen sadakadır.", "Tirmizî, Birr, 36"),
        Inspire(Inspire.HADIS, "Hayâ imandandır.", "Buhârî, Îmân, 3"),
        Inspire(Inspire.HADIS, "Allah'a en sevimli gelen amel, az da olsa devamlı olandır.", "Buhârî, Rikāk, 18"),

        // ---- Dualar
        Inspire(Inspire.DUA, "Rabbimiz! Bize dünyada da iyilik ver, ahirette de iyilik ver ve bizi ateş azabından koru.", "Bakara, 201"),
        Inspire(Inspire.DUA, "Rabbim! İlmimi artır.", "Tâhâ, 114"),
        Inspire(Inspire.DUA, "Rabbim! Göğsümü genişlet, işimi kolaylaştır.", "Tâhâ, 25-26"),
        Inspire(Inspire.DUA, "Allah bize yeter, O ne güzel vekildir.", "Âl-i İmrân, 173"),
        Inspire(Inspire.DUA, "Rabbimiz! Unutursak ya da yanılırsak bizi sorumlu tutma.", "Bakara, 286"),
        Inspire(Inspire.DUA, "Ey kalpleri evirip çeviren Allah'ım! Kalbimi dinin üzere sabit kıl.", "Tirmizî, Kader, 7"),
        Inspire(Inspire.DUA, "Rabbimiz! Eşlerimizi ve çocuklarımızı bize göz aydınlığı kıl.", "Furkân, 74"),
        Inspire(Inspire.DUA, "Allah'ım! Senden dünyada ve ahirette af ve afiyet dilerim.", "İbn Mâce, Dua, 5"),
        Inspire(Inspire.DUA, "Allah'ım! Üzüntüden ve kederden, acizlikten ve tembellikten sana sığınırım.", "Buhârî, Deavât, 36"),

        // ---- Güzel sözler
        Inspire(Inspire.SOZ, "Yaratılanı hoş gör, Yaratan'dan ötürü.", "Yunus Emre"),
        Inspire(Inspire.SOZ, "İyilik yap denize at; balık bilmezse Halik bilir.", "Atasözü"),
        Inspire(Inspire.SOZ, "Şükür, elindekini çoğaltan en güzel duadır.", "Anonim"),
        Inspire(Inspire.SOZ, "Dua, kalbin Rabbine yazdığı en samimi mektuptur.", "Anonim"),
        Inspire(Inspire.SOZ, "Bir tebessüm, kalpleri açan en kısa duadır.", "Anonim"),
        Inspire(Inspire.SOZ, "Sabır, ardındaki hayrı beklemektir.", "Anonim"),
        Inspire(Inspire.SOZ, "Her gün yeni bir başlangıçtır; dünü bırak, bugünü şükürle yaşa.", "Anonim"),
        Inspire(Inspire.SOZ, "Huzur, kalbin Allah'la güzel anlaşmasıdır.", "Anonim"),
        Inspire(Inspire.SOZ, "Dünya bir misafirhanedir; misafire yakışan, geçici olduğunu bilmektir.", "Anonim")
    )

    /** Gün + vakit indeksine göre sabit (her gün değişen) bir içerik. Hadis/ayet ağırlıklı. */
    fun pick(dayEpoch: Long, salt: Int): Inspire {
        val list = ALL.filter { it.kind == Inspire.HADIS || it.kind == Inspire.AYET || it.kind == Inspire.DUA }
        val i = Math.floorMod((dayEpoch * 7 + salt * 3).toInt(), list.size)
        return list[i]
    }
}
