package com.vakitpro.app.data

import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

data class City(val name: String, val lat: Double, val lng: Double)

object Cities {
    val ALL: List<City> = listOf(
        City("Adana", 37.00, 35.32), City("Adıyaman", 37.76, 38.28),
        City("Afyonkarahisar", 38.76, 30.54), City("Ağrı", 39.72, 43.05),
        City("Aksaray", 38.37, 34.03), City("Amasya", 40.65, 35.83),
        City("Ankara", 39.93, 32.86), City("Antalya", 36.90, 30.70),
        City("Ardahan", 41.11, 42.70), City("Artvin", 41.18, 41.82),
        City("Aydın", 37.85, 27.85), City("Balıkesir", 39.65, 27.89),
        City("Bartın", 41.64, 32.34), City("Batman", 37.89, 41.13),
        City("Bayburt", 40.26, 40.23), City("Bilecik", 40.14, 29.98),
        City("Bingöl", 38.88, 40.50), City("Bitlis", 38.40, 42.11),
        City("Bolu", 40.74, 31.61), City("Burdur", 37.72, 30.29),
        City("Bursa", 40.19, 29.06), City("Çanakkale", 40.15, 26.41),
        City("Çankırı", 40.60, 33.62), City("Çorum", 40.55, 34.95),
        City("Denizli", 37.78, 29.09), City("Diyarbakır", 37.91, 40.24),
        City("Düzce", 40.84, 31.16), City("Edirne", 41.68, 26.56),
        City("Elazığ", 38.67, 39.22), City("Erzincan", 39.75, 39.49),
        City("Erzurum", 39.90, 41.27), City("Eskişehir", 39.78, 30.52),
        City("Gaziantep", 37.07, 37.38), City("Giresun", 40.91, 38.39),
        City("Gümüşhane", 40.46, 39.48), City("Hakkâri", 37.58, 43.74),
        City("Hatay", 36.20, 36.16), City("Iğdır", 39.92, 44.04),
        City("Isparta", 37.76, 30.55), City("İstanbul", 41.01, 28.98),
        City("İzmir", 38.42, 27.14), City("Kahramanmaraş", 37.58, 36.94),
        City("Karabük", 41.20, 32.63), City("Karaman", 37.18, 33.22),
        City("Kars", 40.60, 43.10), City("Kastamonu", 41.38, 33.78),
        City("Kayseri", 38.73, 35.49), City("Kırıkkale", 39.85, 33.52),
        City("Kırklareli", 41.74, 27.23), City("Kırşehir", 39.15, 34.17),
        City("Kilis", 36.72, 37.12), City("Kocaeli", 40.77, 29.92),
        City("Konya", 37.87, 32.48), City("Kütahya", 39.42, 29.98),
        City("Malatya", 38.35, 38.31), City("Manisa", 38.61, 27.43),
        City("Mardin", 37.31, 40.74), City("Mersin", 36.80, 34.64),
        City("Muğla", 37.22, 28.36), City("Muş", 38.74, 41.49),
        City("Nevşehir", 38.62, 34.71), City("Niğde", 37.97, 34.68),
        City("Ordu", 40.98, 37.88), City("Osmaniye", 37.07, 36.25),
        City("Rize", 41.02, 40.52), City("Sakarya", 40.78, 30.40),
        City("Samsun", 41.29, 36.33), City("Siirt", 37.93, 41.94),
        City("Sinop", 42.03, 35.15), City("Sivas", 39.75, 37.02),
        City("Şanlıurfa", 37.16, 38.79), City("Şırnak", 37.52, 42.46),
        City("Tekirdağ", 40.98, 27.51), City("Tokat", 40.31, 36.55),
        City("Trabzon", 41.00, 39.72), City("Tunceli", 39.11, 39.55),
        City("Uşak", 38.68, 29.41), City("Van", 38.49, 43.38),
        City("Yalova", 40.65, 29.27), City("Yozgat", 39.82, 34.81),
        City("Zonguldak", 41.45, 31.79),
        // Yurt disi / ek sehirler
        City("Lefkoşa (KKTC)", 35.19, 33.36), City("Berlin", 52.52, 13.40),
        City("Köln", 50.94, 6.96), City("Paris", 48.86, 2.35),
        City("Londra", 51.51, -0.13), City("Amsterdam", 52.37, 4.90),
        City("Bakü", 40.41, 49.87), City("Mekke", 21.42, 39.83),
        City("Medine", 24.47, 39.61), City("Kudüs", 31.77, 35.21)
    )

    fun nearest(lat: Double, lng: Double): Pair<City, Double> {
        var best = ALL[0]
        var bestD = Double.MAX_VALUE
        for (c in ALL) {
            val d = Geo.distanceKm(lat, lng, c.lat, c.lng)
            if (d < bestD) {
                bestD = d
                best = c
            }
        }
        return Pair(best, bestD)
    }
}

object Geo {
    const val KAABA_LAT = 21.4225
    const val KAABA_LNG = 39.8262

    fun distanceKm(lat1: Double, lng1: Double, lat2: Double, lng2: Double): Double {
        val r = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLng = Math.toRadians(lng2 - lng1)
        val a = sin(dLat / 2) * sin(dLat / 2) +
            cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLng / 2) * sin(dLng / 2)
        return r * 2 * atan2(sqrt(a), sqrt(1 - a))
    }

    /** Verilen konumdan Kabe'ye gercek kuzeye gore aci (0..360). */
    fun qiblaBearing(lat: Double, lng: Double): Double {
        val p1 = Math.toRadians(lat)
        val p2 = Math.toRadians(KAABA_LAT)
        val dl = Math.toRadians(KAABA_LNG - lng)
        val y = sin(dl) * cos(p2)
        val x = cos(p1) * sin(p2) - sin(p1) * cos(p2) * cos(dl)
        val deg = Math.toDegrees(atan2(y, x))
        return (deg + 360.0) % 360.0
    }
}
