@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.vakitpro.app.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.vakitpro.app.LocalHolder
import com.vakitpro.app.data.Places

/** Ilk acilis: ulke ve sehri konumdan bul ya da elle sec. */
@Composable
fun OnboardingScreen(onFinish: () -> Unit) {
    var step by remember { mutableStateOf(0) }
    if (step == 1) {
        PermissionsStep(onFinish)
        return
    }
    val onDone = { step = 1 }
    val ctx = LocalContext.current
    val holder = LocalHolder.current
    val cs = MaterialTheme.colorScheme

    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }
    var found by remember { mutableStateOf(false) }
    var picker by remember { mutableStateOf(false) }

    fun gps() {
        busy = true
        msg = null
        LocationHelper.request(ctx) { loc ->
            busy = false
            if (loc == null) {
                msg = "Konum alınamadı. Konum servisini aç ya da elle seç."
            } else {
                val r = Places.resolve(Places.load(ctx), loc.latitude, loc.longitude)
                holder.update {
                    it.copy(cityName = r.label, countryName = r.country, lat = loc.latitude, lng = loc.longitude)
                }
                msg = "${r.country} • ${r.label}"
                found = true
            }
        }
    }

    val locPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res.values.any { it }) gps() else msg = "Konum izni verilmedi. İstersen elle seçebilirsin."
    }

    Surface(Modifier.fillMaxSize(), color = cs.background) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(28.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("🌙", fontSize = 64.sp)
            Spacer(Modifier.size(12.dp))
            Text("Vakit Pro'ya hoş geldin", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Spacer(Modifier.size(8.dp))
            Text(
                "Namaz vakitlerini doğru hesaplamak için bulunduğun ülke ve şehri belirleyelim.",
                color = cs.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.size(28.dp))

            if (!found) {
                Button(
                    onClick = {
                        val fine = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION)
                        val coarse = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION)
                        if (fine == PackageManager.PERMISSION_GRANTED || coarse == PackageManager.PERMISSION_GRANTED) gps()
                        else locPerm.launch(
                            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                        )
                    },
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth()
                ) { Text(if (busy) "Konum aranıyor…" else "📡  Konumumdan bul") }
                OutlinedButton(onClick = { picker = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("🗺️  Ülke ve şehri elle seç")
                }
                TextButton(onClick = onDone) { Text("Şimdilik atla") }
            } else {
                Text("✅ Konum bulundu", color = cs.primary, fontWeight = FontWeight.Bold)
            }
            if (msg != null) {
                Spacer(Modifier.size(10.dp))
                Text(msg ?: "", textAlign = TextAlign.Center, color = if (found) cs.onSurface else cs.error)
            }
            if (found) {
                Spacer(Modifier.size(16.dp))
                Button(onClick = onDone, modifier = Modifier.fillMaxWidth()) { Text("Devam") }
                TextButton(onClick = { picker = true }) { Text("Başka bir yer seç") }
            }
            Text(
                "Daha sonra Ayarlar'dan ana şehri değiştirebilir, ikinci bir şehir ekleyebilirsin.",
                Modifier.padding(top = 18.dp),
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
        }
    }

    if (picker) {
        PlacePickerDialog(
            title = "Ana şehir",
            onPick = { country, name, la, lo ->
                holder.update { it.copy(countryName = country, cityName = name, lat = la, lng = lo) }
                picker = false
                onDone()
            },
            onDismiss = { picker = false }
        )
    }
}


/** Ikinci adim: bildirim ve pil izinleri (konum zaten ilk adimda istenir). */
@Composable
private fun PermissionsStep(onFinish: () -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    var tick by remember { mutableStateOf(0) }
    val owner = androidx.compose.ui.platform.LocalLifecycleOwner.current
    androidx.compose.runtime.DisposableEffect(owner) {
        val ob = androidx.lifecycle.LifecycleEventObserver { _, e ->
            if (e == androidx.lifecycle.Lifecycle.Event.ON_RESUME) tick++
        }
        owner.lifecycle.addObserver(ob)
        onDispose { owner.lifecycle.removeObserver(ob) }
    }
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }

    val notifOk = tick >= 0 && (
        android.os.Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        )
    val pm = ctx.getSystemService(android.content.Context.POWER_SERVICE) as android.os.PowerManager
    val battOk = tick >= 0 && pm.isIgnoringBatteryOptimizations(ctx.packageName)

    Surface(Modifier.fillMaxSize(), color = cs.background) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(28.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("🔔", fontSize = 56.sp)
            Spacer(Modifier.size(10.dp))
            Text("Son adım: izinler", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Spacer(Modifier.size(8.dp))
            Text(
                "Bildirimlerin zamanında gelmesi ve durum çubuğundaki dakikanın kaymaması için bu iki izni ver.",
                color = cs.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.size(24.dp))
            Button(
                onClick = { if (android.os.Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS) },
                enabled = !notifOk,
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (notifOk) "✅  Bildirim izni verildi" else "🔔  Bildirimlere izin ver") }
            Spacer(Modifier.size(8.dp))
            Button(
                onClick = {
                    try {
                        ctx.startActivity(
                            android.content.Intent(
                                android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                                android.net.Uri.parse("package:${ctx.packageName}")
                            ).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    } catch (_: Exception) {
                        try {
                            ctx.startActivity(
                                android.content.Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                                    .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        } catch (_: Exception) {
                        }
                    }
                },
                enabled = !battOk,
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (battOk) "✅  Pil kısıtlaması kapalı" else "🔋  Pil optimizasyonunu kapat") }
            Spacer(Modifier.size(20.dp))
            Button(onClick = onFinish, modifier = Modifier.fillMaxWidth()) { Text("Başla") }
            TextButton(onClick = onFinish) { Text("Şimdilik atla") }
        }
    }
}
