package com.vakitpro.app

import com.vakitpro.app.data.Inspire
import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.vakitpro.app.data.Prefs
import com.vakitpro.app.data.Settings
import com.vakitpro.app.notif.Refresher
import com.vakitpro.app.ui.DiscoverScreen
import com.vakitpro.app.ui.DuasScreen
import com.vakitpro.app.ui.EsmaScreen
import com.vakitpro.app.ui.HomeScreen
import com.vakitpro.app.ui.MonthlyScreen
import com.vakitpro.app.ui.OnboardingScreen
import com.vakitpro.app.ui.QiblaScreen
import com.vakitpro.app.ui.QuranScreen
import com.vakitpro.app.ui.ReligiousDaysScreen
import com.vakitpro.app.ui.SettingsScreen
import com.vakitpro.app.ui.StoriesScreen
import com.vakitpro.app.ui.TrackerScreen
import com.vakitpro.app.ui.VakitTheme
import com.vakitpro.app.ui.ZakatScreen
import com.vakitpro.app.ui.ZikirScreen
import com.vakitpro.app.ui.KazaScreen
import com.vakitpro.app.ui.LettersScreen
import com.vakitpro.app.ui.NamazGuideScreen
import com.vakitpro.app.ui.NotesScreen
import com.vakitpro.app.ui.PrayerModeScreen
import com.vakitpro.app.ui.QuizScreen
import com.vakitpro.app.ui.SplashScreen
import com.vakitpro.app.ui.WordGameScreen
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState

/** Ayarlari tutan, degisince alarm / widget / bildirimi yenileyen kucuk durum yoneticisi. */
class SettingsHolder(private val app: Context) {
    var s by mutableStateOf(Prefs.load(app))
        private set

    fun update(block: (Settings) -> Settings) {
        val n = block(s)
        s = n
        Prefs.save(app, n)
        Refresher.refreshAll(app, n.ongoing)
    }
}

val LocalHolder = staticCompositionLocalOf<SettingsHolder> { error("SettingsHolder yok") }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        takeOpenRequest(intent)
        val holder = SettingsHolder(applicationContext)
        com.vakitpro.app.ui.Lang.init(applicationContext)
        com.vakitpro.app.ui.Pro.init(applicationContext)
        com.vakitpro.app.ui.Billing.refresh(applicationContext)
        setContent {
            CompositionLocalProvider(
                LocalHolder provides holder,
                androidx.compose.ui.platform.LocalLayoutDirection provides
                    (if (com.vakitpro.app.ui.Lang.isRtl()) androidx.compose.ui.unit.LayoutDirection.Rtl else androidx.compose.ui.unit.LayoutDirection.Ltr)
            ) {
                VakitTheme(holder.s) { com.vakitpro.app.ui.AppBackdrop { App() } }
            }
        }
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        takeOpenRequest(intent)
    }

    private fun takeOpenRequest(i: android.content.Intent?) {
        if (i == null) return
        val r = i.getStringExtra("open") ?: return
        OpenRequest.focus.value = i.getStringExtra("focusText")?.let { ft ->
            com.vakitpro.app.data.Inspire(i.getIntExtra("focusKind", 0), ft, i.getStringExtra("focusSource") ?: "")
        }
        OpenRequest.route.value = r
    }

    override fun onResume() {
        super.onResume()
        Refresher.refreshAll(applicationContext, Prefs.load(applicationContext).ongoing)
    }
}

private data class Tab(val icon: Int, val label: String)

private val TABS = listOf(
    Tab(0, "Vakitler"),
    Tab(1, "Kıble"),
    Tab(2, "Zikir"),
    Tab(3, "Keşfet"),
    Tab(4, "Ayarlar")
)

@Composable
fun App() {
    val ctx = LocalContext.current
    val holder = LocalHolder.current
    val s = holder.s

    var tab by rememberSaveable { mutableIntStateOf(0) }
    var sub by rememberSaveable { mutableStateOf<String?>((ctx as? android.app.Activity)?.intent?.getStringExtra("open")) }
    val focusItem = OpenRequest.focus.value
    LaunchedEffect(OpenRequest.route.value) {
        val r = OpenRequest.route.value
        if (r != null) {
            sub = r
            OpenRequest.route.value = null
        }
    }

    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        Refresher.refreshAll(ctx.applicationContext, holder.s.ongoing)
    }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val discoverScroll = androidx.compose.foundation.rememberScrollState()
    val todayEpoch = (System.currentTimeMillis() / 86400000L).toInt()
    var splash by rememberSaveable {
        mutableStateOf(Prefs.getInt(ctx, "intro_on", 1) == 1 && Prefs.getInt(ctx, "intro_day", -1) != todayEpoch)
    }
    LaunchedEffect(Unit) { if (splash) Prefs.putInt(ctx, "intro_day", todayEpoch) }
    val pager = rememberPagerState(initialPage = tab) { 5 }
    LaunchedEffect(tab) {
        if (pager.currentPage != tab) pager.animateScrollToPage(tab)
    }
    LaunchedEffect(pager.settledPage) {
        if (tab != pager.settledPage) tab = pager.settledPage
    }
    var onboarded by rememberSaveable { mutableStateOf(Prefs.getInt(ctx, "onboarded", 0) == 1) }
    if (splash) {
        SplashScreen { splash = false }
        return
    }
    if (!onboarded) {
        OnboardingScreen(onFinish = {
            Prefs.putInt(ctx, "onboarded", 1)
            onboarded = true
        })
        return
    }

    // Pencere izni (diger uygulamalarin ustunde goster): bir kez, acilista sor
    var askOverlay by remember {
        mutableStateOf(
            s.popup && !com.vakitpro.app.notif.Notifier.canOverlay(ctx) && Prefs.getInt(ctx, "ovl_asked", 0) == 0
        )
    }
    if (askOverlay) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = {
                Prefs.putInt(ctx, "ovl_asked", 1)
                askOverlay = false
            },
            title = { Text("Vakit penceresi için izin") },
            text = {
                Text(
                    "Vakit girince resimli pencerenin ana ekranda ve kilit açılınca kendiliğinden çıkması için " +
                        "“Diğer uygulamaların üzerinde göster” iznini açman gerekiyor. Açılan sayfada Ezan Vakti Plus'i aç."
                )
            },
            confirmButton = {
                androidx.compose.material3.TextButton(onClick = {
                    Prefs.putInt(ctx, "ovl_asked", 1)
                    askOverlay = false
                    try {
                        ctx.startActivity(
                            android.content.Intent(
                                android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                android.net.Uri.parse("package:${ctx.packageName}")
                            )
                        )
                    } catch (e: Exception) {
                    }
                }) { Text("İzin ver") }
            },
            dismissButton = {
                androidx.compose.material3.TextButton(onClick = {
                    Prefs.putInt(ctx, "ovl_asked", 1)
                    askOverlay = false
                }) { Text("Şimdilik değil") }
            }
        )
    }

    BackHandler(enabled = sub != null) { sub = null }
    BackHandler(enabled = sub == null && tab != 0) { tab = 0 }

    Scaffold(
        containerColor = androidx.compose.ui.graphics.Color.Transparent,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceContainer) {
                com.vakitpro.app.ui.Nav.items().forEach { t ->
                    val selected = if (t.page != null) (tab == t.page && sub == null) else sub == t.route
                    NavigationBarItem(
                        selected = selected,
                        onClick = {
                            if (t.page != null) {
                                tab = t.page
                                sub = null
                            } else sub = t.route
                        },
                        icon = {
                            val col = if (selected) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.onSurfaceVariant
                            if (t.id == "promenu") com.vakitpro.app.ui.ProTabIcon()
                            else if (t.navIcon >= 0) com.vakitpro.app.ui.NavIcon(t.navIcon, col)
                            else com.vakitpro.app.ui.ToolIcon(t.toolIcon, 26.dp)
                        },
                        label = { Text(com.vakitpro.app.ui.Lang.tr(t.label), fontSize = 11.sp, maxLines = 1) },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer
                        )
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            val back = { sub = null }
            when (sub) {
                "esma" -> EsmaScreen(back)
                "days" -> ReligiousDaysScreen(s, back)
                "monthly" -> MonthlyScreen(s, back)
                "tracker" -> TrackerScreen(back)
                "zakat" -> ZakatScreen(back)
                "duas" -> DuasScreen(back)
                "quran" -> QuranScreen(back)
                "stories" -> StoriesScreen(-1, back, focusItem)
                "stories0" -> StoriesScreen(0, back, focusItem)
                "stories1" -> StoriesScreen(1, back, focusItem)
                "stories2" -> StoriesScreen(2, back, focusItem)
                "stories3" -> StoriesScreen(3, back, focusItem)
                "siyer" -> com.vakitpro.app.ui.SiyerScreen(back)
                "fikih" -> com.vakitpro.app.ui.FikihScreen(back)
                "kaza" -> KazaScreen(back)
                "namaz" -> NamazGuideScreen(back)
                "quiz" -> QuizScreen(back)
                "letters" -> LettersScreen(back)
                "word" -> WordGameScreen(back)
                "notes" -> NotesScreen(back)
                "mode" -> PrayerModeScreen(back)
                "pro" -> com.vakitpro.app.ui.ProScreen(back)
                "promenu" -> com.vakitpro.app.ui.ProMenuScreen(back)
                "hadis" -> com.vakitpro.app.ui.HadisScreen(back)
                "daily" -> com.vakitpro.app.ui.DailyScreen(back)
                else -> HorizontalPager(state = pager, modifier = Modifier.fillMaxSize(), beyondViewportPageCount = 0) { page ->
                    when (page) {
                        0 -> HomeScreen(s, onOpenSettings = { tab = 4 }, onOpen = { sub = it })
                        1 -> QiblaScreen(s)
                        2 -> ZikirScreen()
                        3 -> DiscoverScreen(s, discoverScroll, onOpen = { if (it == "@settings") { tab = 4; sub = null } else sub = it })
                        else -> SettingsScreen()
                    }
                }
            }
        }
    }
}

/** Bildirimden gelen "ac" istegi (hikaye vb.). Compose durumu oldugu icin yeniden olusturmada kaybolmaz. */
object OpenRequest {
    val route = mutableStateOf<String?>(null)
    val focus = mutableStateOf<Inspire?>(null)
}
