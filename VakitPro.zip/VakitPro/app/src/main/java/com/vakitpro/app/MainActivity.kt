package com.vakitpro.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.vakitpro.app.data.Prefs
import com.vakitpro.app.data.Settings
import com.vakitpro.app.notif.Refresher
import com.vakitpro.app.ui.DiscoverScreen
import com.vakitpro.app.ui.DuasScreen
import com.vakitpro.app.ui.EsmaScreen
import com.vakitpro.app.ui.HomeScreen
import com.vakitpro.app.ui.MonthlyScreen
import com.vakitpro.app.ui.OnboardingScreen
import com.vakitpro.app.ui.QiblaScreen
import com.vakitpro.app.ui.QuranScreen
import com.vakitpro.app.ui.ReligiousDaysScreen
import com.vakitpro.app.ui.SettingsScreen
import com.vakitpro.app.ui.TrackerScreen
import com.vakitpro.app.ui.VakitTheme
import com.vakitpro.app.ui.ZakatScreen
import com.vakitpro.app.ui.ZikirScreen

/** Ayarlari tutan, degisince alarm / widget / bildirimi yenileyen kucuk durum yoneticisi. */
class SettingsHolder(private val app: Context) {
    var s by mutableStateOf(Prefs.load(app))
        private set

    fun update(block: (Settings) -> Settings) {
        val n = block(s)
        s = n
        Prefs.save(app, n)
        Refresher.refreshAll(app, n.ongoing)
    }
}

val LocalHolder = staticCompositionLocalOf<SettingsHolder> { error("SettingsHolder yok") }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        val holder = SettingsHolder(applicationContext)
        setContent {
            CompositionLocalProvider(LocalHolder provides holder) {
                VakitTheme(holder.s) { App() }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        Refresher.refreshAll(applicationContext, Prefs.load(applicationContext).ongoing)
    }
}

private data class Tab(val icon: String, val label: String)

private val TABS = listOf(
    Tab("🕌", "Vakitler"),
    Tab("🧭", "Kıble"),
    Tab("📿", "Zikir"),
    Tab("✨", "Keşfet"),
    Tab("⚙️", "Ayarlar")
)

@Composable
fun App() {
    val ctx = LocalContext.current
    val holder = LocalHolder.current
    val s = holder.s

    var tab by rememberSaveable { mutableIntStateOf(0) }
    var sub by rememberSaveable { mutableStateOf<String?>(null) }

    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        Refresher.refreshAll(ctx.applicationContext, holder.s.ongoing)
    }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    var onboarded by rememberSaveable { mutableStateOf(Prefs.getInt(ctx, "onboarded", 0) == 1) }
    if (!onboarded) {
        OnboardingScreen {
            Prefs.putInt(ctx, "onboarded", 1)
            onboarded = true
        }
        return
    }

    BackHandler(enabled = sub != null) { sub = null }
    BackHandler(enabled = sub == null && tab != 0) { tab = 0 }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceContainer) {
                TABS.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i && sub == null,
                        onClick = {
                            tab = i
                            sub = null
                        },
                        icon = { Text(t.icon, fontSize = 20.sp) },
                        label = { Text(t.label, fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer
                        )
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            val back = { sub = null }
            when (sub) {
                "esma" -> EsmaScreen(back)
                "days" -> ReligiousDaysScreen(s, back)
                "monthly" -> MonthlyScreen(s, back)
                "tracker" -> TrackerScreen(back)
                "zakat" -> ZakatScreen(back)
                "duas" -> DuasScreen(back)
                "quran" -> QuranScreen(back)
                else -> when (tab) {
                    0 -> HomeScreen(s, onOpenSettings = { tab = 4 }, onOpen = { sub = it })
                    1 -> QiblaScreen(s)
                    2 -> ZikirScreen()
                    3 -> DiscoverScreen(s, onOpen = { sub = it })
                    else -> SettingsScreen()
                }
            }
        }
    }
}
