@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.vakitpro.app.ui

import android.view.HapticFeedbackConstants
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vakitpro.app.data.Prefs
import com.vakitpro.app.data.ZikirData

@Composable
fun ZikirScreen() {
    val ctx = LocalContext.current
    val view = LocalView.current
    val cs = MaterialTheme.colorScheme

    var preset by remember { mutableIntStateOf(Prefs.getInt(ctx, "z_preset", 0)) }
    var count by remember { mutableIntStateOf(Prefs.getInt(ctx, "z_count", 0)) }
    var total by remember { mutableIntStateOf(Prefs.getInt(ctx, "z_total", 0)) }
    var laps by remember { mutableIntStateOf(Prefs.getInt(ctx, "z_laps", 0)) }

    val p = ZikirData.PRESETS[preset.coerceIn(0, ZikirData.PRESETS.lastIndex)]
    val target = p.target

    fun persist() {
        Prefs.putInt(ctx, "z_preset", preset)
        Prefs.putInt(ctx, "z_count", count)
        Prefs.putInt(ctx, "z_total", total)
        Prefs.putInt(ctx, "z_laps", laps)
    }

    fun tap() {
        count += 1
        total += 1
        if (target > 0 && count >= target) {
            laps += 1
            count = 0
            view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        } else {
            view.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
        }
        persist()
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        ScreenHeader("Zikirmatik", "Dokun, say. Titreşimle hedefi haber verir.")

        Row(
            Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ZikirData.PRESETS.forEachIndexed { i, z ->
                FilterChip(
                    selected = i == preset,
                    onClick = {
                        preset = i
                        count = 0
                        persist()
                    },
                    label = { Text(z.title) }
                )
            }
        }

        if (p.arabic.isNotEmpty()) {
            Text(
                p.arabic,
                modifier = Modifier.padding(top = 18.dp),
                fontSize = 30.sp,
                fontWeight = FontWeight.Bold,
                color = cs.primary,
                textAlign = TextAlign.Center
            )
        }

        Box(
            Modifier
                .padding(top = 20.dp)
                .size(268.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(
                Modifier
                    .size(244.dp)
                    .clip(CircleShape)
                    .background(cs.primaryContainer)
                    .clickable { tap() },
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        count.toString(),
                        fontSize = 76.sp,
                        fontWeight = FontWeight.Bold,
                        color = cs.onPrimaryContainer
                    )
                    Text(
                        if (target > 0) "/ $target" else "serbest sayaç",
                        style = MaterialTheme.typography.titleMedium,
                        color = cs.onPrimaryContainer.copy(alpha = 0.7f)
                    )
                }
            }
            val progress = if (target > 0) count / target.toFloat() else 0f
            val track = cs.outlineVariant
            val bar = cs.primary
            Canvas(Modifier.fillMaxSize()) {
                val stroke = 10.dp.toPx()
                val tl = Offset(stroke / 2f, stroke / 2f)
                val sz = Size(size.width - stroke, size.height - stroke)
                drawArc(
                    color = track, startAngle = -90f, sweepAngle = 360f, useCenter = false,
                    topLeft = tl, size = sz, style = Stroke(width = stroke, cap = StrokeCap.Round)
                )
                if (progress > 0f) {
                    drawArc(
                        color = bar, startAngle = -90f, sweepAngle = 360f * progress, useCenter = false,
                        topLeft = tl, size = sz, style = Stroke(width = stroke, cap = StrokeCap.Round)
                    )
                }
            }
        }

        Row(
            Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            InfoTile("Tamamlanan tur", laps.toString(), Modifier.weight(1f))
            InfoTile("Toplam", total.toString(), Modifier.weight(1f))
        }

        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedButton(
                onClick = {
                    if (count > 0) {
                        count -= 1
                        if (total > 0) total -= 1
                        persist()
                    }
                },
                modifier = Modifier.weight(1f)
            ) { Text("↩ Geri al") }
            OutlinedButton(
                onClick = {
                    count = 0
                    laps = 0
                    total = 0
                    persist()
                },
                modifier = Modifier.weight(1f)
            ) { Text("⟲ Sıfırla") }
        }
        Spacer(Modifier.size(24.dp))
    }
}
