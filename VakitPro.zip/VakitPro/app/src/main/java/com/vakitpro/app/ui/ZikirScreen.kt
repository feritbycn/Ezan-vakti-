@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.vakitpro.app.ui

import android.view.HapticFeedbackConstants
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.foundation.layout.width
import kotlinx.coroutines.delay
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vakitpro.app.data.Prefs
import com.vakitpro.app.data.ZikirData
import java.time.LocalDate

@Suppress("DEPRECATION")
private fun buzz(ctx: android.content.Context, strong: Boolean) {
    try {
        val v: android.os.Vibrator? =
            if (android.os.Build.VERSION.SDK_INT >= 31)
                ctx.getSystemService(android.os.VibratorManager::class.java)?.defaultVibrator
            else ctx.getSystemService(android.content.Context.VIBRATOR_SERVICE) as? android.os.Vibrator
        if (strong) v?.vibrate(android.os.VibrationEffect.createWaveform(longArrayOf(0, 70, 70, 150), -1))
        else v?.vibrate(android.os.VibrationEffect.createOneShot(22, android.os.VibrationEffect.DEFAULT_AMPLITUDE))
    } catch (e: Exception) {
    }
}

private val TARGETS = listOf(0, 33, 99, 100, 500, 1000) // 0 = hedefsiz

@Composable
fun ZikirScreen() {
    val ctx = LocalContext.current
    val view = LocalView.current
    val cs = MaterialTheme.colorScheme
    val dayKey = "z_day_${LocalDate.now()}"

    var preset by remember { mutableIntStateOf(Prefs.getInt(ctx, "z_preset", 0)) }
    var count by remember { mutableIntStateOf(Prefs.getInt(ctx, "z_count", 0)) }
    var total by remember { mutableIntStateOf(Prefs.getInt(ctx, "z_total", 0)) }
    var laps by remember { mutableIntStateOf(Prefs.getInt(ctx, "z_laps", 0)) }
    var today by remember { mutableIntStateOf(Prefs.getInt(ctx, dayKey, 0)) }
    var targetOv by remember { mutableIntStateOf(Prefs.getInt(ctx, "z_target", -1)) } // -1 = hazir degeri
    var haptic by remember { mutableStateOf(Prefs.getInt(ctx, "z_haptic", 1) == 1) }
    var pressed by remember { mutableStateOf(false) }

    val p = ZikirData.PRESETS[preset.coerceIn(0, ZikirData.PRESETS.lastIndex)]
    val target = if (targetOv >= 0) targetOv else p.target
    val scale by animateFloatAsState(if (pressed) 0.94f else 1f, label = "press")
    val progress by animateFloatAsState(
        if (target > 0) count / target.toFloat() else 0f, label = "progress"
    )

    // Zikir ekraninda ekran kapanmasin
    DisposableEffect(Unit) {
        val old = view.keepScreenOn
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = old }
    }

    fun persist() {
        Prefs.putInt(ctx, "z_preset", preset)
        Prefs.putInt(ctx, "z_count", count)
        Prefs.putInt(ctx, "z_total", total)
        Prefs.putInt(ctx, "z_laps", laps)
        Prefs.putInt(ctx, dayKey, today)
    }

    fun tap() {
        // hedefe ulasinca tur +1; sonraki dokunus 1'den yeniden baslar
        count = if (target > 0 && count >= target) 1 else count + 1
        total += 1
        today += 1
        if (target > 0 && count == target) {
            laps += 1
            if (haptic) buzz(ctx, true)
        } else if (haptic) {
            buzz(ctx, false)
        }
        persist()
    }
    val tapNow by rememberUpdatedState<() -> Unit>({ tap() })

    var auto by remember { mutableStateOf(false) }
    var autoSec by remember { mutableStateOf(Prefs.getInt(ctx, "z_auto_sec", 1).toString()) }
    var autoMs by remember { mutableStateOf(Prefs.getInt(ctx, "z_auto_ms", 0).toString()) }
    val intervalMs = ((autoSec.toIntOrNull() ?: 0).coerceIn(0, 60) * 1000L +
        (autoMs.toIntOrNull() ?: 0).coerceIn(0, 999)).coerceAtLeast(50L)
    LaunchedEffect(auto, intervalMs) {
        while (auto) {
            delay(intervalMs)
            tapNow()
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        ScreenHeader("Zikirmatik", "Dokununca titreşir, hedefte uzun titreşimle tur sayar. Otomatik sayma da var.")

        Row(
            Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ZikirData.PRESETS.forEachIndexed { i, z ->
                FilterChip(
                    selected = i == preset,
                    onClick = {
                        preset = i
                        count = 0
                        targetOv = -1
                        Prefs.putInt(ctx, "z_target", -1)
                        persist()
                    },
                    label = { Text(z.title) }
                )
            }
        }

        Text(
            if (p.arabic.isNotEmpty()) p.arabic else "Serbest zikir",
            modifier = Modifier.padding(top = 18.dp, start = 16.dp, end = 16.dp),
            fontSize = 30.sp,
            fontWeight = FontWeight.Bold,
            color = cs.primary,
            textAlign = TextAlign.Center
        )
        Text(
            p.title,
            style = MaterialTheme.typography.bodyMedium,
            color = cs.onSurfaceVariant
        )

        // ------------------------------------------------ Ana sayac dairesi
        Box(
            Modifier
                .padding(top = 18.dp)
                .size(280.dp)
                .scale(scale),
            contentAlignment = Alignment.Center
        ) {
            val track = cs.outlineVariant
            val bar = cs.primary
            val glow = cs.primary.copy(alpha = 0.18f)
            Canvas(Modifier.fillMaxSize()) {
                val stroke = 12.dp.toPx()
                drawCircle(color = glow, radius = size.minDimension / 2f)
                val tl = Offset(stroke / 2f, stroke / 2f)
                val sz = Size(size.width - stroke, size.height - stroke)
                drawArc(
                    color = track, startAngle = -90f, sweepAngle = 360f, useCenter = false,
                    topLeft = tl, size = sz, style = Stroke(width = stroke, cap = StrokeCap.Round)
                )
                if (progress > 0f) {
                    drawArc(
                        color = bar, startAngle = -90f, sweepAngle = 360f * progress.coerceAtMost(1f),
                        useCenter = false, topLeft = tl, size = sz,
                        style = Stroke(width = stroke, cap = StrokeCap.Round)
                    )
                }
            }
            Box(
                Modifier
                    .size(236.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(cs.primary, cs.primary.copy(alpha = 0.78f))
                        )
                    )
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onPress = {
                                pressed = true
                                tryAwaitRelease()
                                pressed = false
                            },
                            onTap = { tap() }
                        )
                    },
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        count.toString(),
                        fontSize = 80.sp,
                        fontWeight = FontWeight.Bold,
                        color = cs.onPrimary
                    )
                    Text(
                        if (target > 0) "/ $target" else "hedefsiz",
                        style = MaterialTheme.typography.titleMedium,
                        color = cs.onPrimary.copy(alpha = 0.8f)
                    )
                    if (target > 0) {
                        Text(
                            "$laps tur",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = cs.onPrimary.copy(alpha = 0.95f)
                        )
                    }
                }
            }
        }

        // ------------------------------------------------ Hedef secimi
        Text(
            "Hedef",
            modifier = Modifier.padding(top = 14.dp),
            style = MaterialTheme.typography.labelMedium,
            color = cs.onSurfaceVariant
        )
        Row(
            Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TARGETS.forEach { t ->
                FilterChip(
                    selected = target == t && (targetOv >= 0 || p.target == t),
                    onClick = {
                        targetOv = t
                        count = 0
                        Prefs.putInt(ctx, "z_target", t)
                        persist()
                    },
                    label = { Text(if (t == 0) "∞" else t.toString()) }
                )
            }
        }

        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .clip(androidx.compose.foundation.shape.RoundedCornerShape(20.dp))
                .background(cs.surfaceContainerHigh)
                .padding(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Otomatik say", fontWeight = FontWeight.SemiBold)
                    Text(
                        "Belirlediğin aralıkta kendisi basmış gibi sayar",
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant
                    )
                }
                Switch(checked = auto, onCheckedChange = { auto = it })
            }
            Row(
                Modifier.padding(top = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = autoSec,
                    onValueChange = { v ->
                        autoSec = v.filter { it.isDigit() }.take(2)
                        Prefs.putInt(ctx, "z_auto_sec", autoSec.toIntOrNull() ?: 0)
                    },
                    label = { Text("saniye") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = autoMs,
                    onValueChange = { v ->
                        autoMs = v.filter { it.isDigit() }.take(3)
                        Prefs.putInt(ctx, "z_auto_ms", autoMs.toIntOrNull() ?: 0)
                    },
                    label = { Text("salise (ms)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
            }
            Text(
                "Aralık: ${intervalMs / 1000}.${"%03d".format(intervalMs % 1000)} sn (en az 0.050)",
                modifier = Modifier.padding(top = 6.dp),
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant
            )
        }

        Row(
            Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            InfoTile("Bugün", today.toString(), Modifier.weight(1f))
            InfoTile("Tur", laps.toString(), Modifier.weight(1f))
            InfoTile("Toplam", total.toString(), Modifier.weight(1f))
        }

        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedButton(
                onClick = {
                    if (count > 0) {
                        if (target > 0 && count == target && laps > 0) laps -= 1
                        count -= 1
                        if (total > 0) total -= 1
                        if (today > 0) today -= 1
                        persist()
                    }
                },
                modifier = Modifier.weight(1f)
            ) { GlyphLabel(Glyph.UNDO, "Geri", size = 16.dp) }
            OutlinedButton(
                onClick = {
                    haptic = !haptic
                    Prefs.putInt(ctx, "z_haptic", if (haptic) 1 else 0)
                },
                modifier = Modifier.weight(1f)
            ) { GlyphLabel(if (haptic) Glyph.VIBRATE else Glyph.BELL_OFF, if (haptic) "Açık" else "Kapalı", size = 16.dp) }
            OutlinedButton(
                onClick = {
                    count = 0
                    laps = 0
                    total = 0
                    today = 0
                    persist()
                },
                modifier = Modifier.weight(1f)
            ) { GlyphLabel(Glyph.RESET, "Sıfırla", size = 16.dp) }
        }
        Spacer(Modifier.size(24.dp))
    }
}
