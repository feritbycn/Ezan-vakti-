package com.vakitpro.app.notif

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.core.content.FileProvider
import com.vakitpro.app.data.Inspire
import java.io.File

/**
 * Bildirimdeki "Önizleme" düğmesi: hikâye ekranındaki paylaşım görselinin aynısını
 * tam ekran gösterir; "Paylaş" düğmesi bu görseli paylaşır.
 */
class SharePreviewActivity : Activity() {

    private var shareBmp: Bitmap? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val kind = intent.getIntExtra("kind", Inspire.AYET)
        val text = intent.getStringExtra("text") ?: ""
        val source = intent.getStringExtra("source") ?: ""
        val item = Inspire(kind, text, source)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            setPadding(16, 16, 16, 16)
        }
        val img = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        root.addView(img, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val close = Button(this).apply {
            text = "Kapat"
            setOnClickListener { finish() }
        }
        val share = Button(this).apply {
            text = "Paylaş"
            setOnClickListener {
                val b = shareBmp
                if (b != null) shareBitmap(this@SharePreviewActivity, b)
                else Toast.makeText(this@SharePreviewActivity, "Görsel hazırlanıyor", Toast.LENGTH_SHORT).show()
            }
        }
        row.addView(close, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(share, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(root)

        Thread {
            val b = try {
                CardArt.story(item, 0, 1080, 1920, this, true)
            } catch (e: Exception) {
                null
            }
            runOnUiThread {
                if (b != null) {
                    shareBmp = b
                    img.setImageBitmap(b)
                } else {
                    Toast.makeText(this, "Önizleme hazırlanamadı", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }

    companion object {
        fun shareBitmap(ctx: Context, bmp: Bitmap) {
            try {
                val dir = File(ctx.cacheDir, "share").apply { mkdirs() }
                val f = File(dir, "paylasim_onizleme.png")
                f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "image/png"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                ctx.startActivity(Intent.createChooser(send, "Paylaş").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) {
                Toast.makeText(ctx, "Paylaşılamadı", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
