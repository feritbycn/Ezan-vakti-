package com.vakitpro.app.notif

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import androidx.core.graphics.drawable.IconCompat
import java.io.File

/** Kullanicinin sectigi resmi bildirim simgesi olarak kullanir. */
object CustomIcon {
    private const val SMALL = "custom_small.png"
    private const val LARGE = "custom_large.png"

    fun exists(ctx: Context) = File(ctx.filesDir, SMALL).exists()

    /** Resmi okur, durum cubugu icin tek renk maske ve bildirimde renkli buyuk simge uretir. */
    fun save(ctx: Context, uri: Uri): Boolean {
        return try {
            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            var sample = 1
            while (opts.outWidth / sample > 1000 || opts.outHeight / sample > 1000) sample *= 2
            val o2 = BitmapFactory.Options().apply { inSampleSize = sample }
            val src = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
                ?: return false
            // Kare kirp
            val side = minOf(src.width, src.height)
            val sq = Bitmap.createBitmap(src, (src.width - side) / 2, (src.height - side) / 2, side, side)
            val large = Bitmap.createScaledBitmap(sq, 192, 192, true)
            val small = Bitmap.createScaledBitmap(sq, 96, 96, true)

            // Maske: saydam alan varsa onu kullan, yoksa koyu kisimlar gorunur olsun
            val px = IntArray(96 * 96)
            small.getPixels(px, 0, 96, 0, 0, 96, 96)
            var transparent = 0
            for (p in px) if (Color.alpha(p) < 200) transparent++
            val useAlpha = transparent > px.size / 10
            for (i in px.indices) {
                val p = px[i]
                val a = if (useAlpha) Color.alpha(p) else {
                    val l = (0.299 * Color.red(p) + 0.587 * Color.green(p) + 0.114 * Color.blue(p)).toInt()
                    (255 - l).coerceIn(0, 255)
                }
                px[i] = Color.argb(a, 255, 255, 255)
            }
            val mask = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888)
            mask.setPixels(px, 0, 96, 0, 0, 96, 96)
            File(ctx.filesDir, SMALL).outputStream().use { mask.compress(Bitmap.CompressFormat.PNG, 100, it) }
            File(ctx.filesDir, LARGE).outputStream().use { large.compress(Bitmap.CompressFormat.PNG, 100, it) }
            true
        } catch (e: Exception) {
            false
        }
    }

    fun small(ctx: Context): IconCompat? {
        val f = File(ctx.filesDir, SMALL)
        if (!f.exists()) return null
        val b = BitmapFactory.decodeFile(f.absolutePath) ?: return null
        return IconCompat.createWithBitmap(b)
    }

    fun large(ctx: Context): Bitmap? {
        val f = File(ctx.filesDir, LARGE)
        return if (f.exists()) BitmapFactory.decodeFile(f.absolutePath) else null
    }
}
