package com.vakitpro.app.data

import android.content.Context

/**
 * Konuya gore ayetler. Konu kelimeleri bu uygulamanin kendi listesidir; Turkce meal metninde
 * kelimenin basi eslesirse ayet o konuya girer. Sonuc ilk acilista hesaplanir ve bellekte tutulur.
 */
object Topics {
    class TopicDef(val name: String, val stems: List<String>)

    /** surah: 0 tabanli sure indeksi, verse: 0 tabanli ayet indeksi. */
    class TopicHit(val surah: Int, val verse: Int, val text: String)

    /** Kelimeler sadelestirilmis (aksansiz, kucuk harf) yazilir. */
    val LIST = listOf(
        TopicDef("Namaz", listOf("namaz", "salat")),
        TopicDef("Oruç", listOf("oruc")),
        TopicDef("Zekât", listOf("zekat", "infak")),
        TopicDef("Sabır", listOf("sabr")),
        TopicDef("Takva", listOf("takva", "muttaki")),
        TopicDef("Tevbe", listOf("tevbe", "istigfar")),
        TopicDef("Dua", listOf("dua")),
        TopicDef("Kıyamet", listOf("kiyamet")),
        TopicDef("Cehennem", listOf("cehennem")),
        TopicDef("Cennet", listOf("cennet")),
        TopicDef("Ölüm", listOf("olum")),
        TopicDef("Yalan", listOf("yalan")),
        TopicDef("Adalet", listOf("adalet", "adil")),
        TopicDef("Anne ve baba", listOf("anne", "baba")),
        TopicDef("Rızık", listOf("rizik", "rizk"))
    )

    private val WORD_SPLIT = Regex("[^\\p{L}]+")

    @Volatile
    private var cache: Map<String, List<TopicHit>>? = null

    /** Konu adina gore ayetler. Ilk cagri biraz surebilir; arka planda cagirin. */
    fun index(ctx: Context): Map<String, List<TopicHit>> {
        cache?.let { return it }
        val q = Quran.load(ctx)
        val out = LinkedHashMap<String, MutableList<TopicHit>>()
        for (t in LIST) out[t.name] = ArrayList()
        for (s in q.tr.indices) {
            for (v in q.tr[s].indices) {
                val text = q.tr[s][v]
                if (text.isBlank()) continue
                val words = Quran.fold(text).split(WORD_SPLIT)
                for (t in LIST) {
                    if (t.stems.any { st -> words.any { it.startsWith(st) } }) {
                        out[t.name]!!.add(TopicHit(s, v, text))
                    }
                }
            }
        }
        val res = out.mapValues { it.value.toList() }
        cache = res
        return res
    }
}
