package com.vakitpro.app.data

import java.time.LocalDate

/** Ramazan modu: hicri 9. ay (ya da test anahtari) acikken iftar/sahur odakli gorunum. */
object Ramadan {
    class State(val active: Boolean, val day: Int, val test: Boolean)

    fun state(s: Settings, today: LocalDate): State {
        if (s.ramadanTest) return State(true, 12, true)
        if (!s.ramadanAuto) return State(false, 0, false)
        val h = Hijri.of(today, s.hijriAdj)
        return if (h.month == 9) State(true, h.day, false) else State(false, 0, false)
    }

    /** Ramazanda aksam "İftar", imsak "Sahur" olarak anilir. */
    fun label(idx: Int, ramadan: Boolean): String = when {
        ramadan && idx == 4 -> "İftar"
        ramadan && idx == 0 -> "Sahur"
        else -> Names.SHORT[idx]
    }

    fun dative(idx: Int, ramadan: Boolean): String = when {
        ramadan && idx == 4 -> "İftar'a"
        ramadan && idx == 0 -> "Sahur'a"
        else -> Names.DATIVE[idx]
    }

    class Target(val toIftar: Boolean, val timeMs: Long, val prevMs: Long)

    /**
     * Ramazan sayaci: gunduz iftara, aksamdan sonra / imsaktan once sahura kalan sure.
     * [times]: bugunun 6 vakti.
     */
    fun target(s: Settings, now: Long, times: LongArray): Target {
        if (now >= times[0] && now < times[4]) return Target(true, times[4], times[0])
        if (now < times[0]) {
            // gece yarisindan sonra: dunku aksam -> bugunku imsak
            val yest = PrayerRepo.times(s, PrayerRepo.today(now).minusDays(1))
            return Target(false, times[0], yest[4])
        }
        val next = PrayerRepo.upcoming(s, now, 12).firstOrNull { it.second == 0 }?.first ?: (times[0] + 86_400_000L)
        return Target(false, next, times[4])
    }
}
