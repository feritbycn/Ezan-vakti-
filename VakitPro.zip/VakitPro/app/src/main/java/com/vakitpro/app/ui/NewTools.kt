package com.vakitpro.app.ui

import android.speech.tts.TextToSpeech
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vakitpro.app.data.Kaza
import com.vakitpro.app.data.Prefs
import com.vakitpro.app.notif.Refresher
import com.vakitpro.app.notif.Silencer
import java.util.Locale

// ============================================================ Kaza takibi
@Composable
fun KazaScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    var days by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenHeader("Kaza namazı", "Borçlarını takip et, kıldıkça düş", onBack)
        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            val total = if (tick >= 0) Kaza.total(ctx) else 0
            ProCard {
                Text("Toplam kaza borcu", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("$total vakit", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text(
                    "Vakit girdiğinde bildirimdeki “Hayır” dersen önceki namaz buraya otomatik eklenir.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            ProCard {
                Kaza.NAMES.forEachIndexed { i, name ->
                    val c = if (tick >= 0) Kaza.get(ctx, i) else 0
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(name, fontWeight = FontWeight.SemiBold)
                            Text("$c kaldı", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        OutlinedButton(onClick = { Kaza.add(ctx, i, -1); tick++ }, enabled = c > 0) { Text("Kıldım") }
                        Spacer(Modifier.width(8.dp))
                        Button(onClick = { Kaza.add(ctx, i, 1); tick++ }) { Text("+1") }
                    }
                }
            }
            ProCard {
                Text("Toplu ekle", fontWeight = FontWeight.SemiBold)
                Text("Kaç günlük namaz borcun var? Her vakte o kadar eklenir.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.size(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = days, onValueChange = { days = it.filter { ch -> ch.isDigit() }.take(5) },
                        label = { Text("Gün") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(10.dp))
                    Button(onClick = {
                        val n = days.toIntOrNull() ?: 0
                        if (n > 0) for (i in 0..5) Kaza.add(ctx, i, n)
                        days = ""; tick++
                    }) { Text("Ekle") }
                }
            }
            TextButton(onClick = { for (i in 0..5) Kaza.set(ctx, i, 0); tick++ }) { Text("Tümünü sıfırla") }
        }
        Spacer(Modifier.size(24.dp))
    }
}

// ============================================================ Namaz & abdest rehberi
private data class Step(val title: String, val text: String, val pose: Int)

private val ABDEST = listOf(
    Step("Niyet ve besmele", "Abdest almaya niyet et, “Bismillâhirrahmânirrahîm” de.", 0),
    Step("Elleri yıka", "Ellerini bileklere kadar üç kez yıka, parmak aralarını hilâllendir.", 0),
    Step("Ağıza su ver", "Sağ elle üç kez ağzını çalkala (mazmaza).", 0),
    Step("Buruna su ver", "Üç kez burnuna su çekip temizle (istinşak).", 0),
    Step("Yüzü yıka", "Alından çene altına, kulak yumuşaklarına kadar üç kez yıka.", 0),
    Step("Kolları yıka", "Önce sağ sonra sol kolu dirseklerle beraber üç kez yıka.", 0),
    Step("Başı mesh et", "Islak elle başın dörtte birini, tercihen tamamını mesh et.", 0),
    Step("Kulakları mesh et", "Parmaklarla kulak içini, başparmakla kulak arkasını mesh et.", 0),
    Step("Ayakları yıka", "Önce sağ sonra sol ayağı topuklarla birlikte üç kez yıka, parmak aralarını ov.", 0),
    Step("Dua", "Abdest sonrası: “Eşhedü en lâ ilâhe illallâh ve eşhedü enne Muhammeden abdühû ve resûlüh.”", 0)
)

private val NAMAZ_ERKEK = listOf(
    Step("Niyet ve kıbleye dönüş", "Kıbleye dön, ayakların arası dört parmak aralıkla dur, kılacağın namaza niyet et.", 0),
    Step("Tekbir", "Eller kulak hizasına kalkar (erkekte başparmaklar kulak yumuşağına), “Allâhü ekber” denir.", 0),
    Step("Kıyam", "Sağ el sol elin üstünde göbek altında bağlanır. Sübhaneke, Euzü-Besmele, Fâtiha ve bir sure okunur.", 0),
    Step("Rükû", "“Allâhü ekber” diyerek eğilinir, eller dizlerde, sırt düz. Üç kez “Sübhâne rabbiyel azîm”.", 1),
    Step("Kavme", "“Semiallâhü limen hamideh” diyerek doğrulunur, “Rabbenâ lekel hamd” denir.", 0),
    Step("Secde", "“Allâhü ekber” ile secdeye gidilir: diz, el, burun, alın yere. Üç kez “Sübhâne rabbiyel a'lâ”.", 2),
    Step("Celse", "“Allâhü ekber” ile secdeden kalkıp kısa süre oturulur, tekrar secdeye gidilir.", 3),
    Step("Ka'de ve Tahiyyat", "İki rekâtın sonunda oturulur; Ettehiyyâtü, Allâhümme salli ve Allâhümme bârik, Rabbenâ duaları okunur.", 3),
    Step("Selam", "Önce sağa sonra sola “Esselâmü aleyküm ve rahmetullâh” diyerek namaz bitirilir.", 3)
)

private val NAMAZ_KADIN = listOf(
    Step("Niyet ve kıbleye dönüş", "Kıbleye dön, ayaklar bitişik veya çok az aralıklı dur, niyet et.", 0),
    Step("Tekbir", "Eller omuz hizasına kaldırılır, “Allâhü ekber” denir.", 0),
    Step("Kıyam", "Eller göğüs üzerinde, sağ el sol elin üstünde bağlanır. Sübhaneke, Fâtiha ve bir sure okunur.", 0),
    Step("Rükû", "Hafifçe eğilinir, eller dizlere konur ama dizler bükülmez, sırt erkekteki kadar düzlenmez.", 1),
    Step("Kavme", "Doğrulurken “Semiallâhü limen hamideh”, “Rabbenâ lekel hamd” denir.", 0),
    Step("Secde", "Kollar vücuda yakın, karın uyluğa, dirsekler yere yakın tutulur. Üç kez “Sübhâne rabbiyel a'lâ”.", 2),
    Step("Celse", "Ayaklar sağ tarafa çıkarılıp sol kalçanın üzerine oturulur.", 3),
    Step("Ka'de ve Tahiyyat", "Aynı şekilde oturulur, Ettehiyyâtü ve salavat-dualar okunur.", 3),
    Step("Selam", "Önce sağa sonra sola selam verilerek namaz tamamlanır.", 3)
)

@Composable
private fun PoseFigure(pose: Int, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val u = size.width / 100f
        fun o(x: Float, y: Float) = Offset(x * u, y * u)
        val sw = 7f * u
        fun l(a: Offset, b: Offset) = drawLine(color, a, b, strokeWidth = sw, cap = StrokeCap.Round)
        drawLine(color.copy(alpha = 0.35f), o(4f, 95f), o(96f, 95f), strokeWidth = 3f * u, cap = StrokeCap.Round)
        when (pose) {
            1 -> { // ruku
                drawCircle(color, 8f * u, o(80f, 40f))
                l(o(40f, 52f), o(70f, 44f))
                l(o(40f, 52f), o(40f, 92f))
                l(o(66f, 46f), o(44f, 74f))
            }
            2 -> { // secde
                drawCircle(color, 8f * u, o(70f, 82f))
                l(o(30f, 66f), o(62f, 84f))
                l(o(30f, 66f), o(38f, 92f))
                l(o(38f, 92f), o(12f, 92f))
                l(o(60f, 86f), o(66f, 92f))
            }
            3 -> { // oturus
                drawCircle(color, 8f * u, o(48f, 20f))
                l(o(48f, 30f), o(46f, 66f))
                l(o(46f, 66f), o(72f, 78f))
                l(o(72f, 78f), o(34f, 90f))
                l(o(48f, 42f), o(62f, 62f))
            }
            else -> { // kiyam
                drawCircle(color, 8f * u, o(50f, 14f))
                l(o(50f, 24f), o(50f, 62f))
                l(o(50f, 62f), o(44f, 92f))
                l(o(50f, 62f), o(56f, 92f))
                l(o(50f, 34f), o(62f, 48f))
                l(o(62f, 48f), o(46f, 50f))
            }
        }
    }
}

@Composable
fun NamazGuideScreen(onBack: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    val steps = when (tab) { 0 -> NAMAZ_ERKEK; 1 -> NAMAZ_KADIN; else -> ABDEST }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenHeader("Namaz rehberi", "Adım adım namaz ve abdest", onBack)
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Erkek", "Kadın", "Abdest").forEachIndexed { i, t ->
                FilterChip(selected = tab == i, onClick = { tab = i }, label = { Text(t) })
            }
        }
        Spacer(Modifier.size(10.dp))
        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            steps.forEachIndexed { i, st ->
                ProCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (tab < 2) {
                            PoseFigure(st.pose, MaterialTheme.colorScheme.primary, Modifier.size(64.dp))
                            Spacer(Modifier.width(12.dp))
                        }
                        Column(Modifier.weight(1f)) {
                            Text("${i + 1}. ${st.title}", fontWeight = FontWeight.SemiBold)
                            Text(st.text, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
            if (tab < 2) {
                Text(
                    "Duaların Arapça, okunuş ve anlamı için Keşfet > Sure ve dualar bölümüne bak. Mezhebe göre ayrıntılar değişebilir.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Spacer(Modifier.size(24.dp))
    }
}

// ============================================================ Elif-Ba
private class Harf(val ch: String, val name: String)

private val HARFLER = listOf(
    Harf("ا", "Elif"), Harf("ب", "Be"), Harf("ت", "Te"), Harf("ث", "Se"), Harf("ج", "Cim"), Harf("ح", "Ha"),
    Harf("خ", "Hı"), Harf("د", "Dal"), Harf("ذ", "Zel"), Harf("ر", "Ra"), Harf("ز", "Ze"), Harf("س", "Sin"),
    Harf("ش", "Şın"), Harf("ص", "Sad"), Harf("ض", "Dad"), Harf("ط", "Tı"), Harf("ظ", "Zı"), Harf("ع", "Ayn"),
    Harf("غ", "Gayn"), Harf("ف", "Fe"), Harf("ق", "Kaf"), Harf("ك", "Kef"), Harf("ل", "Lam"), Harf("م", "Mim"),
    Harf("ن", "Nun"), Harf("ه", "He"), Harf("و", "Vav"), Harf("ي", "Ye")
)

@Composable
fun LettersScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var sel by remember { mutableIntStateOf(0) }
    var ttsOk by remember { mutableStateOf(true) }
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    DisposableEffect(Unit) {
        var engine: TextToSpeech? = null
        engine = TextToSpeech(ctx) { st ->
            if (st == TextToSpeech.SUCCESS) {
                val r = engine?.setLanguage(Locale("ar"))
                ttsOk = r != null && r >= 0
            } else ttsOk = false
        }
        tts = engine
        onDispose { engine?.stop(); engine?.shutdown() }
    }
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Elif-Ba", "28 harf • dokun ve dinle", onBack)
        ProCard(Modifier.padding(horizontal = 16.dp).fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(HARFLER[sel].ch, fontSize = 64.sp, color = cs.primary, modifier = Modifier.width(100.dp), textAlign = TextAlign.Center)
                Column(Modifier.weight(1f)) {
                    Text(HARFLER[sel].name, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("${sel + 1}. harf", color = cs.onSurfaceVariant)
                    if (!ttsOk) Text("Cihazında Arapça ses motoru yok; sesli okuma çalışmayabilir.", style = MaterialTheme.typography.bodySmall, color = cs.error)
                }
                Button(onClick = { tts?.speak(HARFLER[sel].ch, TextToSpeech.QUEUE_FLUSH, null, "h") }) { Text("Dinle") }
            }
        }
        Spacer(Modifier.size(10.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(HARFLER.indices.toList()) { k ->
                Surface(
                    onClick = {
                        sel = k
                        tts?.speak(HARFLER[k].ch, TextToSpeech.QUEUE_FLUSH, null, "h")
                    },
                    shape = RoundedCornerShape(16.dp),
                    color = if (k == sel) cs.primaryContainer else cs.surfaceContainerHigh,
                    border = BorderStroke(1.dp, cs.outlineVariant)
                ) {
                    Column(Modifier.padding(vertical = 10.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(HARFLER[k].ch, fontSize = 30.sp)
                        Text(HARFLER[k].name, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

// ============================================================ Kelime bulmaca
private class W(val word: String, val hint: String)

private val WORDS = listOf(
    W("NAMAZ", "Günde beş vakit kılınan ibadet"), W("ABDEST", "Namazdan önce alınan temizlik"),
    W("ZEKAT", "Malın kırkta biri"), W("KURAN", "İslam'ın kutsal kitabı"),
    W("RAMAZAN", "Oruç ayı"), W("KIBLE", "Namazda yönelinen yön"), W("SECDE", "Alnın yere konulduğu duruş"),
    W("RUKU", "Namazda eğilme"), W("ORUC", "İmsak ile iftar arası yeme içme"), W("TESBIH", "Zikir çekmeye yarayan tanelerin dizisi"),
    W("EZAN", "Vaktin girdiğini bildiren çağrı"), W("CAMI", "Cemaatle namaz kılınan yer"),
    W("HAC", "Kâbe'yi ziyaret ibadeti"), W("DUA", "Allah'a yalvarma"), W("IMSAK", "Oruca başlama vakti"),
    W("IFTAR", "Akşam orucu açma"), W("SAHUR", "İmsaktan önce yenen yemek"), W("MESCID", "Küçük ibadet mekânı"),
    W("MINBER", "İmamın hutbe okuduğu yer"), W("HUTBE", "Cuma günü okunan konuşma"), W("SALAVAT", "Peygambere getirilen dua"),
    W("KABE", "Mekke'deki kutsal yapı"), W("MEDINE", "Peygamberimizin hicret ettiği şehir"), W("TEVHID", "Allah'ın birliği")
)

private fun scramble(w: String): String {
    var s: String
    var n = 0
    do { s = w.toList().shuffled().joinToString(""); n++ } while (s == w && n < 10)
    return s
}

@Composable
fun WordGameScreen(onBack: () -> Unit) {
    var round by remember { mutableIntStateOf(0) }
    val cur = remember(round) { WORDS.random() }
    val mixed = remember(round) { scramble(cur.word) }
    var guess by remember(round) { mutableStateOf("") }
    var hint by remember(round) { mutableStateOf(false) }
    var score by remember { mutableIntStateOf(0) }
    var ok by remember(round) { mutableStateOf<Boolean?>(null) }
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenHeader("Kelime bulmaca", "Harfleri sırala, kelimeyi bul", onBack)
        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Puan: $score", color = cs.onSurfaceVariant)
            ProCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                    mixed.forEach { c ->
                        Box(
                            Modifier.padding(3.dp).size(40.dp).background(cs.primaryContainer, RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) { Text(c.toString(), fontWeight = FontWeight.Bold, fontSize = 20.sp) }
                    }
                }
                Spacer(Modifier.size(8.dp))
                Text("İpucu: ${cur.hint}", color = cs.onSurfaceVariant)
                if (hint) Text("İlk harf: ${cur.word.first()}  •  ${cur.word.length} harf", fontWeight = FontWeight.SemiBold)
            }
            OutlinedTextField(
                value = guess, onValueChange = { guess = it.uppercase(Locale("tr")); ok = null },
                label = { Text("Cevabın") }, singleLine = true, modifier = Modifier.fillMaxWidth()
            )
            if (ok == false) Text("Olmadı, tekrar dene.", color = cs.error)
            if (ok == true) Text("Doğru! Mâşâallah.", color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    val norm = { x: String -> x.trim().uppercase(Locale("tr")).replace('İ', 'I').replace('Ç', 'C').replace('Ş', 'S').replace('Ğ', 'G').replace('Ü', 'U').replace('Ö', 'O') }
                    if (norm(guess) == norm(cur.word)) { ok = true; score += if (hint) 5 else 10 } else ok = false
                }, enabled = ok != true) { Text("Kontrol et") }
                OutlinedButton(onClick = { hint = true }, enabled = !hint) { Text("İpucu") }
                OutlinedButton(onClick = { round++ }) { Text(if (ok == true) "Sonraki" else "Geç") }
            }
        }
        Spacer(Modifier.size(24.dp))
    }
}

// ============================================================ Niyet ve notlar
private const val SEP = "\u001F"

@Composable
fun NotesScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var items by remember { mutableStateOf(Prefs.getStr(ctx, "notes", "").split(SEP).filter { it.isNotBlank() }) }
    var text by remember { mutableStateOf("") }
    fun save(l: List<String>) {
        items = l
        Prefs.putStr(ctx, "notes", l.joinToString(SEP))
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenHeader("Niyet ve notlar", "Fikir, dua, hedef ve öğrendiklerin", onBack)
        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(
                value = text, onValueChange = { text = it }, label = { Text("Aklındaki niyet veya not") },
                modifier = Modifier.fillMaxWidth(), minLines = 2
            )
            Button(onClick = {
                if (text.isNotBlank()) {
                    val d = java.time.LocalDate.now()
                    save(listOf("${d.dayOfMonth}.${d.monthValue}.${d.year}  •  ${text.trim().replace(SEP, " ")}") + items)
                    text = ""
                }
            }, modifier = Modifier.fillMaxWidth()) { Text("Kaydet") }
            items.forEachIndexed { i, n ->
                ProCard {
                    Text(n)
                    TextButton(onClick = { save(items.filterIndexed { k, _ -> k != i }) }) { Text("Sil") }
                }
            }
            if (items.isEmpty()) Text("Henüz not yok.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.size(24.dp))
    }
}

// ============================================================ Namaz modu (sessize al)
@Composable
fun PrayerModeScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var mins by remember { mutableIntStateOf(20) }
    var vib by remember { mutableStateOf(true) }
    var tick by remember { mutableIntStateOf(0) }
    var askAccess by remember { mutableStateOf(false) }
    val until = if (tick >= 0) Silencer.restoreAt(ctx) else 0L
    val active = until > System.currentTimeMillis()
    val hasAccess = remember(tick) { Silencer.hasPolicyAccess(ctx) }
    val cs = MaterialTheme.colorScheme

    // Ayar ekranindan donunce izin durumunu yenile
    val owner = androidx.compose.ui.platform.LocalLifecycleOwner.current
    androidx.compose.runtime.DisposableEffect(owner) {
        val obs = androidx.lifecycle.LifecycleEventObserver { _, e ->
            if (e == androidx.lifecycle.Lifecycle.Event.ON_RESUME) tick++
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    fun openAccess() {
        try {
            ctx.startActivity(
                android.content.Intent(android.provider.Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                    .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            android.widget.Toast.makeText(ctx, "Ayarlar > Bildirimler > Rahatsız Etme erişimi bölümünden izin ver.", android.widget.Toast.LENGTH_LONG).show()
        }
    }

    fun begin(vibrateOnly: Boolean) {
        val ok = Silencer.start(ctx, mins, vibrateOnly)
        Refresher.refreshAll(ctx.applicationContext, Prefs.load(ctx).ongoing)
        tick++
        android.widget.Toast.makeText(
            ctx,
            if (ok) "Namaz modu açıldı. $mins dk sonra ses geri açılır." else "Telefon sesi değiştirilemedi. Rahatsız Etme erişimini kontrol et.",
            android.widget.Toast.LENGTH_LONG
        ).show()
    }

    if (askAccess) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { askAccess = false },
            title = { Text("İzin gerekli") },
            text = { Text("Tam sessiz için “Rahatsız Etme erişimi” izni gerekir. İzin ekranını açayım mı? İzni verip geri dönünce Başlat'a tekrar bas.") },
            confirmButton = { TextButton(onClick = { askAccess = false; openAccess() }) { Text("İzin ver") } },
            dismissButton = { TextButton(onClick = { askAccess = false; vib = true; begin(true) }) { Text("Titreşimle devam et") } }
        )
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenHeader("Namaz modu", "Namaz boyunca telefon sussun", onBack)
        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            ProCard {
                Text("Süre", fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(10, 20, 30, 45, 60).forEach { m ->
                        FilterChip(selected = mins == m, onClick = { mins = m }, label = { Text("$m dk") })
                    }
                }
                Spacer(Modifier.size(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = vib, onClick = { vib = true }, label = { Text("Titreşim") })
                    FilterChip(selected = !vib, onClick = { vib = false }, label = { Text("Tam sessiz") })
                }
                if (!vib && !hasAccess) {
                    Text(
                        "Tam sessiz için “Rahatsız Etme erişimi” izni gerekir.",
                        style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant
                    )
                    OutlinedButton(onClick = { openAccess() }) { Text("Rahatsız Etme erişimini aç") }
                } else if (!vib) {
                    Text("İzin verildi. Telefon tamamen sessize alınır.", style = MaterialTheme.typography.bodySmall, color = cs.primary)
                }
            }
            if (active) {
                ProCard {
                    Text("Namaz modu açık", fontWeight = FontWeight.Bold, color = cs.primary)
                    Text("Bitiş: ${com.vakitpro.app.data.Fmt.hm(until)}")
                }
                OutlinedButton(onClick = {
                    Silencer.restoreIfDue(ctx, true); tick++
                }, modifier = Modifier.fillMaxWidth()) { Text("Şimdi bitir ve sesi geri aç") }
            } else {
                Button(onClick = {
                    if (!vib && !Silencer.hasPolicyAccess(ctx)) askAccess = true else begin(vib)
                }, modifier = Modifier.fillMaxWidth()) { Text("Başlat") }
            }
        }
        Spacer(Modifier.size(24.dp))
    }
}
