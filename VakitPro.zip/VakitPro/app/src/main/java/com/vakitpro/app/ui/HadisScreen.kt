package com.vakitpro.app.ui

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.CompositionLocalProvider
import com.vakitpro.app.data.Dua
import com.vakitpro.app.data.DuaData
import com.vakitpro.app.data.Hadis
import com.vakitpro.app.data.HadisBook
import com.vakitpro.app.data.HadisItem
import com.vakitpro.app.data.Quran
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

fun shareText(ctx: Context, text: String) {
    val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text + "\n\n— NurVakit")
    ctx.startActivity(Intent.createChooser(send, "Paylaş").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

private const val PAGE = 30
private const val FAV = -1

@Composable
fun HadisScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    var books by remember { mutableStateOf<List<HadisBook>>(emptyList()) }
    var tab by rememberSaveable { mutableIntStateOf(1) }
    var query by rememberSaveable { mutableStateOf("") }
    var items by remember { mutableStateOf<List<HadisItem>>(emptyList()) }
    var more by remember { mutableStateOf(false) }
    var read by remember { mutableStateOf<Set<Long>>(emptySet()) }
    var fav by remember { mutableStateOf<Set<Long>>(emptySet()) }
    var counts by remember { mutableStateOf<Map<Int, Int>>(emptyMap()) }

    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            books = Hadis.books(ctx)
            read = Hadis.readIds(ctx)
            fav = Hadis.favIds(ctx)
            counts = Hadis.readCounts(ctx)
        }
    }
    LaunchedEffect(tab, query, fav.size) {
        val r = withContext(Dispatchers.IO) {
            when {
                query.trim().length >= 2 -> Hadis.search(ctx, query, if (tab == FAV) 0 else tab, PAGE * 4)
                tab == FAV -> Hadis.byIds(ctx, fav.toList())
                else -> Hadis.list(ctx, tab, 0, PAGE)
            }
        }
        items = r
        more = query.trim().length < 2 && tab != FAV && r.size == PAGE
    }

    fun toggle(h: HadisItem, col: String) {
        val on = if (col == "rd") h.id !in read else h.id !in fav
        Hadis.setFlag(ctx, h, col, on)
        if (col == "rd") {
            read = if (on) read + h.id else read - h.id
            counts = Hadis.readCounts(ctx)
        } else fav = if (on) fav + h.id else fav - h.id
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Hadisler", "Kütüb-i Sitte", onBack = onBack)
        LazyRow(
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(books) { b ->
                FilterChip(selected = tab == b.id, onClick = { tab = b.id }, label = { Text(b.name) })
            }
            item { FilterChip(selected = tab == FAV, onClick = { tab = FAV }, label = { Text("♥ Favoriler") }) }
        }
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            placeholder = { Text("Hadislerde ara") }, singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
            shape = RoundedCornerShape(16.dp)
        )
        val bk = books.firstOrNull { it.id == tab }
        if (bk != null && query.isBlank()) {
            Text(
                "${counts[bk.id] ?: 0} / ${bk.count} okundu",
                Modifier.padding(horizontal = 20.dp), color = cs.onSurfaceVariant, style = MaterialTheme.typography.labelLarge
            )
        }
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (items.isEmpty()) item {
                Text(
                    if (tab == FAV) "Henüz favorin yok. Bir hadisin altındaki ♥ düğmesiyle ekleyebilirsin." else "Sonuç yok.",
                    color = cs.onSurfaceVariant
                )
            }
            items(items, key = { it.id }) { h ->
                HadisCard(
                    h, books.firstOrNull { it.id == h.bookId }?.name ?: "",
                    isRead = h.id in read, isFav = h.id in fav,
                    onRead = { toggle(h, "rd") }, onFav = { toggle(h, "fav") }
                )
            }
            if (more) item {
                OutlinedButton(
                    onClick = {
                        val off = items.size
                        val extra = Hadis.list(ctx, tab, off, PAGE)
                        items = items + extra
                        more = extra.size == PAGE
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Daha fazla göster") }
            }
        }
    }
}

@Composable
fun HadisCard(
    h: HadisItem, bookName: String, isRead: Boolean, isFav: Boolean,
    onRead: () -> Unit, onFav: () -> Unit
) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    Surface(
        shape = RoundedCornerShape(22.dp), color = cs.surfaceContainerHigh,
        border = BorderStroke(1.dp, cs.outlineVariant)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Pill(bookName, strong = true)
                Spacer(Modifier.size(8.dp))
                if (h.numberLabel.isNotEmpty()) Text(h.numberLabel, color = cs.onSurfaceVariant, fontSize = 13.sp)
            }
            if (h.arabic.isNotBlank()) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Text(
                        h.arabic, Modifier.fillMaxWidth(), fontSize = 22.sp, lineHeight = 38.sp,
                        textAlign = TextAlign.Start
                    )
                }
            }
            Text(h.turkish, style = MaterialTheme.typography.bodyLarge, lineHeight = 24.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                FilterChip(selected = isRead, onClick = onRead, label = { Text(if (isRead) "Okundu ✓" else "Okundu") })
                FilterChip(selected = isFav, onClick = onFav, label = { Text(if (isFav) "♥ Favori" else "♡ Favori") })
                Spacer(Modifier.weight(1f))
                OutlinedButton(onClick = {
                    shareText(ctx, (if (h.arabic.isNotBlank()) h.arabic + "\n\n" else "") + h.turkish + "\n\n— $bookName ${h.numberLabel}".trimEnd())
                }) { Text("Paylaş") }
            }
        }
    }
}

// ------------------------------------------------------------------ Gunun ayeti, hadisi, duasi
private class DailyAyah(val sure: String, val no: Int, val ar: String, val tr: String)

@Composable
fun DailyScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val day = remember { java.time.LocalDate.now().toEpochDay() }
    var ayah by remember { mutableStateOf<DailyAyah?>(null) }
    var hadis by remember { mutableStateOf<HadisItem?>(null) }
    var hadisBook by remember { mutableStateOf("") }
    val dua: Dua = remember { DuaData.ALL[Math.floorMod(day, DuaData.ALL.size.toLong()).toInt()] }

    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            val q = Quran.load(ctx)
            val total = Quran.COUNTS.sum()
            var pos = Math.floorMod(day * 31L, total.toLong()).toInt()
            var s = 0
            while (pos >= Quran.COUNTS[s]) { pos -= Quran.COUNTS[s]; s++ }
            ayah = DailyAyah(Quran.NAMES[s], pos + 1, q.ar[s][pos], q.tr[s][pos])
            val h = Hadis.daily(ctx, day)
            hadis = h
            if (h != null) hadisBook = Hadis.bookName(ctx, h.bookId)
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenHeader("Günün paylaşımı", "Ayet, hadis ve dua", onBack = onBack)
        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            val a = ayah
            val h = hadis
            var fav by remember(h?.id) { mutableStateOf(false) }
            LaunchedEffect(h?.id) { if (h != null) fav = withContext(Dispatchers.IO) { Hadis.favIds(ctx).contains(h.id) } }
            DailyBlock("Günün ayeti", a?.ar, a?.tr ?: "…", a?.let { "${it.sure} Sûresi, ${it.no}. âyet" } ?: "", "ayah")
            DailyBlock(
                "Günün hadisi", h?.arabic, h?.turkish ?: "…", if (h != null) "$hadisBook ${h.numberLabel}".trim() else "", "hadis",
                favorite = if (h != null) fav else null,
                onFav = {
                    if (h != null) {
                        val nv = !fav
                        fav = nv
                        Hadis.setFlag(ctx, h, "fav", nv)
                    }
                }
            )
            DailyBlock("Günün duası", dua.arabic, dua.okunus + "\n\n" + dua.anlam, dua.title, "dua")
            Button(
                onClick = { DailyImage.shareAsync(ctx, "all") },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Hepsini tek görselde paylaş") }
            Spacer(Modifier.size(20.dp))
        }
    }
}

object DailyImage {
    fun shareAsync(ctx: Context, what: String) {
        Thread {
            try {
                com.vakitpro.app.notif.DailyShare.share(ctx, what)
            } catch (e: Exception) {
            }
        }.start()
    }
}

@Composable
private fun DailyBlock(
    title: String, arabic: String?, text: String, source: String, what: String,
    favorite: Boolean? = null, onFav: () -> Unit = {}
) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    Surface(
        shape = RoundedCornerShape(22.dp), color = cs.surfaceContainerHigh,
        border = BorderStroke(1.dp, cs.outlineVariant)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, color = cs.primary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
            if (!arabic.isNullOrBlank()) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Text(arabic, Modifier.fillMaxWidth(), fontSize = 22.sp, lineHeight = 38.sp)
                }
            }
            Text(text, style = MaterialTheme.typography.bodyLarge, lineHeight = 24.sp)
            if (source.isNotBlank()) Text("— $source", color = cs.onSurfaceVariant, fontSize = 13.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { DailyImage.shareAsync(ctx, what) }) { Text("Paylaş") }
                if (favorite != null) {
                    if (favorite) Button(onClick = onFav) { Text("Favoride") }
                    else OutlinedButton(onClick = onFav) { Text("Favoriye ekle") }
                }
            }
        }
    }
}
