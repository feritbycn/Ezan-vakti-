@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.vakitpro.app.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import com.vakitpro.app.data.Country
import com.vakitpro.app.data.Places
import com.vakitpro.app.data.Quran
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Ulke -> il/eyalet secimi. Ayrica "Konumumdan bul" dugmesi vardir. */
@Composable
fun PlacePickerDialog(
    title: String,
    onPick: (country: String, name: String, lat: Double, lng: Double) -> Unit,
    onDismiss: () -> Unit
) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme

    var data by remember { mutableStateOf<Places.Data?>(null) }
    LaunchedEffect(Unit) {
        data = withContext(Dispatchers.IO) { runCatching { Places.load(ctx) }.getOrNull() }
    }
    var country by remember { mutableStateOf<Country?>(null) }
    var q by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }

    BackHandler(enabled = country != null) {
        country = null
        q = ""
    }

    fun gps() {
        val d = data ?: return
        busy = true
        msg = null
        LocationHelper.request(ctx) { loc ->
            busy = false
            if (loc == null) {
                msg = "Konum alınamadı. Konum servisinin açık olduğundan emin ol."
            } else {
                val r = Places.resolve(d, loc.latitude, loc.longitude)
                LocationHelper.districtLabel(ctx, loc.latitude, loc.longitude, r.label) { name ->
                    onPick(r.country, name, loc.latitude, loc.longitude)
                }
            }
        }
    }

    val locPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res.values.any { it }) gps() else msg = "Konum izni verilmedi."
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = cs.background) {
            Column(Modifier.fillMaxSize()) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Spacer(Modifier.width(4.dp))
                    BackButton(onClick = {
                        if (country != null) {
                            country = null
                            q = ""
                        } else onDismiss()
                    })
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text(
                            country?.let { "${it.name} • il / bölge seç" } ?: "Önce ülkeyi seç",
                            style = MaterialTheme.typography.bodySmall,
                            color = cs.onSurfaceVariant
                        )
                    }
                }

                val d = data
                if (d == null) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Yükleniyor…") }
                } else {
                    Column(Modifier.padding(horizontal = 16.dp)) {
                        if (country == null) {
                            Button(
                                onClick = {
                                    val fine = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION)
                                    val coarse = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION)
                                    if (fine == PackageManager.PERMISSION_GRANTED || coarse == PackageManager.PERMISSION_GRANTED) gps()
                                    else locPerm.launch(
                                        arrayOf(
                                            Manifest.permission.ACCESS_FINE_LOCATION,
                                            Manifest.permission.ACCESS_COARSE_LOCATION
                                        )
                                    )
                                },
                                enabled = !busy,
                                modifier = Modifier.fillMaxWidth()
                            ) { if (busy) Text("Konum aranıyor…") else GlyphLabel(Glyph.GPS, "Konumumdan ülke ve şehri bul") }
                            if (msg != null) {
                                Text(msg ?: "", Modifier.padding(top = 6.dp), style = MaterialTheme.typography.bodySmall, color = cs.error)
                            }
                            Spacer(Modifier.size(10.dp))
                        }
                        OutlinedTextField(
                            value = q,
                            onValueChange = { q = it },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text(if (country == null) "Ülke ara…" else "İl / şehir ara…") }
                        )
                        Spacer(Modifier.size(6.dp))
                    }
                    val fq = Quran.fold(q.trim())
                    val c = country
                    LazyColumn(Modifier.fillMaxSize()) {
                        if (c == null) {
                            val list = d.countries.filter { fq.isEmpty() || Quran.fold(it.name).contains(fq) }
                            items(list, key = { it.code }) { it ->
                                Text(
                                    it.name,
                                    Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            country = it
                                            q = ""
                                        }
                                        .padding(horizontal = 20.dp, vertical = 14.dp),
                                    style = MaterialTheme.typography.bodyLarge
                                )
                                HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.4f))
                            }
                        } else {
                            if (fq.isEmpty()) {
                                item {
                                    Text(
                                        "${c.name} (merkez)",
                                        Modifier
                                            .fillMaxWidth()
                                            .clickable { onPick(c.name, c.name, c.lat, c.lng) }
                                            .padding(horizontal = 20.dp, vertical = 14.dp),
                                        style = MaterialTheme.typography.bodyLarge,
                                        color = cs.primary
                                    )
                                    HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.4f))
                                }
                            }
                            val list = (d.places[c.code] ?: emptyList()).filter { fq.isEmpty() || Quran.fold(it.name).contains(fq) }
                            items(list) { p ->
                                Text(
                                    p.name,
                                    Modifier
                                        .fillMaxWidth()
                                        .clickable { onPick(c.name, p.name, p.lat, p.lng) }
                                        .padding(horizontal = 20.dp, vertical = 14.dp),
                                    style = MaterialTheme.typography.bodyLarge
                                )
                                HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.4f))
                            }
                        }
                    }
                }
            }
        }
    }
}
