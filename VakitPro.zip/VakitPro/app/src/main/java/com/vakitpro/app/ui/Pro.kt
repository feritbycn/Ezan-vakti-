package com.vakitpro.app.ui

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate as rotateScope
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vakitpro.app.data.Prefs
import kotlin.math.cos
import kotlin.math.sin

/** Pro durumu. Gercek satin alma (Google Play Billing) baglanana kadar yerel anahtar. */
object Pro {
    var unlocked by mutableStateOf(false)
        private set
    var bg by mutableIntStateOf(0)
        private set

    fun init(ctx: Context) {
        Nav.init(ctx)
        HomeCfg.init(ctx)
        unlocked = Prefs.getInt(ctx, "pro", 0) == 1
        bg = Prefs.getInt(ctx, "pro_bg", 0)
        if (!unlocked && bg > FREE_BG) bg = 0
    }

    fun setUnlocked(ctx: Context, v: Boolean) {
        Prefs.putInt(ctx, "pro", if (v) 1 else 0)
        unlocked = v
        if (!v) {
            setBg(ctx, 0)
            setIcon(ctx, 0)
        }
    }

    fun setBg(ctx: Context, i: Int) {
        Prefs.putInt(ctx, "pro_bg", i)
        bg = i
    }

    const val FREE_BG = 1 // 0: varsayilan, 1: ucretsiz ornek

    val ICONS = listOf("Default", "Night", "Rose", "Indigo", "Coal")
    val ICON_NAMES = listOf("Zümrüt", "Gece mavisi", "Gül", "Mor", "Kömür")
    val ICON_COLORS = listOf(Color(0xFF15806A), Color(0xFF1B2A5E), Color(0xFFB03A5B), Color(0xFF6A4FC4), Color(0xFF3A3F47))

    fun setIcon(ctx: Context, idx: Int) {
        val pm = ctx.packageManager
        ICONS.forEachIndexed { i, n ->
            pm.setComponentEnabledSetting(
                ComponentName(ctx.packageName, "com.vakitpro.app.Icon$n"),
                if (i == idx) PackageManager.COMPONENT_ENABLED_STATE_ENABLED else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP
            )
        }
        Prefs.putInt(ctx, "pro_icon", idx)
    }

    class Bg(val name: String, val colors: List<Color>, val stars: Boolean)

    val BGS = listOf(
        Bg("Varsayılan", emptyList(), false),
        Bg("Zümrüt gece", listOf(Color(0xFF0E4D40), Color(0xFF062B26), Color(0xFF031512)), true),
        Bg("Gece mavisi", listOf(Color(0xFF1B2A5E), Color(0xFF0B1235), Color(0xFF050818)), true),
        Bg("Altın çöl", listOf(Color(0xFF4A3510), Color(0xFF2A1D08), Color(0xFF140E04)), false),
        Bg("Gül bahçesi", listOf(Color(0xFF5E1A33), Color(0xFF330C1C), Color(0xFF16060D)), true),
        Bg("Şafak", listOf(Color(0xFF3D2A6B), Color(0xFF7A3F5E), Color(0xFF1A1030)), true),
        Bg("Lavanta", listOf(Color(0xFF3A2F66), Color(0xFF211A42), Color(0xFF0E0B22)), true),
        Bg("Okyanus", listOf(Color(0xFF0B4A63), Color(0xFF07293A), Color(0xFF03121A)), false),
        Bg("Kabe gecesi", listOf(Color(0xFF1A1A1A), Color(0xFF0D0D0D), Color(0xFF000000)), true)
    )
}

class NavItem(val id: String, val label: String, val page: Int?, val route: String?, val navIcon: Int, val toolIcon: Int)

/** Alt menu: Vakitler ve Kesfet sabit, aradaki 3 yuva Pro ile degistirilebilir. */
object Nav {
    val OPTIONS = listOf(
        NavItem("hadis", "Hadisler", null, "hadis", -1, 9),
        NavItem("daily", "Günün", null, "daily", -1, 9),
        NavItem("qibla", "Kıble", 1, null, 1, -1),
        NavItem("zikir", "Zikir", 2, null, 2, -1),
        NavItem("settings", "Ayarlar", 4, null, 4, -1),
        NavItem("kaza", "Kaza", null, "kaza", -1, 0),
        NavItem("namaz", "Namaz rehberi", null, "namaz", -1, 1),
        NavItem("quiz", "Yarışma", null, "quiz", -1, 2),
        NavItem("letters", "Elif-Ba", null, "letters", -1, 3),
        NavItem("notes", "Notlar", null, "notes", -1, 5),
        NavItem("mode", "Namaz modu", null, "mode", -1, 6),
        NavItem("siyer", "Siyer", null, "siyer", -1, 8)
    )
    val HOME = NavItem("home", "Vakitler", 0, null, 0, -1)
    val MORE = NavItem("more", "Keşfet", 3, null, 3, -1)
    private val DEFAULT = listOf("qibla", "zikir", "hadis")

    var slots by mutableStateOf(DEFAULT)
        private set

    fun init(ctx: Context) {
        val l = Prefs.getStr(ctx, "nav_slots", "").split(",").filter { id -> OPTIONS.any { it.id == id } }
        slots = if (l.size == 3 && l.toSet().size == 3) l else DEFAULT
    }

    fun set(ctx: Context, i: Int, id: String) {
        val l = slots.toMutableList()
        val j = l.indexOf(id)
        if (j >= 0) l[j] = l[i]
        l[i] = id
        slots = l
        Prefs.putStr(ctx, "nav_slots", l.joinToString(","))
    }

    fun reset(ctx: Context) {
        slots = DEFAULT
        Prefs.putStr(ctx, "nav_slots", DEFAULT.joinToString(","))
    }

    /** Pro degilse her zaman varsayilan. */
    fun items(): List<NavItem> {
        val ids = if (Pro.unlocked) slots else DEFAULT
        return listOf(HOME) + ids.map { id -> OPTIONS.first { it.id == id } } + MORE
    }
}

/** Ana sayfa kartlarini gizle/goster (Pro). */
object HomeCfg {
    val CARDS = listOf(
        "times" to "Günün vakitleri",
        "stories" to "Hikâye halkaları",
        "city2" to "İkinci şehir",
        "amel" to "Bugünün amel özeti",
        "event" to "Sıradaki dini gün",
        "quick" to "Hızlı erişim",
        "share" to "Paylaş"
    )
    var hidden by mutableStateOf(setOf<String>())
        private set

    fun init(ctx: Context) {
        hidden = Prefs.getStr(ctx, "home_hidden", "").split(",").filter { it.isNotEmpty() }.toSet()
    }

    fun toggle(ctx: Context, key: String) {
        hidden = if (key in hidden) hidden - key else hidden + key
        Prefs.putStr(ctx, "home_hidden", hidden.joinToString(","))
    }

    fun on(key: String) = !Pro.unlocked || key !in hidden
}

/** Uygulamanin arka plani: secili Pro resmi ya da duz tema rengi. */
@Composable
fun AppBackdrop(content: @Composable () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val b = Pro.BGS.getOrNull(Pro.bg)?.takeIf { Pro.bg > 0 && (Pro.unlocked || Pro.bg <= Pro.FREE_BG) }
    Box(Modifier.fillMaxSize().background(cs.background)) {
        if (b != null) BgCanvas(b, Modifier.fillMaxSize(), 1f)
        content()
    }
}

@Composable
fun BgCanvas(b: Pro.Bg, modifier: Modifier, density: Float) {
    Canvas(modifier) {
        drawRect(Brush.verticalGradient(b.colors))
        drawCircle(Color(0x14FFFFFF), size.minDimension * 0.55f, Offset(size.width * 0.85f, size.height * 0.12f))
        drawCircle(Color(0x0DFFFFFF), size.minDimension * 0.4f, Offset(size.width * 0.1f, size.height * 0.85f))
        if (b.stars) {
            for (i in 0 until 38) {
                val x = ((i * 7919) % 1000) / 1000f * size.width
                val y = ((i * 104729) % 1000) / 1000f * size.height
                val r = (1.2f + (i % 4) * 0.7f) * density
                drawCircle(Color(0x66FFFFFF), r, Offset(x, y))
            }
        }
    }
}

/** Ozel cizim gul: katmanli yapraklar, sap ve iki yaprak. */
@Composable
fun RoseIcon(size: Dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        val w = this.size.width
        val c = Offset(w / 2f, w * 0.43f)
        // yapraklar
        val leaf = Path().apply {
            moveTo(0f, 0f)
            quadraticBezierTo(w * 0.16f, -w * 0.12f, w * 0.3f, 0f)
            quadraticBezierTo(w * 0.16f, w * 0.1f, 0f, 0f)
        }
        listOf(1f to Offset(w * 0.5f, w * 0.82f), -1f to Offset(w * 0.5f, w * 0.8f)).forEach { (d, o) ->
            drawContext.canvas.save()
            drawContext.canvas.translate(o.x, o.y)
            drawContext.canvas.scale(d, 1f)
            drawContext.canvas.rotate(-18f)
            drawPath(leaf, Color(0xFF2E9E5B))
            drawContext.canvas.restore()
        }
        // sap
        drawLine(Color(0xFF2E7D4A), Offset(w / 2, w * 0.62f), Offset(w / 2, w * 0.97f), strokeWidth = w * 0.05f)
        // yapraklar: dis -> ic
        val layers = listOf(
            Triple(5, w * 0.40f, Color(0xFFB3123F)),
            Triple(5, w * 0.31f, Color(0xFFD42A5C)),
            Triple(4, w * 0.22f, Color(0xFFE8517F)),
            Triple(3, w * 0.14f, Color(0xFFF58AAB))
        )
        layers.forEachIndexed { li, (n, rad, col) ->
            for (i in 0 until n) {
                val ang = (360f / n) * i + li * 24f
                rotateScope(ang, c) {
                    val pw = rad * 0.95f
                    drawOval(col, Offset(c.x - pw / 2, c.y - rad), Size(pw, rad * 1.05f))
                    drawOval(Color(0x22FFFFFF), Offset(c.x - pw / 4, c.y - rad * 0.95f), Size(pw / 2, rad * 0.5f))
                }
            }
        }
        // kalp: spiral
        val sp = Path()
        var a = 0f
        var r = 0f
        sp.moveTo(c.x, c.y)
        while (a < 11f) {
            r = w * 0.012f * a
            sp.lineTo(c.x + (r * cos(a)), c.y + (r * sin(a)))
            a += 0.3f
        }
        drawPath(sp, Color(0x99880E2E), style = Stroke(width = w * 0.012f))
    }
}

private val PERKS = listOf(
    "Uygulama simgesini değiştir (5 renk)",
    "8 özel arka plan resmi",
    "Alt menüyü ve ana sayfa kartlarını kendine göre düzenle",
    "Pro rozeti",
    "Yeni araçlar ve temalar öncelikle Pro'ya"
)

@Composable
fun ProScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    var iconSel by remember { mutableIntStateOf(Prefs.getInt(ctx, "pro_icon", 0)) }
    var note by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenHeader("NurVakit Pro+", "Kişiselleştirme", onBack = onBack)
        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Surface(
                shape = RoundedCornerShape(26.dp),
                color = Color.Transparent,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    Modifier
                        .background(Brush.linearGradient(listOf(Color(0xFF15806A), Color(0xFF062B26))))
                        .padding(20.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RoseIcon(46.dp)
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text("NurVakit Pro+", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                                Text(
                                    if (Pro.unlocked) "Pro aktif" else "Kilidi aç, uygulamayı kendine göre yap",
                                    color = Color(0xCCFFFFFF), fontSize = 13.sp
                                )
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        PERKS.forEach {
                            Text("•  $it", color = Color.White, fontSize = 14.sp, modifier = Modifier.padding(vertical = 2.dp))
                        }
                        Spacer(Modifier.height(14.dp))
                        if (!Pro.unlocked) {
                            Button(
                                onClick = {
                                    // TODO: Google Play Billing satin alma akisi buraya baglanacak
                                    Pro.setUnlocked(ctx, true)
                                    note = "Test sürümü: gerçek ödeme Play Faturalandırma bağlanınca devreye girer."
                                },
                                modifier = Modifier.fillMaxWidth().height(50.dp)
                            ) { Text("Pro'yu aç", fontWeight = FontWeight.Bold) }
                        } else {
                            OutlinedButton(onClick = { Pro.setUnlocked(ctx, false); iconSel = 0 }) {
                                Text("Pro'yu kapat (test)", color = Color.White)
                            }
                        }
                        note?.let { Text(it, color = Color(0xCCFFFFFF), fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)) }
                    }
                }
            }

            SectionTitle("Alt menü")
            Text(
                "Vakitler ve Keşfet sabit; aradaki 3 yuvaya en çok kullandığın ekranları koy. Çıkardıkların Keşfet'te kalır.",
                fontSize = 12.sp, color = cs.onSurfaceVariant
            )
            for (slot in 0 until 3) {
                val cur = Nav.items()[slot + 1].id
                Text("Yuva ${slot + 1}", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(Nav.OPTIONS) { o ->
                        androidx.compose.material3.FilterChip(
                            selected = cur == o.id,
                            onClick = {
                                if (Pro.unlocked) Nav.set(ctx, slot, o.id) else note = "Alt menüyü düzenlemek Pro ile açılır."
                            },
                            label = { Text(o.label) }
                        )
                    }
                }
            }
            OutlinedButton(onClick = { Nav.reset(ctx) }) { Text("Varsayılana dön") }

            SectionTitle("Ana sayfa kartları")
            HomeCfg.CARDS.forEach { (key, name) ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(name, Modifier.weight(1f))
                    androidx.compose.material3.Switch(
                        checked = key !in HomeCfg.hidden,
                        onCheckedChange = {
                            if (Pro.unlocked) HomeCfg.toggle(ctx, key) else note = "Kartları düzenlemek Pro ile açılır."
                        }
                    )
                }
            }
            note?.let { Text(it, color = cs.primary, fontSize = 12.sp) }

            SectionTitle("Uygulama simgesi")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pro.ICONS.forEachIndexed { i, _ ->
                    val sel = iconSel == i
                    Column(
                        Modifier.weight(1f).clip(RoundedCornerShape(16.dp))
                            .clickable {
                                if (Pro.unlocked || i == 0) {
                                    Pro.setIcon(ctx, i); iconSel = i
                                } else note = "Bu simge Pro ile açılır."
                            },
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            Modifier.size(52.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Pro.ICON_COLORS[i], Color(0xFF05100E))))
                                .let { if (sel) it.padding(0.dp) else it },
                            contentAlignment = Alignment.Center
                        ) {
                            Text("☪", color = Color(0xFFE6C36A), fontSize = 24.sp)
                            if (sel) Box(Modifier.size(52.dp).clip(CircleShape).background(Color(0x33FFFFFF)))
                        }
                        Text(Pro.ICON_NAMES[i], fontSize = 11.sp, color = if (sel) cs.primary else cs.onSurfaceVariant)
                        if (i > 0 && !Pro.unlocked) Text("Pro", fontSize = 10.sp, color = cs.primary, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Text("Simge değişince bazı telefonlarda ana ekran birkaç saniye sonra yenilenir.", fontSize = 12.sp, color = cs.onSurfaceVariant)

            SectionTitle("Arka plan resimleri")
            Pro.BGS.chunked(2).forEachIndexed { row, pair ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    pair.forEachIndexed { j, b ->
                        val idx = row * 2 + j
                        val sel = Pro.bg == idx
                        val locked = idx > Pro.FREE_BG && !Pro.unlocked
                        Surface(
                            modifier = Modifier.weight(1f).height(120.dp).clip(RoundedCornerShape(18.dp)).clickable {
                                if (locked) note = "Bu arka plan Pro ile açılır." else Pro.setBg(ctx, idx)
                            },
                            shape = RoundedCornerShape(18.dp),
                            border = BorderStroke(if (sel) 3.dp else 1.dp, if (sel) cs.primary else cs.outlineVariant)
                        ) {
                            Box {
                                if (b.colors.isEmpty()) Box(Modifier.fillMaxSize().background(cs.surfaceContainerHigh))
                                else BgCanvas(b, Modifier.fillMaxSize(), 1.5f)
                                Text(
                                    b.name, color = if (b.colors.isEmpty()) cs.onSurface else Color.White,
                                    fontWeight = FontWeight.SemiBold, fontSize = 13.sp,
                                    modifier = Modifier.align(Alignment.BottomStart).padding(10.dp)
                                )
                                if (locked) Text("Pro", color = Color(0xFFE6C36A), fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.align(Alignment.TopEnd).padding(10.dp))
                                if (sel) Text("✓", color = Color(0xFFE6C36A), fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.align(Alignment.TopStart).padding(10.dp))
                            }
                        }
                    }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
