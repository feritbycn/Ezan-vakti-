package com.vakitpro.app.ui

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import com.vakitpro.app.R
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.drawscope.rotate as rotateScope
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vakitpro.app.LocalHolder
import com.vakitpro.app.data.Prefs
import kotlin.math.cos
import kotlin.math.sin

/** Pro durumu. Gercek satin alma (Google Play Billing) baglanana kadar yerel anahtar. */
object Pro {
    var unlocked by mutableStateOf(false)
        private set
    var bg by mutableIntStateOf(0)
        private set

    fun init(ctx: Context) {
        Nav.init(ctx)
        HomeCfg.init(ctx)
        unlocked = Prefs.getInt(ctx, "pro", 0) == 1
        bg = Prefs.getInt(ctx, "pro_bg", 0)
        if (!unlocked && bg > FREE_BG) bg = 0
    }

    fun setUnlocked(ctx: Context, v: Boolean) {
        Prefs.putInt(ctx, "pro", if (v) 1 else 0)
        unlocked = v
        if (!v) {
            setBg(ctx, 0)
            setIcon(ctx, 0)
        }
    }

    fun setBg(ctx: Context, i: Int) {
        Prefs.putInt(ctx, "pro_bg", i)
        bg = i
    }

    const val FREE_BG = 1 // 0: varsayilan, 1: ucretsiz ornek

    val ICONS = listOf("Default", "Night", "Rose", "Indigo", "Coal") + (1..20).map { "Pro%02d".format(it) }
    val ICON_NAMES = listOf("Zümrüt", "Gece mavisi", "Gül", "Mor", "Kömür") + listOf("Zümrüt Hilal", "Gece Mavisi Cami", "Bordo Mihrab", "Mor Tan Vakti", "Kömür Kıble Pusulası", "Zümrüt Fener", "Gece Denizi Hilal", "Geometrik Yıldız", "Fildişi Cami", "Bordo Tespih", "Ay Evreleri", "Turkuaz Gün Doğumu", "Kırmızı Fener", "Yeşil Mihrab", "Mor Cami Silüeti", "Mavi Geometrik Yıldız", "Gece Dalgalar Hilal", "Fildişi Mihrab", "Kabe", "Mavi Hilal Dalga")
    val ICON_RES: List<Int> = List(5) { 0 } + listOf(R.drawable.pro_icon_01, R.drawable.pro_icon_02, R.drawable.pro_icon_03, R.drawable.pro_icon_04, R.drawable.pro_icon_05, R.drawable.pro_icon_06, R.drawable.pro_icon_07, R.drawable.pro_icon_08, R.drawable.pro_icon_09, R.drawable.pro_icon_10, R.drawable.pro_icon_11, R.drawable.pro_icon_12, R.drawable.pro_icon_13, R.drawable.pro_icon_14, R.drawable.pro_icon_15, R.drawable.pro_icon_16, R.drawable.pro_icon_17, R.drawable.pro_icon_18, R.drawable.pro_icon_19, R.drawable.pro_icon_20)
    val ICON_COLORS = listOf(Color(0xFF15806A), Color(0xFF1B2A5E), Color(0xFFB03A5B), Color(0xFF6A4FC4), Color(0xFF3A3F47))

    fun setIcon(ctx: Context, idx: Int) {
        val pm = ctx.packageManager
        ICONS.forEachIndexed { i, n ->
            pm.setComponentEnabledSetting(
                ComponentName(ctx.packageName, "com.vakitpro.app.Icon$n"),
                if (i == idx) PackageManager.COMPONENT_ENABLED_STATE_ENABLED else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP
            )
        }
        Prefs.putInt(ctx, "pro_icon", idx)
    }

    class Bg(val name: String, val colors: List<Color>, val stars: Boolean, val scene: Int = 0, val photo: Int = 0)

    val BGS = listOf(
        Bg("Varsayılan", emptyList(), false),
        Bg("Zümrüt gece", listOf(Color(0xFF0E4D40), Color(0xFF062B26), Color(0xFF031512)), true),
        Bg("Gece mavisi", listOf(Color(0xFF1B2A5E), Color(0xFF0B1235), Color(0xFF050818)), true),
        Bg("Altın çöl", listOf(Color(0xFF4A3510), Color(0xFF2A1D08), Color(0xFF140E04)), false),
        Bg("Gül bahçesi", listOf(Color(0xFF5E1A33), Color(0xFF330C1C), Color(0xFF16060D)), true),
        Bg("Şafak", listOf(Color(0xFF3D2A6B), Color(0xFF7A3F5E), Color(0xFF1A1030)), true),
        Bg("Lavanta", listOf(Color(0xFF3A2F66), Color(0xFF211A42), Color(0xFF0E0B22)), true),
        Bg("Okyanus", listOf(Color(0xFF0B4A63), Color(0xFF07293A), Color(0xFF03121A)), false),
        Bg("Kabe gecesi", listOf(Color(0xFF1A1A1A), Color(0xFF0D0D0D), Color(0xFF000000)), true),
        Bg("Ayasofya", listOf(Color(0xFF0F2A55), Color(0xFFB5683A), Color(0xFFF0B76B)), true, 1),
        Bg("Sultanahmet", listOf(Color(0xFF1B1B52), Color(0xFF6C3A74), Color(0xFFE79A62)), true, 2),
        Bg("Mescid-i Nebevi", listOf(Color(0xFF041E1B), Color(0xFF0B5A4B), Color(0xFF63B79A)), true, 3),
        Bg("Kâbe", listOf(Color(0xFF05080F), Color(0xFF0E2145), Color(0xFF3B5E99)), true, 4),
        Bg("Kubbetüs-Sahra", listOf(Color(0xFF14284F), Color(0xFF3D6E9C), Color(0xFFF2C98A)), true, 5),
        Bg("Arka plan 1", listOf(Color(0xFF0E0A24), Color(0xFF1A1245)), false, 0, com.vakitpro.app.R.drawable.app_bg01),
        Bg("Arka plan 2", listOf(Color(0xFF0E0A24), Color(0xFF1A1245)), false, 0, com.vakitpro.app.R.drawable.app_bg02),
        Bg("Arka plan 3", listOf(Color(0xFF0E0A24), Color(0xFF1A1245)), false, 0, com.vakitpro.app.R.drawable.app_bg03),
        Bg("Arka plan 4", listOf(Color(0xFF0E0A24), Color(0xFF1A1245)), false, 0, com.vakitpro.app.R.drawable.app_bg04),
        Bg("Arka plan 5", listOf(Color(0xFF0E0A24), Color(0xFF1A1245)), false, 0, com.vakitpro.app.R.drawable.app_bg05),
        Bg("Arka plan 6", listOf(Color(0xFF0E0A24), Color(0xFF1A1245)), false, 0, com.vakitpro.app.R.drawable.app_bg06),
        Bg("Arka plan 7", listOf(Color(0xFF0E0A24), Color(0xFF1A1245)), false, 0, com.vakitpro.app.R.drawable.app_bg07),
        Bg("Arka plan 8", listOf(Color(0xFF0E0A24), Color(0xFF1A1245)), false, 0, com.vakitpro.app.R.drawable.app_bg08),
        Bg("Arka plan 9", listOf(Color(0xFF0E0A24), Color(0xFF1A1245)), false, 0, com.vakitpro.app.R.drawable.app_bg09),
        Bg("Arka plan 10", listOf(Color(0xFF0E0A24), Color(0xFF1A1245)), false, 0, com.vakitpro.app.R.drawable.app_bg10)
    )
}

class NavItem(val id: String, val label: String, val page: Int?, val route: String?, val navIcon: Int, val toolIcon: Int)

/** Alt menu: Vakitler ve Kesfet sabit, aradaki 3 yuva Pro ile degistirilebilir. */
object Nav {
    val OPTIONS = listOf(
        NavItem("hadis", "Hadisler", null, "hadis", -1, 9),
        NavItem("daily", "Günün", null, "daily", -1, 9),
        NavItem("qibla", "Kıble", 1, null, 1, -1),
        NavItem("zikir", "Zikir", 2, null, 2, -1),
        NavItem("settings", "Ayarlar", 4, null, 4, -1),
        NavItem("kaza", "Kaza", null, "kaza", -1, 0),
        NavItem("namaz", "Namaz rehberi", null, "namaz", -1, 1),
        NavItem("quiz", "Yarışma", null, "quiz", -1, 2),
        NavItem("letters", "Elif-Ba", null, "letters", -1, 3),
        NavItem("notes", "Notlar", null, "notes", -1, 5),
        NavItem("mode", "Namaz modu", null, "mode", -1, 6),
        NavItem("siyer", "Siyer", null, "siyer", -1, 8)
    )
    val HOME = NavItem("home", "Vakitler", 0, null, 0, -1)
    val MORE = NavItem("more", "Keşfet", 3, null, 3, -1)
    val PRO_TAB = NavItem("promenu", "Pro Menü", null, "promenu", -1, -1)
    private val DEFAULT = listOf("qibla", "zikir", "settings")

    var slots by mutableStateOf(DEFAULT)
        private set

    fun init(ctx: Context) {
        val l = Prefs.getStr(ctx, "nav_slots", "").split(",").filter { id -> OPTIONS.any { it.id == id } }
        slots = if (l.size == 3 && l.toSet().size == 3) l else DEFAULT
    }

    fun set(ctx: Context, i: Int, id: String) {
        val l = slots.toMutableList()
        val j = l.indexOf(id)
        if (j >= 0) l[j] = l[i]
        l[i] = id
        slots = l
        Prefs.putStr(ctx, "nav_slots", l.joinToString(","))
    }

    fun reset(ctx: Context) {
        slots = DEFAULT
        Prefs.putStr(ctx, "nav_slots", DEFAULT.joinToString(","))
    }

    /** Pro degilse her zaman varsayilan. */
    fun items(): List<NavItem> {
        val picked = current().map { id -> OPTIONS.first { it.id == id } }
        // Ayarlar secildiyse her zaman en sagda olur
        val base = listOf(HOME) + picked.filter { it.id != "settings" } + MORE + picked.filter { it.id == "settings" }
        // Pro Menu herkese acik: satin almayan ozellikleri ve satin almayi gorur
        return base + PRO_TAB
    }

    fun current(): List<String> = if (Pro.unlocked) slots else DEFAULT
}

/** Ana sayfa kartlarini gizle/goster (Pro). */
object HomeCfg {
    val CARDS = listOf(
        "times" to "Günün vakitleri",
        "stories" to "Hikâye halkaları",
        "city2" to "İkinci şehir",
        "amel" to "Bugünün amel özeti",
        "event" to "Sıradaki dini gün",
        "quick" to "Hızlı erişim",
        "share" to "Paylaş"
    )
    var hidden by mutableStateOf(setOf<String>())
        private set

    fun init(ctx: Context) {
        hidden = Prefs.getStr(ctx, "home_hidden", "").split(",").filter { it.isNotEmpty() }.toSet()
    }

    fun toggle(ctx: Context, key: String) {
        hidden = if (key in hidden) hidden - key else hidden + key
        Prefs.putStr(ctx, "home_hidden", hidden.joinToString(","))
    }

    fun on(key: String) = !Pro.unlocked || key !in hidden
}

/** Uygulamanin arka plani: secili Pro resmi ya da duz tema rengi.
 *  Agac yapisi her zaman ayni tutulur; aksi halde arka plan secilince App() yeniden olusur ve sayfa Vakitler'e doner. */
@Composable
fun AppBackdrop(content: @Composable () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val b = Pro.BGS.getOrNull(Pro.bg)?.takeIf { Pro.bg > 0 && (Pro.unlocked || Pro.bg <= Pro.FREE_BG) }
    val photo = b != null
    // Koyu bir fon uzerinde okunabilirlik: acik tema yerine koyu yari saydam yuzeyler ve acik yazi
    val scheme = if (!photo) cs else cs.copy(
        background = Color(0xFF0B1220),
        onBackground = Color.White,
        surface = Color(0xD9101A2C),
        onSurface = Color.White,
        surfaceVariant = Color(0xCC1B2740),
        onSurfaceVariant = Color(0xFFD5DDEB),
        surfaceContainerLowest = Color(0xD9101A2C),
        surfaceContainerLow = Color(0xD9101A2C),
        surfaceContainer = Color(0xD9131E33),
        surfaceContainerHigh = Color(0xD91A2740),
        surfaceContainerHighest = Color(0xD9223050),
        outline = Color(0xFF5A6B8C),
        outlineVariant = Color(0xFF34425E)
    )
    MaterialTheme(colorScheme = scheme) {
        androidx.compose.runtime.CompositionLocalProvider(
            androidx.compose.material3.LocalContentColor provides (if (photo) Color.White else cs.onBackground)
        ) {
            Box(Modifier.fillMaxSize().background(if (photo) Color.Transparent else cs.background)) {
                if (b != null) {
                    BgCanvas(b, Modifier.fillMaxSize(), 1f)
                    // Fotograf uzerine hafif karartma: yazilar daha net okunur
                    Box(Modifier.fillMaxSize().background(Color(0x59000000)))
                }
                content()
            }
        }
    }
}

@Composable
fun BgCanvas(b: Pro.Bg, modifier: Modifier, density: Float) {
    val ctx = LocalContext.current
    val photo = if (b.photo != 0) remember(b.photo) {
        android.graphics.BitmapFactory.decodeResource(ctx.resources, b.photo)?.asImageBitmap()
    } else null
    Canvas(modifier) {
        drawRect(Brush.verticalGradient(b.colors))
        if (photo != null) {
            // Resmi kapla (ortala, tasarsa kirp), %50 saydam
            val sc = maxOf(size.width / photo.width, size.height / photo.height)
            val dw = photo.width * sc
            val dh = photo.height * sc
            drawImage(
                photo,
                dstOffset = androidx.compose.ui.unit.IntOffset(((size.width - dw) / 2f).toInt(), ((size.height - dh) / 2f).toInt()),
                dstSize = androidx.compose.ui.unit.IntSize(dw.toInt(), dh.toInt()),
                alpha = 0.5f
            )
        }
        drawCircle(Color(0x14FFFFFF), size.minDimension * 0.55f, Offset(size.width * 0.85f, size.height * 0.12f))
        drawCircle(Color(0x0DFFFFFF), size.minDimension * 0.4f, Offset(size.width * 0.1f, size.height * 0.85f))
        if (b.scene > 0) drawScene(b.scene)
        if (b.stars) {
            for (i in 0 until 38) {
                val x = ((i * 7919) % 1000) / 1000f * size.width
                val y = ((i * 104729) % 1000) / 1000f * size.height
                val r = (1.2f + (i % 4) * 0.7f) * density
                drawCircle(Color(0x66FFFFFF), r, Offset(x, y))
            }
        }
    }
}

/** Ozel cizim gul: katmanli yapraklar, sap ve iki yaprak. */
@Composable
fun RoseIcon(size: Dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        val w = this.size.width
        val c = Offset(w / 2f, w * 0.43f)
        // yapraklar
        val leaf = Path().apply {
            moveTo(0f, 0f)
            quadraticBezierTo(w * 0.16f, -w * 0.12f, w * 0.3f, 0f)
            quadraticBezierTo(w * 0.16f, w * 0.1f, 0f, 0f)
        }
        listOf(1f to Offset(w * 0.5f, w * 0.82f), -1f to Offset(w * 0.5f, w * 0.8f)).forEach { (d, o) ->
            drawContext.canvas.save()
            drawContext.canvas.translate(o.x, o.y)
            drawContext.canvas.scale(d, 1f)
            drawContext.canvas.rotate(-18f)
            drawPath(leaf, Color(0xFF2E9E5B))
            drawContext.canvas.restore()
        }
        // sap
        drawLine(Color(0xFF2E7D4A), Offset(w / 2, w * 0.62f), Offset(w / 2, w * 0.97f), strokeWidth = w * 0.05f)
        // yapraklar: dis -> ic
        val layers = listOf(
            Triple(5, w * 0.40f, Color(0xFFB3123F)),
            Triple(5, w * 0.31f, Color(0xFFD42A5C)),
            Triple(4, w * 0.22f, Color(0xFFE8517F)),
            Triple(3, w * 0.14f, Color(0xFFF58AAB))
        )
        layers.forEachIndexed { li, (n, rad, col) ->
            for (i in 0 until n) {
                val ang = (360f / n) * i + li * 24f
                rotateScope(ang, c) {
                    val pw = rad * 0.95f
                    drawOval(col, Offset(c.x - pw / 2, c.y - rad), Size(pw, rad * 1.05f))
                    drawOval(Color(0x22FFFFFF), Offset(c.x - pw / 4, c.y - rad * 0.95f), Size(pw / 2, rad * 0.5f))
                }
            }
        }
        // kalp: spiral
        val sp = Path()
        var a = 0f
        var r = 0f
        sp.moveTo(c.x, c.y)
        while (a < 11f) {
            r = w * 0.012f * a
            sp.lineTo(c.x + (r * cos(a)), c.y + (r * sin(a)))
            a += 0.3f
        }
        drawPath(sp, Color(0x99880E2E), style = Stroke(width = w * 0.012f))
    }
}

private val PRO_FEATURES: List<Pair<Int, String>> = listOf(
    com.vakitpro.app.R.drawable.ic_pro_orb_ban to "Reklamsız deneyim",
    com.vakitpro.app.R.drawable.ic_pro_orb_image to "Arka plan resimleri",
    com.vakitpro.app.R.drawable.ic_pro_orb_palette to "Uygulama simgesi (25 seçenek)",
    com.vakitpro.app.R.drawable.ic_pro_orb_layout to "Alt menü ve ana sayfa düzeni",
    com.vakitpro.app.R.drawable.ic_pro_orb_sunset to "İftar arka planları",
    com.vakitpro.app.R.drawable.ic_pro_orb_badge to "PRO rozeti"
)

@Composable
private fun ProFeatureList(unlocked: Boolean) {
    val cs = MaterialTheme.colorScheme
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        PRO_FEATURES.forEach { (icon, title) ->
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = cs.surfaceContainer,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    androidx.compose.foundation.Image(
                        painter = androidx.compose.ui.res.painterResource(icon),
                        contentDescription = null,
                        modifier = Modifier.size(44.dp)
                    )
                    Spacer(Modifier.width(12.dp))
                    Text(title, Modifier.weight(1f), fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        if (unlocked) "Açık" else "Kilitli",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (unlocked) cs.primary else cs.onSurfaceVariant
                    )
                }
            }
        }
    }
}

/** Fiyatlar Google Play'den gelir (Billing.priceOf). Henuz yuklenmediyse "Yükleniyor" gosterilir. */
@Composable
private fun ProPlans(selected: Int, onSelect: (Int) -> Unit, onBuy: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val yearly = Billing.priceOf(Billing.YEARLY)
    val monthly = Billing.priceOf(Billing.MONTHLY)
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        PlanCard(
            sel = selected == 1,
            cs = cs,
            name = "Yıllık",
            price = yearly ?: "Yükleniyor…",
            sub = "Yıllık abonelik",
            modifier = Modifier.clickable { onSelect(1) }
        )
        PlanCard(
            sel = selected == 0,
            cs = cs,
            name = "Aylık",
            price = monthly ?: "Yükleniyor…",
            sub = null,
            modifier = Modifier.clickable { onSelect(0) }
        )
        Button(
            onClick = onBuy,
            enabled = !Billing.busy && (if (selected == 1) yearly else monthly) != null,
            modifier = Modifier.fillMaxWidth().height(50.dp)
        ) {
            Text(if (Billing.busy) "Bekleniyor…" else "Pro'yu aç", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun PlanCard(
    sel: Boolean,
    cs: androidx.compose.material3.ColorScheme,
    name: String,
    price: String,
    sub: String?,
    modifier: Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = if (sel) cs.primaryContainer else cs.surfaceContainer,
        border = BorderStroke(if (sel) 2.dp else 1.dp, if (sel) cs.primary else cs.outlineVariant)
    ) {
        Row(
            Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                if (sub != null) Text(sub, fontSize = 11.sp, color = cs.onSurfaceVariant)
            }
            Text(price, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
        }
    }
}

@Composable
fun ProScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    var iconSel by remember { mutableIntStateOf(Prefs.getInt(ctx, "pro_icon", 0)) }
    var plan by rememberSaveable { mutableIntStateOf(1) }
    LaunchedEffect(Unit) {
        Billing.loadProducts(ctx)
        Billing.refresh(ctx)
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenHeader("Pro özellikleri", "Kişiselleştirme", onBack = onBack)
        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Surface(
                shape = RoundedCornerShape(26.dp),
                color = Color.Transparent,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    Modifier
                        .background(Brush.linearGradient(listOf(Color(0xFF15806A), Color(0xFF062B26))))
                        .padding(20.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RoseIcon(46.dp)
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text("Ezan Vakti Plus Pro", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                                Text(
                                    if (Pro.unlocked) "Pro aktif" else "Kilidi aç, uygulamayı kendine göre yap",
                                    color = Color(0xCCFFFFFF), fontSize = 13.sp
                                )
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        Spacer(Modifier.height(14.dp))
                        Billing.message?.let { Text(it, color = Color(0xCCFFFFFF), fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)) }
                    }
                }
            }

            SectionTitle("Pro özellikleri")
            ProFeatureList(Pro.unlocked)
            if (!Pro.unlocked) {
                SectionTitle("Abonelik")
                ProPlans(
                    selected = plan,
                    onSelect = { plan = it },
                    onBuy = {
                        val act = ctx.findActivity()
                        val id = if (plan == 1) Billing.YEARLY else Billing.MONTHLY
                        if (act != null) Billing.buy(act, id) else Billing.message = "Satın alma başlatılamadı."
                    }
                )
            }

            Spacer(Modifier.height(24.dp))
        }
    }
}


// ------------------------------------------------------------ Cami / mekan cizimleri (ozgun vektor cizim)
private val SIL = Color(0xE6050A14)
private val LIT = Color(0xFFFFD27A)

private fun DrawScope.minaret(u: Float, x: Float, base: Float, h: Float, w: Float = 1.7f) {
    drawRect(SIL, Offset((x - w / 2) * u, (base - h) * u), Size(w * u, h * u))
    val bh = base - h * 0.72f
    drawRect(SIL, Offset((x - w * 1.5f) * u, bh * u), Size(w * 3f * u, 0.9f * u))
    drawRect(SIL, Offset((x - w * 0.95f) * u, (bh - 3f) * u), Size(w * 1.9f * u, 3f * u))
    val cap = Path().apply {
        moveTo((x - w * 1.1f) * u, (base - h) * u)
        lineTo(x * u, (base - h - 6f) * u)
        lineTo((x + w * 1.1f) * u, (base - h) * u)
        close()
    }
    drawPath(cap, SIL)
    drawLine(SIL, Offset(x * u, (base - h - 6f) * u), Offset(x * u, (base - h - 8.5f) * u), strokeWidth = 0.35f * u)
    drawCircle(LIT, 0.45f * u, Offset(x * u, (base - h - 9f) * u))
}

private fun DrawScope.dome(u: Float, cx: Float, base: Float, r: Float, col: Color = SIL, finial: Boolean = true) {
    drawArc(col, 180f, 180f, true, Offset((cx - r) * u, (base - r) * u), Size(2 * r * u, 2 * r * u))
    if (finial) {
        drawLine(col, Offset(cx * u, (base - r) * u), Offset(cx * u, (base - r - r * 0.35f) * u), strokeWidth = 0.4f * u)
        drawCircle(LIT, 0.5f * u, Offset(cx * u, (base - r - r * 0.38f) * u))
    }
}

private fun DrawScope.windows(u: Float, x0: Float, x1: Float, y: Float, n: Int) {
    for (i in 0 until n) {
        val x = x0 + (x1 - x0) * (i + 0.5f) / n
        drawRect(LIT.copy(alpha = 0.85f), Offset((x - 0.5f) * u, y * u), Size(1f * u, 2.2f * u))
    }
}

private fun DrawScope.drawScene(kind: Int) {
    val u = minOf(size.width / 100f, size.height / 75f)
    val ox = (size.width - 100f * u) / 2f
    // taban cizgisi: ekranin altindan %12 yukari
    val groundPx = size.height * 0.9f
    val g = groundPx / u
    drawContext.canvas.save()
    drawContext.canvas.translate(ox, 0f)
    // alt zemin
    drawRect(SIL, Offset(-ox, groundPx), Size(size.width, size.height - groundPx))
    when (kind) {
        1 -> { // Ayasofya
            drawRect(SIL, Offset(30f * u, (g - 12f) * u), Size(40f * u, 12f * u))
            dome(u, 50f, g - 12f, 17f)
            drawRect(SIL, Offset(33f * u, (g - 22f) * u), Size(34f * u, 10f * u))
            dome(u, 50f, g - 22f, 15f)
            dome(u, 34f, g - 12f, 9f, finial = false)
            dome(u, 66f, g - 12f, 9f, finial = false)
            drawRect(SIL, Offset(20f * u, (g - 8f) * u), Size(10f * u, 8f * u))
            drawRect(SIL, Offset(70f * u, (g - 8f) * u), Size(10f * u, 8f * u))
            windows(u, 36f, 64f, g - 21f, 9)
            minaret(u, 14f, g, 40f, 2.2f)
            minaret(u, 86f, g, 40f, 2.2f)
            minaret(u, 26f, g - 4f, 30f, 1.9f)
            minaret(u, 74f, g - 4f, 30f, 1.9f)
        }
        2 -> { // Sultanahmet (alti minare)
            drawRect(SIL, Offset(26f * u, (g - 10f) * u), Size(48f * u, 10f * u))
            dome(u, 50f, g - 10f, 15f)
            dome(u, 33f, g - 10f, 8f, finial = false)
            dome(u, 67f, g - 10f, 8f, finial = false)
            dome(u, 40f, g - 4f, 5.5f, finial = false)
            dome(u, 60f, g - 4f, 5.5f, finial = false)
            dome(u, 27f, g - 2f, 4f, finial = false)
            dome(u, 73f, g - 2f, 4f, finial = false)
            windows(u, 32f, 68f, g - 9f, 11)
            minaret(u, 18f, g, 38f); minaret(u, 82f, g, 38f)
            minaret(u, 12f, g, 30f); minaret(u, 88f, g, 30f)
            minaret(u, 22f, g, 24f, 1.5f); minaret(u, 78f, g, 24f, 1.5f)
        }
        3 -> { // Mescid-i Nebevi: yesil kubbe
            drawRect(SIL, Offset(18f * u, (g - 8f) * u), Size(64f * u, 8f * u))
            drawRect(Color(0xFF0F3B2F), Offset(41f * u, (g - 16f) * u), Size(18f * u, 8f * u))
            dome(u, 50f, g - 16f, 9f, Color(0xFF1F8A5B))
            dome(u, 30f, g - 8f, 5f, finial = false)
            dome(u, 70f, g - 8f, 5f, finial = false)
            windows(u, 20f, 80f, g - 6f, 15)
            minaret(u, 12f, g, 36f, 1.6f); minaret(u, 88f, g, 36f, 1.6f)
            minaret(u, 24f, g, 30f, 1.4f); minaret(u, 76f, g, 30f, 1.4f)
            minaret(u, 36f, g, 24f, 1.3f); minaret(u, 64f, g, 24f, 1.3f)
        }
        4 -> { // Kabe: siyah kup, altin kusak
            drawRect(Color(0xFF0A0A0C), Offset(38f * u, (g - 22f) * u), Size(24f * u, 22f * u))
            drawRect(Color(0xFFD9AE4C), Offset(38f * u, (g - 16f) * u), Size(24f * u, 1.6f * u))
            drawRect(Color(0xFFD9AE4C), Offset(47f * u, (g - 13f) * u), Size(6f * u, 6f * u))
            drawRect(Color(0xFF05060A), Offset(48.2f * u, (g - 12f) * u), Size(3.6f * u, 4.5f * u))
            // avlu duvari + ucgen sutunlar
            drawRect(SIL, Offset(5f * u, (g - 6f) * u), Size(90f * u, 6f * u))
            windows(u, 8f, 92f, g - 4.5f, 24)
            minaret(u, 10f, g - 6f, 34f, 1.5f); minaret(u, 90f, g - 6f, 34f, 1.5f)
            minaret(u, 22f, g - 6f, 26f, 1.4f); minaret(u, 78f, g - 6f, 26f, 1.4f)
        }
        5 -> { // Kubbetus-Sahra: sekizgen govde + altin kubbe
            drawRect(Color(0xFF1C4F8C), Offset(32f * u, (g - 18f) * u), Size(36f * u, 18f * u))
            drawRect(Color(0xFF0E2D54), Offset(32f * u, (g - 11f) * u), Size(36f * u, 1.1f * u))
            for (i in 0 until 7) {
                val x = 34.5f + i * 5f
                drawArc(Color(0xFF0A1E3A), 180f, 180f, true, Offset((x - 1.4f) * u, (g - 9f) * u), Size(2.8f * u, 2.8f * u))
                drawRect(Color(0xFF0A1E3A), Offset((x - 1.4f) * u, (g - 7.6f) * u), Size(2.8f * u, 7.6f * u))
            }
            drawRect(Color(0xFF1C4F8C), Offset(40f * u, (g - 24f) * u), Size(20f * u, 6f * u))
            dome(u, 50f, g - 24f, 12f, Color(0xFFE2B547))
            drawArc(Color(0x33FFFFFF), 200f, 100f, false, Offset(40f * u, (g - 35f) * u), Size(20f * u, 20f * u), style = Stroke(1.2f * u))
            minaret(u, 14f, g, 26f, 1.5f); minaret(u, 86f, g, 26f, 1.5f)
            drawRect(SIL, Offset(0f, (g - 2f) * u), Size(100f * u, 2f * u))
        }
    }
    // hilal
    if (kind != 4) {
        val moon = Path.combine(
            PathOperation.Difference,
            Path().apply { addOval(Rect(Offset(78f * u, 14f * u), 4f * u)) },
            Path().apply { addOval(Rect(Offset(79.8f * u, 13f * u), 3.5f * u)) }
        )
        drawPath(moon, Color(0xF2FFF2CF))
    }
    drawContext.canvas.restore()
}


/** Pro Menu sekmesi: alt menu yuvalari, ana sayfa kartlari, uygulama simgesi ve arka plan secimleri. */
@Composable
fun ProMenuScreen(onBack: () -> Unit) {
    // Satin almayanlar: ozellikler ve satin alma ekrani
    if (!Pro.unlocked) {
        ProScreen(onBack)
        return
    }
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val holder = LocalHolder.current
    val settings = holder.s
    var iconSel by remember { mutableIntStateOf(Prefs.getInt(ctx, "pro_icon", 0)) }
    var note by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenHeader("Pro Menü", "Kişiselleştirme", onBack = onBack)
        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            SectionTitle("Alt menü")
            Text(
                "Vakitler ve Keşfet sabit; aradaki 3 yuvaya en çok kullandığın ekranları koy. Çıkardıkların Keşfet'te kalır.",
                fontSize = 12.sp, color = cs.onSurfaceVariant
            )
            for (slot in 0 until 3) {
                val cur = Nav.current()[slot]
                Text("Yuva ${slot + 1}", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(Nav.OPTIONS) { o ->
                        androidx.compose.material3.FilterChip(
                            selected = cur == o.id,
                            onClick = {
                                if (Pro.unlocked) Nav.set(ctx, slot, o.id) else note = "Alt menüyü düzenlemek Pro ile açılır."
                            },
                            label = { Text(o.label) }
                        )
                    }
                }
            }
            OutlinedButton(onClick = { Nav.reset(ctx) }) { Text("Varsayılana dön") }

            SectionTitle("Ana sayfa kartları")
            HomeCfg.CARDS.forEach { (key, name) ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(name, Modifier.weight(1f))
                    androidx.compose.material3.Switch(
                        checked = key !in HomeCfg.hidden,
                        onCheckedChange = {
                            if (Pro.unlocked) HomeCfg.toggle(ctx, key) else note = "Kartları düzenlemek Pro ile açılır."
                        }
                    )
                }
            }
            note?.let { Text(it, color = cs.primary, fontSize = 12.sp) }

            SectionTitle("Uygulama simgesi")
            (5 until Pro.ICONS.size).toList().chunked(5).forEach { rowIdx ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    rowIdx.forEach { i ->
                        val sel = iconSel == i
                        val res = Pro.ICON_RES[i]
                        Column(
                            Modifier.weight(1f).clip(RoundedCornerShape(16.dp))
                                .clickable {
                                    Pro.setIcon(ctx, i); iconSel = i
                                },
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            if (res != 0) {
                                Image(
                                    painter = androidx.compose.ui.res.painterResource(res),
                                    contentDescription = Pro.ICON_NAMES[i],
                                    modifier = Modifier.size(52.dp).clip(CircleShape)
                                )
                            } else {
                                Box(
                                    Modifier.size(52.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Pro.ICON_COLORS[i], Color(0xFF05100E)))),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("☪", color = Color(0xFFE6C36A), fontSize = 24.sp)
                                }
                            }
                            Text(Pro.ICON_NAMES[i], fontSize = 10.sp, maxLines = 2, textAlign = TextAlign.Center, color = if (sel) cs.primary else cs.onSurfaceVariant)
                        }
                    }
                    repeat(5 - rowIdx.size) { Spacer(Modifier.weight(1f)) }
                }
            }
            Text("Simge değişince bazı telefonlarda ana ekran birkaç saniye sonra yenilenir.", fontSize = 12.sp, color = cs.onSurfaceVariant)

            SectionTitle("Arka plan resimleri")
            Pro.BGS.chunked(2).forEachIndexed { row, pair ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    pair.forEachIndexed { j, b ->
                        val idx = row * 2 + j
                        val sel = Pro.bg == idx
                        val locked = idx > Pro.FREE_BG && !Pro.unlocked
                        Surface(
                            modifier = Modifier.weight(1f).height(120.dp).clip(RoundedCornerShape(18.dp)).clickable {
                                if (locked) note = "Bu arka plan Pro ile açılır." else Pro.setBg(ctx, idx)
                            },
                            shape = RoundedCornerShape(18.dp),
                            border = BorderStroke(if (sel) 3.dp else 1.dp, if (sel) cs.primary else cs.outlineVariant)
                        ) {
                            Box {
                                if (b.colors.isEmpty()) Box(Modifier.fillMaxSize().background(cs.surfaceContainerHigh))
                                else BgCanvas(b, Modifier.fillMaxSize(), 1.5f)
                                Text(
                                    b.name, color = if (b.colors.isEmpty()) cs.onSurface else Color.White,
                                    fontWeight = FontWeight.SemiBold, fontSize = 13.sp,
                                    modifier = Modifier.align(Alignment.BottomStart).padding(10.dp)
                                )
                                if (locked) Text("Pro", color = Color(0xFFE6C36A), fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.align(Alignment.TopEnd).padding(10.dp))
                                if (sel) Text("✓", color = Color(0xFFE6C36A), fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.align(Alignment.TopStart).padding(10.dp))
                            }
                        }
                    }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
            SectionTitle("İftar kartı arka planı")
            RAM_BG_RES.chunked(3).forEachIndexed { row, chunk ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    chunk.forEachIndexed { col, res ->
                        val n = row * 3 + col + 1
                        val locked = isBgLocked(n)
                        val sel = effectiveRamBg(settings) == n
                        Box(
                            Modifier
                                .weight(1f)
                                .height(64.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .then(if (sel) Modifier.border(2.dp, cs.primary, RoundedCornerShape(12.dp)) else Modifier)
                                .clickable {
                                    if (locked) android.widget.Toast.makeText(ctx, "Bu görsel PRO sürümünde açık", android.widget.Toast.LENGTH_SHORT).show()
                                    else holder.update { it.copy(ramBg = n) }
                                }
                        ) {
                            androidx.compose.foundation.Image(
                                painter = androidx.compose.ui.res.painterResource(res),
                                contentDescription = null,
                                contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                            if (locked) {
                                Box(
                                    Modifier.matchParentSize().background(Color(0x80000000)),
                                    contentAlignment = Alignment.Center
                                ) { ProBadge() }
                            }
                        }
                    }
                    repeat(3 - chunk.size) { Spacer(Modifier.weight(1f)) }
                }
                Spacer(Modifier.height(8.dp))
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
