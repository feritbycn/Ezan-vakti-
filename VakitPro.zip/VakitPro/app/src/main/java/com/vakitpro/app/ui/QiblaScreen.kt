@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.vakitpro.app.ui

import android.content.Context
import android.graphics.Paint
import android.hardware.GeomagneticField
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.view.HapticFeedbackConstants
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.vakitpro.app.data.Geo
import com.vakitpro.app.data.Settings
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun QiblaScreen(s: Settings) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val cs = MaterialTheme.colorScheme

    val bearing = remember(s.lat, s.lng) { Geo.qiblaBearing(s.lat, s.lng).toFloat() }
    val dist = remember(s.lat, s.lng) {
        Geo.distanceKm(s.lat, s.lng, Geo.KAABA_LAT, Geo.KAABA_LNG)
    }
    var heading by remember { mutableFloatStateOf(0f) }
    var hasSensor by remember { mutableStateOf(true) }
    var lowAccuracy by remember { mutableStateOf(false) }

    DisposableEffect(s.lat, s.lng) {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensor = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        if (sensor == null) {
            hasSensor = false
            onDispose { }
        } else {
            hasSensor = true
            val decl = GeomagneticField(
                s.lat.toFloat(), s.lng.toFloat(), 0f, System.currentTimeMillis()
            ).declination
            val rot = FloatArray(9)
            val remapped = FloatArray(9)
            val ori = FloatArray(3)
            var cur = Float.NaN
            val listener = object : SensorEventListener {
                override fun onSensorChanged(e: SensorEvent) {
                    SensorManager.getRotationMatrixFromVector(rot, e.values)
                    val upright = abs(rot[7]) > 0.7f
                    if (upright) {
                        SensorManager.remapCoordinateSystem(
                            rot, SensorManager.AXIS_X, SensorManager.AXIS_Z, remapped
                        )
                        SensorManager.getOrientation(remapped, ori)
                    } else {
                        SensorManager.getOrientation(rot, ori)
                    }
                    var az = Math.toDegrees(ori[0].toDouble()).toFloat() + decl
                    az = ((az % 360f) + 360f) % 360f
                    if (cur.isNaN()) {
                        cur = az
                    } else {
                        var d = az - cur
                        while (d > 180f) d -= 360f
                        while (d < -180f) d += 360f
                        cur = (((cur + d * 0.18f) % 360f) + 360f) % 360f
                    }
                    heading = cur
                }

                override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
                    lowAccuracy = accuracy <= SensorManager.SENSOR_STATUS_ACCURACY_LOW
                }
            }
            sm.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_GAME)
            onDispose { sm.unregisterListener(listener) }
        }
    }

    val diff = ((bearing - heading + 540f) % 360f) - 180f
    val aligned = hasSensor && abs(diff) < 4f
    LaunchedEffect(aligned) {
        if (aligned) view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
    }

    val green = Color(0xFF22C55E)
    val ringColor = cs.outline
    val textColor = cs.onSurface.toArgb()
    val subColor = cs.onSurfaceVariant.toArgb()
    val accent = if (aligned) green else cs.primary
    val gold = Gold

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        ScreenHeader("Kıble Pusulası", "${s.cityName} konumuna göre")

        Canvas(
            Modifier
                .padding(top = 8.dp)
                .size(310.dp)
        ) {
            val c = center
            val r = size.minDimension / 2f - 6.dp.toPx()

            drawCircle(color = ringColor.copy(alpha = 0.5f), radius = r, style = Stroke(width = 2.dp.toPx()))
            drawCircle(
                color = if (aligned) green.copy(alpha = 0.16f) else cs.primary.copy(alpha = 0.07f),
                radius = r - 2.dp.toPx()
            )

            // Derece cizgileri (kadran, kuzeye gore doner)
            rotate(-heading, pivot = c) {
                for (a in 0 until 360 step 10) {
                    val major = a % 90 == 0
                    val len = if (major) 16.dp.toPx() else 8.dp.toPx()
                    rotate(a.toFloat(), pivot = c) {
                        drawLine(
                            color = if (major) cs.onSurface else ringColor,
                            start = Offset(c.x, c.y - r),
                            end = Offset(c.x, c.y - r + len),
                            strokeWidth = if (major) 3.dp.toPx() else 1.5.dp.toPx(),
                            cap = StrokeCap.Round
                        )
                    }
                }
                // Kible cizgisi
                rotate(bearing, pivot = c) {
                    drawLine(
                        color = if (aligned) green else gold,
                        start = c,
                        end = Offset(c.x, c.y - r + 44.dp.toPx()),
                        strokeWidth = 5.dp.toPx(),
                        cap = StrokeCap.Round
                    )
                }
            }

            // Yazilar (dik kalir)
            drawIntoCanvas { canvas ->
                val p = Paint(Paint.ANTI_ALIAS_FLAG)
                p.textAlign = Paint.Align.CENTER
                val labels = listOf("K" to 0f, "D" to 90f, "G" to 180f, "B" to 270f)
                p.textSize = 18.dp.toPx()
                p.isFakeBoldText = true
                for ((t, ang) in labels) {
                    val th = Math.toRadians((ang - heading).toDouble())
                    val rr = r - 36.dp.toPx()
                    val x = c.x + (rr * sin(th)).toFloat()
                    val y = c.y - (rr * cos(th)).toFloat() + p.textSize / 3f
                    p.color = if (t == "K") android.graphics.Color.parseColor("#EF4444") else textColor
                    canvas.nativeCanvas.drawText(t, x, y, p)
                }
                // Kabe simgesi
                val thk = Math.toRadians((bearing - heading).toDouble())
                val rk = r - 62.dp.toPx()
                p.textSize = 28.dp.toPx()
                p.isFakeBoldText = false
                p.color = textColor
                val kx = c.x + (rk * sin(thk)).toFloat()
                val ky = c.y - (rk * cos(thk)).toFloat()
                val ks = 15.dp.toPx()
                drawRoundRect(Color(0xFF1B1B1B), Offset(kx - ks, ky - ks), androidx.compose.ui.geometry.Size(2 * ks, 2 * ks), androidx.compose.ui.geometry.CornerRadius(4.dp.toPx()))
                drawRect(Color(0xFFE0B65A), Offset(kx - ks, ky - ks * 0.45f), androidx.compose.ui.geometry.Size(2 * ks, ks * 0.28f))
                drawRoundRect(Color(0xFFE0B65A), Offset(kx - ks * 0.22f, ky + ks * 0.2f), androidx.compose.ui.geometry.Size(ks * 0.44f, ks * 0.8f), androidx.compose.ui.geometry.CornerRadius(2.dp.toPx()))
            }

            // Sabit ust isaretci
            val tri = Path().apply {
                moveTo(c.x, c.y - r - 4.dp.toPx())
                lineTo(c.x - 10.dp.toPx(), c.y - r + 14.dp.toPx())
                lineTo(c.x + 10.dp.toPx(), c.y - r + 14.dp.toPx())
                close()
            }
            drawPath(tri, color = accent)
            drawCircle(color = accent, radius = 8.dp.toPx(), center = c)
            drawCircle(color = Color.White.copy(alpha = 0.9f), radius = 3.dp.toPx(), center = c)
        }

        Text(
            if (!hasSensor) "Pusula sensörü bulunamadı"
            else if (aligned) "Kıbledesin"
            else if (diff > 0) "Sağa dön  ${abs(diff).toInt()}°" else "Sola dön  ${abs(diff).toInt()}°",
            modifier = Modifier.padding(top = 8.dp),
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = if (aligned) green else cs.onSurface
        )

        Row(
            Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            InfoTile("Kıble açısı", "${bearing.toInt()}°", Modifier.weight(1f))
            InfoTile("Yönün", if (hasSensor) "${heading.toInt()}°" else "—", Modifier.weight(1f))
            InfoTile(
                "Kabe'ye",
                String.format(Locale.US, "%,.0f km", dist).replace(',', '.'),
                Modifier.weight(1f)
            )
        }

        Text(
            if (!hasSensor) "Bu cihazda dönme/pusula sensörü yok. Kıble açısını (kuzeyden saat yönünde) bir pusula ile kullanabilirsin."
            else if (lowAccuracy) "Pusula hassasiyeti düşük. Telefonu havada ∞ (sekiz) şeklinde hareket ettirerek kalibre et. Metal ve mıknatıslardan uzak tut."
            else "En iyi sonuç için telefonu yatay tut ya da dik tut; sekiz çizerek kalibre edebilirsin. Kâbe simgesini tepedeki işaretin altına getir.",
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 4.dp),
            style = MaterialTheme.typography.bodySmall,
            color = cs.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        androidx.compose.foundation.layout.Spacer(Modifier.size(24.dp))
    }
}

@Composable
fun InfoTile(label: String, value: String, modifier: Modifier = Modifier) {
    ProCard(modifier = modifier, corner = 18.dp) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    }
}
