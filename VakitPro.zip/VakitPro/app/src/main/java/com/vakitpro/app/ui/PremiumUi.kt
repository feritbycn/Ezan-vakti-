package com.vakitpro.app.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import com.vakitpro.app.R

private val TURQ = Color(0xFF34F5C5)
private val TURQ_DARK = Color(0xFF0F766E)

/** Kesfet'teki Pro satiri ikonu: kristal elmas. */
@Composable
fun PremiumRowIcon(size: Dp) {
    val t = rememberInfiniteTransition(label = "premIcon")
    val tilt by t.animateFloat(
        initialValue = -6f, targetValue = 6f,
        animationSpec = infiniteRepeatable(tween(1500, easing = LinearEasing), RepeatMode.Reverse),
        label = "tilt"
    )
    Image(
        painter = painterResource(R.drawable.ic_pro_row_diamond),
        contentDescription = null,
        modifier = Modifier.size(size).graphicsLayer { rotationZ = tilt }
    )
}

/** Kesfet'teki PRO rozeti: turkuaz gradyan, nefes, parlama suplurmesi ve kivilcim. */
@Composable
fun PremiumPill(modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "premPill")
    val breathe by t.animateFloat(
        1f, 1.06f,
        infiniteRepeatable(tween(1000, easing = LinearEasing), RepeatMode.Reverse), label = "breathe"
    )
    val glow by t.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(1000, easing = LinearEasing), RepeatMode.Reverse), label = "glow"
    )
    val sweep by t.animateFloat(
        -0.6f, 1.3f,
        infiniteRepeatable(tween(2400, easing = LinearEasing), RepeatMode.Restart), label = "sweep"
    )
    val spark by t.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(1800, easing = LinearEasing), RepeatMode.Restart), label = "spark"
    )
    Box(
        modifier
            .graphicsLayer { scaleX = breathe; scaleY = breathe }
            .shadow(elevation = (3f + 5f * glow).dp, shape = RoundedCornerShape(50), spotColor = TURQ, ambientColor = TURQ)
            .clip(RoundedCornerShape(50))
            .background(Brush.linearGradient(listOf(TURQ, TURQ_DARK)))
            .drawWithContent {
                drawContent()
                val w = size.width
                val x = sweep * w
                drawRect(
                    Brush.linearGradient(
                        listOf(Color.Transparent, Color.White.copy(alpha = 0.85f), Color.Transparent),
                        start = Offset(x - w * 0.2f, 0f),
                        end = Offset(x + w * 0.2f, 0f)
                    )
                )
            }
            .padding(horizontal = 9.dp, vertical = 6.dp)
    ) {
        Text("✦ PRO", color = Color(0xFF06231D), fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)
    }
}

/** Alt menudeki Pro Menu sekmesi: koyu turkuaz kutu, icinden isik dalgasi gecer. */
@Composable
fun ProTabIcon() {
    val t = rememberInfiniteTransition(label = "proTab")
    val wave by t.animateFloat(
        -0.6f, 1.3f,
        infiniteRepeatable(tween(2400, easing = LinearEasing), RepeatMode.Restart), label = "wave"
    )
    Box(
        Modifier
            .width(52.dp)
            .height(30.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF0A1F1B))
            .border(1.5.dp, TURQ, RoundedCornerShape(12.dp))
            .drawWithContent {
                drawContent()
                val w = size.width
                val x = wave * w
                drawRect(
                    Brush.linearGradient(
                        listOf(Color.Transparent, Color.White.copy(alpha = 0.45f), Color.Transparent),
                        start = Offset(x - w * 0.25f, 0f),
                        end = Offset(x + w * 0.25f, 0f)
                    )
                )
            },
        contentAlignment = androidx.compose.ui.Alignment.Center
    ) {
        Text("✦", color = TURQ, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}
