package com.vakitpro.app.data

import android.content.Context
import java.time.LocalDate

object Names {
    val SHORT = arrayOf("İmsak", "Güneş", "Öğle", "İkindi", "Akşam", "Yatsı")
    val DATIVE = arrayOf("İmsak'a", "Güneş'e", "Öğle'ye", "İkindi'ye", "Akşam'a", "Yatsı'ya")
    val EZAN = arrayOf(
        "İmsak vakti girdi",
        "Güneş doğdu",
        "Öğle ezanı",
        "İkindi ezanı",
        "Akşam ezanı",
        "Yatsı ezanı"
    )
    val EMOJI = arrayOf("🌌", "🌅", "☀️", "🌤️", "🌇", "🌙")
}

data class Settings(
    val cityName: String = "İstanbul",
    val lat: Double = 41.0082,
    val lng: Double = 28.9784,
    val method: String = "DIYANET",
    val hanafi: Boolean = false,
    val adj: List<Int> = listOf(0, 0, 0, 0, 0, 0),
    val ongoing: Boolean = true,
    val statusMinutes: Boolean = true,
    val liveUpdate: Boolean = false, // Android 16 canli guncelleme: sayaci durum cubugunda sistem cizer
    val preciseTick: Boolean = false, // son 60 dk'da CPU'yu uyanik tut (ikon sayaçla eşit kalsın)
    val alertMask: Int = 61, // imsak, ogle, ikindi, aksam, yatsi
    val reminderMin: Int = 0,
    val vibrate: Boolean = true,
    val soundMode: String = "default", // default | alarm | custom | ezan
    val soundUri: String = "",
    val channelVer: Int = 1,
    val theme: String = "system", // system | light | dark | amoled
    val accent: Int = 0,
    val dynamicColor: Boolean = false,
    val hijriAdj: Int = 0,
    // Vakitten once hatirlat: her vakit icin dakika (0 = kapali)
    val remind: List<Int> = listOf(0, 0, 0, 0, 0, 0),
    // Vakit girince telefonu sessize al
    val silenceOn: Boolean = false,
    val silenceMask: Int = 0,
    val silenceMins: List<Int> = listOf(20, 20, 20, 20, 20, 20),
    val silenceVibrate: Boolean = false, // true: sessiz yerine titresim modu
    // Test: durum cubugu dakika ikonunu 60 dk kalmis gibi gosterir
    val testMinutes: Boolean = false,
    // Vakit girince ana ekranda kart (pencere) ac
    val popup: Boolean = true,
    // Vakit/hatirlatma alarmini "alarm saati" olarak kur (uyutan telefonlarda kacirmaz)
    val reliableAlarm: Boolean = true,
    val countryName: String = "Türkiye",
    // Ikinci sehir (bos ad = yok)
    val city2Name: String = "",
    val lat2: Double = 0.0,
    val lng2: Double = 0.0
)

object Prefs {
    private const val FILE = "vakit_settings"

    private fun sp(ctx: Context) =
        ctx.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun load(ctx: Context): Settings {
        val p = sp(ctx)
        val d = Settings()
        val adj = (p.getString("adj", null) ?: "0,0,0,0,0,0")
            .split(",")
            .mapNotNull { it.trim().toIntOrNull() }
            .let { if (it.size == 6) it else d.adj }
        val oldRem = p.getInt("reminderMin", 0)
        val remind = (p.getString("remind", null) ?: List(6) { oldRem }.joinToString(","))
            .split(",").mapNotNull { it.trim().toIntOrNull() }
            .let { if (it.size == 6) it else d.remind }
        val silMins = (p.getString("silenceMins", null) ?: "20,20,20,20,20,20")
            .split(",").mapNotNull { it.trim().toIntOrNull() }
            .let { if (it.size == 6) it else d.silenceMins }
        return Settings(
            cityName = p.getString("cityName", d.cityName) ?: d.cityName,
            lat = p.getString("lat", null)?.toDoubleOrNull() ?: d.lat,
            lng = p.getString("lng", null)?.toDoubleOrNull() ?: d.lng,
            method = p.getString("method", d.method) ?: d.method,
            hanafi = p.getBoolean("hanafi", d.hanafi),
            adj = adj,
            ongoing = p.getBoolean("ongoing", d.ongoing),
            statusMinutes = p.getBoolean("statusMinutes", d.statusMinutes),
            preciseTick = p.getBoolean("preciseTick", d.preciseTick),
            liveUpdate = p.getBoolean("liveUpdate", d.liveUpdate),
            alertMask = p.getInt("alertMask", d.alertMask),
            reminderMin = p.getInt("reminderMin", d.reminderMin),
            vibrate = p.getBoolean("vibrate", d.vibrate),
            soundMode = p.getString("soundMode", d.soundMode) ?: d.soundMode,
            soundUri = p.getString("soundUri", "") ?: "",
            channelVer = p.getInt("channelVer", d.channelVer),
            theme = p.getString("theme", d.theme) ?: d.theme,
            accent = p.getInt("accent", d.accent),
            dynamicColor = p.getBoolean("dynamicColor", d.dynamicColor),
            hijriAdj = p.getInt("hijriAdj", d.hijriAdj),
            remind = remind,
            silenceOn = p.getBoolean("silenceOn", d.silenceOn),
            silenceMask = p.getInt("silenceMask", d.silenceMask),
            silenceMins = silMins,
            silenceVibrate = p.getBoolean("silenceVibrate", d.silenceVibrate),
            testMinutes = p.getBoolean("testMinutes", d.testMinutes),
            popup = p.getBoolean("popup", d.popup),
            reliableAlarm = p.getBoolean("reliableAlarm", d.reliableAlarm),
            countryName = p.getString("countryName", d.countryName) ?: d.countryName,
            city2Name = p.getString("city2Name", "") ?: "",
            lat2 = p.getString("lat2", null)?.toDoubleOrNull() ?: 0.0,
            lng2 = p.getString("lng2", null)?.toDoubleOrNull() ?: 0.0
        )
    }

    fun save(ctx: Context, s: Settings) {
        sp(ctx).edit()
            .putString("cityName", s.cityName)
            .putString("lat", s.lat.toString())
            .putString("lng", s.lng.toString())
            .putString("method", s.method)
            .putBoolean("hanafi", s.hanafi)
            .putString("adj", s.adj.joinToString(","))
            .putBoolean("ongoing", s.ongoing)
            .putBoolean("statusMinutes", s.statusMinutes)
            .putBoolean("preciseTick", s.preciseTick)
            .putBoolean("liveUpdate", s.liveUpdate)
            .putInt("alertMask", s.alertMask)
            .putInt("reminderMin", s.reminderMin)
            .putBoolean("vibrate", s.vibrate)
            .putString("soundMode", s.soundMode)
            .putString("soundUri", s.soundUri)
            .putInt("channelVer", s.channelVer)
            .putString("theme", s.theme)
            .putInt("accent", s.accent)
            .putBoolean("dynamicColor", s.dynamicColor)
            .putInt("hijriAdj", s.hijriAdj)
            .putString("remind", s.remind.joinToString(","))
            .putBoolean("silenceOn", s.silenceOn)
            .putInt("silenceMask", s.silenceMask)
            .putString("silenceMins", s.silenceMins.joinToString(","))
            .putBoolean("silenceVibrate", s.silenceVibrate)
            .putBoolean("testMinutes", s.testMinutes)
            .putBoolean("popup", s.popup)
            .putBoolean("reliableAlarm", s.reliableAlarm)
            .putString("countryName", s.countryName)
            .putString("city2Name", s.city2Name)
            .putString("lat2", s.lat2.toString())
            .putString("lng2", s.lng2.toString())
            .apply()
    }

    // ---- Amel defteri (gunluk ibadet takibi) ----
    fun getDone(ctx: Context, date: LocalDate): Int = sp(ctx).getInt("done_$date", 0)

    fun setDone(ctx: Context, date: LocalDate, mask: Int) {
        sp(ctx).edit().putInt("done_$date", mask).apply()
    }

    fun getLong(ctx: Context, key: String, def: Long): Long = sp(ctx).getLong(key, def)
    fun putLong(ctx: Context, key: String, v: Long) {
        sp(ctx).edit().putLong(key, v).apply()
    }

    // ---- Genel amacli kucuk degerler (zikir, zekat vb.) ----
    fun getInt(ctx: Context, key: String, def: Int): Int = sp(ctx).getInt(key, def)
    fun putInt(ctx: Context, key: String, v: Int) {
        sp(ctx).edit().putInt(key, v).apply()
    }

    fun getStr(ctx: Context, key: String, def: String): String = sp(ctx).getString(key, def) ?: def
    fun putStr(ctx: Context, key: String, v: String) {
        sp(ctx).edit().putString(key, v).apply()
    }
}
