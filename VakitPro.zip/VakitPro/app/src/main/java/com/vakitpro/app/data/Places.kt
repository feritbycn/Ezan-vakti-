package com.vakitpro.app.data

import android.content.Context

data class Country(val code: String, val name: String, val lat: Double, val lng: Double)
data class Place(val name: String, val lat: Double, val lng: Double)

/** Dunya ulkeleri + il/eyalet listesi (cevrimdisi, assets/places.txt). Turkiye icin 81 il dahili listeden gelir. */
object Places {
    class Data(val countries: List<Country>, val places: Map<String, List<Place>>)

    @Volatile
    private var cache: Data? = null

    fun load(ctx: Context): Data {
        cache?.let { return it }
        val countries = ArrayList<Country>()
        val places = HashMap<String, MutableList<Place>>()
        ctx.applicationContext.assets.open("places.txt").bufferedReader(Charsets.UTF_8).useLines { lines ->
            for (line in lines) {
                val f = line.split("|")
                if (f.size < 5) continue
                if (f[0] == "C") {
                    countries.add(Country(f[1], f[2], f[3].toDoubleOrNull() ?: 0.0, f[4].toDoubleOrNull() ?: 0.0))
                } else if (f[0] == "P") {
                    val la = f[3].toDoubleOrNull() ?: continue
                    val lo = f[4].toDoubleOrNull() ?: continue
                    places.getOrPut(f[1]) { ArrayList() }.add(Place(f[2], la, lo))
                }
            }
        }
        // Turkiye: 81 il (ilk 81 kayit)
        places["TR"] = Cities.ALL.take(81).map { Place(it.name, it.lat, it.lng) }.toMutableList()
        val sorted = countries.sortedWith(compareBy({ if (it.code == "TR") 0 else 1 }, { it.name }))
        val d = Data(sorted, places)
        cache = d
        return d
    }

    class Resolved(val country: String, val label: String)

    /** Verilen konuma en yakin il/eyaleti bulur; ulke ve gorunecek ad doner. */
    fun resolve(d: Data, lat: Double, lng: Double): Resolved {
        var bestC: Country? = null
        var bestP: Place? = null
        var bestD = Double.MAX_VALUE
        for (c in d.countries) {
            for (p in d.places[c.code] ?: emptyList()) {
                val dist = Geo.distanceKm(lat, lng, p.lat, p.lng)
                if (dist < bestD) {
                    bestD = dist
                    bestC = c
                    bestP = p
                }
            }
        }
        val c = bestC ?: return Resolved("", "Konumum")
        val label = if (bestP != null && bestD < 120.0) "${bestP.name} (GPS)" else "Konumum"
        return Resolved(c.name, label)
    }
}
