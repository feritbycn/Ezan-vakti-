@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.vakitpro.app.ui

import android.content.Intent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vakitpro.app.LocalHolder
import com.vakitpro.app.data.Fmt
import com.vakitpro.app.data.Hijri
import com.vakitpro.app.data.Names
import com.vakitpro.app.data.PrayerRepo
import com.vakitpro.app.data.Prefs
import com.vakitpro.app.data.ReligiousDays
import com.vakitpro.app.data.Settings
import java.time.temporal.ChronoUnit
import kotlinx.coroutines.delay

@Composable
fun HomeScreen(s: Settings, onOpenSettings: () -> Unit, onOpen: (String) -> Unit) {
    val ctx = LocalContext.current
    val holder = LocalHolder.current
    val cs = MaterialTheme.colorScheme

    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(1000L - (now % 1000L) + 5L)
        }
    }

    val info = PrayerRepo.next(s, now)
    val today = PrayerRepo.today(now)
    val times = PrayerRepo.times(s, today)
    val remain = info.timeMs - now
    val total = (info.timeMs - info.prevMs).coerceAtLeast(1L)
    val frac = ((now - info.prevMs).toFloat() / total.toFloat()).coerceIn(0f, 1f)
    val hijri = Hijri.of(today, s.hijriAdj + (if (now >= times[4]) 1 else 0)).text()
    val done = Prefs.getDone(ctx, today)
    val doneCount = Integer.bitCount(done and 31)
    val nextEvent = remember(today, s.hijriAdj) {
        ReligiousDays.upcoming(today, s.hijriAdj, 120).firstOrNull()
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Baslik: ilce/sehir adi buyuk, yaninda konum dugmesi
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        s.cityName.replace(" (GPS)", ""),
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                    Text(
                        methodLabel(s.method),
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant
                    )
                }
                Surface(
                    onClick = onOpenSettings,
                    shape = RoundedCornerShape(50),
                    color = cs.surfaceContainerHigh
                ) {
                    Text(
                        "📍",
                        Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                        style = MaterialTheme.typography.titleMedium
                    )
                }
            }
        }

        // Kompakt geri sayim karti
        item {
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(
                                lerp(cs.primary, Color.Black, 0.30f),
                                lerp(cs.primary, Color(0xFF0B1220), 0.70f)
                            )
                        )
                    )
                    .padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        "Şu an ${Names.SHORT[info.prevIndex]} vakti",
                        color = Color(0xFFF5C26B),
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.SemiBold
                    )
                    val hms = Fmt.hms(remain)
                    val main = if (hms.length > 3) hms.substring(0, hms.length - 3) else hms
                    val sec = if (hms.length > 3) hms.substring(hms.length - 3) else ""
                    Text(
                        androidx.compose.ui.text.buildAnnotatedString {
                            append(main)
                            withStyle(androidx.compose.ui.text.SpanStyle(fontSize = 26.sp, color = Color.White.copy(alpha = 0.7f))) {
                                append(sec)
                            }
                        },
                        color = Color.White,
                        fontSize = 54.sp,
                        fontWeight = FontWeight.Light
                    )
                    Text(
                        "${Names.DATIVE[info.index]} kalan • ${Fmt.hm(info.timeMs)}",
                        color = Color.White.copy(alpha = 0.85f),
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(Modifier.size(12.dp))
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(5.dp)
                            .clip(RoundedCornerShape(50))
                            .background(Color.White.copy(alpha = 0.18f))
                    ) {
                        Box(
                            Modifier
                                .fillMaxWidth(frac)
                                .height(5.dp)
                                .clip(RoundedCornerShape(50))
                                .background(Color(0xFFF5C26B))
                        )
                    }
                }
            }
        }

        // Tarih + aksama kalan
        item {
            val toMaghrib = times[4] - now
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(cs.surfaceContainerHigh)
                    .padding(horizontal = 18.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        Fmt.dayLong(today),
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(hijri, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                }
                if (toMaghrib > 0L) {
                    Box(
                        Modifier
                            .width(1.dp)
                            .height(34.dp)
                            .background(cs.outlineVariant.copy(alpha = 0.7f))
                    )
                    Spacer(Modifier.width(14.dp))
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            "AKŞAM'A",
                            fontSize = 10.sp,
                            letterSpacing = 1.2.sp,
                            fontWeight = FontWeight.Bold,
                            color = cs.primary
                        )
                        Text(
                            Fmt.human(toMaghrib),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Gunun vakitleri: tek satir, kompakt
        item {
            ProCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    for (i in 0 until 6) {
                        val active = i == info.index
                        val passed = times[i] < now && !active
                        val alertOn = ((s.alertMask shr i) and 1) == 1
                        Column(
                            Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (active) cs.primaryContainer else Color.Transparent)
                                .padding(vertical = 8.dp)
                                .alpha(if (passed) 0.55f else 1f),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                Names.SHORT[i],
                                style = MaterialTheme.typography.labelMedium,
                                color = if (active) cs.onPrimaryContainer else cs.onSurfaceVariant,
                                maxLines = 1
                            )
                            Text(
                                Fmt.hm(times[i]),
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (active) cs.onPrimaryContainer else cs.onSurface
                            )
                            Spacer(Modifier.size(4.dp))
                            BellToggle(alertOn) {
                                holder.update { it.copy(alertMask = it.alertMask xor (1 shl i)) }
                            }
                        }
                    }
                }
            }
        }

        // Hikaye halkalari
        item {
            Box(Modifier.padding(vertical = 4.dp)) { StoryRow(onOpen) }
        }

        if (Ads.ENABLED) item { AdBanner() }

        // Ikinci sehir
        if (s.city2Name.isNotEmpty()) {
            item {
                val s2 = s.copy(cityName = s.city2Name, lat = s.lat2, lng = s.lng2)
                val n2 = PrayerRepo.next(s2, now)
                val t2 = PrayerRepo.times(s2, PrayerRepo.today(now))
                ProCard(onClick = onOpenSettings) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("📍 ${s.city2Name}", fontWeight = FontWeight.SemiBold)
                            Text(
                                "${Names.DATIVE[n2.index]} ${Fmt.hms(n2.timeMs - now)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = cs.onSurfaceVariant
                            )
                        }
                        Pill("2. şehir")
                    }
                    Spacer(Modifier.size(10.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        for (i in 0 until 6) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    Names.SHORT[i],
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (i == n2.index) cs.primary else cs.onSurfaceVariant
                                )
                                Text(
                                    Fmt.hm(t2[i]),
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = if (i == n2.index) FontWeight.Bold else FontWeight.Normal,
                                    color = if (i == n2.index) cs.primary else cs.onSurface
                                )
                            }
                        }
                    }
                }
            }
        }

        // Bugunun amel ozeti
        item {
            ProCard(onClick = { onOpen("tracker") }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("✅", fontSize = 22.sp)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Bugünkü namazlar", fontWeight = FontWeight.SemiBold)
                        Text(
                            "$doneCount / 5 kılındı",
                            style = MaterialTheme.typography.bodySmall,
                            color = cs.onSurfaceVariant
                        )
                    }
                    Text("Takip →", color = cs.primary, style = MaterialTheme.typography.labelLarge)
                }
                Spacer(Modifier.size(10.dp))
                LinearProgressIndicator(
                    progress = { doneCount / 5f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(50)),
                    color = cs.primary,
                    trackColor = cs.surfaceVariant
                )
            }
        }

        // Siradaki dini gun
        if (nextEvent != null) {
            item {
                val days = ChronoUnit.DAYS.between(today, nextEvent.date)
                ProCard(onClick = { onOpen("days") }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(if (nextEvent.night) "🌙" else "🎉", fontSize = 24.sp)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(nextEvent.name, fontWeight = FontWeight.SemiBold)
                            Text(
                                Fmt.dayLong(nextEvent.date) + if (nextEvent.night) " (akşamı)" else "",
                                style = MaterialTheme.typography.bodySmall,
                                color = cs.onSurfaceVariant
                            )
                        }
                        Pill(
                            if (days <= 0L) "Bugün" else "$days gün",
                            strong = days <= 7L
                        )
                    }
                }
            }
        }

        if (Ads.ENABLED) item { AdBanner() }

        // Hizli erisim
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                QuickTile("🗓️", "İmsakiye", Modifier.weight(1f)) { onOpen("monthly") }
                QuickTile("🌙", "Dini günler", Modifier.weight(1f)) { onOpen("days") }
                QuickTile("🤲", "Dualar", Modifier.weight(1f)) { onOpen("duas") }
                QuickTile("💠", "Esmâ", Modifier.weight(1f)) { onOpen("esma") }
            }
        }

        // Paylas
        item {
            Surface(
                onClick = {
                    val sb = StringBuilder()
                    sb.append("📍 ${s.cityName} — ${Fmt.dayLong(today)}\n")
                    for (i in 0 until 6) sb.append("${Names.SHORT[i]}: ${Fmt.hm(times[i])}\n")
                    sb.append("\nVakit Pro ile gönderildi")
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, sb.toString())
                    }
                    ctx.startActivity(Intent.createChooser(send, "Vakitleri paylaş").apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    })
                },
                shape = RoundedCornerShape(20.dp),
                color = cs.surfaceContainerHigh,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    "📤  Bugünün vakitlerini paylaş",
                    Modifier.padding(16.dp),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.labelLarge
                )
            }
        }
    }
}

private fun methodLabel(m: String): String =
    if (m == "DIYANET") "Diyanet Takvimi" else com.vakitpro.app.data.CalcMethod.of(m).label

@Composable
fun QuickTile(emoji: String, label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surfaceContainerHigh
    ) {
        Column(
            Modifier.padding(vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(emoji, fontSize = 24.sp)
            Spacer(Modifier.size(4.dp))
            Text(label, style = MaterialTheme.typography.labelSmall, maxLines = 1)
        }
    }
}
