@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.vakitpro.app.ui

import android.content.Intent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vakitpro.app.LocalHolder
import com.vakitpro.app.data.Fmt
import com.vakitpro.app.data.Hijri
import com.vakitpro.app.data.Names
import com.vakitpro.app.data.PrayerRepo
import com.vakitpro.app.data.Prefs
import com.vakitpro.app.data.ReligiousDays
import com.vakitpro.app.data.Settings
import java.time.temporal.ChronoUnit
import kotlinx.coroutines.delay

@Composable
fun HomeScreen(s: Settings, onOpenSettings: () -> Unit, onOpen: (String) -> Unit) {
    val ctx = LocalContext.current
    val holder = LocalHolder.current
    val cs = MaterialTheme.colorScheme

    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(1000L - (now % 1000L) + 5L)
        }
    }

    val info = PrayerRepo.next(s, now)
    val today = PrayerRepo.today(now)
    val times = PrayerRepo.times(s, today)
    val remain = info.timeMs - now
    val total = (info.timeMs - info.prevMs).coerceAtLeast(1L)
    val frac = ((now - info.prevMs).toFloat() / total.toFloat()).coerceIn(0f, 1f)
    val hijri = Hijri.of(today, s.hijriAdj + (if (now >= times[4]) 1 else 0)).text()
    val done = Prefs.getDone(ctx, today)
    val doneCount = Integer.bitCount(done and 31)
    val nextEvent = remember(today, s.hijriAdj) {
        ReligiousDays.upcoming(today, s.hijriAdj, 120).firstOrNull()
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Baslik
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        Fmt.dayLong(today),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        hijri,
                        style = MaterialTheme.typography.bodyMedium,
                        color = cs.onSurfaceVariant
                    )
                }
                Surface(
                    onClick = onOpenSettings,
                    shape = RoundedCornerShape(50),
                    color = cs.surfaceContainerHigh
                ) {
                    Text(
                        "📍 ${s.cityName}",
                        Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }
        }

        // Ana geri sayim karti
        item {
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(32.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(
                                lerp(cs.primary, Color.Black, 0.30f),
                                lerp(cs.primary, Color(0xFF0B1220), 0.70f)
                            )
                        )
                    )
                    .padding(vertical = 22.dp, horizontal = 16.dp)
            ) {
                Column(
                    Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        "${Names.EMOJI[info.prevIndex]} Şu an ${Names.SHORT[info.prevIndex]} vakti",
                        color = Color.White.copy(alpha = 0.85f),
                        style = MaterialTheme.typography.labelLarge
                    )
                    Spacer(Modifier.size(12.dp))
                    Box(Modifier.size(236.dp), contentAlignment = Alignment.Center) {
                        Canvas(Modifier.fillMaxSize()) {
                            val stroke = 14.dp.toPx()
                            val tl = Offset(stroke / 2f, stroke / 2f)
                            val sz = Size(size.width - stroke, size.height - stroke)
                            drawArc(
                                color = Color.White.copy(alpha = 0.18f),
                                startAngle = -90f,
                                sweepAngle = 360f,
                                useCenter = false,
                                topLeft = tl,
                                size = sz,
                                style = Stroke(width = stroke, cap = StrokeCap.Round)
                            )
                            drawArc(
                                color = Color(0xFFF5C26B),
                                startAngle = -90f,
                                sweepAngle = 360f * frac,
                                useCenter = false,
                                topLeft = tl,
                                size = sz,
                                style = Stroke(width = stroke, cap = StrokeCap.Round)
                            )
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                "${Names.DATIVE[info.index]} kalan",
                                color = Color.White.copy(alpha = 0.8f),
                                style = MaterialTheme.typography.labelLarge
                            )
                            Text(
                                Fmt.hms(remain),
                                color = Color.White,
                                fontSize = 40.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                "${Names.SHORT[info.index]} • ${Fmt.hm(info.timeMs)}",
                                color = Color(0xFFF5C26B),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                    Spacer(Modifier.size(12.dp))
                    Text(
                        "≈ ${Fmt.human(remain)} sonra",
                        color = Color.White.copy(alpha = 0.9f),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }

        // Gunun vakitleri
        item {
            ProCard {
                for (i in 0 until 6) {
                    val active = i == info.index
                    val passed = times[i] < now && !active
                    val alertOn = ((s.alertMask shr i) and 1) == 1
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (active) cs.primaryContainer else Color.Transparent)
                            .padding(horizontal = 10.dp, vertical = 10.dp)
                            .alpha(if (passed) 0.5f else 1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(Names.EMOJI[i], fontSize = 22.sp)
                        Spacer(Modifier.width(12.dp))
                        Text(
                            Names.SHORT[i],
                            Modifier.weight(1f),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = if (active) FontWeight.Bold else FontWeight.Medium
                        )
                        Text(
                            Fmt.hm(times[i]),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = if (active) cs.onPrimaryContainer else cs.onSurface
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            if (alertOn) "🔔" else "🔕",
                            fontSize = 20.sp,
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .clickable {
                                    holder.update { it.copy(alertMask = it.alertMask xor (1 shl i)) }
                                }
                                .padding(6.dp)
                        )
                    }
                    if (i < 5) HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                }
            }
        }

        // Ikinci sehir
        if (s.city2Name.isNotEmpty()) {
            item {
                val s2 = s.copy(cityName = s.city2Name, lat = s.lat2, lng = s.lng2)
                val n2 = PrayerRepo.next(s2, now)
                val t2 = PrayerRepo.times(s2, PrayerRepo.today(now))
                ProCard(onClick = onOpenSettings) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("📍 ${s.city2Name}", fontWeight = FontWeight.SemiBold)
                            Text(
                                "${Names.DATIVE[n2.index]} ${Fmt.hms(n2.timeMs - now)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = cs.onSurfaceVariant
                            )
                        }
                        Pill("2. şehir")
                    }
                    Spacer(Modifier.size(10.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        for (i in 0 until 6) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    Names.SHORT[i],
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (i == n2.index) cs.primary else cs.onSurfaceVariant
                                )
                                Text(
                                    Fmt.hm(t2[i]),
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = if (i == n2.index) FontWeight.Bold else FontWeight.Normal,
                                    color = if (i == n2.index) cs.primary else cs.onSurface
                                )
                            }
                        }
                    }
                }
            }
        }

        // Bugunun amel ozeti
        item {
            ProCard(onClick = { onOpen("tracker") }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("✅", fontSize = 22.sp)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Bugünkü namazlar", fontWeight = FontWeight.SemiBold)
                        Text(
                            "$doneCount / 5 kılındı",
                            style = MaterialTheme.typography.bodySmall,
                            color = cs.onSurfaceVariant
                        )
                    }
                    Text("Takip →", color = cs.primary, style = MaterialTheme.typography.labelLarge)
                }
                Spacer(Modifier.size(10.dp))
                LinearProgressIndicator(
                    progress = { doneCount / 5f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(50)),
                    color = cs.primary,
                    trackColor = cs.surfaceVariant
                )
            }
        }

        // Siradaki dini gun
        if (nextEvent != null) {
            item {
                val days = ChronoUnit.DAYS.between(today, nextEvent.date)
                ProCard(onClick = { onOpen("days") }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(if (nextEvent.night) "🌙" else "🎉", fontSize = 24.sp)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(nextEvent.name, fontWeight = FontWeight.SemiBold)
                            Text(
                                Fmt.dayLong(nextEvent.date) + if (nextEvent.night) " (akşamı)" else "",
                                style = MaterialTheme.typography.bodySmall,
                                color = cs.onSurfaceVariant
                            )
                        }
                        Pill(
                            if (days <= 0L) "Bugün" else "$days gün",
                            strong = days <= 7L
                        )
                    }
                }
            }
        }

        // Hizli erisim
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                QuickTile("🗓️", "İmsakiye", Modifier.weight(1f)) { onOpen("monthly") }
                QuickTile("🌙", "Dini günler", Modifier.weight(1f)) { onOpen("days") }
                QuickTile("🤲", "Dualar", Modifier.weight(1f)) { onOpen("duas") }
                QuickTile("💠", "Esmâ", Modifier.weight(1f)) { onOpen("esma") }
            }
        }

        // Paylas
        item {
            Surface(
                onClick = {
                    val sb = StringBuilder()
                    sb.append("📍 ${s.cityName} — ${Fmt.dayLong(today)}\n")
                    for (i in 0 until 6) sb.append("${Names.SHORT[i]}: ${Fmt.hm(times[i])}\n")
                    sb.append("\nVakit Pro ile gönderildi")
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, sb.toString())
                    }
                    ctx.startActivity(Intent.createChooser(send, "Vakitleri paylaş").apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    })
                },
                shape = RoundedCornerShape(20.dp),
                color = cs.surfaceContainerHigh,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    "📤  Bugünün vakitlerini paylaş",
                    Modifier.padding(16.dp),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.labelLarge
                )
            }
        }
    }
}

@Composable
fun QuickTile(emoji: String, label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surfaceContainerHigh
    ) {
        Column(
            Modifier.padding(vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(emoji, fontSize = 24.sp)
            Spacer(Modifier.size(4.dp))
            Text(label, style = MaterialTheme.typography.labelSmall, maxLines = 1)
        }
    }
}
