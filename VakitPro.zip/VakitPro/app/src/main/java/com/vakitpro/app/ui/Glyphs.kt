package com.vakitpro.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Uygulama ici tek renkli (tint) cizim simgeleri: emoji yerine. */
enum class Glyph {
    PIN, CHECK, CALENDAR, PARTY, CRESCENT, MOSQUE, SHARE, COPY, GPS, MAP, KAABA, BOOKMARK, MIC,
    BELL, BELL_OFF, ALARM, TIMER, FLAME, BOOK, BEADS, HEART, BOWL, VIBRATE, UNDO, RESET, CLOSE,
    CHAT, MEGAPHONE, STAR8, HANDS, WINDOW, BATTERY, DOWNLOAD
}

@Composable
fun GlyphIcon(g: Glyph, tint: Color = LocalContentColor.current, size: Dp = 20.dp) {
    when (g) {
        Glyph.MOSQUE -> NavIcon(0, tint, size)
        Glyph.BEADS -> NavIcon(2, tint, size)
        Glyph.BATTERY -> PermIcon(1, tint, size)
        Glyph.WINDOW -> PermIcon(2, tint, size, mark = Color.Transparent)
        else -> Canvas(Modifier.size(size)) { drawG(g, tint) }
    }
}

/** Simge + yazi yan yana (dugme etiketi). */
@Composable
fun GlyphLabel(g: Glyph, text: String, tint: Color = LocalContentColor.current, size: Dp = 18.dp) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        GlyphIcon(g, tint, size)
        Spacer(Modifier.width(8.dp))
        Text(text)
    }
}

private fun DrawScope.drawG(g: Glyph, c: Color) {
    val u = size.width / 100f
    fun o(x: Float, y: Float) = Offset(x * u, y * u)
    fun sz(a: Float, b: Float) = Size(a * u, b * u)
    fun line(x1: Float, y1: Float, x2: Float, y2: Float, sw: Float = 7f, a: Float = 1f) =
        drawLine(c.copy(alpha = a), o(x1, y1), o(x2, y2), strokeWidth = sw * u, cap = StrokeCap.Round)
    val st = Stroke(width = 7f * u, cap = StrokeCap.Round, join = StrokeJoin.Round)
    fun circ(x: Float, y: Float) = Path().apply { addOval(Rect((x - 1f) * u, (y - 1f) * u, (x + 1f) * u, (y + 1f) * u)) }
    fun ov(x: Float, y: Float, r: Float) = Path().apply { addOval(Rect((x - r) * u, (y - r) * u, (x + r) * u, (y + r) * u)) }
    fun cut(base: Path, vararg holes: Path) {
        var p = base
        for (h in holes) p = Path.combine(PathOperation.Difference, p, h)
        drawPath(p, c)
    }
    when (g) {
        Glyph.PIN -> {
            val pin = Path().apply {
                moveTo(50f * u, 94f * u); lineTo(22f * u, 54f * u)
                arcTo(Rect(22f * u, 8f * u, 78f * u, 64f * u), 160f, 220f, false)
                lineTo(50f * u, 94f * u); close()
            }
            cut(pin, ov(50f, 36f, 11f))
        }
        Glyph.CHECK -> {
            drawCircle(c, 40f * u, o(50f, 50f), style = st)
            val p = Path().apply { moveTo(32f * u, 52f * u); lineTo(45f * u, 65f * u); lineTo(69f * u, 37f * u) }
            drawPath(p, c, style = st)
        }
        Glyph.CALENDAR -> {
            drawRoundRect(c, o(10f, 18f), sz(80f, 72f), CornerRadius(14f * u), style = st)
            line(10f, 40f, 90f, 40f, 6f)
            line(32f, 8f, 32f, 26f); line(68f, 8f, 68f, 26f)
            for (cc in 0 until 3) drawCircle(c, 4f * u, o(28f + cc * 22f, 62f))
        }
        Glyph.PARTY -> {
            val p = Path()
            for (i in 0 until 24) {
                val a = Math.toRadians(-90.0 + i * 15.0)
                val r = if (i % 2 == 0) 44f else 28f
                val x = 50f + r * Math.cos(a).toFloat(); val y = 50f + r * Math.sin(a).toFloat()
                if (i == 0) p.moveTo(x * u, y * u) else p.lineTo(x * u, y * u)
            }
            p.close()
            cut(p, ov(50f, 50f, 10f))
        }
        Glyph.CRESCENT -> {
            val a = ov(42f, 52f, 36f); val b = ov(58f, 44f, 30f)
            drawPath(Path.combine(PathOperation.Difference, a, b), c)
            sparkle(76f * u, 26f * u, 12f * u, c)
        }
        Glyph.SHARE -> {
            line(24f, 50f, 74f, 24f, 6f); line(24f, 50f, 74f, 76f, 6f)
            drawCircle(c, 13f * u, o(24f, 50f)); drawCircle(c, 13f * u, o(74f, 24f)); drawCircle(c, 13f * u, o(74f, 76f))
        }
        Glyph.COPY -> {
            drawRoundRect(c.copy(alpha = 0.6f), o(34f, 8f), sz(54f, 62f), CornerRadius(10f * u), style = st)
            drawRoundRect(c, o(12f, 30f), sz(54f, 62f), CornerRadius(10f * u), style = st)
        }
        Glyph.GPS -> {
            drawCircle(c, 24f * u, o(50f, 50f), style = st)
            drawCircle(c, 8f * u, o(50f, 50f))
            line(50f, 6f, 50f, 22f); line(50f, 78f, 50f, 94f); line(6f, 50f, 22f, 50f); line(78f, 50f, 94f, 50f)
        }
        Glyph.MAP -> {
            val p = Path().apply {
                moveTo(8f * u, 22f * u); lineTo(36f * u, 12f * u); lineTo(64f * u, 24f * u); lineTo(92f * u, 14f * u)
                lineTo(92f * u, 78f * u); lineTo(64f * u, 88f * u); lineTo(36f * u, 76f * u); lineTo(8f * u, 86f * u); close()
            }
            drawPath(p, c, style = Stroke(width = 6f * u, join = StrokeJoin.Round))
            line(36f, 12f, 36f, 76f, 5f); line(64f, 24f, 64f, 88f, 5f)
        }
        Glyph.KAABA -> {
            val base = Path().apply { addRoundRect(androidx.compose.ui.geometry.RoundRect(14f * u, 22f * u, 86f * u, 90f * u, CornerRadius(6f * u))) }
            val band = Path().apply { addRect(Rect(10f * u, 40f * u, 90f * u, 48f * u)) }
            val door = Path().apply { addRoundRect(androidx.compose.ui.geometry.RoundRect(42f * u, 62f * u, 58f * u, 92f * u, CornerRadius(4f * u))) }
            cut(base, band, door)
        }
        Glyph.BOOKMARK -> {
            val p = Path().apply {
                moveTo(24f * u, 8f * u); lineTo(76f * u, 8f * u); lineTo(76f * u, 92f * u); lineTo(50f * u, 70f * u); lineTo(24f * u, 92f * u); close()
            }
            drawPath(p, c)
        }
        Glyph.MIC -> {
            drawRoundRect(c, o(36f, 6f), sz(28f, 54f), CornerRadius(14f * u))
            drawArc(c, 0f, 180f, false, o(22f, 28f), sz(56f, 50f), style = st)
            line(50f, 78f, 50f, 92f); line(34f, 92f, 66f, 92f)
        }
        Glyph.BELL, Glyph.BELL_OFF -> {
            drawArc(c, 180f, 180f, true, o(26f, 14f), sz(48f, 48f))
            val body = Path().apply {
                moveTo(26f * u, 38f * u); lineTo(74f * u, 38f * u); lineTo(84f * u, 70f * u); lineTo(16f * u, 70f * u); close()
            }
            drawPath(body, c)
            drawRoundRect(c, o(12f, 66f), sz(76f, 8f), CornerRadius(4f * u))
            drawCircle(c, 8f * u, o(50f, 84f))
            if (g == Glyph.BELL_OFF) line(12f, 10f, 88f, 90f, 9f)
        }
        Glyph.ALARM -> {
            drawCircle(c, 32f * u, o(50f, 56f), style = st)
            line(50f, 56f, 50f, 38f, 6f); line(50f, 56f, 63f, 64f, 6f)
            drawCircle(c, 11f * u, o(20f, 24f)); drawCircle(c, 11f * u, o(80f, 24f))
        }
        Glyph.TIMER -> {
            drawCircle(c, 34f * u, o(50f, 58f), style = st)
            line(40f, 8f, 60f, 8f); line(50f, 8f, 50f, 22f, 6f); line(50f, 58f, 50f, 36f, 6f)
        }
        Glyph.FLAME -> {
            val p = Path().apply {
                moveTo(50f * u, 6f * u)
                cubicTo(70f * u, 28f * u, 86f * u, 46f * u, 80f * u, 68f * u)
                cubicTo(76f * u, 86f * u, 62f * u, 94f * u, 50f * u, 94f * u)
                cubicTo(36f * u, 94f * u, 20f * u, 86f * u, 20f * u, 64f * u)
                cubicTo(20f * u, 48f * u, 34f * u, 40f * u, 40f * u, 22f * u)
                cubicTo(44f * u, 28f * u, 48f * u, 24f * u, 50f * u, 6f * u)
                close()
            }
            cut(p, ov(50f, 72f, 12f))
        }
        Glyph.BOOK -> {
            val l = Path().apply {
                moveTo(48f * u, 26f * u); quadraticBezierTo(28f * u, 14f * u, 8f * u, 22f * u)
                lineTo(8f * u, 76f * u); quadraticBezierTo(28f * u, 68f * u, 48f * u, 80f * u); close()
            }
            val r = Path().apply {
                moveTo(52f * u, 26f * u); quadraticBezierTo(72f * u, 14f * u, 92f * u, 22f * u)
                lineTo(92f * u, 76f * u); quadraticBezierTo(72f * u, 68f * u, 52f * u, 80f * u); close()
            }
            drawPath(l, c); drawPath(r, c.copy(alpha = 0.8f))
        }
        Glyph.HEART -> {
            val p = Path().apply {
                moveTo(50f * u, 88f * u)
                cubicTo(6f * u, 56f * u, 10f * u, 16f * u, 34f * u, 16f * u)
                cubicTo(44f * u, 16f * u, 50f * u, 24f * u, 50f * u, 30f * u)
                cubicTo(50f * u, 24f * u, 56f * u, 16f * u, 66f * u, 16f * u)
                cubicTo(90f * u, 16f * u, 94f * u, 56f * u, 50f * u, 88f * u)
                close()
            }
            drawPath(p, c)
        }
        Glyph.BOWL -> {
            drawArc(c, 0f, 180f, true, o(10f, 20f), sz(80f, 80f))
            line(8f, 56f, 92f, 56f, 8f)
            line(36f, 8f, 36f, 38f, 6f, 0.7f); line(64f, 8f, 64f, 38f, 6f, 0.7f)
        }
        Glyph.VIBRATE -> {
            drawRoundRect(c, o(34f, 10f), sz(32f, 80f), CornerRadius(8f * u), style = st)
            line(18f, 32f, 18f, 68f, 6f); line(82f, 32f, 82f, 68f, 6f)
            line(5f, 42f, 5f, 58f, 6f); line(95f, 42f, 95f, 58f, 6f)
        }
        Glyph.UNDO -> {
            val p = Path().apply {
                moveTo(14f * u, 40f * u); lineTo(60f * u, 40f * u)
                quadraticBezierTo(90f * u, 40f * u, 90f * u, 64f * u)
                quadraticBezierTo(90f * u, 86f * u, 60f * u, 86f * u); lineTo(34f * u, 86f * u)
            }
            drawPath(p, c, style = st)
            val h = Path().apply { moveTo(32f * u, 20f * u); lineTo(12f * u, 40f * u); lineTo(32f * u, 60f * u) }
            drawPath(h, c, style = st)
        }
        Glyph.RESET -> {
            drawArc(c, -40f, 290f, false, o(16f, 16f), sz(68f, 68f), style = st)
            val h = Path().apply { moveTo(68f * u, 6f * u); lineTo(80f * u, 24f * u); lineTo(58f * u, 28f * u) }
            drawPath(h, c, style = st)
        }
        Glyph.CLOSE -> { line(20f, 20f, 80f, 80f, 9f); line(80f, 20f, 20f, 80f, 9f) }
        Glyph.CHAT -> {
            val bub = Path().apply {
                addRoundRect(androidx.compose.ui.geometry.RoundRect(8f * u, 10f * u, 92f * u, 72f * u, CornerRadius(16f * u)))
                moveTo(22f * u, 68f * u); lineTo(20f * u, 92f * u); lineTo(46f * u, 70f * u); close()
            }
            cut(bub, ov(32f, 41f, 5f), ov(50f, 41f, 5f), ov(68f, 41f, 5f))
        }
        Glyph.MEGAPHONE -> {
            val p = Path().apply {
                moveTo(12f * u, 38f * u); lineTo(40f * u, 38f * u); lineTo(82f * u, 14f * u)
                lineTo(82f * u, 86f * u); lineTo(40f * u, 62f * u); lineTo(12f * u, 62f * u); close()
            }
            drawPath(p, c)
            drawRoundRect(c, o(22f, 62f), sz(16f, 28f), CornerRadius(5f * u))
        }
        Glyph.STAR8 -> {
            val p = Path()
            for (i in 0 until 16) {
                val a = Math.toRadians(-90.0 + i * 22.5)
                val r = if (i % 2 == 0) 44f else 24f
                val x = 50f + r * Math.cos(a).toFloat(); val y = 50f + r * Math.sin(a).toFloat()
                if (i == 0) p.moveTo(x * u, y * u) else p.lineTo(x * u, y * u)
            }
            p.close()
            cut(p, ov(50f, 50f, 9f))
        }
        Glyph.HANDS -> {
            val left = Path().apply {
                moveTo(50f * u, 90f * u); quadraticBezierTo(10f * u, 68f * u, 22f * u, 30f * u)
                quadraticBezierTo(46f * u, 44f * u, 50f * u, 90f * u); close()
            }
            val right = Path().apply {
                moveTo(50f * u, 90f * u); quadraticBezierTo(90f * u, 68f * u, 78f * u, 30f * u)
                quadraticBezierTo(54f * u, 44f * u, 50f * u, 90f * u); close()
            }
            drawPath(left, c); drawPath(right, c.copy(alpha = 0.8f))
            sparkle(50f * u, 18f * u, 10f * u, c)
        }
        Glyph.DOWNLOAD -> {
            line(50f, 8f, 50f, 62f, 8f)
            val h = Path().apply { moveTo(26f * u, 40f * u); lineTo(50f * u, 64f * u); lineTo(74f * u, 40f * u) }
            drawPath(h, c, style = st)
            line(14f, 86f, 86f, 86f, 8f)
        }
        else -> {}
    }
}
