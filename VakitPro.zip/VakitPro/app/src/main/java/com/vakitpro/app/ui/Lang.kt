package com.vakitpro.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vakitpro.app.data.Prefs

class LangInfo(val code: String, val native: String, val english: String, val badge: String, val rtl: Boolean = false)

object Lang {
    val ALL = listOf(
        LangInfo("tr", "Türkçe", "Turkish", "TR"),
        LangInfo("en", "English", "English", "EN"),
        LangInfo("ar", "العربية", "Arabic", "ع", true),
        LangInfo("id", "Bahasa Indonesia", "Indonesian", "ID"),
        LangInfo("ur", "اردو", "Urdu", "ار", true),
        LangInfo("fr", "Français", "French", "FR"),
        LangInfo("de", "Deutsch", "German", "DE"),
        LangInfo("ms", "Bahasa Melayu", "Malay", "MS"),
        LangInfo("bn", "বাংলা", "Bengali", "বা"),
        LangInfo("fa", "فارسی", "Persian", "فا", true)
    )
    private val ORDER = listOf("en", "ar", "id", "ur", "fr", "de", "ms", "bn", "fa")

    var code by mutableStateOf("tr")
        private set

    fun init(ctx: android.content.Context) {
        code = Prefs.getStr(ctx, "lang", "tr")
    }

    fun set(ctx: android.content.Context, c: String) {
        Prefs.putStr(ctx, "lang", c)
        Prefs.putInt(ctx, "lang_chosen", 1)
        code = c
    }

    fun chosen(ctx: android.content.Context) = Prefs.getInt(ctx, "lang_chosen", 0) == 1
    fun info() = ALL.firstOrNull { it.code == code } ?: ALL[0]
    fun isRtl() = info().rtl

    /** Turkce metni secili dile cevirir; ceviri yoksa Turkce kalir. */
    fun tr(s: String): String {
        val c = code
        if (c == "tr") return s
        val row = T[s] ?: return s
        val i = ORDER.indexOf(c)
        return row.getOrNull(i)?.takeIf { it.isNotEmpty() } ?: s
    }

    // sira: en, ar, id, ur, fr, de, ms, bn, fa
    private fun r(vararg v: String) = v.toList()
    private val T: Map<String, List<String>> = mapOf(
        "Vakitler" to r("Times", "الأوقات", "Waktu", "اوقات", "Horaires", "Zeiten", "Waktu", "সময়", "اوقات"),
        "Kıble" to r("Qibla", "القبلة", "Kiblat", "قبلہ", "Qibla", "Kibla", "Kiblat", "কিবলা", "قبله"),
        "Zikir" to r("Dhikr", "الذكر", "Zikir", "ذکر", "Dhikr", "Dhikr", "Zikir", "জিকির", "ذکر"),
        "Keşfet" to r("Discover", "اكتشف", "Jelajah", "دریافت", "Découvrir", "Entdecken", "Teroka", "আবিষ্কার", "کاوش"),
        "Ayarlar" to r("Settings", "الإعدادات", "Pengaturan", "ترتیبات", "Réglages", "Einstellungen", "Tetapan", "সেটিংস", "تنظیمات"),
        "Devam et" to r("Continue", "متابعة", "Lanjutkan", "جاری رکھیں", "Continuer", "Weiter", "Teruskan", "চালিয়ে যান", "ادامه"),
        "Devam" to r("Continue", "متابعة", "Lanjut", "جاری رکھیں", "Continuer", "Weiter", "Teruskan", "চালিয়ে যান", "ادامه"),
        "Başla" to r("Start", "ابدأ", "Mulai", "شروع کریں", "Commencer", "Starten", "Mula", "শুরু করুন", "شروع"),
        "Şimdilik atla" to r("Skip for now", "تخطي الآن", "Lewati dulu", "ابھی چھوڑیں", "Passer pour l'instant", "Vorerst überspringen", "Langkau buat masa ini", "এখন এড়িয়ে যান", "فعلاً رد شو"),
        "Es-selâmü aleyküm" to r("As-salamu alaykum", "السلام عليكم", "Assalamu'alaikum", "السلام علیکم", "As-salamu alaykum", "As-salamu alaikum", "Assalamualaikum", "আসসালামু আলাইকুম", "السلام علیکم"),
        "Hoş geldin" to r("Welcome", "أهلاً بك", "Selamat datang", "خوش آمدید", "Bienvenue", "Willkommen", "Selamat datang", "স্বাগতম", "خوش آمدید"),
        "NurVakit'e hoş geldin" to r("Welcome to NurVakit", "مرحباً بك في NurVakit", "Selamat datang di NurVakit", "NurVakit میں خوش آمدید", "Bienvenue sur NurVakit", "Willkommen bei NurVakit", "Selamat datang ke NurVakit", "NurVakit-তে স্বাগতম", "به NurVakit خوش آمدید"),
        "Namaz vakitleri • Kıble • Zikir" to r("Prayer times • Qibla • Dhikr", "أوقات الصلاة • القبلة • الذكر", "Waktu salat • Kiblat • Zikir", "نماز کے اوقات • قبلہ • ذکر", "Heures de prière • Qibla • Dhikr", "Gebetszeiten • Kibla • Dhikr", "Waktu solat • Kiblat • Zikir", "নামাজের সময় • কিবলা • জিকির", "اوقات نماز • قبله • ذکر"),
        "Bulunduğun yere göre ezan vakitleri, vakitten önce hatırlatma, kıble, zikir, kaza takibi ve daha fazlası tek yerde." to r(
            "Prayer times for your location, reminders, Qibla, dhikr, missed-prayer tracking and more in one place.",
            "أوقات الصلاة حسب موقعك، تذكيرات، القبلة، الذكر، تتبع القضاء والمزيد في مكان واحد.",
            "Waktu salat sesuai lokasi, pengingat, kiblat, zikir, pelacak qadha, dan lainnya dalam satu aplikasi.",
            "آپ کے مقام کے مطابق نماز کے اوقات، یاد دہانیاں، قبلہ، ذکر، قضا نماز کا حساب اور بہت کچھ ایک جگہ۔",
            "Heures de prière selon votre position, rappels, Qibla, dhikr, suivi des prières manquées et plus encore.",
            "Gebetszeiten für Ihren Standort, Erinnerungen, Kibla, Dhikr, Nachholgebete und mehr an einem Ort.",
            "Waktu solat ikut lokasi, peringatan, kiblat, zikir, penjejak qada dan banyak lagi dalam satu tempat.",
            "আপনার অবস্থান অনুযায়ী নামাজের সময়, রিমাইন্ডার, কিবলা, জিকির, কাযা ট্র্যাকিং ও আরও অনেক কিছু এক জায়গায়।",
            "اوقات نماز بر اساس موقعیت شما، یادآوری، قبله، ذکر، پیگیری قضا و بیشتر در یک جا."),
        "Namaz vakitlerini doğru hesaplamak için bulunduğun ülke ve şehri belirleyelim." to r(
            "Let's set your country and city to calculate prayer times accurately.",
            "لنحدد بلدك ومدينتك لحساب أوقات الصلاة بدقة.",
            "Tentukan negara dan kota Anda agar waktu salat dihitung dengan tepat.",
            "نماز کے اوقات درست حساب کرنے کے لیے اپنا ملک اور شہر منتخب کریں۔",
            "Définissons votre pays et votre ville pour calculer les horaires avec précision.",
            "Legen wir Land und Stadt fest, damit die Gebetszeiten genau berechnet werden.",
            "Tetapkan negara dan bandar anda untuk mengira waktu solat dengan tepat.",
            "নামাজের সময় সঠিকভাবে হিসাব করতে আপনার দেশ ও শহর নির্ধারণ করুন।",
            "برای محاسبه دقیق اوقات نماز، کشور و شهر خود را مشخص کنید."),
        "Konumumdan bul" to r("Find my location", "حدد موقعي", "Temukan lokasiku", "میرا مقام تلاش کریں", "Trouver ma position", "Meinen Standort finden", "Cari lokasi saya", "আমার অবস্থান খুঁজুন", "یافتن موقعیت من"),
        "Ülke ve şehri elle seç" to r("Choose country and city", "اختر البلد والمدينة", "Pilih negara dan kota", "ملک اور شہر منتخب کریں", "Choisir pays et ville", "Land und Stadt wählen", "Pilih negara dan bandar", "দেশ ও শহর বেছে নিন", "انتخاب کشور و شهر"),
        "Başka bir yer seç" to r("Choose another place", "اختر مكاناً آخر", "Pilih tempat lain", "کوئی اور جگہ منتخب کریں", "Choisir un autre lieu", "Anderen Ort wählen", "Pilih tempat lain", "অন্য জায়গা বেছে নিন", "انتخاب مکان دیگر"),
        "Konum bulundu" to r("Location found", "تم تحديد الموقع", "Lokasi ditemukan", "مقام مل گیا", "Position trouvée", "Standort gefunden", "Lokasi ditemui", "অবস্থান পাওয়া গেছে", "موقعیت پیدا شد"),
        "Son adım: izinler" to r("Last step: permissions", "الخطوة الأخيرة: الأذونات", "Langkah terakhir: izin", "آخری مرحلہ: اجازتیں", "Dernière étape : autorisations", "Letzter Schritt: Berechtigungen", "Langkah akhir: kebenaran", "শেষ ধাপ: অনুমতি", "مرحله آخر: مجوزها"),
        "Konum" to r("Location", "الموقع", "Lokasi", "مقام", "Position", "Standort", "Lokasi", "অবস্থান", "موقعیت"),
        "Ülke" to r("Country", "البلد", "Negara", "ملک", "Pays", "Land", "Negara", "দেশ", "کشور"),
        "Şehir / il" to r("City / province", "المدينة / المحافظة", "Kota / provinsi", "شہر / صوبہ", "Ville / province", "Stadt / Provinz", "Bandar / wilayah", "শহর / প্রদেশ", "شهر / استان"),
        "İkinci şehir" to r("Second city", "المدينة الثانية", "Kota kedua", "دوسرا شہر", "Deuxième ville", "Zweite Stadt", "Bandar kedua", "দ্বিতীয় শহর", "شهر دوم"),
        "Seçilmedi" to r("Not selected", "غير محدد", "Belum dipilih", "منتخب نہیں", "Non défini", "Nicht gewählt", "Belum dipilih", "নির্বাচিত নয়", "انتخاب نشده"),
        "Vakit hesaplama" to r("Calculation", "حساب الأوقات", "Perhitungan waktu", "اوقات کا حساب", "Calcul des horaires", "Berechnung", "Pengiraan waktu", "সময় গণনা", "محاسبه اوقات"),
        "Yöntem" to r("Method", "الطريقة", "Metode", "طریقہ", "Méthode", "Methode", "Kaedah", "পদ্ধতি", "روش"),
        "Hanefî ikindi" to r("Hanafi Asr", "العصر الحنفي", "Asar Hanafi", "حنفی عصر", "Asr hanafite", "Hanafitisches Asr", "Asar Hanafi", "হানাফী আসর", "عصر حنفی"),
        "Dakika ayarları" to r("Minute adjustments", "تعديل الدقائق", "Penyesuaian menit", "منٹ کی ترتیب", "Ajustement des minutes", "Minuten anpassen", "Pelarasan minit", "মিনিট সমন্বয়", "تنظیم دقیقه"),
        "Bildirim ve widget" to r("Notifications & widget", "الإشعارات والودجت", "Notifikasi & widget", "اطلاعات اور ویجٹ", "Notifications et widget", "Benachrichtigung & Widget", "Notifikasi & widget", "বিজ্ঞপ্তি ও উইজেট", "اعلان و ویجت"),
        "Ramazan" to r("Ramadan", "رمضان", "Ramadan", "رمضان", "Ramadan", "Ramadan", "Ramadan", "রমজান", "رمضان"),
        "Bildirimleri dene" to r("Test notifications", "تجربة الإشعارات", "Coba notifikasi", "اطلاعات آزمائیں", "Tester les notifications", "Benachrichtigungen testen", "Uji notifikasi", "বিজ্ঞপ্তি পরীক্ষা", "آزمایش اعلان‌ها"),
        "Vakit girince haber ver" to r("Notify at prayer time", "تنبيه عند دخول الوقت", "Beri tahu saat waktu salat", "وقت ہونے پر اطلاع دیں", "Notifier à l'heure de prière", "Zur Gebetszeit benachrichtigen", "Beritahu bila masuk waktu", "ওয়াক্ত হলে জানান", "اعلان در وقت نماز"),
        "Titreşim" to r("Vibration", "الاهتزاز", "Getar", "وائبریشن", "Vibration", "Vibration", "Getaran", "কম্পন", "لرزش"),
        "Vakitten önce hatırlat" to r("Remind before prayer", "تذكير قبل الصلاة", "Ingatkan sebelum waktu salat", "نماز سے پہلے یاد دلائیں", "Rappel avant la prière", "Vor dem Gebet erinnern", "Ingatkan sebelum solat", "ওয়াক্তের আগে মনে করান", "یادآوری پیش از نماز"),
        "Vakit girince telefonu sessize al" to r("Silence phone at prayer time", "كتم الهاتف عند الصلاة", "Senyapkan ponsel saat salat", "نماز کے وقت فون خاموش کریں", "Mettre le téléphone en silencieux", "Telefon zur Gebetszeit stummschalten", "Senyapkan telefon semasa solat", "ওয়াক্তে ফোন সাইলেন্ট করুন", "بی‌صدا کردن گوشی هنگام نماز"),
        "İzinler ve güvenilirlik" to r("Permissions & reliability", "الأذونات والموثوقية", "Izin & keandalan", "اجازتیں اور اعتبار", "Autorisations et fiabilité", "Berechtigungen & Zuverlässigkeit", "Kebenaran & kebolehpercayaan", "অনুমতি ও নির্ভরযোগ্যতা", "مجوزها و پایداری"),
        "Görünüm" to r("Appearance", "المظهر", "Tampilan", "ظاہری شکل", "Apparence", "Darstellung", "Paparan", "চেহারা", "نمایش"),
        "Dinamik renk" to r("Dynamic color", "الألوان الديناميكية", "Warna dinamis", "ڈائنامک رنگ", "Couleurs dynamiques", "Dynamische Farben", "Warna dinamik", "ডাইনামিক রঙ", "رنگ پویا"),
        "Hakkında" to r("About", "حول", "Tentang", "کے بارے میں", "À propos", "Über", "Perihal", "সম্পর্কে", "درباره"),
        "Dil" to r("Language", "اللغة", "Bahasa", "زبان", "Langue", "Sprache", "Bahasa", "ভাষা", "زبان"),
        "Dil seçimi" to r("Choose language", "اختر اللغة", "Pilih bahasa", "زبان منتخب کریں", "Choisir la langue", "Sprache wählen", "Pilih bahasa", "ভাষা নির্বাচন", "انتخاب زبان"),
        "Uygulama dilini seç" to r("Select app language", "اختر لغة التطبيق", "Pilih bahasa aplikasi", "ایپ کی زبان منتخب کریں", "Choisissez la langue de l'application", "App-Sprache wählen", "Pilih bahasa aplikasi", "অ্যাপের ভাষা বেছে নিন", "زبان برنامه را انتخاب کنید"),
        "Dilini seç" to r("Select your language", "اختر لغتك", "Pilih bahasa Anda", "اپنی زبان منتخب کریں", "Choisissez votre langue", "Wählen Sie Ihre Sprache", "Pilih bahasa anda", "আপনার ভাষা বেছে নিন", "زبان خود را انتخاب کنید"),
        "Keşfet" to r("Discover", "اكتشف", "Jelajah", "دریافت", "Découvrir", "Entdecken", "Teroka", "আবিষ্কার", "کاوش"),
        "İbadet, öğrenme ve araçlar" to r("Worship, learning and tools", "العبادة والتعلم والأدوات", "Ibadah, belajar, dan alat", "عبادت، سیکھنا اور اوزار", "Culte, apprentissage et outils", "Gottesdienst, Lernen und Werkzeuge", "Ibadah, pembelajaran dan alat", "ইবাদত, শেখা ও টুলস", "عبادت، یادگیری و ابزار"),
        "İbadet" to r("Worship", "العبادة", "Ibadah", "عبادت", "Culte", "Gottesdienst", "Ibadah", "ইবাদত", "عبادت"),
        "Kur'an ve dua" to r("Quran & dua", "القرآن والدعاء", "Al-Qur'an & doa", "قرآن اور دعا", "Coran et invocations", "Koran & Bittgebete", "Al-Quran & doa", "কুরআন ও দোয়া", "قرآن و دعا"),
        "Öğren" to r("Learn", "تعلّم", "Belajar", "سیکھیں", "Apprendre", "Lernen", "Belajar", "শিখুন", "یادگیری"),
        "Takvim" to r("Calendar", "التقويم", "Kalender", "کیلنڈر", "Calendrier", "Kalender", "Kalendar", "ক্যালেন্ডার", "تقویم"),
        "Diğer" to r("Other", "أخرى", "Lainnya", "دیگر", "Autres", "Sonstiges", "Lain-lain", "অন্যান্য", "سایر"),
        "Namaz rehberi" to r("Prayer guide", "دليل الصلاة", "Panduan salat", "نماز گائیڈ", "Guide de la prière", "Gebetsanleitung", "Panduan solat", "নামাজ গাইড", "راهنمای نماز"),
        "Sünnet ve fıkıh" to r("Sunnah & fiqh", "السنة والفقه", "Sunnah & fikih", "سنت اور فقہ", "Sunna et fiqh", "Sunna & Fiqh", "Sunnah & fiqh", "সুন্নাহ ও ফিকহ", "سنت و فقه"),
        "Kaza namazı" to r("Missed prayers", "الصلوات الفائتة", "Salat qadha", "قضا نماز", "Prières manquées", "Nachgebete", "Solat qada", "কাযা নামাজ", "نماز قضا"),
        "Namaz takibi" to r("Prayer tracker", "متابعة الصلاة", "Pelacak salat", "نماز ٹریکر", "Suivi des prières", "Gebets-Tracker", "Penjejak solat", "নামাজ ট্র্যাকার", "پیگیری نماز"),
        "Namaz modu" to r("Prayer mode", "وضع الصلاة", "Mode salat", "نماز موڈ", "Mode prière", "Gebetsmodus", "Mod solat", "নামাজ মোড", "حالت نماز"),
        "Zekât hesabı" to r("Zakat calculator", "حاسبة الزكاة", "Kalkulator zakat", "زکوٰۃ کیلکولیٹر", "Calcul de la zakat", "Zakat-Rechner", "Kalkulator zakat", "যাকাত হিসাব", "محاسبه زکات"),
        "Kur'an-ı Kerim" to r("Holy Quran", "القرآن الكريم", "Al-Qur'an", "قرآنِ کریم", "Saint Coran", "Heiliger Koran", "Al-Quran", "পবিত্র কুরআন", "قرآن کریم"),
        "Sure ve dualar" to r("Surahs & duas", "السور والأدعية", "Surat & doa", "سورتیں اور دعائیں", "Sourates et invocations", "Suren & Bittgebete", "Surah & doa", "সূরা ও দোয়া", "سوره‌ها و دعاها"),
        "Esmâü'l-Hüsnâ" to r("Asma ul-Husna", "أسماء الله الحسنى", "Asmaul Husna", "اسماء الحسنیٰ", "Asma ul-Husna", "Asma ul-Husna", "Asmaul Husna", "আসমাউল হুসনা", "اسماءالحسنی"),
        "Elif-Ba" to r("Alif-Ba", "الألف باء", "Alif-Ba", "الف باء", "Alif-Ba", "Alif-Ba", "Alif-Ba", "আলিফ-বা", "الف‌با"),
        "Hikâyeler" to r("Stories", "قصص", "Kisah", "کہانیاں", "Histoires", "Geschichten", "Kisah", "গল্প", "داستان‌ها"),
        "Siyer ve Sahabe" to r("Seerah & Companions", "السيرة والصحابة", "Sirah & Sahabat", "سیرت اور صحابہ", "Sîra et Compagnons", "Sira & Gefährten", "Sirah & Sahabat", "সীরাত ও সাহাবা", "سیره و صحابه"),
        "Bilgi yarışması" to r("Quiz", "مسابقة معلومات", "Kuis", "کوئز", "Quiz", "Quiz", "Kuiz", "কুইজ", "مسابقه"),
        "Kelime bulmaca" to r("Word puzzle", "لعبة الكلمات", "Teka-teki kata", "الفاظ کی پہیلی", "Mots mêlés", "Wörterrätsel", "Teka-teki perkataan", "শব্দ ধাঁধা", "معمای کلمه"),
        "Dini günler" to r("Religious days", "الأيام الدينية", "Hari besar Islam", "مذہبی ایام", "Jours religieux", "Religiöse Tage", "Hari-hari Islam", "ধর্মীয় দিবস", "روزهای مذهبی"),
        "Aylık vakitler" to r("Monthly times", "الأوقات الشهرية", "Waktu bulanan", "ماہانہ اوقات", "Horaires mensuels", "Monatszeiten", "Waktu bulanan", "মাসিক সময়", "اوقات ماهانه"),
        "Niyet ve notlar" to r("Intentions & notes", "النوايا والملاحظات", "Niat & catatan", "نیت اور نوٹس", "Intentions et notes", "Absichten & Notizen", "Niat & nota", "নিয়ত ও নোট", "نیت و یادداشت"),
        "Yakındaki camiler" to r("Nearby mosques", "المساجد القريبة", "Masjid terdekat", "قریبی مساجد", "Mosquées à proximité", "Moscheen in der Nähe", "Masjid berhampiran", "কাছের মসজিদ", "مساجد نزدیک"),
        "Uygulamayı değerlendir" to r("Rate the app", "قيّم التطبيق", "Beri nilai aplikasi", "ایپ کو ریٹ کریں", "Noter l'application", "App bewerten", "Nilai aplikasi", "অ্যাপ রেট করুন", "امتیاز به برنامه")
    )
}

@Composable
fun LanguageGrid(selected: String, onSelect: (String) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Lang.ALL.chunked(2).forEach { pair ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                pair.forEach { l ->
                    val sel = l.code == selected
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .height(74.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .clickable { onSelect(l.code) },
                        shape = RoundedCornerShape(18.dp),
                        color = if (sel) cs.primaryContainer else cs.surfaceContainerHigh,
                        border = BorderStroke(if (sel) 2.dp else 1.dp, if (sel) cs.primary else cs.outlineVariant)
                    ) {
                        Row(Modifier.padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier.size(38.dp).clip(CircleShape).background(if (sel) cs.primary else cs.surfaceVariant),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    l.badge, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                                    color = if (sel) cs.onPrimary else cs.onSurfaceVariant
                                )
                            }
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(l.native, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1)
                                Text(l.english, fontSize = 11.sp, color = cs.onSurfaceVariant, maxLines = 1)
                            }
                            if (sel) Text("✓", color = cs.primary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        }
                    }
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

/** Ilk acilis dil secimi. */
@Composable
fun LanguageStep(onNext: () -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    Surface(Modifier.fillMaxSize(), color = cs.background) {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 18.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(24.dp))
            Text(Lang.tr("Dilini seç"), fontSize = 26.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Text("Select your language", color = cs.onSurfaceVariant, fontSize = 14.sp)
            Spacer(Modifier.height(18.dp))
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                LanguageGrid(Lang.code) { Lang.set(ctx, it) }
            }
            Spacer(Modifier.height(12.dp))
            Button(onClick = onNext, modifier = Modifier.fillMaxWidth().height(54.dp)) {
                Text(Lang.tr("Devam et"), fontWeight = FontWeight.Bold, fontSize = 17.sp)
            }
        }
    }
}
