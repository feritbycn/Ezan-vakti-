@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.vakitpro.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vakitpro.app.data.Prefs
import com.vakitpro.app.notif.CustomIcon
import com.vakitpro.app.notif.NotifTheme
import com.vakitpro.app.notif.Notifier

/** Bildirim gorunumu: arka plan, saydamlik, vurgu ve yazi rengi + canli onizleme. */
@Composable
fun NotifLookCard(live: Boolean) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    var bg by remember { mutableIntStateOf(NotifTheme.bgIdx(ctx)) }
    var alpha by remember { mutableFloatStateOf(NotifTheme.alphaPct(ctx).toFloat()) }
    var acc by remember { mutableIntStateOf(NotifTheme.accIdx(ctx)) }
    var txt by remember { mutableIntStateOf(NotifTheme.txtIdx(ctx)) }
    var icon by remember { mutableIntStateOf(Prefs.getInt(ctx, "nt_icon", 0)) }

    var largeOn by remember { mutableIntStateOf(Prefs.getInt(ctx, "nt_icon_large", 0)) }
    var picMsg by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            scope.launch {
                val ok = withContext(Dispatchers.IO) { CustomIcon.save(ctx, uri) }
                if (ok) {
                    icon = 4
                    Prefs.putInt(ctx, "nt_icon", 4)
                    picMsg = "Resim ayarlandı."
                    Notifier.updateOngoing(ctx)
                } else picMsg = "Resim okunamadı."
            }
        }
    }

    fun apply() {
        Notifier.updateOngoing(ctx)
    }

    val a = alpha.toInt()
    val bgArgb = NotifTheme.bgColor(bg, a)
    val txtArgb = NotifTheme.text(bg, a, txt)
    val accArgb = NotifTheme.accent(acc)
    val fg = txtArgb?.let { Color(it) } ?: cs.onSurface

    ProCard {
        Text("Önizleme", style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
        Spacer(Modifier.size(6.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(cs.surfaceVariant)
                .padding(6.dp)
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(bgArgb))
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Akşam'a kalan süre", fontSize = 12.sp, color = fg.copy(alpha = 0.75f))
                        Text("Akşam 18:28 • İstanbul", fontSize = 11.sp, color = fg.copy(alpha = 0.75f))
                    }
                    Text("3:45:21", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color(accArgb))
                }
                Spacer(Modifier.size(6.dp))
                Row(Modifier.fillMaxWidth()) {
                    val names = listOf("İmsak", "Güneş", "Öğle", "İkindi", "Akşam", "Yatsı")
                    val times = listOf("05:47", "07:11", "12:55", "15:57", "18:28", "19:48")
                    for (i in 0 until 6) {
                        Column(
                            Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (i == 4) Color(accArgb).copy(alpha = 0.19f) else Color.Transparent)
                                .padding(vertical = 3.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(names[i], fontSize = 10.sp, color = if (i == 4) Color(accArgb) else fg.copy(alpha = 0.75f), maxLines = 1)
                            Text(times[i], fontSize = 13.sp, fontWeight = FontWeight.Bold, color = if (i == 4) Color(accArgb) else fg, maxLines = 1)
                        }
                    }
                }
            }
        }
        if (live) {
            Text(
                "Canlı güncelleme açıkken bildirimin özel görünümü kullanılmaz; bu ayarlar kapatınca geçerli olur.",
                Modifier.padding(top = 6.dp),
                style = MaterialTheme.typography.bodySmall,
                color = cs.error
            )
        }

        Spacer(Modifier.size(10.dp))
        Text("Simge (durum çubuğu ve bildirim)", style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("☪ Ayyıldız", "🌙 Hilal ve yıldız", "Hilal", "🕌 Cami", "🖼 Kendi resmim").forEachIndexed { i, name ->
                FilterChip(
                    selected = icon == i,
                    onClick = {
                        if (i == 4 && !CustomIcon.exists(ctx)) {
                            picker.launch("image/*")
                        } else {
                            icon = i
                            Prefs.putInt(ctx, "nt_icon", i)
                            apply()
                        }
                    },
                    label = { Text(name) }
                )
            }
        }
        if (icon == 4) {
            OutlinedButton(onClick = { picker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) {
                Text("🖼  Resmi değiştir")
            }
            Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Bildirimde renkli de göster", Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                Switch(checked = largeOn == 1, onCheckedChange = {
                    largeOn = if (it) 1 else 0
                    Prefs.putInt(ctx, "nt_icon_large", largeOn)
                    apply()
                })
            }
            Text(
                "Durum çubuğu simgeleri tek renk olur: resmin saydam arka planlı (PNG) olması ya da koyu bir çizim olması en iyi sonucu verir. Renkli hali bildirim panelinde görünür.",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant
            )
        }
        if (picMsg != null) Text(picMsg ?: "", style = MaterialTheme.typography.bodySmall, color = cs.primary)
        Text("60 dakikadan az kalınca simge, kalan dakikayı gösteren cami ikonuna döner.", Modifier.padding(top = 4.dp), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)

        Spacer(Modifier.size(10.dp))
        Text("Arka plan", style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NotifTheme.BG_NAMES.forEachIndexed { i, name ->
                FilterChip(
                    selected = bg == i,
                    onClick = {
                        bg = i
                        Prefs.putInt(ctx, "nt_bg", i)
                        apply()
                    },
                    label = { Text(name) }
                )
            }
        }

        Text(
            "Saydamlık: %${100 - a} saydam",
            Modifier.padding(top = 6.dp),
            style = MaterialTheme.typography.labelMedium,
            color = cs.onSurfaceVariant
        )
        Slider(
            value = alpha,
            onValueChange = { alpha = it },
            onValueChangeFinished = {
                Prefs.putInt(ctx, "nt_alpha", alpha.toInt())
                apply()
            },
            valueRange = 0f..100f,
            enabled = bg != 0
        )

        Text("Vurgu rengi (sayaç ve sıradaki vakit)", style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NotifTheme.ACC_NAMES.forEachIndexed { i, name ->
                FilterChip(
                    selected = acc == i,
                    onClick = {
                        acc = i
                        Prefs.putInt(ctx, "nt_acc", i)
                        apply()
                    },
                    label = { Text(name) }
                )
            }
        }

        Text(
            "Yazı rengi",
            Modifier.padding(top = 6.dp),
            style = MaterialTheme.typography.labelMedium,
            color = cs.onSurfaceVariant
        )
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NotifTheme.TXT_NAMES.forEachIndexed { i, name ->
                FilterChip(
                    selected = txt == i,
                    onClick = {
                        txt = i
                        Prefs.putInt(ctx, "nt_txt", i)
                        apply()
                    },
                    label = { Text(name) }
                )
            }
        }
    }
}
