package com.vakitpro.app.notif

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.vakitpro.app.data.Inspire

/**
 * Uygulamanin gorsel diline uygun (gece yesili/lacivert gradyan, islami yildiz deseni, cami silueti)
 * kart resimleri uretir. Hikaye kartlari, bildirim resmi ve acilan pencere ayni cizimi kullanir.
 */
object CardArt {
    class Theme(val top: Int, val bottom: Int, val accent: Int)

    val STORY_THEMES = listOf(
        Theme(0xFF06403A.toInt(), 0xFF0E7566.toInt(), 0xFFF2C26B.toInt()),
        Theme(0xFF0B1228.toInt(), 0xFF27306B.toInt(), 0xFFF2C26B.toInt()),
        Theme(0xFF3A1442.toInt(), 0xFF7A2E5C.toInt(), 0xFFFFD08A.toInt()),
        Theme(0xFF3B2A14.toInt(), 0xFF9A6B2E.toInt(), 0xFFFFE2A8.toInt()),
        Theme(0xFF052B3A.toInt(), 0xFF136C86.toInt(), 0xFF9BE7E0.toInt()),
        Theme(0xFF2A0F1F.toInt(), 0xFF7C2D47.toInt(), 0xFFF6C177.toInt())
    )

    // imsak, gunes, ogle, ikindi, aksam, yatsi
    private val PRAYER_THEMES = listOf(
        Theme(0xFF0B1B3A.toInt(), 0xFF2B3A67.toInt(), 0xFFF2C26B.toInt()),
        Theme(0xFF7A2E1B.toInt(), 0xFFF29C38.toInt(), 0xFFFFF0C8.toInt()),
        Theme(0xFF0A4D55.toInt(), 0xFF2FA7A0.toInt(), 0xFFFFE9A8.toInt()),
        Theme(0xFF7A4A10.toInt(), 0xFFE3B04B.toInt(), 0xFFFFF4D6.toInt()),
        Theme(0xFF4A1A4A.toInt(), 0xFFE0613F.toInt(), 0xFFFFE0B0.toInt()),
        Theme(0xFF0B0F2E.toInt(), 0xFF2A2563.toInt(), 0xFFF2C26B.toInt())
    )

    fun prayerTheme(idx: Int): Theme = PRAYER_THEMES[idx.coerceIn(0, 5)]

    private fun background(c: Canvas, w: Int, h: Int, t: Theme) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, 0f, h.toFloat(), t.top, t.bottom, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)

        // Ust kosede yumusak isik
        val g = Paint(Paint.ANTI_ALIAS_FLAG)
        g.shader = RadialGradient(
            w * 0.5f, h * 0.12f, w * 0.8f,
            Color.argb(70, Color.red(t.accent), Color.green(t.accent), Color.blue(t.accent)),
            Color.TRANSPARENT, Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), g)

        // Sekiz kollu yildiz deseni (iki ic ice kare)
        val line = Paint(Paint.ANTI_ALIAS_FLAG)
        line.style = Paint.Style.STROKE
        line.strokeWidth = (w / 540f).coerceAtLeast(1.2f)
        line.color = Color.argb(26, 255, 255, 255)
        val step = w / 6.5f
        val r = step * 0.42f
        var cy = -step * 0.3f
        var row = 0
        while (cy < h + step) {
            var cx = if (row % 2 == 0) 0f else step / 2f
            while (cx < w + step) {
                c.save()
                c.translate(cx, cy)
                c.drawRect(-r, -r, r, r, line)
                c.rotate(45f)
                c.drawRect(-r, -r, r, r, line)
                c.restore()
                cx += step
            }
            cy += step * 0.75f
            row++
        }

        // Alt kisma dogru kararma (silueti ve yaziyi okunur tutar)
        val v = Paint()
        v.shader = LinearGradient(
            0f, h * 0.55f, 0f, h.toFloat(),
            Color.TRANSPARENT, Color.argb(120, 0, 0, 0), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), v)
    }

    /** Kubbeli, iki minareli cami silueti. cx: orta, baseY: zemin, s: olcek. */
    private fun mosque(c: Canvas, cx: Float, baseY: Float, s: Float, p: Paint) {
        c.drawRect(cx - 32 * s, baseY - 32 * s, cx + 32 * s, baseY, p)
        c.drawCircle(cx, baseY - 32 * s, 26 * s, p)
        c.drawRect(cx - 1.5f * s, baseY - 78 * s, cx + 1.5f * s, baseY - 54 * s, p)
        c.drawCircle(cx, baseY - 80 * s, 4.5f * s, p)
        for (side in intArrayOf(-1, 1)) {
            val sx = cx + side * 36 * s
            c.drawCircle(sx, baseY - 26 * s, 11 * s, p)
            c.drawRect(sx - 11 * s, baseY - 26 * s, sx + 11 * s, baseY, p)
            val mx = cx + side * 62 * s
            c.drawRect(mx - 4.5f * s, baseY - 92 * s, mx + 4.5f * s, baseY, p)
            val tip = Path()
            tip.moveTo(mx - 5.5f * s, baseY - 92 * s)
            tip.lineTo(mx, baseY - 124 * s)
            tip.lineTo(mx + 5.5f * s, baseY - 92 * s)
            tip.close()
            c.drawPath(tip, p)
            c.drawRect(mx - 8 * s, baseY - 66 * s, mx + 8 * s, baseY - 61 * s, p)
        }
    }

    private fun skyline(c: Canvas, w: Int, h: Int, baseY: Float, s: Float, cxFrac: Float = 0.5f, sideDomes: Boolean = true) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = Color.argb(110, 0, 0, 0)
        mosque(c, w * cxFrac, baseY, s, p)
        if (sideDomes) {
            c.drawCircle(w * 0.12f, baseY - 14 * s, 14 * s, p)
            c.drawCircle(w * 0.88f, baseY - 14 * s, 14 * s, p)
        }
        c.drawRect(0f, baseY, w.toFloat(), h.toFloat(), p)
    }

    private fun crescent(c: Canvas, cx: Float, cy: Float, r: Float, color: Int) {
        val a = Path()
        a.addCircle(cx, cy, r, Path.Direction.CW)
        val b = Path()
        b.addCircle(cx + r * 0.42f, cy - r * 0.12f, r * 0.82f, Path.Direction.CW)
        a.op(b, Path.Op.DIFFERENCE)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = color
        c.drawPath(a, p)
        // yildiz
        val sx = cx + r * 0.95f
        val sy = cy - r * 0.55f
        val st = Path()
        val sr = r * 0.2f
        for (i in 0 until 10) {
            val ang = Math.toRadians((i * 36 - 90).toDouble())
            val rr = if (i % 2 == 0) sr else sr * 0.42f
            val x = sx + (rr * Math.cos(ang)).toFloat()
            val y = sy + (rr * Math.sin(ang)).toFloat()
            if (i == 0) st.moveTo(x, y) else st.lineTo(x, y)
        }
        st.close()
        c.drawPath(st, p)
    }

    private fun fitLayout(text: String, paint: TextPaint, width: Int, maxH: Int, maxSize: Float, minSize: Float): StaticLayout {
        var size = maxSize
        var layout: StaticLayout
        while (true) {
            paint.textSize = size
            layout = StaticLayout.Builder.obtain(text, 0, text.length, paint, width)
                .setAlignment(Layout.Alignment.ALIGN_CENTER)
                .setLineSpacing(0f, 1.18f)
                .build()
            if (layout.height <= maxH || size <= minSize) break
            size -= 2f
        }
        return layout
    }

    /** Ana ekrandaki hikaye halkasi icin kare rozet. */
    fun badge(kind: Int, size: Int): Bitmap {
        val t = STORY_THEMES[Math.floorMod(kind, STORY_THEMES.size)]
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        background(c, size, size, t)
        crescent(c, size * 0.46f, size * 0.52f, size * 0.26f, t.accent)
        return bmp
    }

    /** 1080x1920 dikey hikaye karti. */
    fun story(item: Inspire, themeIdx: Int, w: Int = 1080, h: Int = 1920): Bitmap {
        val t = STORY_THEMES[Math.floorMod(themeIdx, STORY_THEMES.size)]
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val k = w / 1080f
        background(c, w, h, t)
        skyline(c, w, h, h - 150f * k, 6.2f * k)
        crescent(c, w / 2f, 250f * k, 70f * k, t.accent)

        // Tur etiketi
        val tag = TextPaint(Paint.ANTI_ALIAS_FLAG)
        tag.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        tag.color = t.accent
        tag.textSize = 40f * k
        tag.letterSpacing = 0.12f
        tag.textAlign = Paint.Align.CENTER
        val label = item.kindName.uppercase(java.util.Locale("tr"))
        val tw = tag.measureText(label)
        val pill = RectF(w / 2f - tw / 2f - 44f * k, 400f * k, w / 2f + tw / 2f + 44f * k, 482f * k)
        val pp = Paint(Paint.ANTI_ALIAS_FLAG)
        pp.style = Paint.Style.STROKE
        pp.strokeWidth = 3f * k
        pp.color = Color.argb(190, Color.red(t.accent), Color.green(t.accent), Color.blue(t.accent))
        c.drawRoundRect(pill, 41f * k, 41f * k, pp)
        c.drawText(label, w / 2f, 457f * k, tag)

        // Metin
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
        tp.typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
        tp.color = Color.WHITE
        val tw2 = (w - 190f * k).toInt()
        val layout = fitLayout(item.text, tp, tw2, (700f * k).toInt(), 78f * k, 40f * k)
        val area = 760f * k
        val top = 560f * k + (area - layout.height) / 2f
        // Buyuk tirnak
        val q = TextPaint(Paint.ANTI_ALIAS_FLAG)
        q.typeface = Typeface.SERIF
        q.color = Color.argb(120, Color.red(t.accent), Color.green(t.accent), Color.blue(t.accent))
        q.textSize = 220f * k
        q.textAlign = Paint.Align.CENTER
        c.drawText("“", w / 2f, top - 10f * k, q)
        c.save()
        c.translate((w - tw2) / 2f, top)
        layout.draw(c)
        c.restore()

        // Kaynak
        val sp = TextPaint(Paint.ANTI_ALIAS_FLAG)
        sp.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        sp.color = t.accent
        sp.textSize = 44f * k
        sp.textAlign = Paint.Align.CENTER
        if (item.source.isNotBlank()) c.drawText("— ${item.source}", w / 2f, top + layout.height + 90f * k, sp)

        footer(c, w, h, k, Color.argb(235, 255, 255, 255))
        return bmp
    }

    private fun footer(c: Canvas, w: Int, h: Int, k: Float, color: Int) {
        val f = TextPaint(Paint.ANTI_ALIAS_FLAG)
        f.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        f.color = color
        f.textSize = 42f * k
        f.textAlign = Paint.Align.RIGHT
        c.drawText("Vakit Pro", w - 56f * k, h - 58f * k, f)
        crescent(c, w - 56f * k - f.measureText("Vakit Pro") - 46f * k, h - 74f * k, 22f * k, color)
    }

    /**
     * 2:1 bildirim / pencere resmi.
     * title: vakit adi, line2: "45 dk kaldi" ya da "Vakit girdi", time: "12:55", place: sehir.
     */
    fun prayerCard(idx: Int, title: String, line2: String, time: String, place: String, w: Int = 1024, h: Int = 512): Bitmap {
        val t = prayerTheme(idx)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val k = w / 1024f
        background(c, w, h, t)
        skyline(c, w, h, h - 36f * k, 3.3f * k, 0.76f, false)
        crescent(c, w - 120f * k, 110f * k, 46f * k, t.accent)

        val a = TextPaint(Paint.ANTI_ALIAS_FLAG)
        a.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        a.color = Color.argb(215, 255, 255, 255)
        a.textSize = 40f * k
        c.drawText(place, 56f * k, 84f * k, a)

        val b = TextPaint(Paint.ANTI_ALIAS_FLAG)
        b.typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
        b.color = Color.WHITE
        b.textSize = 104f * k
        c.drawText(title, 56f * k, 200f * k, b)

        val d = TextPaint(Paint.ANTI_ALIAS_FLAG)
        d.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        d.color = t.accent
        d.textSize = 54f * k
        c.drawText(line2, 56f * k, 272f * k, d)

        val e = TextPaint(Paint.ANTI_ALIAS_FLAG)
        e.typeface = Typeface.create("sans-serif", Typeface.BOLD)
        e.color = Color.WHITE
        e.textSize = 84f * k
        c.drawText(time, 56f * k, 372f * k, e)

        val f = TextPaint(Paint.ANTI_ALIAS_FLAG)
        f.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        f.color = Color.argb(235, 255, 255, 255)
        f.textSize = 30f * k
        f.textAlign = Paint.Align.RIGHT
        c.drawText("Vakit Pro", w - 28f * k, h - 12f * k, f)
        return bmp
    }
}
