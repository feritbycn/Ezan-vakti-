package com.vakitpro.app.notif

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.vakitpro.app.data.Inspire

/**
 * Uygulamanin gorsel diline uygun (gece yesili/lacivert gradyan, islami yildiz deseni, cami silueti)
 * kart resimleri uretir. Hikaye kartlari, bildirim resmi ve acilan pencere ayni cizimi kullanir.
 */
object CardArt {
    class Theme(val top: Int, val bottom: Int, val accent: Int)

    val STORY_THEMES = listOf(
        Theme(0xFF06403A.toInt(), 0xFF0E7566.toInt(), 0xFFF2C26B.toInt()),
        Theme(0xFF0B1228.toInt(), 0xFF27306B.toInt(), 0xFFF2C26B.toInt()),
        Theme(0xFF3A1442.toInt(), 0xFF7A2E5C.toInt(), 0xFFFFD08A.toInt()),
        Theme(0xFF3B2A14.toInt(), 0xFF9A6B2E.toInt(), 0xFFFFE2A8.toInt()),
        Theme(0xFF052B3A.toInt(), 0xFF136C86.toInt(), 0xFF9BE7E0.toInt()),
        Theme(0xFF2A0F1F.toInt(), 0xFF7C2D47.toInt(), 0xFFF6C177.toInt())
    )

    // imsak, gunes, ogle, ikindi, aksam, yatsi
    private val PRAYER_THEMES = listOf(
        Theme(0xFF0B1B3A.toInt(), 0xFF2B3A67.toInt(), 0xFFF2C26B.toInt()),
        Theme(0xFF7A2E1B.toInt(), 0xFFF29C38.toInt(), 0xFFFFF0C8.toInt()),
        Theme(0xFF0A4D55.toInt(), 0xFF2FA7A0.toInt(), 0xFFFFE9A8.toInt()),
        Theme(0xFF7A4A10.toInt(), 0xFFE3B04B.toInt(), 0xFFFFF4D6.toInt()),
        Theme(0xFF4A1A4A.toInt(), 0xFFE0613F.toInt(), 0xFFFFE0B0.toInt()),
        Theme(0xFF0B0F2E.toInt(), 0xFF2A2563.toInt(), 0xFFF2C26B.toInt())
    )

    fun prayerTheme(idx: Int): Theme = PRAYER_THEMES[idx.coerceIn(0, 5)]

    private fun background(c: Canvas, w: Int, h: Int, t: Theme, pattern: Boolean = true) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, 0f, h.toFloat(), t.top, t.bottom, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)

        // Ust kosede yumusak isik
        val g = Paint(Paint.ANTI_ALIAS_FLAG)
        g.shader = RadialGradient(
            w * 0.5f, h * 0.12f, w * 0.8f,
            Color.argb(70, Color.red(t.accent), Color.green(t.accent), Color.blue(t.accent)),
            Color.TRANSPARENT, Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), g)

        // Sekiz kollu yildiz deseni (iki ic ice kare)
        if (pattern) drawPattern(c, w, h)

        // Alt kisma dogru kararma (silueti ve yaziyi okunur tutar)
        val v = Paint()
        v.shader = LinearGradient(
            0f, h * 0.55f, 0f, h.toFloat(),
            Color.TRANSPARENT, Color.argb(120, 0, 0, 0), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), v)
    }

    private fun drawPattern(c: Canvas, w: Int, h: Int) {
        val line = Paint(Paint.ANTI_ALIAS_FLAG)
        line.style = Paint.Style.STROKE
        line.strokeWidth = (w / 540f).coerceAtLeast(1.2f)
        line.color = Color.argb(26, 255, 255, 255)
        val step = w / 6.5f
        val r = step * 0.42f
        var cy = -step * 0.3f
        var row = 0
        while (cy < h + step) {
            var cx = if (row % 2 == 0) 0f else step / 2f
            while (cx < w + step) {
                c.save()
                c.translate(cx, cy)
                c.drawRect(-r, -r, r, r, line)
                c.rotate(45f)
                c.drawRect(-r, -r, r, r, line)
                c.restore()
                cx += step
            }
            cy += step * 0.75f
            row++
        }
    }

    /** Kubbeli, iki minareli cami silueti. cx: orta, baseY: zemin, s: olcek. */
    private fun mosque(c: Canvas, cx: Float, baseY: Float, s: Float, p: Paint) {
        c.drawRect(cx - 32 * s, baseY - 32 * s, cx + 32 * s, baseY, p)
        c.drawCircle(cx, baseY - 32 * s, 26 * s, p)
        c.drawRect(cx - 1.5f * s, baseY - 78 * s, cx + 1.5f * s, baseY - 54 * s, p)
        c.drawCircle(cx, baseY - 80 * s, 4.5f * s, p)
        for (side in intArrayOf(-1, 1)) {
            val sx = cx + side * 36 * s
            c.drawCircle(sx, baseY - 26 * s, 11 * s, p)
            c.drawRect(sx - 11 * s, baseY - 26 * s, sx + 11 * s, baseY, p)
            val mx = cx + side * 62 * s
            c.drawRect(mx - 4.5f * s, baseY - 92 * s, mx + 4.5f * s, baseY, p)
            val tip = Path()
            tip.moveTo(mx - 5.5f * s, baseY - 92 * s)
            tip.lineTo(mx, baseY - 124 * s)
            tip.lineTo(mx + 5.5f * s, baseY - 92 * s)
            tip.close()
            c.drawPath(tip, p)
            c.drawRect(mx - 8 * s, baseY - 66 * s, mx + 8 * s, baseY - 61 * s, p)
        }
    }

    private fun skyline(c: Canvas, w: Int, h: Int, baseY: Float, s: Float, cxFrac: Float = 0.5f, sideDomes: Boolean = true) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = Color.argb(110, 0, 0, 0)
        mosque(c, w * cxFrac, baseY, s, p)
        if (sideDomes) {
            c.drawCircle(w * 0.12f, baseY - 14 * s, 14 * s, p)
            c.drawCircle(w * 0.88f, baseY - 14 * s, 14 * s, p)
        }
        c.drawRect(0f, baseY, w.toFloat(), h.toFloat(), p)
    }

    private fun crescent(c: Canvas, cx: Float, cy: Float, r: Float, color: Int) {
        val a = Path()
        a.addCircle(cx, cy, r, Path.Direction.CW)
        val b = Path()
        b.addCircle(cx + r * 0.42f, cy - r * 0.12f, r * 0.82f, Path.Direction.CW)
        a.op(b, Path.Op.DIFFERENCE)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = color
        c.drawPath(a, p)
        // yildiz
        val sx = cx + r * 0.95f
        val sy = cy - r * 0.55f
        val st = Path()
        val sr = r * 0.2f
        for (i in 0 until 10) {
            val ang = Math.toRadians((i * 36 - 90).toDouble())
            val rr = if (i % 2 == 0) sr else sr * 0.42f
            val x = sx + (rr * Math.cos(ang)).toFloat()
            val y = sy + (rr * Math.sin(ang)).toFloat()
            if (i == 0) st.moveTo(x, y) else st.lineTo(x, y)
        }
        st.close()
        c.drawPath(st, p)
    }

    private fun fitLayout(text: String, paint: TextPaint, width: Int, maxH: Int, maxSize: Float, minSize: Float): StaticLayout {
        var size = maxSize
        var layout: StaticLayout
        while (true) {
            paint.textSize = size
            layout = StaticLayout.Builder.obtain(text, 0, text.length, paint, width)
                .setAlignment(Layout.Alignment.ALIGN_CENTER)
                .setLineSpacing(0f, 1.18f)
                .build()
            if (layout.height <= maxH || size <= minSize) break
            size -= 2f
        }
        return layout
    }

    /** Ana ekrandaki hikaye halkasi icin kare rozet. */
    fun badge(kind: Int, size: Int): Bitmap {
        val t = STORY_THEMES[Math.floorMod(kind, STORY_THEMES.size)]
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        background(c, size, size, t)
        crescent(c, size * 0.46f, size * 0.52f, size * 0.26f, t.accent)
        return bmp
    }

    private fun accentA(t: Theme, a: Int) = Color.argb(a, Color.red(t.accent), Color.green(t.accent), Color.blue(t.accent))

    private fun layoutLeft(text: String, paint: TextPaint, width: Int, maxH: Int, maxSize: Float, minSize: Float): StaticLayout {
        var size = maxSize
        var layout: StaticLayout
        while (true) {
            paint.textSize = size
            layout = StaticLayout.Builder.obtain(text, 0, text.length, paint, width)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setLineSpacing(0f, 1.15f)
                .build()
            if (layout.height <= maxH || size <= minSize) break
            size -= 2f
        }
        return layout
    }

    private fun label(item: Inspire): String = item.kindName.uppercase(java.util.Locale("tr"))

    /**
     * 1080x1920 dikey hikaye karti. themeIdx arttikca renk (6) ve tasarim (4) degisir;
     * yan yana iki kart hic ayni gorunmez.
     */
    fun story(item: Inspire, themeIdx: Int, w: Int = 1080, h: Int = 1920, ctx: android.content.Context? = null, sign: Boolean = false): Bitmap {
        val t = STORY_THEMES[Math.floorMod(themeIdx, STORY_THEMES.size)]
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val k = w / 1080f
        if (ctx != null) {
            try {
                PanelArt.draw(ctx, c, w, h, PanelArt.res(item.kind), null, item.text, item.source, sign)
                return bmp
            } catch (e: Exception) {
            }
        }
        when (Math.floorMod(themeIdx, 4)) {
            0 -> storyCentered(c, item, t, w, h, k)
            1 -> storyArch(c, item, t, w, h, k)
            2 -> storyMinimal(c, item, t, w, h, k)
            else -> storyMedallion(c, item, t, w, h, k)
        }
        footer(c, w, h, k, Color.argb(235, 255, 255, 255))
        return bmp
    }

    // ---- Dua: ozel dua arka plani
    private fun storyDua(ctx: android.content.Context, c: Canvas, item: Inspire, t: Theme, w: Int, h: Int, k: Float) {
        val src = android.graphics.BitmapFactory.decodeResource(ctx.resources, when (item.kind) { Inspire.AYET -> com.vakitpro.app.R.drawable.story_ayet_bg; Inspire.HADIS -> com.vakitpro.app.R.drawable.story_hadis_bg; else -> com.vakitpro.app.R.drawable.story_dua_bg })
        val sc = maxOf(w / src.width.toFloat(), h / src.height.toFloat())
        val dw = src.width * sc
        val dh = src.height * sc
        c.drawBitmap(src, null, RectF((w - dw) / 2f, (h - dh) / 2f, (w + dw) / 2f, (h + dh) / 2f), Paint(Paint.FILTER_BITMAP_FLAG))
        val gold = Color.rgb(236, 200, 120)
        val tag = TextPaint(Paint.ANTI_ALIAS_FLAG)
        tag.typeface = Typeface.create("serif", Typeface.BOLD)
        tag.color = gold
        tag.textSize = 64f * k
        tag.textAlign = Paint.Align.CENTER
        tag.setShadowLayer(8f, 0f, 3f, Color.argb(190, 0, 0, 0))
        val ay = item.kind == Inspire.AYET
        val hd = item.kind == Inspire.HADIS
        val tTop = if (hd) 0.27f else if (ay) 0.30f else 0.275f
        c.drawText(if (hd) "HADİS" else if (ay) "AYET" else "DUA", w / 2f, h * (tTop - 0.03f), tag)

        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
        tp.typeface = Typeface.create("serif", Typeface.NORMAL)
        tp.color = Color.rgb(250, 247, 238)
        tp.setShadowLayer(8f, 0f, 3f, Color.argb(190, 0, 0, 0))
        val tw = (w * 0.70f).toInt()
        val body = "\u201C" + item.text.trim() + "\u201D"
        val layout = fitLayout(body, tp, tw, (h * (if (hd) 0.33f else if (ay) 0.24f else 0.17f)).toInt(), 62f * k, 32f * k)
        val top = h * tTop
        c.save()
        c.translate((w - tw) / 2f, top)
        layout.draw(c)
        c.restore()
        if (item.source.isNotBlank()) {
            val sp = TextPaint(Paint.ANTI_ALIAS_FLAG)
            sp.typeface = Typeface.create("serif", Typeface.NORMAL)
            sp.color = gold
            sp.textSize = 44f * k
            sp.textAlign = Paint.Align.CENTER
            sp.setShadowLayer(8f, 0f, 3f, Color.argb(190, 0, 0, 0))
            c.drawText("\u2014 " + item.source, w / 2f, top + layout.height + 66f * k, sp)
        }
    }

    private fun sourceLine(c: Canvas, item: Inspire, t: Theme, x: Float, y: Float, k: Float, align: Paint.Align) {
        if (item.source.isBlank()) return
        val sp = TextPaint(Paint.ANTI_ALIAS_FLAG)
        sp.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        sp.color = t.accent
        sp.textSize = 44f * k
        sp.textAlign = align
        c.drawText("— ${item.source}", x, y, sp)
    }

    // ---- Tasarim 0: ortali, cami silueti
    private fun storyCentered(c: Canvas, item: Inspire, t: Theme, w: Int, h: Int, k: Float) {
        background(c, w, h, t)
        skyline(c, w, h, h - 150f * k, 6.2f * k)
        crescent(c, w / 2f, 250f * k, 70f * k, t.accent)

        val tag = TextPaint(Paint.ANTI_ALIAS_FLAG)
        tag.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        tag.color = t.accent
        tag.textSize = 40f * k
        tag.letterSpacing = 0.12f
        tag.textAlign = Paint.Align.CENTER
        val lb = label(item)
        val tw = tag.measureText(lb)
        val pill = RectF(w / 2f - tw / 2f - 44f * k, 400f * k, w / 2f + tw / 2f + 44f * k, 482f * k)
        val pp = Paint(Paint.ANTI_ALIAS_FLAG)
        pp.style = Paint.Style.STROKE
        pp.strokeWidth = 3f * k
        pp.color = accentA(t, 190)
        c.drawRoundRect(pill, 41f * k, 41f * k, pp)
        c.drawText(lb, w / 2f, 457f * k, tag)

        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
        tp.typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
        tp.color = Color.WHITE
        val tw2 = (w - 190f * k).toInt()
        val layout = fitLayout(item.text, tp, tw2, (700f * k).toInt(), 78f * k, 40f * k)
        val top = 560f * k + (760f * k - layout.height) / 2f
        val q = TextPaint(Paint.ANTI_ALIAS_FLAG)
        q.typeface = Typeface.SERIF
        q.color = accentA(t, 120)
        q.textSize = 220f * k
        q.textAlign = Paint.Align.CENTER
        c.drawText("\u201C", w / 2f, top - 10f * k, q)
        c.save()
        c.translate((w - tw2) / 2f, top)
        layout.draw(c)
        c.restore()
        sourceLine(c, item, t, w / 2f, top + layout.height + 90f * k, k, Paint.Align.CENTER)
    }

    private fun archPath(l: Float, top: Float, r: Float, bottom: Float): Path {
        val rad = (r - l) / 2f
        val p = Path()
        p.moveTo(l, bottom)
        p.lineTo(l, top + rad)
        p.arcTo(RectF(l, top, r, top + 2 * rad), 180f, 180f)
        p.lineTo(r, bottom)
        p.close()
        return p
    }

    // ---- Tasarim 1: mihrap kemeri icinde
    private fun storyArch(c: Canvas, item: Inspire, t: Theme, w: Int, h: Int, k: Float) {
        background(c, w, h, t)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        fill.color = Color.argb(34, 255, 255, 255)
        c.drawPath(archPath(130f * k, 360f * k, 950f * k, 1640f * k), fill)
        val st = Paint(Paint.ANTI_ALIAS_FLAG)
        st.style = Paint.Style.STROKE
        st.color = accentA(t, 220)
        st.strokeWidth = 6f * k
        c.drawPath(archPath(130f * k, 360f * k, 950f * k, 1640f * k), st)
        st.strokeWidth = 2.5f * k
        st.color = accentA(t, 120)
        c.drawPath(archPath(160f * k, 392f * k, 920f * k, 1640f * k), st)

        crescent(c, w / 2f - 14f * k, 640f * k, 52f * k, t.accent)
        val tag = TextPaint(Paint.ANTI_ALIAS_FLAG)
        tag.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        tag.color = t.accent
        tag.textSize = 38f * k
        tag.letterSpacing = 0.14f
        tag.textAlign = Paint.Align.CENTER
        c.drawText(label(item), w / 2f, 770f * k, tag)

        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
        tp.typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD_ITALIC)
        tp.color = Color.WHITE
        val tw2 = (600f * k).toInt()
        val layout = fitLayout(item.text, tp, tw2, (640f * k).toInt(), 68f * k, 36f * k)
        val top = 830f * k + (690f * k - layout.height) / 2f
        c.save()
        c.translate((w - tw2) / 2f, top)
        layout.draw(c)
        c.restore()
        sourceLine(c, item, t, w / 2f, minOf(top + layout.height + 80f * k, 1590f * k), k, Paint.Align.CENTER)

        val ground = Paint()
        ground.color = Color.argb(90, 0, 0, 0)
        c.drawRect(0f, 1640f * k, w.toFloat(), h.toFloat(), ground)
    }

    // ---- Tasarim 2: sola hizali, sade ve modern
    private fun storyMinimal(c: Canvas, item: Inspire, t: Theme, w: Int, h: Int, k: Float) {
        background(c, w, h, t, false)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = accentA(t, 34)
        c.drawCircle(w * 0.88f, 330f * k, 400f * k, p)
        p.color = Color.argb(18, 255, 255, 255)
        c.drawCircle(w * 0.06f, h - 360f * k, 320f * k, p)
        crescent(c, w - 230f * k, 300f * k, 100f * k, accentA(t, 235))

        val bar = Paint(Paint.ANTI_ALIAS_FLAG)
        bar.color = t.accent
        c.drawRoundRect(RectF(110f * k, 560f * k, 122f * k, 1330f * k), 6f * k, 6f * k, bar)

        val tag = TextPaint(Paint.ANTI_ALIAS_FLAG)
        tag.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        tag.color = t.accent
        tag.textSize = 40f * k
        tag.letterSpacing = 0.16f
        c.drawText(label(item), 160f * k, 520f * k, tag)

        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
        tp.typeface = Typeface.create("sans-serif", Typeface.BOLD)
        tp.color = Color.WHITE
        val tw2 = (790f * k).toInt()
        val layout = layoutLeft(item.text, tp, tw2, (700f * k).toInt(), 80f * k, 40f * k)
        val top = 580f * k
        c.save()
        c.translate(160f * k, top)
        layout.draw(c)
        c.restore()
        sourceLine(c, item, t, 160f * k, top + layout.height + 80f * k, k, Paint.Align.LEFT)

        // alt kisimda egik seritler
        val s = Paint(Paint.ANTI_ALIAS_FLAG)
        for ((i, a) in intArrayOf(46, 30, 18).withIndex()) {
            s.color = accentA(t, a)
            val y = h - (330f - i * 95f) * k
            val path = Path()
            path.moveTo(0f, y)
            path.lineTo(w.toFloat(), y - 150f * k)
            path.lineTo(w.toFloat(), y - 150f * k + 70f * k)
            path.lineTo(0f, y + 70f * k)
            path.close()
            c.drawPath(path, s)
        }
    }

    // ---- Tasarim 3: medalyon + isinlar
    private fun storyMedallion(c: Canvas, item: Inspire, t: Theme, w: Int, h: Int, k: Float) {
        background(c, w, h, t, false)
        val ray = Paint(Paint.ANTI_ALIAS_FLAG)
        ray.color = Color.argb(16, 255, 255, 255)
        val cx = w / 2f
        val cy = 980f * k
        for (i in 0 until 24) {
            val a1 = Math.toRadians((i * 15.0))
            val a2 = Math.toRadians((i * 15.0 + 6.0))
            val path = Path()
            path.moveTo(cx, cy)
            path.lineTo(cx + (1800f * k * Math.cos(a1)).toFloat(), cy + (1800f * k * Math.sin(a1)).toFloat())
            path.lineTo(cx + (1800f * k * Math.cos(a2)).toFloat(), cy + (1800f * k * Math.sin(a2)).toFloat())
            path.close()
            c.drawPath(path, ray)
        }
        val disc = Paint(Paint.ANTI_ALIAS_FLAG)
        disc.color = Color.argb(110, 0, 0, 0)
        c.drawCircle(cx, cy, 430f * k, disc)
        val ring = Paint(Paint.ANTI_ALIAS_FLAG)
        ring.style = Paint.Style.STROKE
        ring.strokeWidth = 6f * k
        ring.color = accentA(t, 230)
        c.drawCircle(cx, cy, 430f * k, ring)
        ring.strokeWidth = 5f * k
        ring.color = accentA(t, 160)
        ring.pathEffect = android.graphics.DashPathEffect(floatArrayOf(3f * k, 20f * k), 0f)
        ring.strokeCap = Paint.Cap.ROUND
        c.drawCircle(cx, cy, 468f * k, ring)

        crescent(c, cx - 16f * k, 320f * k, 74f * k, t.accent)
        val tag = TextPaint(Paint.ANTI_ALIAS_FLAG)
        tag.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        tag.color = t.accent
        tag.textSize = 38f * k
        tag.letterSpacing = 0.14f
        tag.textAlign = Paint.Align.CENTER
        c.drawText(label(item), cx, 470f * k, tag)

        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
        tp.typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
        tp.color = Color.WHITE
        val tw2 = (610f * k).toInt()
        val layout = fitLayout(item.text, tp, tw2, (560f * k).toInt(), 64f * k, 34f * k)
        c.save()
        c.translate(cx - tw2 / 2f, cy - layout.height / 2f)
        layout.draw(c)
        c.restore()
        sourceLine(c, item, t, cx, cy + 430f * k + 110f * k, k, Paint.Align.CENTER)
        skyline(c, w, h, h - 110f * k, 4.2f * k)
    }

    private fun footer(c: Canvas, w: Int, h: Int, k: Float, color: Int) {
        val f = TextPaint(Paint.ANTI_ALIAS_FLAG)
        f.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        f.color = color
        f.textSize = 42f * k
        f.textAlign = Paint.Align.RIGHT
        c.drawText("NurVakit", w - 56f * k, h - 58f * k, f)
        crescent(c, w - 56f * k - f.measureText("NurVakit") - 46f * k, h - 74f * k, 22f * k, color)
    }

    /**
     * 2:1 bildirim / pencere resmi.
     * title: vakit adi, line2: "45 dk kaldi" ya da "Vakit girdi", time: "12:55", place: sehir.
     */
    fun prayerCard(idx: Int, title: String, line2: String, time: String, place: String, w: Int = 1024, h: Int = 512): Bitmap {
        val t = prayerTheme(idx)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val k = w / 1024f
        background(c, w, h, t)
        skyline(c, w, h, h - 36f * k, 3.3f * k, 0.76f, false)
        crescent(c, w - 120f * k, 110f * k, 46f * k, t.accent)

        val a = TextPaint(Paint.ANTI_ALIAS_FLAG)
        a.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        a.color = Color.argb(215, 255, 255, 255)
        a.textSize = 40f * k
        c.drawText(place, 56f * k, 84f * k, a)

        val b = TextPaint(Paint.ANTI_ALIAS_FLAG)
        b.typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
        b.color = Color.WHITE
        b.textSize = 104f * k
        c.drawText(title, 56f * k, 200f * k, b)

        val d = TextPaint(Paint.ANTI_ALIAS_FLAG)
        d.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        d.color = t.accent
        d.textSize = 54f * k
        c.drawText(line2, 56f * k, 272f * k, d)

        val e = TextPaint(Paint.ANTI_ALIAS_FLAG)
        e.typeface = Typeface.create("sans-serif", Typeface.BOLD)
        e.color = Color.WHITE
        e.textSize = 84f * k
        c.drawText(time, 56f * k, 372f * k, e)

        val f = TextPaint(Paint.ANTI_ALIAS_FLAG)
        f.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        f.color = Color.argb(235, 255, 255, 255)
        f.textSize = 30f * k
        f.textAlign = Paint.Align.RIGHT
        c.drawText("NurVakit", w - 28f * k, h - 12f * k, f)
        return bmp
    }
}
