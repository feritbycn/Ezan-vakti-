package com.vakitpro.app.notif

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import androidx.core.app.NotificationCompat
import androidx.core.graphics.drawable.IconCompat
import com.vakitpro.app.MainActivity
import com.vakitpro.app.R
import com.vakitpro.app.data.Fmt
import com.vakitpro.app.data.Names
import com.vakitpro.app.data.PrayerRepo
import com.vakitpro.app.data.Prefs
import com.vakitpro.app.data.Settings
import java.util.Locale

object Notifier {
    const val ONGOING_ID = 4242
    private const val ALERT_BASE = 5000
    private const val REMIND_BASE = 5100

    const val CH_ONGOING = "ongoing_v2"
    const val CH_REMIND = "remind_v1"
    private const val ALERT_PREFIX = "vakit_v"

    fun alertChannelId(s: Settings) = "$ALERT_PREFIX${s.channelVer}"

    private fun nm(ctx: Context): NotificationManager =
        ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    /** Ozel ezan sesi: app/src/main/res/raw/ezan.mp3 eklenirse "Ezan sesi" secenegi calisir. */
    fun ezanRawUri(ctx: Context): Uri? {
        val id = ctx.resources.getIdentifier("ezan", "raw", ctx.packageName)
        return if (id != 0) Uri.parse("android.resource://${ctx.packageName}/$id") else null
    }

    fun soundUri(ctx: Context, s: Settings): Uri? = when (s.soundMode) {
        "alarm" -> RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        "custom" -> if (s.soundUri.isNotBlank()) Uri.parse(s.soundUri)
        else RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        "ezan" -> ezanRawUri(ctx) ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        else -> RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
    }

    fun ensureChannels(ctx: Context, s: Settings) {
        val m = nm(ctx)

        val ongoing = NotificationChannel(CH_ONGOING, "Geri sayım (kalıcı)", NotificationManager.IMPORTANCE_LOW)
        ongoing.description = "Sıradaki vakte kalan süreyi bildirim çubuğunda gösterir."
        ongoing.setShowBadge(false)
        ongoing.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        m.createNotificationChannel(ongoing)

        val remind = NotificationChannel(CH_REMIND, "Vakit hatırlatıcı", NotificationManager.IMPORTANCE_DEFAULT)
        remind.description = "Vakitten önce haber verir."
        m.createNotificationChannel(remind)

        val id = alertChannelId(s)
        if (m.getNotificationChannel(id) == null) {
            val usage = if (s.soundMode == "alarm" || s.soundMode == "ezan")
                AudioAttributes.USAGE_ALARM else AudioAttributes.USAGE_NOTIFICATION
            val attrs = AudioAttributes.Builder()
                .setUsage(usage)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            val ch = NotificationChannel(id, "Vakit girdi (ezan)", NotificationManager.IMPORTANCE_HIGH)
            ch.description = "Vakit girdiğinde ses ve titreşimle bildirir."
            ch.setSound(soundUri(ctx, s), attrs)
            ch.enableVibration(s.vibrate)
            if (s.vibrate) ch.vibrationPattern = longArrayOf(0, 400, 200, 400)
            ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            m.createNotificationChannel(ch)
        }
        // eski surum kanallarini temizle
        for (c in m.notificationChannels) {
            if (c.id.startsWith(ALERT_PREFIX) && c.id != id) m.deleteNotificationChannel(c.id)
        }
    }

    private fun openAppIntent(ctx: Context): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        return PendingIntent.getActivity(
            ctx, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    /** Durum cubugu ikonu: kalan dakikayi sayi olarak cizer (100 dk ustu icin "S:DD"). */
    private fun minuteIcon(min: Int): IconCompat {
        val size = 96
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = Color.WHITE
        p.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
        p.textAlign = Paint.Align.CENTER
        val text = if (min < 100) min.toString()
        else String.format(Locale.US, "%d:%02d", min / 60, min % 60)
        var ts = 84f
        p.textSize = ts
        while (p.measureText(text) > size - 4 && ts > 20f) {
            ts -= 4f
            p.textSize = ts
        }
        val y = size / 2f - (p.descent() + p.ascent()) / 2f
        c.drawText(text, size / 2f, y, p)
        return IconCompat.createWithBitmap(bmp)
    }

    fun buildOngoing(ctx: Context, s: Settings, now: Long = System.currentTimeMillis()): Notification {
        val n = PrayerRepo.next(s, now)
        val remainMin = ((n.timeMs - now + 59_999L) / 60_000L).toInt().coerceAtLeast(0)
        val times = PrayerRepo.times(s, PrayerRepo.today(now))

        val sb = StringBuilder()
        for (i in 0 until 6) {
            val mark = if (times[i] > now && i == n.index) "▶" else "•"
            sb.append(mark).append(' ').append(Names.SHORT[i]).append("  ").append(Fmt.hm(times[i]))
            if (i < 5) sb.append('\n')
        }

        val b = NotificationCompat.Builder(ctx, CH_ONGOING)
            .setContentTitle("${Names.DATIVE[n.index]} kalan süre")
            .setContentText("${Names.SHORT[n.index]} ${Fmt.hm(n.timeMs)} • ${s.cityName}")
            .setStyle(NotificationCompat.BigTextStyle().bigText(sb.toString()))
            .setWhen(n.timeMs)
            .setShowWhen(true)
            .setUsesChronometer(true)
            .setChronometerCountDown(true)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setContentIntent(openAppIntent(ctx))

        if (s.statusMinutes) b.setSmallIcon(minuteIcon(remainMin))
        else b.setSmallIcon(R.drawable.ic_stat_crescent)
        return b.build()
    }

    fun updateOngoing(ctx: Context) {
        val s = Prefs.load(ctx)
        val m = nm(ctx)
        if (!s.ongoing) {
            m.cancel(ONGOING_ID)
            return
        }
        ensureChannels(ctx, s)
        m.notify(ONGOING_ID, buildOngoing(ctx, s))
    }

    fun cancelOngoing(ctx: Context) {
        nm(ctx).cancel(ONGOING_ID)
    }

    fun showPrayerAlert(ctx: Context, s: Settings, idx: Int, test: Boolean = false) {
        ensureChannels(ctx, s)
        val now = System.currentTimeMillis()
        val times = PrayerRepo.times(s, PrayerRepo.today(now))
        val n = NotificationCompat.Builder(ctx, alertChannelId(s))
            .setSmallIcon(R.drawable.ic_stat_crescent)
            .setContentTitle(if (test) "🔔 Test bildirimi" else "${Names.EMOJI[idx]} ${Names.EZAN[idx]}")
            .setContentText(
                if (test) "Ses ve titreşim ayarların böyle çalışacak."
                else "${s.cityName} • ${Fmt.hm(times[idx])}"
            )
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .setContentIntent(openAppIntent(ctx))
            .build()
        nm(ctx).notify(ALERT_BASE + idx, n)
    }

    fun showReminder(ctx: Context, s: Settings, idx: Int) {
        ensureChannels(ctx, s)
        val now = System.currentTimeMillis()
        val times = PrayerRepo.times(s, PrayerRepo.today(now))
        val n = NotificationCompat.Builder(ctx, CH_REMIND)
            .setSmallIcon(R.drawable.ic_stat_crescent)
            .setContentTitle("${Names.DATIVE[idx]} ${s.reminderMin} dk kaldı")
            .setContentText("${Names.SHORT[idx]} ${Fmt.hm(times[idx])} • ${s.cityName}")
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(openAppIntent(ctx))
            .build()
        nm(ctx).notify(REMIND_BASE + idx, n)
    }

    fun showTest(ctx: Context) {
        val s = Prefs.load(ctx)
        showPrayerAlert(ctx, s, 3, true)
    }
}
