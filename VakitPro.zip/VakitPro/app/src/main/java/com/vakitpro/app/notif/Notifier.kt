package com.vakitpro.app.notif

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Typeface
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.SystemClock
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import androidx.core.graphics.drawable.IconCompat
import com.vakitpro.app.MainActivity
import com.vakitpro.app.R
import com.vakitpro.app.data.Fmt
import com.vakitpro.app.data.Names
import com.vakitpro.app.data.PrayerRepo
import com.vakitpro.app.data.Prefs
import com.vakitpro.app.data.Settings
import java.util.Locale

object Notifier {
    const val ONGOING_ID = 4242
    private const val ALERT_BASE = 5000
    private const val REMIND_BASE = 5100

    const val CH_ONGOING = "ongoing_v3"
    private const val CH_ONGOING_OLD = "ongoing_v2"
    const val CH_REMIND = "remind_v1"
    private const val ALERT_PREFIX = "vakit_v"

    fun alertChannelId(s: Settings) = "$ALERT_PREFIX${s.channelVer}"

    private fun nm(ctx: Context): NotificationManager =
        ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    /** Ozel ezan sesi: app/src/main/res/raw/ezan.mp3 eklenirse "Ezan sesi" secenegi calisir. */
    fun ezanRawUri(ctx: Context): Uri? {
        val id = ctx.resources.getIdentifier("ezan", "raw", ctx.packageName)
        return if (id != 0) Uri.parse("android.resource://${ctx.packageName}/$id") else null
    }

    fun soundUri(ctx: Context, s: Settings): Uri? = when (s.soundMode) {
        "alarm" -> RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        "custom" -> if (s.soundUri.isNotBlank()) Uri.parse(s.soundUri)
        else RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        "ezan" -> ezanRawUri(ctx) ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        else -> RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
    }

    fun ensureChannels(ctx: Context, s: Settings) {
        val m = nm(ctx)

        // Normal onem: bildirim "Sessiz" bolumune dusmez, durum cubugunda ikon gorunur. Ses/titresim kapali.
        m.deleteNotificationChannel(CH_ONGOING_OLD)
        val ongoing = NotificationChannel(CH_ONGOING, "Geri sayım (kalıcı)", NotificationManager.IMPORTANCE_DEFAULT)
        ongoing.setSound(null, null)
        ongoing.enableVibration(false)
        ongoing.description = "Sıradaki vakte kalan süreyi bildirim çubuğunda gösterir."
        ongoing.setShowBadge(false)
        ongoing.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        m.createNotificationChannel(ongoing)

        val remind = NotificationChannel(CH_REMIND, "Vakit hatırlatıcı", NotificationManager.IMPORTANCE_DEFAULT)
        remind.description = "Vakitten önce haber verir."
        m.createNotificationChannel(remind)

        val id = alertChannelId(s)
        if (m.getNotificationChannel(id) == null) {
            val usage = if (s.soundMode == "alarm" || s.soundMode == "ezan")
                AudioAttributes.USAGE_ALARM else AudioAttributes.USAGE_NOTIFICATION
            val attrs = AudioAttributes.Builder()
                .setUsage(usage)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            val ch = NotificationChannel(id, "Vakit girdi (ezan)", NotificationManager.IMPORTANCE_HIGH)
            ch.description = "Vakit girdiğinde ses ve titreşimle bildirir."
            ch.setSound(soundUri(ctx, s), attrs)
            ch.enableVibration(s.vibrate)
            if (s.vibrate) ch.vibrationPattern = longArrayOf(0, 400, 200, 400)
            ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            m.createNotificationChannel(ch)
        }
        // eski surum kanallarini temizle
        for (c in m.notificationChannels) {
            if (c.id.startsWith(ALERT_PREFIX) && c.id != id) m.deleteNotificationChannel(c.id)
        }
    }

    private fun openAppIntent(ctx: Context): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        return PendingIntent.getActivity(
            ctx, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    /**
     * Durum cubugu ikonu: kubbeli, iki minareli cami silueti; kalan dakika kubbenin icine oyulur.
     * (Durum cubugu ikonlari tek renk/alfa maskesi olarak cizilir; oyuk sayi bu yuzden gorunur.)
     */
    private fun minuteIcon(min: Int): IconCompat {
        val size = 96
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        fill.color = Color.WHITE
        fill.style = Paint.Style.FILL

        // Ana govde + kubbe
        c.drawRect(16f, 54f, 80f, 92f, fill)
        c.drawCircle(48f, 54f, 32f, fill)
        // Kubbe ucundaki alem (ince cubuk + kucuk hilal topu)
        c.drawRect(46.5f, 6f, 49.5f, 24f, fill)
        c.drawCircle(48f, 9f, 4.5f, fill)
        // Minareler (govde + sivri tepe)
        for (x in floatArrayOf(2f, 84f)) {
            c.drawRect(x + 1f, 38f, x + 9f, 92f, fill)
            val tip = Path()
            tip.moveTo(x, 38f)
            tip.lineTo(x + 5f, 14f)
            tip.lineTo(x + 10f, 38f)
            tip.close()
            c.drawPath(tip, fill)
            c.drawRect(x - 1f, 52f, x + 11f, 56f, fill) // serefe
        }
        // Zemin cizgisi
        c.drawRect(0f, 90f, 96f, 96f, fill)

        // Sayiyi oy (seffaf yap)
        val text = if (min < 100) min.toString()
        else String.format(Locale.US, "%d:%02d", min / 60, min % 60)
        val cut = Paint(Paint.ANTI_ALIAS_FLAG)
        cut.xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        cut.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
        cut.textAlign = Paint.Align.CENTER
        var ts = 46f
        cut.textSize = ts
        while (cut.measureText(text) > 52f && ts > 16f) {
            ts -= 2f
            cut.textSize = ts
        }
        val y = 68f - (cut.descent() + cut.ascent()) / 2f
        c.drawText(text, 48f, y, cut)
        return IconCompat.createWithBitmap(bmp)
    }

    /** Sonraki vakte (ya da test modunda 60 dk'lik sayaca) kalan sure. Ikinci deger: test aktif mi. */
    fun remainInfo(ctx: Context, s: Settings, now: Long): Pair<Long, Boolean> {
        val n = PrayerRepo.next(s, now)
        var remainMs = (n.timeMs - now).coerceAtLeast(0L)
        var testing = false
        if (s.testMinutes) {
            val start = Prefs.getLong(ctx, "test_start", 0L)
            val left = 60 * 60_000L - (now - start)
            if (start > 0L && left > 0L) {
                remainMs = left
                testing = true
            }
        }
        return Pair(remainMs, testing)
    }

    /** Ikonun gostermesi gereken dakika (60 dk ustunde ya da kapaliysa -1 = hilal). */
    fun expectedIconMin(ctx: Context, s: Settings, now: Long): Int {
        val (rem, _) = remainInfo(ctx, s, now)
        val m = (rem / 60_000L).toInt()
        return if (s.statusMinutes && rem in 0..3_600_000L) m else -1
    }

    /** Ikonun degisecegi ana kadar kac ms var (+300 ms pay). */
    fun msToNextIconChange(ctx: Context, s: Settings, now: Long): Long {
        val (rem, _) = remainInfo(ctx, s, now)
        return if (rem > 3_600_000L) minOf(rem - 3_600_000L + 300L, 300_000L)
        else {
            (rem % 60_000L) + 300L
        }
    }

    fun buildOngoing(ctx: Context, s: Settings, now: Long = System.currentTimeMillis()): Notification {
        val n = PrayerRepo.next(s, now)
        val (remainMs, testing) = remainInfo(ctx, s, now)
        val remainMin = (remainMs / 60_000L).toInt()
        val times = PrayerRepo.times(s, PrayerRepo.today(now))

        val nameIds = intArrayOf(R.id.nt_n0, R.id.nt_n1, R.id.nt_n2, R.id.nt_n3, R.id.nt_n4, R.id.nt_n5)
        val timeIds = intArrayOf(R.id.nt_t0, R.id.nt_t1, R.id.nt_t2, R.id.nt_t3, R.id.nt_t4, R.id.nt_t5)
        val orange = Color.parseColor("#FF7043")

        val rv = RemoteViews(ctx.packageName, R.layout.notification_times)
        rv.setTextViewText(
            R.id.nt_title,
            if (testing) "TEST • ${Names.DATIVE[n.index]} kalan süre" else "${Names.DATIVE[n.index]} kalan süre"
        )
        rv.setChronometerCountDown(R.id.nt_chrono, true)
        rv.setChronometer(R.id.nt_chrono, SystemClock.elapsedRealtime() + remainMs, null, true)
        for (i in 0 until 6) {
            rv.setTextViewText(nameIds[i], Names.SHORT[i])
            rv.setTextViewText(timeIds[i], Fmt.hm(times[i]))
            if (i == n.index) {
                rv.setTextColor(nameIds[i], orange)
                rv.setTextColor(timeIds[i], orange)
            }
        }

        val b = NotificationCompat.Builder(ctx, CH_ONGOING)
            .setContentTitle(if (testing) "TEST • ${Names.DATIVE[n.index]} kalan süre" else "${Names.DATIVE[n.index]} kalan süre")
            .setContentText("${Names.SHORT[n.index]} ${Fmt.hm(n.timeMs)} • ${s.cityName}")
            .setWhen(now + remainMs)
            .setShowWhen(true)
            .setUsesChronometer(true)
            .setChronometerCountDown(true)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setSilent(true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setContentIntent(openAppIntent(ctx))

        val live = s.liveUpdate && Build.VERSION.SDK_INT >= 36
        if (live) {
            // Android 16 canli guncelleme: ozel gorunum kullanilamaz. Sayaci sistem (chip) kendisi cizer,
            // uygulama donsa bile durum cubugunda canli akar.
            val sb = StringBuilder()
            for (i in 0 until 6) {
                if (i == 3) sb.append('\n') else if (i > 0) sb.append("   ")
                sb.append(Names.SHORT[i]).append(' ').append(Fmt.hm(times[i]))
            }
            b.setStyle(NotificationCompat.BigTextStyle().bigText(sb.toString()))
            b.setColorized(false)
            val ex = android.os.Bundle()
            ex.putBoolean("android.requestPromotedOngoing", true)
            // Kutuda (chip) gorunecek kisa yazi: 1 saatten azsa "58dk", fazlaysa "4:52"
            val short = if (remainMin in 0..59) "${remainMin}dk"
            else "${remainMin / 60}:${"%02d".format(remainMin % 60)}"
            ex.putString("android.shortCriticalText", short)
            b.addExtras(ex)
        } else {
            b.setStyle(NotificationCompat.DecoratedCustomViewStyle())
            b.setCustomContentView(rv)
            b.setCustomBigContentView(rv)
        }

        // Son 60 dakikaya girince durum cubugunda (saatin yaninda) kalan dakika gorunur
        val showMin = s.statusMinutes && remainMs in 0..3_600_000L
        if (showMin) b.setSmallIcon(minuteIcon(remainMin))
        else b.setSmallIcon(R.drawable.ic_stat_crescent)
        // Tani kaydi: ikonda hangi dakika cizildi, sayac kac dk gosteriyor
        Prefs.putInt(ctx, "diag_icon_min", if (showMin) remainMin else -1)
        Prefs.putLong(ctx, "diag_icon_at", now)
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
        TickLog.add(ctx, "çizildi [${TickLog.source}] ekran=${if (pm.isInteractive) "AÇIK" else "kapalı"} doze=${pm.isDeviceIdleMode} ikon=${if (showMin) remainMin.toString() else "hilal"} sayaç=${remainMs / 60000}:${"%02d".format((remainMs / 1000) % 60)}")
        TickLog.source = "?"
        return b.build()
    }

    fun updateOngoing(ctx: Context) {
        val s = Prefs.load(ctx)
        val m = nm(ctx)
        if (!s.ongoing) {
            m.cancel(ONGOING_ID)
            return
        }
        ensureChannels(ctx, s)
        m.notify(ONGOING_ID, buildOngoing(ctx, s))
    }

    fun cancelOngoing(ctx: Context) {
        nm(ctx).cancel(ONGOING_ID)
    }

    fun showPrayerAlert(ctx: Context, s: Settings, idx: Int, test: Boolean = false) {
        ensureChannels(ctx, s)
        val now = System.currentTimeMillis()
        val times = PrayerRepo.times(s, PrayerRepo.today(now))
        val n = NotificationCompat.Builder(ctx, alertChannelId(s))
            .setSmallIcon(R.drawable.ic_stat_crescent)
            .setContentTitle(if (test) "🔔 Test bildirimi" else "${Names.EMOJI[idx]} ${Names.EZAN[idx]}")
            .setContentText(
                if (test) "Ses ve titreşim ayarların böyle çalışacak."
                else "${s.cityName} • ${Fmt.hm(times[idx])}"
            )
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .setContentIntent(openAppIntent(ctx))
            .build()
        nm(ctx).notify(ALERT_BASE + idx, n)
    }

    fun showReminder(ctx: Context, s: Settings, idx: Int) {
        ensureChannels(ctx, s)
        val now = System.currentTimeMillis()
        val times = PrayerRepo.times(s, PrayerRepo.today(now))
        val n = NotificationCompat.Builder(ctx, CH_REMIND)
            .setSmallIcon(R.drawable.ic_stat_crescent)
            .setContentTitle("${Names.DATIVE[idx]} ${s.remind[idx]} dk kaldı")
            .setContentText("${Names.SHORT[idx]} ${Fmt.hm(times[idx])} • ${s.cityName}")
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(openAppIntent(ctx))
            .build()
        nm(ctx).notify(REMIND_BASE + idx, n)
    }

    fun showTest(ctx: Context) {
        val s = Prefs.load(ctx)
        showPrayerAlert(ctx, s, 3, true)
    }
}
