package com.vakitpro.app.notif

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Typeface
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.SystemClock
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import androidx.core.graphics.drawable.IconCompat
import com.vakitpro.app.MainActivity
import com.vakitpro.app.R
import com.vakitpro.app.data.Fmt
import com.vakitpro.app.data.Hijri
import com.vakitpro.app.data.InspireData
import com.vakitpro.app.data.Names
import com.vakitpro.app.data.PrayerRepo
import com.vakitpro.app.data.Prefs
import com.vakitpro.app.data.Settings
import java.util.Locale

object Notifier {
    const val ONGOING_ID = 4242
    const val ALERT_BASE = 5000
    private const val REMIND_BASE = 5100

    const val CH_ONGOING = "ongoing_v3"
    private const val CH_ONGOING_OLD = "ongoing_v2"
    const val CH_REMIND = "remind_v2"
    private const val CH_REMIND_OLD = "remind_v1"
    private const val ALERT_PREFIX = "vakit_v"
    private const val REMIND_PREFIX = "remind_s_"

    fun remindChannelId(s: Settings) = "$REMIND_PREFIX${s.remindSound}"

    /** Hatirlatma sesi: app/src/main/res/raw altindaki bildirim, bildirim1..7 dosyalari. */
    fun remindSoundUri(ctx: Context, name: String): Uri? {
        val id = ctx.resources.getIdentifier(name, "raw", ctx.packageName)
        return if (id != 0) Uri.parse("android.resource://${ctx.packageName}/$id")
        else RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
    }

    /** Secimde kisa onizleme. */
    fun previewRemindSound(ctx: Context, name: String) {
        val id = ctx.resources.getIdentifier(name, "raw", ctx.packageName)
        if (id == 0) return
        try {
            val mp = android.media.MediaPlayer.create(ctx, id) ?: return
            mp.setOnCompletionListener { it.release() }
            mp.start()
        } catch (_: Exception) {}
    }

    fun alertChannelId(s: Settings) = "$ALERT_PREFIX${s.channelVer}"

    private fun nm(ctx: Context): NotificationManager =
        ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    /** Ozel ezan sesi: app/src/main/res/raw/ezan.mp3 eklenirse "Ezan sesi" secenegi calisir. */
    fun ezanRawUri(ctx: Context): Uri? {
        val id = ctx.resources.getIdentifier("ezan", "raw", ctx.packageName)
        return if (id != 0) Uri.parse("android.resource://${ctx.packageName}/$id") else null
    }

    fun soundUri(ctx: Context, s: Settings): Uri? = when (s.soundMode) {
        "alarm" -> RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        "custom" -> if (s.soundUri.isNotBlank()) Uri.parse(s.soundUri)
        else RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        "ezan" -> ezanRawUri(ctx) ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        else -> RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
    }

    fun ensureChannels(ctx: Context, s: Settings) {
        val m = nm(ctx)

        // Normal onem: bildirim "Sessiz" bolumune dusmez, durum cubugunda ikon gorunur. Ses/titresim kapali.
        m.deleteNotificationChannel(CH_ONGOING_OLD)
        val ongoing = NotificationChannel(CH_ONGOING, "Geri sayım (kalıcı)", NotificationManager.IMPORTANCE_DEFAULT)
        ongoing.setSound(null, null)
        ongoing.enableVibration(false)
        ongoing.description = "Sıradaki vakte kalan süreyi bildirim çubuğunda gösterir."
        ongoing.setShowBadge(false)
        ongoing.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        m.createNotificationChannel(ongoing)

        m.deleteNotificationChannel(CH_REMIND_OLD)
        m.deleteNotificationChannel(CH_REMIND)
        // Kanal sesi sonradan degismez: ses adi kanal kimligine eklenir
        val rid = remindChannelId(s)
        if (m.getNotificationChannel(rid) == null) {
            val remind = NotificationChannel(rid, "Vakit hatırlatıcı", NotificationManager.IMPORTANCE_HIGH)
            remind.description = "Vakitten önce ses ve kısa titreşimle haber verir."
            remind.setSound(
                remindSoundUri(ctx, s.remindSound),
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            remind.enableVibration(true)
            remind.vibrationPattern = longArrayOf(0, 220)
            remind.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            m.createNotificationChannel(remind)
        }
        for (c in m.notificationChannels) {
            if (c.id.startsWith(REMIND_PREFIX) && c.id != rid) m.deleteNotificationChannel(c.id)
        }

        val id = alertChannelId(s)
        if (m.getNotificationChannel(id) == null) {
            val usage = if (s.soundMode == "alarm" || s.soundMode == "ezan")
                AudioAttributes.USAGE_ALARM else AudioAttributes.USAGE_NOTIFICATION
            val attrs = AudioAttributes.Builder()
                .setUsage(usage)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            val ch = NotificationChannel(id, "Vakit girdi (ezan)", NotificationManager.IMPORTANCE_HIGH)
            ch.description = "Vakit girdiğinde ses ve titreşimle bildirir."
            ch.setSound(soundUri(ctx, s), attrs)
            ch.enableVibration(s.vibrate)
            if (s.vibrate) ch.vibrationPattern = longArrayOf(0, 400, 200, 400)
            ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            m.createNotificationChannel(ch)
        }
        // eski surum kanallarini temizle
        for (c in m.notificationChannels) {
            if (c.id.startsWith(ALERT_PREFIX) && c.id != id) m.deleteNotificationChannel(c.id)
        }
    }

    /** Dokununca uygulamada bildirimdeki ayet/hadis/dua hikaye grubunu acar. */
    private fun openStoryIntent(ctx: Context, kind: Int, idx: Int): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("open", "stories$kind")
        }
        return PendingIntent.getActivity(
            ctx, 970 + idx, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun openAppIntent(ctx: Context): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        return PendingIntent.getActivity(
            ctx, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    /**
     * Durum cubugu ikonu: kubbeli, iki minareli cami silueti; kalan dakika kubbenin icine oyulur.
     * (Durum cubugu ikonlari tek renk/alfa maskesi olarak cizilir; oyuk sayi bu yuzden gorunur.)
     */
    private fun minuteIcon(ctx: Context, min: Int): IconCompat {
        return minuteIconDrawn(min)
    }

    private fun minuteIconDrawn(min: Int): IconCompat {
        val size = 96
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        fill.color = Color.WHITE
        fill.style = Paint.Style.FILL

        // Cami: orta govde + kubbe + alem, yanlarda belirgin minareler; sayi govdeye buyuk oyulur
        c.drawRect(8f, 50f, 88f, 96f, fill)
        c.drawCircle(48f, 52f, 30f, fill)
        c.drawRect(46.5f, 6f, 49.5f, 24f, fill)
        c.drawCircle(48f, 8f, 4.5f, fill)
        for (x in floatArrayOf(0f, 85f)) {
            c.drawRect(x + 1f, 34f, x + 10f, 96f, fill)
            val tip = Path()
            tip.moveTo(x - 0.5f, 34f)
            tip.lineTo(x + 5.5f, 4f)
            tip.lineTo(x + 11.5f, 34f)
            tip.close()
            c.drawPath(tip, fill)
            c.drawRect(x - 2f, 46f, x + 13f, 51f, fill) // serefe
        }
        c.drawRect(0f, 92f, 96f, 96f, fill)

        // Sayiyi oy (seffaf yap)
        val text = if (min < 100) String.format(Locale.US, "%02d", min)
        else String.format(Locale.US, "%d:%02d", min / 60, min % 60)
        val cut = Paint(Paint.ANTI_ALIAS_FLAG)
        cut.xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        cut.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
        cut.textAlign = Paint.Align.CENTER
        var ts = 62f
        cut.textSize = ts
        while (cut.measureText(text) > 64f && ts > 16f) {
            ts -= 2f
            cut.textSize = ts
        }
        val y = 72f - (cut.descent() + cut.ascent()) / 2f
        c.drawText(text, 48f, y, cut)
        return IconCompat.createWithBitmap(bmp)
    }

    /** Sonraki vakte (ya da test modunda 60 dk'lik sayaca) kalan sure. Ikinci deger: test aktif mi. */
    fun remainInfo(ctx: Context, s: Settings, now: Long): Pair<Long, Boolean> {
        val n = PrayerRepo.next(s, now)
        var remainMs = (n.timeMs - now).coerceAtLeast(0L)
        var testing = false
        if (s.testMinutes) {
            val start = Prefs.getLong(ctx, "test_start", 0L)
            val left = 60 * 60_000L - (now - start)
            if (start > 0L && left > 0L) {
                remainMs = left
                testing = true
            }
        }
        return Pair(remainMs, testing)
    }

    /** Ikonun gostermesi gereken dakika (60 dk ustunde ya da kapaliysa -1 = hilal). */
    fun expectedIconMin(ctx: Context, s: Settings, now: Long): Int {
        val (rem, _) = remainInfo(ctx, s, now)
        val m = (rem / 60_000L).toInt()
        return if (s.statusMinutes && rem in 0..3_600_000L) m else -1
    }

    /** Ikonun degisecegi ana kadar kac ms var (+300 ms pay). */
    fun msToNextIconChange(ctx: Context, s: Settings, now: Long): Long {
        val (rem, _) = remainInfo(ctx, s, now)
        return if (rem > 3_600_000L) minOf(rem - 3_600_000L + 300L, 300_000L)
        else {
            (rem % 60_000L) + 300L
        }
    }

    fun buildOngoing(ctx: Context, s: Settings, now: Long = System.currentTimeMillis()): Notification {
        val n = PrayerRepo.next(s, now)
        val (remainMs, testing) = remainInfo(ctx, s, now)
        val remainMin = (remainMs / 60_000L).toInt()
        val times = PrayerRepo.times(s, PrayerRepo.today(now))
        val ram = com.vakitpro.app.data.Ramadan.state(s, PrayerRepo.today(now)).active
        fun rl(i: Int) = com.vakitpro.app.data.Ramadan.label(i, ram)
        fun rd(i: Int) = com.vakitpro.app.data.Ramadan.dative(i, ram)

        val nameIds = intArrayOf(R.id.nt_n0, R.id.nt_n1, R.id.nt_n2, R.id.nt_n3, R.id.nt_n4, R.id.nt_n5)
        val timeIds = intArrayOf(R.id.nt_t0, R.id.nt_t1, R.id.nt_t2, R.id.nt_t3, R.id.nt_t4, R.id.nt_t5)

        val rv = RemoteViews(ctx.packageName, R.layout.notification_times)
        rv.setTextViewText(R.id.nt_title, if (testing) "- TEST ${rd(n.index)}" else "- ${rd(n.index)}")
        val todayD = PrayerRepo.today(now)
        val hd = Hijri.of(todayD, s.hijriAdj + (if (now >= times[4]) 1 else 0))
        rv.setTextViewText(R.id.nt_city, s.cityName.replace(" (GPS)", ""))
        rv.setTextViewText(
            R.id.nt_hijri,
            "${hd.year}, ${Hijri.MONTHS[(hd.month - 1).coerceIn(0, 11)]} ${hd.day}"
        )
        rv.setImageViewResource(R.id.nt_icon, R.drawable.ic_ayyildiz_tr)
        rv.setChronometerCountDown(R.id.nt_chrono, true)
        rv.setChronometer(R.id.nt_chrono, SystemClock.elapsedRealtime() + remainMs, null, true)

        // Gorunum ayarlari: arka plan rengi + saydamlik, vurgu ve yazi rengi
        val bgI = NotifTheme.bgIdx(ctx)
        val alphaP = NotifTheme.alphaPct(ctx)
        val kerahat = com.vakitpro.app.data.Kerahat.current(times, now)
        val accent = if (kerahat != null) 0xFFFF7A1A.toInt() else NotifTheme.accent(NotifTheme.accIdx(ctx))
        val txt = NotifTheme.text(bgI, alphaP, NotifTheme.txtIdx(ctx))
        val bg = NotifTheme.bgColor(bgI, alphaP)
        if (Build.VERSION.SDK_INT >= 31) {
            rv.setColorStateList(R.id.nt_root, "setBackgroundTintList", android.content.res.ColorStateList.valueOf(bg))
        } else {
            rv.setInt(R.id.nt_root, "setBackgroundColor", bg)
        }
        if (txt != null) {
            rv.setTextColor(R.id.nt_city, txt)
            rv.setTextColor(R.id.nt_hijri, NotifTheme.withAlpha(txt, 0xB8))
            rv.setTextColor(R.id.nt_title, NotifTheme.withAlpha(txt, 0xB8))
        }
        rv.setTextColor(R.id.nt_chrono, accent)
        if (kerahat != null) rv.setTextColor(R.id.nt_title, accent)
        rv.setInt(R.id.nt_div, "setBackgroundColor", NotifTheme.withAlpha(accent, 0x99))
        val cellIds = intArrayOf(R.id.nt_c0, R.id.nt_c1, R.id.nt_c2, R.id.nt_c3, R.id.nt_c4, R.id.nt_c5)
        // Vurgu: su an icinde bulunulan vakit (imsaktan once yatsi)
        val cur = (0 until 6).lastOrNull { times[it] <= now } ?: 5
        for (i in 0 until 6) {
            rv.setTextViewText(nameIds[i], rl(i))
            rv.setTextViewText(timeIds[i], Fmt.hm(times[i]))
            if (i == cur) {
                rv.setTextColor(nameIds[i], accent)
                rv.setTextColor(timeIds[i], accent)
                val chip = NotifTheme.withAlpha(accent, 0x30)
                if (Build.VERSION.SDK_INT >= 31) {
                    rv.setColorStateList(cellIds[i], "setBackgroundTintList", android.content.res.ColorStateList.valueOf(chip))
                } else {
                    rv.setInt(cellIds[i], "setBackgroundColor", chip)
                }
            } else if (txt != null) {
                rv.setTextColor(nameIds[i], NotifTheme.withAlpha(txt, 0xB8))
                rv.setTextColor(timeIds[i], txt)
            }
        }

        val b = NotificationCompat.Builder(ctx, CH_ONGOING)
            .setContentTitle(if (testing) "TEST • ${rd(n.index)} kalan süre" else "${rd(n.index)} kalan süre")
            .setContentText("${rl(n.index)} ${Fmt.hm(n.timeMs)} • ${s.cityName}")
            .setSubText((if (kerahat != null) "Kerahat • " else "") + "${rl(n.index)}: ${Fmt.hm(n.timeMs)}")
            .setWhen(now + remainMs)
            .setShowWhen(true)
            .setUsesChronometer(true)
            .setChronometerCountDown(true)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setSilent(true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setContentIntent(openAppIntent(ctx))

        val live = s.liveUpdate && Build.VERSION.SDK_INT >= 36
        if (live) {
            // Android 16 canli guncelleme: ozel gorunum kullanilamaz. Sayaci sistem (chip) kendisi cizer,
            // uygulama donsa bile durum cubugunda canli akar.
            val sb = StringBuilder()
            for (i in 0 until 6) {
                if (i == 3) sb.append('\n') else if (i > 0) sb.append("   ")
                sb.append(Names.SHORT[i]).append(' ').append(Fmt.hm(times[i]))
            }
            b.setStyle(NotificationCompat.BigTextStyle().bigText(sb.toString()))
            b.setColorized(false)
            val ex = android.os.Bundle()
            ex.putBoolean("android.requestPromotedOngoing", true)
            // Kutuda (chip) gorunecek kisa yazi: 1 saatten azsa "58dk", fazlaysa "4:52"
            val short = if (remainMin in 0..59) "${remainMin}dk"
            else "${remainMin / 60}:${"%02d".format(remainMin % 60)}"
            ex.putString("android.shortCriticalText", short)
            b.addExtras(ex)
        } else {
            b.setCustomContentView(rv)
            b.setCustomBigContentView(rv)
        }

        // Son 60 dakikaya girince durum cubugunda (saatin yaninda) kalan dakika gorunur
        val showMin = s.statusMinutes && remainMs in 0..3_600_000L
        if (showMin) b.setSmallIcon(minuteIcon(ctx, remainMin))
        else b.setSmallIcon(baseIcon(ctx))
        return b.build()
    }

    /** Ayarlardan secilen bildirim simgesi (60 dk disindaki durumlar ve uyarilar). */
    fun baseIcon(ctx: Context): Int = when (Prefs.getInt(ctx, "nt_icon", 0)) {
        1 -> R.drawable.ic_stat_ayyildiz_img
        2 -> R.drawable.ic_stat_crescent
        3 -> R.drawable.ic_stat_hilal_img
        else -> R.drawable.ic_stat_cami_img
    }

    fun updateOngoing(ctx: Context) {
        val s = Prefs.load(ctx)
        val m = nm(ctx)
        if (!s.ongoing) {
            m.cancel(ONGOING_ID)
            return
        }
        ensureChannels(ctx, s)
        val now = System.currentTimeMillis()
        val (rem, _) = remainInfo(ctx, s, now)
        val iconMin = if (s.statusMinutes && rem in 0..3_600_000L) (rem / 60_000L).toInt() else -1
        DebugLog.add(
            ctx,
            "TANI updateOngoing kalan=${rem / 60_000L}dk ${(rem / 1000L) % 60}sn ikonDakika=$iconMin"
        )
        m.notify(ONGOING_ID, buildOngoing(ctx, s, now))
    }

    fun cancelOngoing(ctx: Context) {
        nm(ctx).cancel(ONGOING_ID)
    }

    fun timeOf(s: Settings, idx: Int, now: Long): Long {
        for ((tm, i) in PrayerRepo.upcoming(s, now - 60_000L, 12)) if (i == idx) return tm
        return now
    }

    private fun bigPicture(bmp: Bitmap, summary: String) =
        NotificationCompat.BigPictureStyle().bigPicture(bmp).bigLargeIcon(null as Bitmap?).setSummaryText(summary)

    /** Pencere (popup) ekranini acar; "diger uygulamalarin ustunde goster" izni varsa dogrudan, yoksa tam ekran bildirimi ile. */
    fun popupIntent(ctx: Context, idx: Int, test: Boolean): PendingIntent {
        val i = Intent(ctx, PrayerPopupActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NO_ANIMATION
            putExtra("idx", idx)
            putExtra("test", test)
        }
        return PendingIntent.getActivity(
            ctx, 900 + idx, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun canOverlay(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 23 || android.provider.Settings.canDrawOverlays(ctx)

    private fun prayedIntent(ctx: Context, bit: Int, yes: Boolean, yesterday: Boolean, nid: Int, test: Boolean = false): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, 1200 + bit * 4 + (if (yes) 1 else 0) + (if (yesterday) 2 else 0) + (if (test) 100 else 0),
            Intent(ctx, PrayedReceiver::class.java)
                .putExtra("bit", bit).putExtra("yes", yes).putExtra("yesterday", yesterday).putExtra("nid", nid).putExtra("test", test),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    fun showPrayerAlert(ctx: Context, s: Settings, idx: Int, test: Boolean = false, collapse: Boolean = false) {
        ensureChannels(ctx, s)
        val now = System.currentTimeMillis()
        val tm = if (test) now else timeOf(s, idx, now)
        val item = InspireData.pick(java.time.LocalDate.now().toEpochDay(), idx)
        val bmp = CardArt.prayerCard(
            idx, Names.SHORT[idx], if (test) "Test bildirimi" else "Vakit girdi", Fmt.hm(tm), s.cityName, ctx = ctx
        )
        val b = NotificationCompat.Builder(ctx, alertChannelId(s))
            .setSmallIcon(baseIcon(ctx))
            .setContentTitle(if (test) "🔔 Test: ${Names.EZAN[idx]}" else "${Names.EMOJI[idx]} ${Names.EZAN[idx]}")
            .setContentText(item.oneLine)
            .setLargeIcon(bmp)
            .setStyle(bigPicture(bmp, item.withSource))
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .setContentIntent(openAppIntent(ctx))
        if (collapse) {
            // Bildirim cubuguna inis: sessiz guncelleme, ust banner acilmaz
            b.setPriority(NotificationCompat.PRIORITY_DEFAULT).setOnlyAlertOnce(true)
        }
        val prev = com.vakitpro.app.data.Kaza.previousOf(idx)
        // Göster: ana ekranda kucuk pencere (Paylas / WhatsApp / Indir) acar
        val previewPi = PendingIntent.getActivity(
            ctx, 1700 + idx,
            Intent(ctx, SharePopupActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
                putExtra("kind", item.kind)
                putExtra("text", item.text)
                putExtra("source", item.source)
                putExtra("nid", ALERT_BASE + idx)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        if (prev >= 0) {
            b.setSubText("${com.vakitpro.app.data.Kaza.NAMES[prev]} namazını kıldın mı?")
            b.addAction(0, "Evet, kıldım", prayedIntent(ctx, prev, true, idx == 0, ALERT_BASE + idx, test))
            b.addAction(0, "Göster", previewPi)
            b.addAction(0, "Hayır (kazaya ekle)", prayedIntent(ctx, prev, false, idx == 0, ALERT_BASE + idx, test))
        } else {
            b.addAction(0, "Göster", previewPi)
        }
        // Tam ekran / arka planli pencere acilmaz; yalnizca ust bant bildirimi gosterilir.
        try {
            val chId = alertChannelId(s)
            val ch = nm(ctx).getNotificationChannel(chId)
            DebugLog.add(
                ctx,
                "BILDIRIM hazir: kanal=$chId onem=${ch?.importance} izin=${androidx.core.app.NotificationManagerCompat.from(ctx).areNotificationsEnabled()} " +
                    "DND=${nm(ctx).currentInterruptionFilter} popup=${s.popup} overlay=${canOverlay(ctx)}" +
                    (if (Build.VERSION.SDK_INT >= 34) " fullScreenIzin=${nm(ctx).canUseFullScreenIntent()}" else "")
            )
        } catch (e: Exception) {
        }
        nm(ctx).notify(ALERT_BASE + idx, b.build())
        DebugLog.add(ctx, "BILDIRIM notify() cagrildi idx=$idx test=$test collapse=$collapse")
        if (!collapse) {
            // 5 sn sonra ust bannerdan cubuga in
            try {
                val pi = PendingIntent.getBroadcast(
                    ctx, 970 + idx,
                    Intent(ctx, AlarmReceiver::class.java).apply {
                        action = "com.vakitpro.app.PEEK"
                        putExtra("kind", KIND_PEEK)
                        putExtra("idx", idx)
                        putExtra("test", test)
                    },
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                ctx.getSystemService(android.app.AlarmManager::class.java)
                    .set(android.app.AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + 5_000L, pi)
            } catch (e: Exception) {
                DebugLog.add(ctx, "PEEK planlanamadi: ${e.javaClass.simpleName}")
            }
        }
    }

    /**
     * Vakitten once hatirlatma: resim + ayet/hadis, ses ve kisa titresim.
     * "Hatirlatmayi ertele" yalnizca bu vakit icin bir kez, 10 dk sonra tekrar hatirlatir.
     * snoozed = true ise bu zaten ertelenmis bir hatirlatmadir: tekrar ertelenmez.
     */
    fun showReminder(
        ctx: Context, s: Settings, idx: Int, test: Boolean = false, prayerAt: Long = -1L, snoozed: Boolean = false
    ) {
        ensureChannels(ctx, s)
        val now = System.currentTimeMillis()
        val tm = if (prayerAt > 0L) prayerAt else timeOf(s, idx, now)
        var mins = Math.ceil((tm - now) / 60000.0).toInt()
        if (test) mins = if (s.remind[idx] > 0) s.remind[idx] else 45
        if (mins <= 0) return
        if (!test && !snoozed) {
            // Ayni vakit icin hatirlatma iki kez gosterilmez
            if (Prefs.getLong(ctx, "rem_shown_$idx", 0L) == tm) return
            Prefs.putLong(ctx, "rem_shown_$idx", tm)
        }
        val shownTime = if (test) now + mins * 60_000L else tm
        val item = InspireData.pick(java.time.LocalDate.now().toEpochDay(), idx + 1)
        val bmp = CardArt.prayerCard(idx, Names.SHORT[idx], "$mins dk kaldı", Fmt.hm(shownTime), s.cityName, ctx = ctx)
        val snooze = PendingIntent.getBroadcast(
            ctx, 950 + idx,
            Intent(ctx, AlarmReceiver::class.java).apply {
                action = "com.vakitpro.app.SNOOZE"
                putExtra("kind", KIND_SNOOZE_SET)
                putExtra("idx", idx)
                putExtra("pt", tm)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val b = NotificationCompat.Builder(ctx, remindChannelId(s))
            .setSmallIcon(baseIcon(ctx))
            .setContentTitle("${if (test) "Test: " else ""}${Names.SHORT[idx]} vaktine $mins dk kaldı.")
            .setContentText(item.oneLine)
            .setLargeIcon(bmp)
            .setStyle(bigPicture(bmp, item.withSource))
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setOnlyAlertOnce(true)
            .setTimeoutAfter(15 * 60_000L)
            .setContentIntent(openStoryIntent(ctx, item.kind, idx))
        if (!snoozed) b.addAction(0, "Hatırlatmayı ertele", snooze)
        val n = b.build()
        nm(ctx).notify(REMIND_BASE + idx, n)
        DebugLog.add(ctx, "HATIRLATMA notify() cagrildi idx=$idx test=$test")
    }

    fun snooze(ctx: Context, idx: Int, minutes: Int = 10, prayerAt: Long = -1L) {
        nm(ctx).cancel(REMIND_BASE + idx)
        val at = System.currentTimeMillis() + minutes * 60_000L
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager
        val pi = PendingIntent.getBroadcast(
            ctx, 960 + idx,
            Intent(ctx, AlarmReceiver::class.java).apply {
                action = "com.vakitpro.app.SNOOZE_FIRE"
                putExtra("kind", KIND_SNOOZE_FIRE)
                putExtra("idx", idx)
                putExtra("pt", prayerAt)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        try {
            if (AlarmScheduler.canExact(ctx)) am.setExactAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP, at, pi)
            else am.setAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP, at, pi)
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    /** Eski erteleme kayitlarini ve bekleyen erteleme alarmlarini temizler (bir kerelik). */
    fun resetSnoozes(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager
        for (i in 0..5) {
            nm(ctx).cancel(REMIND_BASE + i)
            Prefs.putLong(ctx, "rem_shown_$i", 0L)
            val pi = PendingIntent.getBroadcast(
                ctx, 960 + i,
                Intent(ctx, AlarmReceiver::class.java).apply { action = "com.vakitpro.app.SNOOZE_FIRE" },
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
            )
            if (pi != null) {
                am.cancel(pi)
                pi.cancel()
            }
        }
    }

    /** Resimli bildirim kurulamazsa en sade haliyle yine de haber verir. */
    fun showPlain(ctx: Context, s: Settings, idx: Int, prayer: Boolean) {
        ensureChannels(ctx, s)
        val n = NotificationCompat.Builder(ctx, if (prayer) alertChannelId(s) else remindChannelId(s))
            .setSmallIcon(baseIcon(ctx))
            .setContentTitle(if (prayer) "${Names.EMOJI[idx]} ${Names.EZAN[idx]}" else "${Names.SHORT[idx]} vaktine ${s.remind[idx]} dk kaldı.")
            .setContentText(s.cityName)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(openAppIntent(ctx))
            .build()
        nm(ctx).notify((if (prayer) ALERT_BASE else REMIND_BASE) + idx, n)
    }

    fun showTestDelayed(ctx: Context, sec: Int) {
        val app = ctx.applicationContext
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            try {
                showTest(app)
            } catch (e: Exception) {
            }
        }, sec * 1000L)
        android.widget.Toast.makeText(app, "$sec sn sonra gelecek", android.widget.Toast.LENGTH_SHORT).show()
    }

    fun showReminderTest(ctx: Context) {
        val s = Prefs.load(ctx)
        showReminder(ctx, s, 2, true)
    }

    fun showTest(ctx: Context) {
        val s = Prefs.load(ctx)
        showPrayerAlert(ctx, s, 3, true)
    }
}
