package com.vakitpro.app.notif

import android.content.Context
import com.vakitpro.app.data.Prefs

/** Kalici bildirimin gorunum ayarlari (arka plan, saydamlik, vurgu ve yazi rengi). */
object NotifTheme {
    // Arka plan on ayarlari. 0 = sistem (saydam, telefonun kendi bildirim rengi)
    val BG_NAMES = listOf("Sistem", "Gece", "Zümrüt", "Mor", "Bordo", "Altın", "Açık")
    val BG_RGB = intArrayOf(0x000000, 0x111C2B, 0x0D3B35, 0x2A1A47, 0x3E1522, 0x3B2E0F, 0xF2F4F7)

    val ACC_NAMES = listOf("Turuncu", "Altın", "Turkuaz", "Pembe", "Beyaz")
    val ACC_RGB = intArrayOf(0xFF8A50, 0xFFC857, 0x3DDCC4, 0xFF7AA8, 0xFFFFFF)

    val TXT_NAMES = listOf("Otomatik", "Beyaz", "Siyah", "Altın")

    fun bgIdx(ctx: Context) = Prefs.getInt(ctx, "nt_bg", 0).coerceIn(0, BG_NAMES.lastIndex)
    fun alphaPct(ctx: Context) = Prefs.getInt(ctx, "nt_alpha", 92).coerceIn(0, 100)
    fun accIdx(ctx: Context) = Prefs.getInt(ctx, "nt_acc", 1).coerceIn(0, ACC_NAMES.lastIndex)
    fun txtIdx(ctx: Context) = Prefs.getInt(ctx, "nt_txt", 0).coerceIn(0, TXT_NAMES.lastIndex)

    /** Arka plan ARGB (saydamlik dahil). */
    fun bgColor(bg: Int, alphaPct: Int): Int {
        if (bg == 0) return 0
        val a = (alphaPct * 255 / 100) and 0xFF
        return (a shl 24) or BG_RGB[bg]
    }

    fun accent(acc: Int): Int = 0xFF000000.toInt() or ACC_RGB[acc]

    private fun lum(rgb: Int): Double {
        val r = (rgb shr 16) and 0xFF
        val g = (rgb shr 8) and 0xFF
        val b = rgb and 0xFF
        return (0.299 * r + 0.587 * g + 0.114 * b) / 255.0
    }

    /** Ana yazi rengi; null = sistem varsayilani. */
    fun text(bg: Int, alphaPct: Int, txt: Int): Int? = when (txt) {
        1 -> 0xFFFFFFFF.toInt()
        2 -> 0xFF111111.toInt()
        3 -> 0xFFF5C86B.toInt()
        else -> when {
            bg == 0 || alphaPct < 40 -> null
            lum(BG_RGB[bg]) > 0.6 -> 0xFF14181F.toInt()
            else -> 0xFFFFFFFF.toInt()
        }
    }

    fun withAlpha(c: Int, a: Int): Int = (c and 0x00FFFFFF) or ((a and 0xFF) shl 24)
}
