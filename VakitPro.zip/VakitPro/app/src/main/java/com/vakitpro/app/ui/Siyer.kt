package com.vakitpro.app.ui

import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.RadioButton
import androidx.compose.material3.TextButton
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vakitpro.app.data.Prefs
import org.json.JSONArray
import java.util.Locale

private class Doc(val id: String, val cat: String, val title: String, val sub: String, val sum: String, val text: String)

private fun loadDocs(ctx: android.content.Context): List<Doc> = try {
    val txt = ctx.assets.open("siyer.json").bufferedReader().use { it.readText() }
    val arr = JSONArray(txt)
    List(arr.length()) { i ->
        val o = arr.getJSONObject(i)
        Doc(o.getString("id"), o.getString("cat"), o.getString("title"), o.optString("sub"), o.optString("sum"), o.getString("text"))
    }
} catch (e: Exception) {
    emptyList()
}

private fun chunksOf(text: String): List<String> =
    text.split(Regex("(?<=[.!?])\\s+")).map { it.trim() }.filter { it.isNotEmpty() }

private val CATS = listOf("Hz. Muhammed", "Peygamberler", "Bedir", "Muhacir", "Ensar", "Aşere-i Mübeşşere", "Ehl-i Beyt", "Sözler")

@Composable
fun SiyerScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val docs = remember { loadDocs(ctx) }
    var cat by rememberSaveable { mutableStateOf(CATS[0]) }
    var openId by rememberSaveable { mutableStateOf<String?>(null) }
    var tick by remember { mutableIntStateOf(0) }
    val cs = MaterialTheme.colorScheme

    val cur = docs.firstOrNull { it.id == openId }
    if (cur != null) {
        ReaderView(cur, onBack = { openId = null; tick++ })
        return
    }
    val list = docs.filter { it.cat == cat }
    val readCount = list.count { tick >= 0 && Prefs.getInt(ctx, "rd_done_${it.id}", 0) == 1 }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenHeader("Siyer ve Sahabe", "Dinle, kaldığın yerden devam et", onBack)
        androidx.compose.foundation.lazy.LazyRow(
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(CATS) { c ->
                FilterChip(selected = cat == c, onClick = { cat = c }, label = {
                    if (c == "Hz. Muhammed") {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RoseIcon(20.dp)
                            Spacer(Modifier.size(6.dp))
                            Text("Hz. Muhammed (ﷺ)")
                        }
                    } else Text(if (c == "Aşere-i Mübeşşere") "Aşere" else c)
                })
            }
        }
        Spacer(Modifier.size(8.dp))
        Text(
            "$readCount / ${list.size} okundu",
            Modifier.padding(horizontal = 20.dp), color = cs.onSurfaceVariant, style = MaterialTheme.typography.labelLarge
        )
        Spacer(Modifier.size(6.dp))
        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            list.forEach { d ->
                val done = tick >= 0 && Prefs.getInt(ctx, "rd_done_${d.id}", 0) == 1
                val pos = if (tick >= 0) Prefs.getInt(ctx, "rd_pos_${d.id}", 0) else 0
                ProCard(onClick = { openId = d.id }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(d.title, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleSmall)
                            Text(d.sub, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                            if (d.sum.isNotEmpty()) {
                                Text(d.sum, style = MaterialTheme.typography.bodySmall, maxLines = 2)
                            }
                        }
                        Spacer(Modifier.width(8.dp))
                        when {
                            done -> Text("Okundu", color = cs.primary, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                            pos > 0 -> Text("Devam et", color = cs.tertiary, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                            else -> Text("›", fontSize = 22.sp, color = cs.onSurfaceVariant)
                        }
                    }
                }
            }
        }
        Spacer(Modifier.size(24.dp))
    }
}

private fun voiceLabel(v: Voice): String {
    val kalite = when {
        v.quality >= Voice.QUALITY_VERY_HIGH -> "çok yüksek kalite"
        v.quality >= Voice.QUALITY_HIGH -> "yüksek kalite"
        else -> "standart"
    }
    val net = if (v.isNetworkConnectionRequired) ", internet gerekir" else ""
    return "${v.name} ($kalite$net)"
}

@Composable
private fun ReaderView(doc: Doc, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val chunks = remember(doc.id) { chunksOf(doc.text) }
    var pos by remember(doc.id) {
        mutableIntStateOf(Prefs.getInt(ctx, "rd_pos_${doc.id}", 0).coerceIn(0, (chunks.size - 1).coerceAtLeast(0)))
    }
    var playing by remember(doc.id) { mutableStateOf(false) }
    var done by remember(doc.id) { mutableStateOf(Prefs.getInt(ctx, "rd_done_${doc.id}", 0) == 1) }
    var rate by remember { mutableStateOf(1f) }
    var ttsOk by remember { mutableStateOf(true) }
    var voices by remember { mutableStateOf<List<Voice>>(emptyList()) }
    var voiceName by remember { mutableStateOf(Prefs.getStr(ctx, "tts_voice", "")) }
    var showVoice by remember { mutableStateOf(false) }
    val holder = remember { arrayOfNulls<TextToSpeech>(1) }
    val handler = remember { Handler(Looper.getMainLooper()) }
    val listState = rememberLazyListState()

    DisposableEffect(doc.id) {
        holder[0] = TextToSpeech(ctx) { st ->
            val t = holder[0]
            if (st == TextToSpeech.SUCCESS && t != null) {
                val r = t.setLanguage(Locale("tr", "TR"))
                ttsOk = r >= 0
                val list = try {
                    t.voices?.filter { it.locale.language == "tr" }
                        ?.sortedWith(compareByDescending<Voice> { it.quality }.thenBy { it.name })
                        ?: emptyList()
                } catch (e: Exception) { emptyList() }
                voices = list
                if (voiceName.isEmpty() || list.none { it.name == voiceName }) {
                    voiceName = list.firstOrNull()?.name ?: ""
                }
                t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        val k = utteranceId?.removePrefix("c")?.toIntOrNull() ?: return
                        handler.post {
                            pos = k
                            Prefs.putInt(ctx, "rd_pos_${doc.id}", k)
                        }
                    }

                    override fun onDone(utteranceId: String?) {
                        val k = utteranceId?.removePrefix("c")?.toIntOrNull() ?: return
                        if (k >= chunks.size - 1) {
                            handler.post {
                                playing = false
                                done = true
                                pos = 0
                                Prefs.putInt(ctx, "rd_done_${doc.id}", 1)
                                Prefs.putInt(ctx, "rd_pos_${doc.id}", 0)
                            }
                        }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        handler.post { playing = false }
                    }
                })
            } else ttsOk = false
        }
        onDispose {
            holder[0]?.stop()
            holder[0]?.shutdown()
            holder[0] = null
        }
    }

    fun play(from: Int) {
        val t = holder[0] ?: return
        t.stop()
        voices.firstOrNull { it.name == voiceName }?.let { t.voice = it }
        t.setPitch(1.0f)
        t.setSpeechRate(rate)
        playing = true
        for (k in from until chunks.size) {
            // Cumleler arasina kisa dogal bir duraklama
            if (k > from) t.playSilentUtterance(180L, TextToSpeech.QUEUE_ADD, "s$k")
            t.speak(chunks[k], if (k == from) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, "c$k")
        }
    }

    fun pause() {
        holder[0]?.stop()
        playing = false
    }

    LaunchedEffect(pos) {
        if (chunks.isNotEmpty()) listState.animateScrollToItem(pos.coerceIn(0, chunks.size - 1))
    }

    if (showVoice) {
        AlertDialog(
            onDismissRequest = { showVoice = false },
            title = { Text("Okuma sesi") },
            text = {
                Column {
                    if (voices.isEmpty()) {
                        Text("Bu cihazda Türkçe ses bulunamadı. Ayarlar > Erişilebilirlik > Metinden konuşmaya bölümünden ses yükleyebilirsin.")
                    }
                    voices.forEach { v ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable {
                                    voiceName = v.name
                                    Prefs.putStr(ctx, "tts_voice", v.name)
                                    showVoice = false
                                    if (playing) play(pos)
                                }
                                .padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = v.name == voiceName, onClick = null)
                            Spacer(Modifier.size(8.dp))
                            Text(voiceLabel(v))
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showVoice = false }) { Text("Kapat") } }
        )
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(doc.title, doc.sub, onBack = { pause(); onBack() })
        ProCard(Modifier.padding(horizontal = 16.dp).fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (playing) {
                    Button(onClick = { pause() }) { Text("Duraklat") }
                } else {
                    Button(onClick = { play(if (done && pos == 0) 0 else pos) }) {
                        Text(if (pos > 0) "Devam et" else "Dinle")
                    }
                }
                OutlinedButton(onClick = { pos = 0; Prefs.putInt(ctx, "rd_pos_${doc.id}", 0); if (playing) play(0) }) { Text("Başa al") }
            }
            Spacer(Modifier.size(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Hız", color = cs.onSurfaceVariant)
                listOf(0.8f, 1f, 1.25f).forEach { r ->
                    FilterChip(selected = rate == r, onClick = { rate = r; if (playing) play(pos) }, label = { Text("${r}x") })
                }
            }
            Spacer(Modifier.size(4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Ses", color = cs.onSurfaceVariant)
                OutlinedButton(onClick = { showVoice = true }, enabled = voices.isNotEmpty()) {
                    Text(voices.firstOrNull { it.name == voiceName }?.let { voiceLabel(it) } ?: "Türkçe ses yok")
                }
            }
            Spacer(Modifier.size(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = {
                    done = !done
                    Prefs.putInt(ctx, "rd_done_${doc.id}", if (done) 1 else 0)
                }) { Text(if (done) "Okundu işaretini kaldır" else "Okundu olarak işaretle") }
            }
            if (!ttsOk) {
                Text(
                    "Cihazında Türkçe ses motoru bulunamadı. Ayarlar > Erişilebilirlik > Metinden konuşmaya bölümünden Türkçe ses verisini yükleyebilirsin.",
                    style = MaterialTheme.typography.bodySmall, color = cs.error
                )
            }
        }
        Spacer(Modifier.size(8.dp))
        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            itemsIndexed(chunks) { k, c ->
                val on = k == pos
                Text(
                    c,
                    Modifier
                        .fillMaxWidth()
                        .background(if (on) cs.primaryContainer else androidx.compose.ui.graphics.Color.Transparent, RoundedCornerShape(12.dp))
                        .clickable { play(k) }
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    style = MaterialTheme.typography.bodyLarge,
                    lineHeight = 26.sp
                )
            }
        }
    }
}
