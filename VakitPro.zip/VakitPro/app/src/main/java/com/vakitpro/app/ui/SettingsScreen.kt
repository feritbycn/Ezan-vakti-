@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.vakitpro.app.ui

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.Settings as AndroidSettings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import com.vakitpro.app.LocalHolder
import com.vakitpro.app.data.CalcMethod
import com.vakitpro.app.data.Places
import com.vakitpro.app.data.Names
import com.vakitpro.app.notif.AlarmScheduler
import com.vakitpro.app.notif.Notifier
import com.vakitpro.app.notif.Refresher
import com.vakitpro.app.notif.Silencer
import com.vakitpro.app.data.Prefs

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    val holder = LocalHolder.current
    val s = holder.s
    val cs = MaterialTheme.colorScheme

    var dialog by remember { mutableStateOf<String?>(null) }
    var gpsBusy by remember { mutableStateOf(false) }
    var gpsMsg by remember { mutableStateOf<String?>(null) }
    var tick by remember { mutableStateOf(0) } // izin durumunu yeniden okumak icin
    var silenceMsg by remember { mutableStateOf<String?>(null) }
    val lifecycleOwner = androidx.compose.ui.platform.LocalLifecycleOwner.current
    androidx.compose.runtime.DisposableEffect(lifecycleOwner) {
        val obs = androidx.lifecycle.LifecycleEventObserver { _, e ->
            if (e == androidx.lifecycle.Lifecycle.Event.ON_RESUME) tick++
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    fun fetchLocation() {
        gpsBusy = true
        gpsMsg = null
        LocationHelper.request(ctx) { loc ->
            gpsBusy = false
            if (loc == null) {
                gpsMsg = "Konum alınamadı. Konum servisinin açık olduğundan emin ol."
            } else {
                val r = Places.resolve(Places.load(ctx), loc.latitude, loc.longitude)
                holder.update {
                    it.copy(cityName = r.label, countryName = r.country, lat = loc.latitude, lng = loc.longitude)
                }
                gpsMsg = "Konum güncellendi: ${r.country} • ${r.label}"
            }
        }
    }

    val locPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res.values.any { it }) fetchLocation() else gpsMsg = "Konum izni verilmedi."
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == Activity.RESULT_OK && data != null) {
            val uri = IntentCompat.getParcelableExtra(
                data, RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java
            )
            holder.update {
                it.copy(soundMode = "custom", soundUri = uri?.toString() ?: "", channelVer = it.channelVer + 1)
            }
        }
    }

    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }

    val hasNotifPerm = remember(tick) {
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
    }
    val exactOk = remember(tick) { AlarmScheduler.canExact(ctx) }
    val silenceOk = remember(tick) { Silencer.hasPolicyAccess(ctx) }
    val ezanAvail = remember { Notifier.ezanRawUri(ctx) != null }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        ScreenHeader("Ayarlar", "Vakit Pro")
        Column(
            Modifier.padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // ------------------------------------------------ Konum
            SectionTitle("Konum")
            ProCard {
                ValueRow("Ülke", s.countryName) { dialog = "city" }
                HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                ValueRow("Şehir / il", s.cityName) { dialog = "city" }
                HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                ValueRow("İkinci şehir", if (s.city2Name.isEmpty()) "Seçilmedi" else s.city2Name) { dialog = "city2" }
                if (s.city2Name.isNotEmpty()) {
                    HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                    Row(Modifier.fillMaxWidth()) {
                        TextButton(onClick = {
                            holder.update {
                                it.copy(
                                    cityName = it.city2Name, lat = it.lat2, lng = it.lng2,
                                    city2Name = it.cityName, lat2 = it.lat, lng2 = it.lng
                                )
                            }
                        }) { Text("⇄ Ana şehir ile değiştir") }
                        TextButton(onClick = {
                            holder.update { it.copy(city2Name = "", lat2 = 0.0, lng2 = 0.0) }
                        }) { Text("✕ Kaldır") }
                    }
                }
                HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                Spacer(Modifier.size(10.dp))
                Button(
                    onClick = {
                        val fine = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION)
                        val coarse = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION)
                        if (fine == PackageManager.PERMISSION_GRANTED || coarse == PackageManager.PERMISSION_GRANTED) {
                            fetchLocation()
                        } else {
                            locPerm.launch(
                                arrayOf(
                                    Manifest.permission.ACCESS_FINE_LOCATION,
                                    Manifest.permission.ACCESS_COARSE_LOCATION
                                )
                            )
                        }
                    },
                    enabled = !gpsBusy,
                    modifier = Modifier.fillMaxWidth()
                ) { Text(if (gpsBusy) "Konum aranıyor…" else "📡  GPS ile konumumu bul") }
                if (gpsMsg != null) {
                    Text(
                        gpsMsg ?: "",
                        Modifier.padding(top = 8.dp),
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant
                    )
                }
            }

            // ------------------------------------------------ Hesaplama
            SectionTitle("Vakit hesaplama")
            ProCard {
                ValueRow("Yöntem", CalcMethod.of(s.method).label) { dialog = "method" }
                HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                SwitchRow("Hanefî ikindi", "Gölge iki katı olunca (daha geç ikindi)", s.hanafi) { v ->
                    holder.update { it.copy(hanafi = v) }
                }
                HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                ValueRow("Dakika ayarları", "Her vakte ± dakika") { dialog = "adj" }
                HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                ValueRow(
                    "Hicrî tarih düzeltmesi",
                    if (s.hijriAdj == 0) "Yok" else (if (s.hijriAdj > 0) "+${s.hijriAdj} gün" else "${s.hijriAdj} gün")
                ) { dialog = "hijri" }
            }

            // ------------------------------------------------ Bildirimler
            SectionTitle("Bildirim ve widget")
            ProCard {
                SwitchRow(
                    "Kalıcı geri sayım bildirimi",
                    "Bildirim panelinde sıradaki vakte kalan süre canlı görünür",
                    s.ongoing
                ) { v -> holder.update { it.copy(ongoing = v) } }
                HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                SwitchRow(
                    "Durum çubuğunda kalan dakika",
                    "Vakte 60 dakikadan az kalınca saatin yanında kalan dakika görünür",
                    s.statusMinutes,
                    enabled = s.ongoing
                ) { v -> holder.update { it.copy(statusMinutes = v) } }
                HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                SwitchRow(
                    "Test: 60 dk kalmış gibi göster",
                    "Durum çubuğundaki dakika ikonunu hemen görmek için. 60 dk geriye sayar, sonra kendiliğinden biter.",
                    s.testMinutes,
                    enabled = s.ongoing
                ) { v ->
                    if (v) Prefs.putLong(ctx, "test_start", System.currentTimeMillis())
                    holder.update { it.copy(testMinutes = v) }
                }
            }

            SectionTitle("Vakit girince haber ver")
            ProCard {
                for (i in 0 until 6) {
                    SwitchRow(
                        "${Names.EMOJI[i]}  ${Names.SHORT[i]}",
                        null,
                        ((s.alertMask shr i) and 1) == 1
                    ) { v ->
                        holder.update {
                            it.copy(alertMask = if (v) it.alertMask or (1 shl i) else it.alertMask and (1 shl i).inv())
                        }
                    }
                    if (i < 5) HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                }
            }
            ProCard {
                ValueRow(
                    "Bildirim sesi",
                    when (s.soundMode) {
                        "alarm" -> "Alarm sesi"
                        "custom" -> "Özel ses"
                        "ezan" -> "Ezan sesi"
                        else -> "Varsayılan"
                    }
                ) { dialog = "sound" }
                HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                SwitchRow("Titreşim", null, s.vibrate) { v ->
                    holder.update { it.copy(vibrate = v, channelVer = it.channelVer + 1) }
                }
                Spacer(Modifier.size(8.dp))
                OutlinedButton(
                    onClick = { Notifier.showTest(ctx) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("🔔  Bildirimi dene") }
                Spacer(Modifier.size(6.dp))
                OutlinedButton(
                    onClick = { dialog = "diag" },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("🩺  Dakika ikonu tanı testi") }
            }

            SectionTitle("Vakitten önce hatırlat")
            ProCard {
                Text(
                    "Her vakit için ayrı süre seç. “Kapalı” olan vakit için hatırlatma gelmez.",
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant
                )
                for (i in 0 until 6) {
                    ValueRow(
                        "${Names.EMOJI[i]}  ${Names.SHORT[i]}",
                        if (s.remind[i] == 0) "Kapalı" else "${s.remind[i]} dk önce"
                    ) { dialog = "rem$i" }
                    if (i < 5) HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                }
            }

            SectionTitle("Vakit girince telefonu sessize al")
            ProCard {
                SwitchRow(
                    "Otomatik sessize alma",
                    "Seçtiğin vakit girince telefon sessize geçer, süre dolunca eski haline döner",
                    s.silenceOn
                ) { v -> holder.update { it.copy(silenceOn = v) } }
                HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                SwitchRow(
                    "Sessiz yerine titreşim",
                    "Kapalıysa tamamen sessize alır (Rahatsız Etme erişimi gerekir)",
                    s.silenceVibrate,
                    enabled = s.silenceOn
                ) { v -> holder.update { it.copy(silenceVibrate = v) } }
                HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                PermRow(
                    "Rahatsız Etme erişimi",
                    silenceOk,
                    "Tam sessiz mod için gerekli. Verilmezse titreşim moduna alınır."
                ) {
                    openIntent(ctx, Intent(AndroidSettings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                }
                HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                for (i in 0 until 6) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(
                            Modifier
                                .weight(1f)
                                .clickable(enabled = s.silenceOn) { dialog = "sil$i" }
                                .padding(vertical = 8.dp)
                        ) {
                            Text("${Names.EMOJI[i]}  ${Names.SHORT[i]}", fontWeight = FontWeight.Medium)
                            Text(
                                "${s.silenceMins[i]} dk sessiz kalır",
                                style = MaterialTheme.typography.bodySmall,
                                color = cs.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = ((s.silenceMask shr i) and 1) == 1,
                            enabled = s.silenceOn,
                            onCheckedChange = { v ->
                                holder.update {
                                    it.copy(
                                        silenceMask = if (v) it.silenceMask or (1 shl i)
                                        else it.silenceMask and (1 shl i).inv()
                                    )
                                }
                            }
                        )
                    }
                    if (i < 5) HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                }
                Spacer(Modifier.size(8.dp))
                OutlinedButton(
                    onClick = {
                        val ok = Silencer.start(ctx, 1, s.silenceVibrate)
                        Refresher.refreshAll(ctx, false)
                        silenceMsg = if (ok) "Telefon 1 dakika sessize alındı, sonra eski haline döner." else "Sessize alınamadı."
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("🔕  Şimdi dene (1 dk sessize al)") }
                if (silenceMsg != null) {
                    Text(
                        silenceMsg!!,
                        Modifier.padding(top = 6.dp),
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.primary
                    )
                }
            }

            // ------------------------------------------------ Izinler
            SectionTitle("İzinler ve güvenilirlik")
            ProCard {
                PermRow("Bildirim izni", hasNotifPerm, "Vakit bildirimleri için gerekli") {
                    if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
                    else openIntent(ctx, Intent(AndroidSettings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(AndroidSettings.EXTRA_APP_PACKAGE, ctx.packageName))
                }
                HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                PermRow("Tam zamanlı alarm", exactOk, "Ezanın tam dakikasında bildirim için") {
                    if (Build.VERSION.SDK_INT >= 31) {
                        openIntent(
                            ctx,
                            Intent(
                                AndroidSettings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                                Uri.parse("package:${ctx.packageName}")
                            )
                        )
                    }
                }
                HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                Spacer(Modifier.size(8.dp))
                OutlinedButton(
                    onClick = {
                        openIntent(
                            ctx,
                            Intent(
                                AndroidSettings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                                Uri.parse("package:${ctx.packageName}")
                            )
                        )
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("🔋  Pil optimizasyonunu kapat (önerilir)") }
                Text(
                    "Xiaomi, Huawei, Samsung gibi cihazlarda uygulamayı “otomatik başlat / arka planda çalışsın” listesine eklemen bildirimlerin kesintisiz gelmesini sağlar.",
                    Modifier.padding(top = 8.dp),
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant
                )
            }

            // ------------------------------------------------ Gorunum
            SectionTitle("Görünüm")
            ProCard {
                Text("Tema", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
                Spacer(Modifier.size(6.dp))
                Row(
                    Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("system" to "Sistem", "light" to "Açık", "dark" to "Koyu", "amoled" to "AMOLED").forEach { (k, label) ->
                        FilterChip(
                            selected = s.theme == k,
                            onClick = { holder.update { it.copy(theme = k) } },
                            label = { Text(label) }
                        )
                    }
                }
                Spacer(Modifier.size(14.dp))
                Text("Vurgu rengi", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
                Spacer(Modifier.size(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    ACCENTS.forEachIndexed { i, c ->
                        Box(
                            Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(c)
                                .then(
                                    if (s.accent == i && !s.dynamicColor)
                                        Modifier.border(3.dp, cs.onSurface, CircleShape)
                                    else Modifier
                                )
                                .clickable { holder.update { it.copy(accent = i, dynamicColor = false) } }
                        )
                    }
                }
                if (Build.VERSION.SDK_INT >= 31) {
                    Spacer(Modifier.size(6.dp))
                    SwitchRow("Dinamik renk", "Duvar kağıdına göre (Android 12+)", s.dynamicColor) { v ->
                        holder.update { it.copy(dynamicColor = v) }
                    }
                }
            }

            SectionTitle("Hakkında")
            ProCard {
                Text("Vakit Pro 1.0", fontWeight = FontWeight.Bold)
                Text(
                    "Namaz vakitleri internet gerektirmeden, seçtiğin yöntemle cihazında hesaplanır. " +
                        "Varsayılan yöntem Diyanet (İmsak 18°, Yatsı 17°, ihtiyat dakikalarıyla). " +
                        "Hesaplanan vakitler resmî takvimlerden 1-2 dakika sapabilir; gerekirse dakika ayarını kullan.",
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant
                )
            }
            Spacer(Modifier.size(32.dp))
        }
    }

    // ================================================== Diyaloglar
    when (dialog) {
        "city" -> PlacePickerDialog(
            title = "Ana şehir",
            onPick = { country, name, la, lo ->
                holder.update { it.copy(countryName = country, cityName = name, lat = la, lng = lo) }
                dialog = null
            },
            onDismiss = { dialog = null }
        )
        "diag" -> DiagDialog(onDismiss = { dialog = null })
        "city2" -> PlacePickerDialog(
            title = "İkinci şehir",
            onPick = { _, name, la, lo ->
                holder.update { it.copy(city2Name = name, lat2 = la, lng2 = lo) }
                dialog = null
            },
            onDismiss = { dialog = null }
        )
        "method" -> {
            val all = CalcMethod.values()
            ChoiceDialog(
                "Hesaplama yöntemi",
                all.map { it.label },
                all.indexOfFirst { it.name == s.method }.coerceAtLeast(0),
                onSelect = { i ->
                    holder.update { it.copy(method = all[i].name) }
                    dialog = null
                },
                onDismiss = { dialog = null }
            )
        }
        "hijri" -> {
            val opts = listOf(-2, -1, 0, 1, 2)
            ChoiceDialog(
                "Hicrî tarih düzeltmesi",
                opts.map { if (it == 0) "Yok" else if (it > 0) "+$it gün" else "$it gün" },
                opts.indexOf(s.hijriAdj).coerceAtLeast(0),
                onSelect = { i ->
                    holder.update { it.copy(hijriAdj = opts[i]) }
                    dialog = null
                },
                onDismiss = { dialog = null }
            )
        }
        "sound" -> {
            val labels = ArrayList<String>()
            labels.add("Varsayılan bildirim sesi")
            labels.add("Alarm sesi")
            labels.add("Özel ses seç…")
            if (ezanAvail) labels.add("Ezan sesi (res/raw/ezan)")
            val sel = when (s.soundMode) {
                "alarm" -> 1
                "custom" -> 2
                "ezan" -> if (ezanAvail) 3 else 0
                else -> 0
            }
            ChoiceDialog(
                "Bildirim sesi",
                labels,
                sel,
                onSelect = { i ->
                    dialog = null
                    when (i) {
                        0 -> holder.update { it.copy(soundMode = "default", channelVer = it.channelVer + 1) }
                        1 -> holder.update { it.copy(soundMode = "alarm", channelVer = it.channelVer + 1) }
                        2 -> {
                            val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                                putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALL)
                                putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
                                putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Ezan / bildirim sesi seç")
                            }
                            picker.launch(intent)
                        }
                        else -> holder.update { it.copy(soundMode = "ezan", channelVer = it.channelVer + 1) }
                    }
                },
                onDismiss = { dialog = null }
            )
        }
        "adj" -> AlertDialog(
            onDismissRequest = { dialog = null },
            confirmButton = { TextButton(onClick = { dialog = null }) { Text("Tamam") } },
            title = { Text("Dakika ayarları") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    for (i in 0 until 6) {
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(Names.SHORT[i], Modifier.weight(1f), fontWeight = FontWeight.Medium)
                            StepBtn("−") {
                                holder.update { st ->
                                    st.copy(adj = st.adj.mapIndexed { j, v -> if (j == i) (v - 1).coerceAtLeast(-30) else v })
                                }
                            }
                            Text(
                                (if (s.adj[i] > 0) "+" else "") + s.adj[i].toString(),
                                Modifier.width(48.dp),
                                textAlign = TextAlign.Center,
                                fontWeight = FontWeight.Bold
                            )
                            StepBtn("+") {
                                holder.update { st ->
                                    st.copy(adj = st.adj.mapIndexed { j, v -> if (j == i) (v + 1).coerceAtMost(30) else v })
                                }
                            }
                        }
                    }
                }
            }
        )
        else -> {
            val d = dialog
            if (d != null && d.startsWith("rem")) {
                val i = d.substring(3).toIntOrNull() ?: 0
                val opts = listOf(0, 5, 10, 15, 20, 30, 45, 60)
                ChoiceDialog(
                    "${Names.SHORT[i]} için vakitten kaç dakika önce?",
                    opts.map { if (it == 0) "Kapalı" else "$it dakika önce" },
                    opts.indexOf(s.remind[i]).coerceAtLeast(0),
                    onSelect = { k ->
                        holder.update { st ->
                            st.copy(remind = st.remind.mapIndexed { j, v -> if (j == i) opts[k] else v })
                        }
                        dialog = null
                    },
                    onDismiss = { dialog = null }
                )
            } else if (d != null && d.startsWith("sil")) {
                val i = d.substring(3).toIntOrNull() ?: 0
                val opts = listOf(5, 10, 15, 20, 30, 40, 45, 60, 90)
                ChoiceDialog(
                    "${Names.SHORT[i]} girince kaç dakika sessiz kalsın?",
                    opts.map { "$it dakika" },
                    opts.indexOf(s.silenceMins[i]).coerceAtLeast(0),
                    onSelect = { k ->
                        holder.update { st ->
                            st.copy(silenceMins = st.silenceMins.mapIndexed { j, v -> if (j == i) opts[k] else v })
                        }
                        dialog = null
                    },
                    onDismiss = { dialog = null }
                )
            }
        }
    }
}

private fun openIntent(ctx: android.content.Context, intent: Intent) {
    try {
        ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        try {
            ctx.startActivity(
                Intent(AndroidSettings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e2: Exception) {
        }
    }
}

@Composable
private fun StepBtn(label: String, onClick: () -> Unit) {
    Box(
        Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) { Text(label, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
}

@Composable
private fun ValueRow(title: String, value: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
        Text(value, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodyMedium)
        Text("  ›", color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun SwitchRow(
    title: String,
    sub: String?,
    checked: Boolean,
    enabled: Boolean = true,
    onChange: (Boolean) -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                title,
                style = MaterialTheme.typography.titleSmall,
                color = if (enabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline
            )
            if (sub != null) {
                Text(
                    sub,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}

@Composable
private fun PermRow(title: String, ok: Boolean, sub: String, onFix: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (ok) {
            Text("✅ Tamam", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge)
        } else {
            TextButton(onClick = onFix) { Text("İzin ver") }
        }
    }
}

@Composable
private fun ChoiceDialog(
    title: String,
    options: List<String>,
    selected: Int,
    onSelect: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Kapat") } },
        title = { Text(title) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                options.forEachIndexed { i, o ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onSelect(i) }
                            .padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = i == selected, onClick = null)
                        Spacer(Modifier.width(12.dp))
                        Text(o)
                    }
                }
            }
        }
    )
}
