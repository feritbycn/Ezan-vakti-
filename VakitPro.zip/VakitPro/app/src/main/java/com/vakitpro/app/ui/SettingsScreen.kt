@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.vakitpro.app.ui

import android.widget.Toast
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.ui.text.font.FontFamily
import com.vakitpro.app.notif.DebugLog
import androidx.compose.foundation.layout.height
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.Image
import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.Settings as AndroidSettings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import com.vakitpro.app.LocalHolder
import com.vakitpro.app.data.CalcMethod
import com.vakitpro.app.data.Places
import com.vakitpro.app.data.Names
import com.vakitpro.app.notif.AlarmScheduler
import com.vakitpro.app.notif.Notifier
import com.vakitpro.app.notif.Refresher
import com.vakitpro.app.notif.Silencer
import com.vakitpro.app.data.Prefs

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    val holder = LocalHolder.current
    val s = holder.s
    val cs = MaterialTheme.colorScheme

    var dialog by remember { mutableStateOf<String?>(null) }
    var langDlg by remember { mutableStateOf(false) }
    if (langDlg) {
        AlertDialog(
            onDismissRequest = { langDlg = false },
            title = { Text(Lang.tr("Dil seçimi")) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    LanguageGrid(Lang.code) { Lang.set(ctx, it) }
                }
            },
            confirmButton = { TextButton(onClick = { langDlg = false }) { Text("OK") } }
        )
    }
    var gpsBusy by remember { mutableStateOf(false) }
    var gpsMsg by remember { mutableStateOf<String?>(null) }
    var tick by remember { mutableStateOf(0) } // izin durumunu yeniden okumak icin
    var silenceMsg by remember { mutableStateOf<String?>(null) }
    val lifecycleOwner = androidx.compose.ui.platform.LocalLifecycleOwner.current
    androidx.compose.runtime.DisposableEffect(lifecycleOwner) {
        val obs = androidx.lifecycle.LifecycleEventObserver { _, e ->
            if (e == androidx.lifecycle.Lifecycle.Event.ON_RESUME) tick++
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    var locDialog by remember { mutableStateOf(false) }
    var locAuto by remember { mutableStateOf(false) }

    fun fetchLocation() {
        if (!LocationHelper.isOn(ctx)) {
            locDialog = true
            return
        }
        gpsBusy = true
        gpsMsg = null
        LocationHelper.request(ctx) { loc ->
            gpsBusy = false
            if (loc == null) {
                gpsMsg = "Konum alınamadı. Konum servisinin açık olduğundan emin ol."
            } else {
                val r = Places.resolve(Places.load(ctx), loc.latitude, loc.longitude)
                LocationHelper.districtLabel(ctx, loc.latitude, loc.longitude, r.label) { name ->
                    holder.update {
                        it.copy(cityName = name, countryName = r.country, lat = loc.latitude, lng = loc.longitude)
                    }
                    gpsMsg = "Konum güncellendi: ${r.country} • $name"
                }
            }
        }
    }

    val locPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res.values.any { it }) fetchLocation() else gpsMsg = "Konum izni verilmedi."
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == Activity.RESULT_OK && data != null) {
            val uri = IntentCompat.getParcelableExtra(
                data, RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java
            )
            holder.update {
                it.copy(soundMode = "custom", soundUri = uri?.toString() ?: "", channelVer = it.channelVer + 1)
            }
        }
    }

    androidx.compose.runtime.LaunchedEffect(tick) {
        if (locAuto && LocationHelper.isOn(ctx)) {
            locAuto = false
            fetchLocation()
        }
    }
    if (locDialog) {
        AlertDialog(
            onDismissRequest = { locDialog = false },
            title = { Text("Konum kapalı") },
            text = { Text("Vakitleri bulunduğun yere göre hesaplayabilmem için konumu açman gerekiyor. Konumu açtığında uygulama konumunu otomatik bulacak.") },
            confirmButton = {
                TextButton(onClick = {
                    locDialog = false
                    locAuto = true
                    LocationHelper.openSettings(ctx)
                }) { Text("Konumu aç") }
            },
            dismissButton = { TextButton(onClick = { locDialog = false }) { Text("Vazgeç") } }
        )
    }

    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }

    val hasNotifPerm = remember(tick) {
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
    }
    val exactOk = remember(tick) { AlarmScheduler.canExact(ctx) }
    val silenceOk = remember(tick) { Silencer.hasPolicyAccess(ctx) }
    val ezanAvail = remember { Notifier.ezanRawUri(ctx) != null }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        ScreenHeader("Ayarlar", "Ezan Vakti Plus")
        Column(
            Modifier.padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // ------------------------------------------------ Konum
            SectionTitle("Konum")
            ProCard {
                ValueRow("Ülke", s.countryName) { dialog = "city" }
                HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                ValueRow("Şehir / il", s.cityName) { dialog = "city" }
                HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                ValueRow("İkinci şehir", if (s.city2Name.isEmpty()) "Seçilmedi" else s.city2Name) { dialog = "city2" }
                if (s.city2Name.isNotEmpty()) {
                    HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                    Row(Modifier.fillMaxWidth()) {
                        TextButton(onClick = {
                            holder.update {
                                it.copy(
                                    cityName = it.city2Name, lat = it.lat2, lng = it.lng2,
                                    city2Name = it.cityName, lat2 = it.lat, lng2 = it.lng
                                )
                            }
                        }) { Text("⇄ Ana şehir ile değiştir") }
                        TextButton(onClick = {
                            holder.update { it.copy(city2Name = "", lat2 = 0.0, lng2 = 0.0) }
                        }) { GlyphLabel(Glyph.CLOSE, "Kaldır") }
                    }
                }
                HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                Spacer(Modifier.size(10.dp))
                Button(
                    onClick = {
                        val fine = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION)
                        val coarse = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION)
                        if (fine == PackageManager.PERMISSION_GRANTED || coarse == PackageManager.PERMISSION_GRANTED) {
                            fetchLocation()
                        } else {
                            locPerm.launch(
                                arrayOf(
                                    Manifest.permission.ACCESS_FINE_LOCATION,
                                    Manifest.permission.ACCESS_COARSE_LOCATION
                                )
                            )
                        }
                    },
                    enabled = !gpsBusy,
                    modifier = Modifier.fillMaxWidth()
                ) { if (gpsBusy) Text("Konum aranıyor…") else GlyphLabel(Glyph.GPS, "GPS ile konumumu bul") }
                if (gpsMsg != null) {
                    Text(
                        gpsMsg ?: "",
                        Modifier.padding(top = 8.dp),
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant
                    )
                }
            }

            // ------------------------------------------------ Hesaplama
            SectionTitle("Vakit hesaplama")
            ProCard {
                ValueRow("Yöntem", CalcMethod.of(s.method).label) { dialog = "method" }
                HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                SwitchRow("Hanefî ikindi", "Gölge iki katı olunca (daha geç ikindi)", s.hanafi) { v ->
                    holder.update { it.copy(hanafi = v) }
                }
                HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                ValueRow("Dakika ayarları", "Her vakte ± dakika") { dialog = "adj" }
                HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                ValueRow(
                    "Hicrî tarih düzeltmesi",
                    if (s.hijriAdj == 0) "Yok" else (if (s.hijriAdj > 0) "+${s.hijriAdj} gün" else "${s.hijriAdj} gün")
                ) { dialog = "hijri" }
            }

            // ------------------------------------------------ Bildirimler
            SectionTitle("Bildirim ve widget")
            ProCard {
                SwitchRow(
                    "Kalıcı geri sayım bildirimi",
                    "Bildirim panelinde sıradaki vakte kalan süre canlı görünür",
                    s.ongoing
                ) { v -> holder.update { it.copy(ongoing = v) } }
                HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                SwitchRow(
                    "Durum çubuğunda kalan dakika",
                    "Vakte 60 dakikadan az kalınca saatin yanında kalan dakika görünür",
                    s.statusMinutes,
                    enabled = s.ongoing
                ) { v -> holder.update { it.copy(statusMinutes = v) } }
                HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                if (Build.VERSION.SDK_INT >= 36) {
                    SwitchRow(
                        "Canlı güncelleme (Android 16, deneysel)",
                        "Sayaç durum çubuğunda sistem tarafından canlı gösterilir; uygulama uyusa bile durmaz. Bildirimin özel görünümü sadeleşir.",
                        s.liveUpdate,
                        enabled = s.ongoing
                    ) { v -> holder.update { it.copy(liveUpdate = v) } }
                    TextButton(onClick = {
                        openIntent(
                            ctx,
                            Intent("android.settings.MANAGE_APP_PROMOTED_NOTIFICATIONS")
                                .putExtra(AndroidSettings.EXTRA_APP_PACKAGE, ctx.packageName)
                        )
                    }) { Text("Canlı güncelleme iznini kontrol et") }
                }
            }

            SectionTitle("Ramazan")
            ProCard {
                SwitchRow("Ramazan modu (otomatik)", "Ramazan ayında iftar sayacı ve özel tema kendiliğinden açılır", s.ramadanAuto) { v ->
                    holder.update { it.copy(ramadanAuto = v) }
                }
                if (com.vakitpro.app.data.DevTools.ENABLED) {
                    SwitchRow("Ramazan testi", "Modu şimdi zorla aç (Ramazan 12. gün gibi). Ana ekranı, temayı ve widget'ı görmek için.", s.ramadanTest) { v ->
                        holder.update { it.copy(ramadanTest = v) }
                    }
                }
            }

            if (com.vakitpro.app.data.DevTools.ENABLED) {
            SectionTitle("Bildirimleri dene")
            ProCard {
                Text(
                    "Aşağıdaki süreli testler gerçek alarmla çalışır: düğmeye bas, ekranı kilitle ve bekle. " +
                        "Bildirim üstten çıkmalı, ekranı açınca resimli pencere görünmeli.",
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant
                )
                Spacer(Modifier.size(10.dp))
                Button(
                    onClick = { Notifier.showTest(ctx) },
                    modifier = Modifier.fillMaxWidth()
                ) { GlyphLabel(Glyph.BELL, "Vakit girdi bildirimi (hemen)") }
                Spacer(Modifier.size(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (sec in listOf(5, 10, 30)) {
                        OutlinedButton(
                            onClick = {
                                AlarmScheduler.scheduleTest(ctx, sec, false)
                                android.widget.Toast.makeText(ctx, "$sec sn sonra gelecek — ekranı kilitleyebilirsin", android.widget.Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.weight(1f)
                        ) { GlyphLabel(Glyph.TIMER, "$sec sn", size = 16.dp) }
                    }
                }
                Spacer(Modifier.size(8.dp))
                OutlinedButton(
                    onClick = {
                        AlarmScheduler.scheduleTest(ctx, 10, true)
                        android.widget.Toast.makeText(ctx, "10 sn sonra hatırlatıcı gelecek", android.widget.Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { GlyphLabel(Glyph.ALARM, "Vakitten önce hatırlatıcı (10 sn sonra)") }
            }
            }

            SectionTitle("Bildirim görünümü")
            NotifLookCard(live = s.liveUpdate && s.ongoing)

            SectionTitle("Vakit girince haber ver")
            ProCard {
                SwitchRow(
                    "Güvenilir alarm modu",
                    "Alarm saati gibi kurulur; telefon uygulamayı uyutsa da vakit kaçmaz. Durum çubuğunda alarm simgesi görünebilir.",
                    s.reliableAlarm
                ) { v -> holder.update { it.copy(reliableAlarm = v) } }
                HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                for (i in 0 until 6) {
                    SwitchRow(
                        Names.SHORT[i],
                        null,
                        ((s.alertMask shr i) and 1) == 1,
                        lead = i
                    ) { v ->
                        holder.update {
                            it.copy(alertMask = if (v) it.alertMask or (1 shl i) else it.alertMask and (1 shl i).inv())
                        }
                    }
                    if (i < 5) HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                }
            }
            ProCard {
                ValueRow(
                    "Bildirim sesi",
                    when (s.soundMode) {
                        "alarm" -> "Alarm sesi"
                        "custom" -> "Özel ses"
                        "ezan" -> "Ezan sesi"
                        else -> "Varsayılan"
                    }
                ) { dialog = "sound" }
                HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                SwitchRow("Titreşim", null, s.vibrate) { v ->
                    holder.update { it.copy(vibrate = v, channelVer = it.channelVer + 1) }
                }
                HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                SwitchRow("Vakit girince pencere aç", "Ana ekranda resimli kart açılır (aşağıdaki izin gerekir)", s.popup) { v ->
                    holder.update { it.copy(popup = v) }
                }
                if (com.vakitpro.app.data.DevTools.ENABLED) {
                    Spacer(Modifier.size(8.dp))
                    OutlinedButton(
                        onClick = { Notifier.showTest(ctx) },
                        modifier = Modifier.fillMaxWidth()
                    ) { GlyphLabel(Glyph.BELL, "Vakit girdi bildirimini dene") }
                }
            }

            SectionTitle("Vakitten önce hatırlat")
            ProCard {
                Text(
                    "Her vakit için ayrı süre seç. “Kapalı” olan vakit için hatırlatma gelmez.",
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant
                )
                for (i in 0 until 6) {
                    ValueRow(
                        Names.SHORT[i],
                        if (s.remind[i] == 0) "Kapalı" else "${s.remind[i]} dk önce",
                        lead = i
                    ) { dialog = "rem$i" }
                    if (i < 5) HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                }
                HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                ValueRow("Hatırlatma sesi", s.remindSound) { dialog = "rsnd" }
                Spacer(Modifier.size(8.dp))
                Text(
                    "Hatırlatma resimli gelir; ayet veya hadis içerir, kısa titreşim yapar ve “Hatırlatmayı ertele” düğmesi vardır. Ertele, yalnızca o vakit için 10 dk sonra bir kez hatırlatır.",
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant
                )
                if (com.vakitpro.app.data.DevTools.ENABLED) {
                    Spacer(Modifier.size(8.dp))
                    OutlinedButton(
                        onClick = { Notifier.showReminderTest(ctx) },
                        modifier = Modifier.fillMaxWidth()
                    ) { GlyphLabel(Glyph.ALARM, "Hatırlatıcıyı dene") }
                }
            }

            SectionTitle("Vakit girince telefonu sessize al")
            ProCard {
                SwitchRow(
                    "Otomatik sessize alma",
                    "Seçtiğin vakit girince telefon sessize geçer, süre dolunca eski haline döner",
                    s.silenceOn
                ) { v -> holder.update { it.copy(silenceOn = v) } }
                HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                SwitchRow(
                    "Sessiz yerine titreşim",
                    "Kapalıysa tamamen sessize alır (Rahatsız Etme erişimi gerekir)",
                    s.silenceVibrate,
                    enabled = s.silenceOn
                ) { v -> holder.update { it.copy(silenceVibrate = v) } }
                HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                PermItem(
                    Glyph.BELL_OFF,
                    "Rahatsız Etme erişimi",
                    "Tam sessiz mod için gerekli. Verilmezse titreşim moduna alınır.",
                    silenceOk
                ) {
                    openIntent(ctx, Intent(AndroidSettings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                }
                HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                for (i in 0 until 6) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        PrayerIcon(i, 34.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(
                            Modifier
                                .weight(1f)
                                .clickable(enabled = s.silenceOn) { dialog = "sil$i" }
                                .padding(vertical = 8.dp)
                        ) {
                            Text(Names.SHORT[i], fontWeight = FontWeight.Medium)
                            Text(
                                "${s.silenceMins[i]} dk sessiz kalır",
                                style = MaterialTheme.typography.bodySmall,
                                color = cs.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = ((s.silenceMask shr i) and 1) == 1,
                            enabled = s.silenceOn,
                            onCheckedChange = { v ->
                                holder.update {
                                    it.copy(
                                        silenceMask = if (v) it.silenceMask or (1 shl i)
                                        else it.silenceMask and (1 shl i).inv()
                                    )
                                }
                            }
                        )
                    }
                    if (i < 5) HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                }
                Spacer(Modifier.size(8.dp))
                OutlinedButton(
                    onClick = {
                        val ok = Silencer.start(ctx, 1, s.silenceVibrate)
                        Refresher.refreshAll(ctx, false)
                        silenceMsg = if (ok) "Telefon 1 dakika sessize alındı, sonra eski haline döner." else "Sessize alınamadı."
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { GlyphLabel(Glyph.BELL_OFF, "Şimdi dene (1 dk sessize al)") }
                if (silenceMsg != null) {
                    Text(
                        silenceMsg!!,
                        Modifier.padding(top = 6.dp),
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.primary
                    )
                }
            }

            // ------------------------------------------------ Izinler
            SectionTitle("İzinler ve güvenilirlik")
            ProCard {
                val pmSvc = ctx.getSystemService(android.content.Context.POWER_SERVICE) as android.os.PowerManager
                val battOk = tick >= 0 && pmSvc.isIgnoringBatteryOptimizations(ctx.packageName)
                PermItem(Glyph.BELL, "Bildirim izni", "Vakit bildirimleri için gerekli", hasNotifPerm) {
                    if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
                    else openIntent(ctx, Intent(AndroidSettings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(AndroidSettings.EXTRA_APP_PACKAGE, ctx.packageName))
                }
                Spacer(Modifier.size(8.dp))
                PermItem(Glyph.ALARM, "Tam zamanlı alarm", "Ezanın tam dakikasında bildirim için", exactOk) {
                    if (Build.VERSION.SDK_INT >= 31) {
                        openIntent(
                            ctx,
                            Intent(
                                AndroidSettings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                                Uri.parse("package:${ctx.packageName}")
                            )
                        )
                    }
                }
                Spacer(Modifier.size(8.dp))
                val overlayOk = tick >= 0 && Notifier.canOverlay(ctx)
                PermItem(Glyph.WINDOW, "Diğer uygulamaların üzerinde göster", "Vakit girince pencerenin doğrudan açılması için", overlayOk) {
                    openIntent(
                        ctx,
                        Intent(AndroidSettings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                    )
                }
                Spacer(Modifier.size(8.dp))
                PermItem(
                    Glyph.BATTERY, "Pil kısıtlaması",
                    "Kapalı olunca bildirimler ve dakika ikonu kesintisiz çalışır. Xiaomi, Huawei, Samsung gibi telefonlarda uygulamayı “otomatik başlat” listesine de ekle.",
                    battOk,
                    okLabel = "Kapalı",
                    fixLabel = "Kapat"
                ) {
                    openIntent(
                        ctx,
                        Intent(
                            AndroidSettings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                            Uri.parse("package:${ctx.packageName}")
                        )
                    )
                }
            }

            // ------------------------------------------------ Acilis videosu
            SectionTitle("Açılış")
            ProCard {
                var iOn by remember { mutableStateOf(Prefs.getInt(ctx, "intro_on", 1) == 1) }
                SwitchRow("Açılış videosu", "Günde bir kez, ilk açılışta oynar", iOn) { v ->
                    iOn = v
                    Prefs.putInt(ctx, "intro_on", if (v) 1 else 0)
                }
            }

            // ------------------------------------------------ Gunluk ayet/hadis/dua
            SectionTitle("Günlük paylaşım")
            ProCard {
                var dOn by remember { mutableStateOf(com.vakitpro.app.notif.DailyAlarm.enabled(ctx)) }
                var dMin by remember { mutableStateOf(com.vakitpro.app.notif.DailyAlarm.minutes(ctx)) }
                SwitchRow("Günün ayeti, hadisi, duası", "Her gün bildirim olarak gelir; görselli paylaşılabilir", dOn) { v ->
                    dOn = v
                    Prefs.putInt(ctx, "daily_on", if (v) 1 else 0)
                    com.vakitpro.app.notif.DailyAlarm.schedule(ctx)
                }
                HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                ValueRow("Bildirim saati", "%02d:%02d".format(dMin / 60, dMin % 60)) {
                    android.app.TimePickerDialog(ctx, { _, h, m ->
                        dMin = h * 60 + m
                        Prefs.putInt(ctx, "daily_min", dMin)
                        com.vakitpro.app.notif.DailyAlarm.schedule(ctx)
                    }, dMin / 60, dMin % 60, true).show()
                }
                if (com.vakitpro.app.data.DevTools.ENABLED) {
                    HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                    ValueRow("Test et", "Bildirimi şimdi gönder") {
                        Thread { try { com.vakitpro.app.notif.DailyAlarm.show(ctx) } catch (e: Exception) { } }.start()
                    }
                }
            }

            // ------------------------------------------------ Gorunum
            SectionTitle("Görünüm")
            ProCard {
                ValueRow("Dil", Lang.info().native) { langDlg = true }
            }
            ProCard {
                Text("Tema", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
                Spacer(Modifier.size(6.dp))
                Row(
                    Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("system" to "Sistem", "light" to "Açık", "dark" to "Koyu", "amoled" to "AMOLED").forEach { (k, label) ->
                        FilterChip(
                            selected = s.theme == k,
                            onClick = { holder.update { it.copy(theme = k) } },
                            label = { Text(label) }
                        )
                    }
                }
                Spacer(Modifier.size(14.dp))
                Text("Vurgu rengi", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
                Spacer(Modifier.size(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    ACCENTS.forEachIndexed { i, c ->
                        Box(
                            Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(c)
                                .then(
                                    if (s.accent == i && !s.dynamicColor)
                                        Modifier.border(3.dp, cs.onSurface, CircleShape)
                                    else Modifier
                                )
                                .clickable { holder.update { it.copy(accent = i, dynamicColor = false, accentPicked = true) } }
                        )
                    }
                }
                if (Build.VERSION.SDK_INT >= 31) {
                    Spacer(Modifier.size(6.dp))
                    SwitchRow("Dinamik renk", "Duvar kağıdına göre (Android 12+)", s.dynamicColor) { v ->
                        holder.update { it.copy(dynamicColor = v) }
                    }
                }
            }

            ProCard {
                Text("Renk teması", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
                Spacer(Modifier.size(8.dp))
                PALETTES.forEach { p ->
                    val selected = s.palette == p.id
                    val locked = isPaletteLocked(p.id)
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .then(if (selected) Modifier.border(2.dp, cs.primary, RoundedCornerShape(14.dp)) else Modifier)
                            .clickable {
                                if (locked) Toast.makeText(ctx, "Bu tema PRO sürümünde açık", Toast.LENGTH_SHORT).show()
                                else holder.update { it.copy(palette = p.id) }
                            }
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(40.dp).clip(CircleShape).background(p.dBg)) {
                            Box(Modifier.align(Alignment.BottomEnd).size(16.dp).clip(CircleShape).background(p.dAcc))
                        }
                        Spacer(Modifier.width(12.dp))
                        Text(p.name, modifier = Modifier.weight(1f), color = cs.onSurface)
                        if (locked) ProBadge()
                        else if (selected) Text("Seçili", color = cs.primary, style = MaterialTheme.typography.labelMedium)
                    }
                }
                Spacer(Modifier.size(14.dp))
                Text("İftar kartı arka planı", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
                Spacer(Modifier.size(8.dp))
                RAM_BG_RES.chunked(3).forEachIndexed { row, chunk ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        chunk.forEachIndexed { col, res ->
                            val n = row * 3 + col + 1
                            val locked = isBgLocked(n)
                            val sel = effectiveRamBg(s) == n
                            Box(
                                Modifier
                                    .weight(1f)
                                    .height(64.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .then(if (sel) Modifier.border(2.dp, cs.primary, RoundedCornerShape(12.dp)) else Modifier)
                                    .clickable {
                                        if (locked) Toast.makeText(ctx, "Bu görsel PRO sürümünde açık", Toast.LENGTH_SHORT).show()
                                        else holder.update { it.copy(ramBg = n) }
                                    }
                            ) {
                                Image(
                                    painter = painterResource(res),
                                    contentDescription = null,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                                if (locked) {
                                    Box(
                                        Modifier.matchParentSize().background(Color(0x80000000)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        ProBadge()
                                    }
                                }
                            }
                        }
                        repeat(3 - chunk.size) { Spacer(Modifier.weight(1f)) }
                    }
                    Spacer(Modifier.size(8.dp))
                }
            }

            if (com.vakitpro.app.data.DevTools.ENABLED) {
            SectionTitle("Tanı (dakika ikonu)")
            ProCard {
                var diag by remember { mutableStateOf(DebugLog.all(ctx)) }
                Text(
                    if (diag.isBlank()) "Kayıt yok" else diag.lines().takeLast(40).joinToString("\n"),
                    style = MaterialTheme.typography.bodySmall,
                    fontFamily = FontFamily.Monospace,
                    color = cs.onSurfaceVariant
                )
                Row {
                    TextButton(onClick = { diag = DebugLog.all(ctx) }) { Text("Yenile") }
                    TextButton(onClick = {
                        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("tanı", DebugLog.all(ctx)))
                        Toast.makeText(ctx, "Kopyalandı", Toast.LENGTH_SHORT).show()
                    }) { Text("Kopyala") }
                    TextButton(onClick = { DebugLog.clear(ctx); diag = "" }) { Text("Temizle") }
                }
            }
            }

            SectionTitle("Hakkında")
            ProCard {
                Text("Ezan Vakti Plus 1.8", fontWeight = FontWeight.Bold)
                Text(
                    "Namaz vakitleri internet gerektirmeden, seçtiğin yöntemle cihazında hesaplanır. " +
                        "Varsayılan yöntem Diyanet (İmsak 18°, Yatsı 17°, ihtiyat dakikalarıyla). " +
                        "Hesaplanan vakitler resmî takvimlerden 1-2 dakika sapabilir; gerekirse dakika ayarını kullan.",
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant
                )
            }
            Spacer(Modifier.size(32.dp))
        }
    }

    // ================================================== Diyaloglar
    when (dialog) {
        "city" -> PlacePickerDialog(
            title = "Ana şehir",
            onPick = { country, name, la, lo ->
                holder.update { it.copy(countryName = country, cityName = name, lat = la, lng = lo) }
                dialog = null
            },
            onDismiss = { dialog = null }
        )
        "city2" -> PlacePickerDialog(
            title = "İkinci şehir",
            onPick = { _, name, la, lo ->
                holder.update { it.copy(city2Name = name, lat2 = la, lng2 = lo) }
                dialog = null
            },
            onDismiss = { dialog = null }
        )
        "method" -> {
            val all = CalcMethod.values()
            ChoiceDialog(
                "Hesaplama yöntemi",
                all.map { it.label },
                all.indexOfFirst { it.name == s.method }.coerceAtLeast(0),
                onSelect = { i ->
                    holder.update { it.copy(method = all[i].name) }
                    dialog = null
                },
                onDismiss = { dialog = null }
            )
        }
        "hijri" -> {
            val opts = listOf(-2, -1, 0, 1, 2)
            ChoiceDialog(
                "Hicrî tarih düzeltmesi",
                opts.map { if (it == 0) "Yok" else if (it > 0) "+$it gün" else "$it gün" },
                opts.indexOf(s.hijriAdj).coerceAtLeast(0),
                onSelect = { i ->
                    holder.update { it.copy(hijriAdj = opts[i]) }
                    dialog = null
                },
                onDismiss = { dialog = null }
            )
        }
        "sound" -> {
            val labels = ArrayList<String>()
            labels.add("Varsayılan bildirim sesi")
            labels.add("Alarm sesi")
            labels.add("Özel ses seç…")
            if (ezanAvail) labels.add("Ezan sesi (res/raw/ezan)")
            val sel = when (s.soundMode) {
                "alarm" -> 1
                "custom" -> 2
                "ezan" -> if (ezanAvail) 3 else 0
                else -> 0
            }
            ChoiceDialog(
                "Bildirim sesi",
                labels,
                sel,
                onSelect = { i ->
                    dialog = null
                    when (i) {
                        0 -> holder.update { it.copy(soundMode = "default", channelVer = it.channelVer + 1) }
                        1 -> holder.update { it.copy(soundMode = "alarm", channelVer = it.channelVer + 1) }
                        2 -> {
                            val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                                putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALL)
                                putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
                                putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Ezan / bildirim sesi seç")
                            }
                            picker.launch(intent)
                        }
                        else -> holder.update { it.copy(soundMode = "ezan", channelVer = it.channelVer + 1) }
                    }
                },
                onDismiss = { dialog = null }
            )
        }
        "adj" -> AlertDialog(
            onDismissRequest = { dialog = null },
            confirmButton = { TextButton(onClick = { dialog = null }) { Text("Tamam") } },
            title = { Text("Dakika ayarları") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    for (i in 0 until 6) {
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(Names.SHORT[i], Modifier.weight(1f), fontWeight = FontWeight.Medium)
                            StepBtn("−") {
                                holder.update { st ->
                                    st.copy(adj = st.adj.mapIndexed { j, v -> if (j == i) (v - 1).coerceAtLeast(-120) else v })
                                }
                            }
                            AdjField(s.adj[i]) { nv ->
                                holder.update { st ->
                                    st.copy(adj = st.adj.mapIndexed { j, v -> if (j == i) nv.coerceIn(-120, 120) else v })
                                }
                            }
                            StepBtn("+") {
                                holder.update { st ->
                                    st.copy(adj = st.adj.mapIndexed { j, v -> if (j == i) (v + 1).coerceAtMost(120) else v })
                                }
                            }
                        }
                    }
                }
            }
        )
        else -> {
            val d = dialog
            if (d != null && d.startsWith("rem")) {
                val i = d.substring(3).toIntOrNull() ?: 0
                val opts = listOf(0, 5, 10, 15, 20, 30, 45, 60)
                ChoiceDialog(
                    "${Names.SHORT[i]} için vakitten kaç dakika önce?",
                    opts.map { if (it == 0) "Kapalı" else "$it dakika önce" },
                    opts.indexOf(s.remind[i]).coerceAtLeast(0),
                    onSelect = { k ->
                        holder.update { st ->
                            st.copy(remind = st.remind.mapIndexed { j, v -> if (j == i) opts[k] else v })
                        }
                        dialog = null
                    },
                    onDismiss = { dialog = null }
                )
            } else if (d == "rsnd") {
                val names = listOf("bildirim", "bildirim1", "bildirim2", "bildirim3", "bildirim4", "bildirim5", "bildirim6", "bildirim7", "bildirim8", "bildirim9")
                ChoiceDialog(
                    "Hatırlatma sesi",
                    names,
                    names.indexOf(s.remindSound).coerceAtLeast(0),
                    onSelect = { k ->
                        Notifier.previewRemindSound(ctx, names[k])
                        holder.update { st -> st.copy(remindSound = names[k]) }
                        dialog = null
                    },
                    onDismiss = { dialog = null }
                )
            } else if (d != null && d.startsWith("sil")) {
                val i = d.substring(3).toIntOrNull() ?: 0
                val opts = listOf(5, 10, 15, 20, 30, 40, 45, 60, 90)
                ChoiceDialog(
                    "${Names.SHORT[i]} girince kaç dakika sessiz kalsın?",
                    opts.map { "$it dakika" },
                    opts.indexOf(s.silenceMins[i]).coerceAtLeast(0),
                    onSelect = { k ->
                        holder.update { st ->
                            st.copy(silenceMins = st.silenceMins.mapIndexed { j, v -> if (j == i) opts[k] else v })
                        }
                        dialog = null
                    },
                    onDismiss = { dialog = null }
                )
            }
        }
    }
}

private fun openIntent(ctx: android.content.Context, intent: Intent) {
    try {
        ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        try {
            ctx.startActivity(
                Intent(AndroidSettings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e2: Exception) {
        }
    }
}

/** Dakika degerini hem +/- ile hem klavyeyle yazarak girmeyi saglar. */
@Composable
private fun AdjField(value: Int, onValue: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    var text by remember(value) { mutableStateOf(value.toString()) }
    var focused by remember { mutableStateOf(false) }
    androidx.compose.foundation.text.BasicTextField(
        value = if (focused) text else (if (value > 0) "+" else "") + value.toString(),
        onValueChange = { raw ->
            val f = raw.filter { it.isDigit() || it == '-' }.take(4)
            text = f
            val n = f.toIntOrNull()
            if (n != null) onValue(n)
        },
        singleLine = true,
        textStyle = androidx.compose.ui.text.TextStyle(
            color = cs.onSurface,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            textAlign = TextAlign.Center
        ),
        cursorBrush = androidx.compose.ui.graphics.SolidColor(cs.primary),
        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
            keyboardType = androidx.compose.ui.text.input.KeyboardType.Number
        ),
        modifier = Modifier
            .width(64.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(cs.surfaceVariant.copy(alpha = 0.6f))
            .padding(vertical = 8.dp)
            .onFocusChanged {
                focused = it.isFocused
                if (it.isFocused) text = value.toString()
            }
    )
}

@Composable
private fun StepBtn(label: String, onClick: () -> Unit) {
    Box(
        Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) { Text(label, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
}

@Composable
private fun ValueRow(title: String, value: String, lead: Int? = null, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (lead != null) {
            PrayerIcon(lead, 34.dp)
            Spacer(Modifier.width(12.dp))
        }
        Text(Lang.tr(title), Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
        Text(Lang.tr(value), color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodyMedium)
        Text("  ›", color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun SwitchRow(
    title: String,
    sub: String?,
    checked: Boolean,
    enabled: Boolean = true,
    lead: Int? = null,
    onChange: (Boolean) -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (lead != null) {
            PrayerIcon(lead, 34.dp)
            Spacer(Modifier.width(12.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(
                Lang.tr(title),
                style = MaterialTheme.typography.titleSmall,
                color = if (enabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline
            )
            if (sub != null) {
                Text(
                    Lang.tr(sub),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}

@Composable
private fun PermItem(
    glyph: Glyph,
    title: String,
    sub: String,
    ok: Boolean,
    okLabel: String = "Açık",
    fixLabel: String = "İzin ver",
    onFix: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val green = Color(0xFF16A34A)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(cs.surfaceContainerHighest.copy(alpha = 0.55f))
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(if (ok) green.copy(alpha = 0.16f) else cs.primary.copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center
        ) { GlyphIcon(glyph, if (ok) green else cs.primary, 20.dp) }
        Spacer(Modifier.size(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Text(sub, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        }
        Spacer(Modifier.size(8.dp))
        if (ok) {
            Row(
                Modifier
                    .clip(RoundedCornerShape(50))
                    .background(green.copy(alpha = 0.16f))
                    .padding(horizontal = 10.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(green))
                Spacer(Modifier.size(6.dp))
                Text(okLabel, color = green, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
            }
        } else {
            androidx.compose.material3.FilledTonalButton(
                onClick = onFix,
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 14.dp, vertical = 0.dp)
            ) { Text(fixLabel) }
        }
    }
}

@Composable
private fun ChoiceDialog(
    title: String,
    options: List<String>,
    selected: Int,
    onSelect: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Kapat") } },
        title = { Text(title) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                options.forEachIndexed { i, o ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onSelect(i) }
                            .padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = i == selected, onClick = null)
                        Spacer(Modifier.width(12.dp))
                        Text(o)
                    }
                }
            }
        }
    )
}
