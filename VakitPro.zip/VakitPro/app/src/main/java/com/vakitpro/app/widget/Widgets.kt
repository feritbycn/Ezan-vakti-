package com.vakitpro.app.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.SystemClock
import android.widget.RemoteViews
import com.vakitpro.app.MainActivity
import com.vakitpro.app.R
import com.vakitpro.app.data.Fmt
import com.vakitpro.app.data.Hijri
import com.vakitpro.app.data.Names
import com.vakitpro.app.data.PrayerRepo
import com.vakitpro.app.data.Prefs
import com.vakitpro.app.notif.Refresher

abstract class BaseWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        WidgetUpdater.updateAll(context)
    }

    override fun onEnabled(context: Context) {
        Refresher.refreshAll(context, false)
    }
}

class CountdownWidget : BaseWidget()
class DayWidget : BaseWidget()
class BarWidget : BaseWidget()
class RingWidget : BaseWidget()
class GaugeWidget : BaseWidget()
class RamadanWidget : BaseWidget()

object WidgetUpdater {
    private val ACCENT = Color.parseColor("#5EEAD4")
    private val GOLD = Color.parseColor("#F5C26B")
    private val WHITE = Color.WHITE
    private val SUB = Color.parseColor("#B8C4D6")

    private val NAME_IDS = intArrayOf(R.id.wd_n0, R.id.wd_n1, R.id.wd_n2, R.id.wd_n3, R.id.wd_n4, R.id.wd_n5)
    private val TIME_IDS = intArrayOf(R.id.wd_t0, R.id.wd_t1, R.id.wd_t2, R.id.wd_t3, R.id.wd_t4, R.id.wd_t5)
    private val CELL_IDS = intArrayOf(R.id.wd_c0, R.id.wd_c1, R.id.wd_c2, R.id.wd_c3, R.id.wd_c4, R.id.wd_c5)

    private fun openApp(ctx: Context): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        return PendingIntent.getActivity(
            ctx, 11, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun countdown(rv: RemoteViews, viewId: Int, remainMs: Long) {
        rv.setChronometerCountDown(viewId, true)
        rv.setChronometer(viewId, SystemClock.elapsedRealtime() + remainMs, null, true)
    }

    fun updateAll(ctx: Context) {
        val mgr = AppWidgetManager.getInstance(ctx)
        val s = Prefs.load(ctx)
        val now = System.currentTimeMillis()
        val n = PrayerRepo.next(s, now)
        val remain = n.timeMs - now
        val today = PrayerRepo.today(now)
        val times = PrayerRepo.times(s, today)
        val hijriAdj = s.hijriAdj + (if (now >= times[4]) 1 else 0)
        val hijri = Hijri.of(today, hijriAdj).text()
        val pi = openApp(ctx)

        // 1) Geri sayim (2x2)
        val ids1 = mgr.getAppWidgetIds(ComponentName(ctx, CountdownWidget::class.java))
        if (ids1.isNotEmpty()) {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_countdown)
            rv.setTextViewText(R.id.wc_label, "${Names.DATIVE[n.index]} kalan")
            rv.setTextViewText(R.id.wc_name, Names.SHORT[n.index])
            rv.setTextViewText(R.id.wc_time, "${Fmt.hm(n.timeMs)} • ${s.cityName}")
            countdown(rv, R.id.wc_chrono, remain)
            rv.setOnClickPendingIntent(R.id.wc_root, pi)
            mgr.updateAppWidget(ids1, rv)
        }

        // 2) Gunluk vakitler (4x2)
        val ids2 = mgr.getAppWidgetIds(ComponentName(ctx, DayWidget::class.java))
        if (ids2.isNotEmpty()) {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_day)
            rv.setTextViewText(R.id.wd_title, "${Names.DATIVE[n.index]} kalan süre")
            rv.setTextViewText(R.id.wd_sub, "${s.cityName} • ${Fmt.dayShort(today)} • $hijri")
            countdown(rv, R.id.wd_chrono, remain)
            for (i in 0 until 6) {
                rv.setTextViewText(NAME_IDS[i], Names.SHORT[i])
                rv.setTextViewText(TIME_IDS[i], Fmt.hm(times[i]))
                val active = i == n.index
                rv.setInt(CELL_IDS[i], "setBackgroundResource", if (active) R.drawable.widget_cell_active else 0)
                rv.setTextColor(NAME_IDS[i], if (active) ACCENT else SUB)
                rv.setTextColor(TIME_IDS[i], if (active) GOLD else WHITE)
            }
            rv.setOnClickPendingIntent(R.id.wd_root, pi)
            mgr.updateAppWidget(ids2, rv)
        }

        // 4) Halka (2x2)
        val ids4 = mgr.getAppWidgetIds(ComponentName(ctx, RingWidget::class.java))
        if (ids4.isNotEmpty()) {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_ring)
            val span = (n.timeMs - n.prevMs).coerceAtLeast(1L)
            val frac = ((now - n.prevMs).toFloat() / span.toFloat()).coerceIn(0f, 1f)
            rv.setImageViewBitmap(R.id.wr_img, WidgetArt.ring(frac))
            rv.setTextViewText(R.id.wr_label, "${Names.DATIVE[n.index]} kalan")
            rv.setTextViewText(R.id.wr_time, "${Names.SHORT[n.index]} ${Fmt.hm(n.timeMs)}")
            countdown(rv, R.id.wr_chrono, remain)
            rv.setOnClickPendingIntent(R.id.wr_root, pi)
            mgr.updateAppWidget(ids4, rv)
        }

        // 6) Ramazan / iftar sayaci (4x2)
        val ids6 = mgr.getAppWidgetIds(ComponentName(ctx, RamadanWidget::class.java))
        if (ids6.isNotEmpty()) {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_ramadan)
            val ram = com.vakitpro.app.data.Ramadan.state(s, today)
            val tg = com.vakitpro.app.data.Ramadan.target(s, now, times)
            rv.setImageViewBitmap(R.id.wm_img, WidgetArt.ramadan())
            rv.setTextViewText(R.id.wm_title, if (ram.active) (if (ram.test) "Ramazan testi • " else "") + "Ramazan ${ram.day}. gün" else "İftar vakti • ${s.cityName}")
            rv.setTextViewText(R.id.wm_label, if (tg.toIftar) "İftara kalan süre" else "Sahur'a kalan süre")
            rv.setTextViewText(R.id.wm_times, "Sahur ${Fmt.hm(times[0])}   •   İftar ${Fmt.hm(times[4])}")
            countdown(rv, R.id.wm_chrono, (tg.timeMs - now).coerceAtLeast(0L))
            rv.setOnClickPendingIntent(R.id.wm_root, pi)
            mgr.updateAppWidget(ids6, rv)
        }

        // 5) Gun kadrani (4x2)
        val ids5 = mgr.getAppWidgetIds(ComponentName(ctx, GaugeWidget::class.java))
        if (ids5.isNotEmpty()) {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_gauge)
            val t0 = times[0]
            val span = (times[5] - t0).coerceAtLeast(1L).toFloat()
            val marks = FloatArray(6) { (times[it] - t0).toFloat() / span }
            val pos = (now - t0).toFloat() / span
            rv.setImageViewBitmap(R.id.wg_img, WidgetArt.gauge(marks, pos, n.index))
            rv.setTextViewText(R.id.wg_label, "${Names.DATIVE[n.index]} kalan")
            countdown(rv, R.id.wg_chrono, remain)
            val gn = intArrayOf(R.id.wg_n0, R.id.wg_n1, R.id.wg_n2, R.id.wg_n3, R.id.wg_n4, R.id.wg_n5)
            val gt = intArrayOf(R.id.wg_t0, R.id.wg_t1, R.id.wg_t2, R.id.wg_t3, R.id.wg_t4, R.id.wg_t5)
            val gc = intArrayOf(R.id.wg_c0, R.id.wg_c1, R.id.wg_c2, R.id.wg_c3, R.id.wg_c4, R.id.wg_c5)
            for (i in 0 until 6) {
                rv.setTextViewText(gn[i], Names.SHORT[i])
                rv.setTextViewText(gt[i], Fmt.hm(times[i]))
                val active = i == n.index
                rv.setInt(gc[i], "setBackgroundResource", if (active) R.drawable.widget_cell_active else 0)
                rv.setTextColor(gn[i], if (active) ACCENT else SUB)
                rv.setTextColor(gt[i], if (active) GOLD else WHITE)
            }
            rv.setOnClickPendingIntent(R.id.wg_root, pi)
            mgr.updateAppWidget(ids5, rv)
        }

        // 3) Serit (4x1)
        val ids3 = mgr.getAppWidgetIds(ComponentName(ctx, BarWidget::class.java))
        if (ids3.isNotEmpty()) {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_bar)
            rv.setTextViewText(R.id.wb_name, "${Names.SHORT[n.index]} ${Fmt.hm(n.timeMs)}")
            rv.setTextViewText(R.id.wb_sub, "${s.cityName} • $hijri")
            countdown(rv, R.id.wb_chrono, remain)
            rv.setOnClickPendingIntent(R.id.wb_root, pi)
            mgr.updateAppWidget(ids3, rv)
        }
    }
}
