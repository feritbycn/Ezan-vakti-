package com.vakitpro.app.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.SystemClock
import android.widget.RemoteViews
import com.vakitpro.app.MainActivity
import com.vakitpro.app.R
import com.vakitpro.app.data.Fmt
import com.vakitpro.app.data.Hijri
import com.vakitpro.app.data.Names
import com.vakitpro.app.data.PrayerRepo
import com.vakitpro.app.data.Prefs
import com.vakitpro.app.notif.Refresher

abstract class BaseWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        WidgetUpdater.updateAll(context)
    }

    override fun onEnabled(context: Context) {
        Refresher.refreshAll(context, false)
    }
}

class CountdownWidget : BaseWidget()
class DayWidget : BaseWidget()
class BarWidget : BaseWidget()

object WidgetUpdater {
    private val ACCENT = Color.parseColor("#5EEAD4")
    private val GOLD = Color.parseColor("#F5C26B")
    private val WHITE = Color.WHITE
    private val SUB = Color.parseColor("#B8C4D6")

    private val NAME_IDS = intArrayOf(R.id.wd_n0, R.id.wd_n1, R.id.wd_n2, R.id.wd_n3, R.id.wd_n4, R.id.wd_n5)
    private val TIME_IDS = intArrayOf(R.id.wd_t0, R.id.wd_t1, R.id.wd_t2, R.id.wd_t3, R.id.wd_t4, R.id.wd_t5)
    private val CELL_IDS = intArrayOf(R.id.wd_c0, R.id.wd_c1, R.id.wd_c2, R.id.wd_c3, R.id.wd_c4, R.id.wd_c5)

    private fun openApp(ctx: Context): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        return PendingIntent.getActivity(
            ctx, 11, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun countdown(rv: RemoteViews, viewId: Int, remainMs: Long) {
        rv.setChronometerCountDown(viewId, true)
        rv.setChronometer(viewId, SystemClock.elapsedRealtime() + remainMs, null, true)
    }

    fun updateAll(ctx: Context) {
        val mgr = AppWidgetManager.getInstance(ctx)
        val s = Prefs.load(ctx)
        val now = System.currentTimeMillis()
        val n = PrayerRepo.next(s, now)
        val remain = n.timeMs - now
        val today = PrayerRepo.today(now)
        val times = PrayerRepo.times(s, today)
        val hijriAdj = s.hijriAdj + (if (now >= times[4]) 1 else 0)
        val hijri = Hijri.of(today, hijriAdj).text()
        val pi = openApp(ctx)

        // 1) Geri sayim (2x2)
        val ids1 = mgr.getAppWidgetIds(ComponentName(ctx, CountdownWidget::class.java))
        if (ids1.isNotEmpty()) {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_countdown)
            rv.setTextViewText(R.id.wc_label, "${Names.DATIVE[n.index]} kalan")
            rv.setTextViewText(R.id.wc_name, Names.SHORT[n.index])
            rv.setTextViewText(R.id.wc_time, "${Fmt.hm(n.timeMs)} • ${s.cityName}")
            countdown(rv, R.id.wc_chrono, remain)
            rv.setOnClickPendingIntent(R.id.wc_root, pi)
            mgr.updateAppWidget(ids1, rv)
        }

        // 2) Gunluk vakitler (4x2)
        val ids2 = mgr.getAppWidgetIds(ComponentName(ctx, DayWidget::class.java))
        if (ids2.isNotEmpty()) {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_day)
            rv.setTextViewText(R.id.wd_title, "${Names.DATIVE[n.index]} kalan süre")
            rv.setTextViewText(R.id.wd_sub, "${s.cityName} • ${Fmt.dayShort(today)} • $hijri")
            countdown(rv, R.id.wd_chrono, remain)
            for (i in 0 until 6) {
                rv.setTextViewText(NAME_IDS[i], Names.SHORT[i])
                rv.setTextViewText(TIME_IDS[i], Fmt.hm(times[i]))
                val active = i == n.index
                rv.setInt(CELL_IDS[i], "setBackgroundResource", if (active) R.drawable.widget_cell_active else 0)
                rv.setTextColor(NAME_IDS[i], if (active) ACCENT else SUB)
                rv.setTextColor(TIME_IDS[i], if (active) GOLD else WHITE)
            }
            rv.setOnClickPendingIntent(R.id.wd_root, pi)
            mgr.updateAppWidget(ids2, rv)
        }

        // 3) Serit (4x1)
        val ids3 = mgr.getAppWidgetIds(ComponentName(ctx, BarWidget::class.java))
        if (ids3.isNotEmpty()) {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_bar)
            rv.setTextViewText(R.id.wb_name, "${Names.SHORT[n.index]} ${Fmt.hm(n.timeMs)}")
            rv.setTextViewText(R.id.wb_sub, "${s.cityName} • $hijri")
            countdown(rv, R.id.wb_chrono, remain)
            rv.setOnClickPendingIntent(R.id.wb_root, pi)
            mgr.updateAppWidget(ids3, rv)
        }
    }
}
