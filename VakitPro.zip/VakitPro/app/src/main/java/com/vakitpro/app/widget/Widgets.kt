package com.vakitpro.app.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.SystemClock
import android.view.View
import android.widget.RemoteViews
import com.vakitpro.app.MainActivity
import com.vakitpro.app.R
import com.vakitpro.app.data.Fmt
import com.vakitpro.app.data.Hijri
import com.vakitpro.app.data.Kerahat
import com.vakitpro.app.data.Names
import com.vakitpro.app.data.PrayerRepo
import com.vakitpro.app.data.Prefs
import com.vakitpro.app.notif.DailyContent
import com.vakitpro.app.notif.Refresher

abstract class BaseWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        WidgetUpdater.updateAll(context)
    }

    override fun onEnabled(context: Context) {
        Refresher.refreshAll(context, false)
    }
}

class CountdownWidget : BaseWidget()
class DayWidget : BaseWidget()
class BarWidget : BaseWidget()
class RingWidget : BaseWidget()
class GaugeWidget : BaseWidget()
class RamadanWidget : BaseWidget()
class HadisWidget : BaseWidget()
class AyetWidget : BaseWidget()

/** Kullanicinin widget eklerken sectigi arka plan: koyu cam ya da saydam (0 = arka plan yok). */
private fun isClear(ctx: Context, wid: Int): Boolean =
    Prefs.getStr(ctx, "wbg_$wid", "dark") == "clear"

private fun applyBg(ctx: Context, rv: RemoteViews, viewId: Int, wid: Int, glass: Int) {
    rv.setInt(viewId, "setBackgroundResource", if (isClear(ctx, wid)) 0 else glass)
}

private fun isNight(ctx: Context): Boolean =
    (ctx.resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
        android.content.res.Configuration.UI_MODE_NIGHT_YES

/**
 * Kullanicinin sectigi yazi rengini uygular.
 * Otomatik + koyu cam: layout'un varsayilan renkleri kalir.
 * Otomatik + saydam: sistem temasina gore krem ya da siyah (duvar kagidi parlakligi okunmaz).
 */
private fun applyText(ctx: Context, rv: RemoteViews, wid: Int, ids: IntArray, titleId: Int = -1) {
    val clear = isClear(ctx, wid)
    val c: Int = when (Prefs.getStr(ctx, "wtxt_$wid", "auto")) {
        "cream" -> 0xFFF3EAD3.toInt()
        "white" -> 0xFFFFFFFF.toInt()
        "black" -> if (clear) 0xFF0B1A1A.toInt() else return
        else -> {
            // Saydam zeminde otomatik mod her zaman krem: koyu duvar kagidinda siyah yazi okunmuyordu
            if (!clear) return
            0xFFF3EAD3.toInt()
        }
    }
    ids.forEach { rv.setTextColor(it, c) }
    if (titleId != -1) {
        rv.setTextColor(titleId, if (c == 0xFF0B1A1A.toInt()) 0xFF7A5A14.toInt() else 0xFFE7C97A.toInt())
    }
}

object WidgetUpdater {
    private val ACCENT = Color.parseColor("#5EEAD4")
    private val GOLD = Color.parseColor("#F5C26B")
    private val WHITE = Color.WHITE
    private val SUB = Color.parseColor("#B8C4D6")
    private val KERAHAT = Color.parseColor("#FF9A3D")

    private val NAME_IDS = intArrayOf(R.id.wd_n0, R.id.wd_n1, R.id.wd_n2, R.id.wd_n3, R.id.wd_n4, R.id.wd_n5)
    private val TIME_IDS = intArrayOf(R.id.wd_t0, R.id.wd_t1, R.id.wd_t2, R.id.wd_t3, R.id.wd_t4, R.id.wd_t5)
    private val CELL_IDS = intArrayOf(R.id.wd_c0, R.id.wd_c1, R.id.wd_c2, R.id.wd_c3, R.id.wd_c4, R.id.wd_c5)

    private fun openApp(ctx: Context): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        return PendingIntent.getActivity(
            ctx, 11, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun countdown(rv: RemoteViews, viewId: Int, remainMs: Long) {
        rv.setChronometerCountDown(viewId, true)
        rv.setChronometer(viewId, SystemClock.elapsedRealtime() + remainMs, null, true)
    }

    fun updateAll(ctx: Context) {
        val mgr = AppWidgetManager.getInstance(ctx)
        val s = Prefs.load(ctx)
        val now = System.currentTimeMillis()
        val n = PrayerRepo.next(s, now)
        val remain = n.timeMs - now
        val today = PrayerRepo.today(now)
        val times = PrayerRepo.times(s, today)
        val hijriAdj = s.hijriAdj + (if (now >= times[4]) 1 else 0)
        val hijri = Hijri.of(today, hijriAdj).text()
        val pi = openApp(ctx)

        // 1) Geri sayim (2x2)
        val ids1 = mgr.getAppWidgetIds(ComponentName(ctx, CountdownWidget::class.java))
        for (wid in ids1) {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_countdown)
            rv.setTextViewText(R.id.wc_name, Names.SHORT[n.index])
            rv.setTextViewText(R.id.wc_time, Fmt.hm(n.timeMs))
            countdown(rv, R.id.wc_chrono, remain)
            applyBg(ctx, rv, R.id.wc_root, wid, R.drawable.widget_bg)
            applyText(ctx, rv, wid, intArrayOf(R.id.wc_name, R.id.wc_chrono))
            rv.setOnClickPendingIntent(R.id.wc_root, pi)
            mgr.updateAppWidget(wid, rv)
        }

        // 2) Gunluk vakitler (4x2)
        val ids2 = mgr.getAppWidgetIds(ComponentName(ctx, DayWidget::class.java))
        val ker = Kerahat.current(times, now)
        // Vurgu icinde bulunulan vakitte olur (sirada olan vakitte degil)
        val curIdx = (n.index + 5) % 6
        for (wid in ids2) {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_day)
            rv.setTextViewText(R.id.wd_title, "${Names.DATIVE[n.index]} kalan süre")
            rv.setTextViewText(R.id.wd_sub, "${s.cityName} • ${Fmt.dayShort(today)} • $hijri")
            countdown(rv, R.id.wd_chrono, remain)
            rv.setTextColor(R.id.wd_chrono, if (ker != null) KERAHAT else ACCENT)
            val kv = if (ker != null) View.VISIBLE else View.GONE
            rv.setViewVisibility(R.id.wd_kmini, kv)
            if (ker != null) rv.setTextViewText(R.id.wd_kmini, "${ker.name.substringBefore(" (")} • ${Fmt.hm(ker.endMs)}'e kadar")
            for (i in 0 until 6) {
                rv.setTextViewText(NAME_IDS[i], Names.SHORT[i])
                rv.setTextViewText(TIME_IDS[i], Fmt.hm(times[i]))
                val active = i == curIdx
                rv.setInt(CELL_IDS[i], "setBackgroundResource", if (active) R.drawable.widget_cell_active else 0)
                rv.setTextColor(NAME_IDS[i], if (active) ACCENT else SUB)
                rv.setTextColor(TIME_IDS[i], if (active) GOLD else WHITE)
            }
            applyBg(ctx, rv, R.id.wd_root, wid, if (ker != null) R.drawable.widget_bg_kerahat else R.drawable.widget_bg)
            applyText(ctx, rv, wid, intArrayOf(R.id.wd_title, R.id.wd_sub))
            rv.setOnClickPendingIntent(R.id.wd_root, pi)
            mgr.updateAppWidget(wid, rv)
        }

        // 4) Halka (2x2)
        val ids4 = mgr.getAppWidgetIds(ComponentName(ctx, RingWidget::class.java))
        val span = (n.timeMs - n.prevMs).coerceAtLeast(1L)
        val frac = ((now - n.prevMs).toFloat() / span.toFloat()).coerceIn(0f, 1f)
        for (wid in ids4) {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_ring)
            rv.setImageViewBitmap(R.id.wr_img, WidgetArt.ring(frac))
            rv.setTextViewText(R.id.wr_label, "${Names.DATIVE[n.index]} kalan")
            rv.setTextViewText(R.id.wr_time, "${Names.SHORT[n.index]} ${Fmt.hm(n.timeMs)}")
            countdown(rv, R.id.wr_chrono, remain)
            applyBg(ctx, rv, R.id.wr_root, wid, R.drawable.widget_bg)
            applyText(ctx, rv, wid, intArrayOf(R.id.wr_label, R.id.wr_time, R.id.wr_chrono))
            rv.setOnClickPendingIntent(R.id.wr_root, pi)
            mgr.updateAppWidget(wid, rv)
        }

        // 6) Ramazan / iftar sayaci (4x2)
        val ids6 = mgr.getAppWidgetIds(ComponentName(ctx, RamadanWidget::class.java))
        for (wid in ids6) {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_ramadan)
            val ram = com.vakitpro.app.data.Ramadan.state(s, today)
            val tg = com.vakitpro.app.data.Ramadan.target(s, now, times)
            rv.setImageViewBitmap(R.id.wm_img, WidgetArt.ramadan(clear = isClear(ctx, wid)))
            rv.setTextViewText(R.id.wm_title, if (ram.active) (if (ram.test) "Ramazan testi • " else "") + "Ramazan ${ram.day}. gün" else "İftar vakti • ${s.cityName}")
            rv.setTextViewText(R.id.wm_label, if (tg.toIftar) "İftara kalan süre" else "Sahur'a kalan süre")
            rv.setTextViewText(R.id.wm_times, "Sahur ${Fmt.hm(times[0])}   •   İftar ${Fmt.hm(times[4])}")
            countdown(rv, R.id.wm_chrono, (tg.timeMs - now).coerceAtLeast(0L))
            applyText(ctx, rv, wid, intArrayOf(R.id.wm_label, R.id.wm_times, R.id.wm_chrono), R.id.wm_title)
            rv.setOnClickPendingIntent(R.id.wm_root, pi)
            mgr.updateAppWidget(wid, rv)
        }

        // 5) Gun kadrani (4x2)
        val ids5 = mgr.getAppWidgetIds(ComponentName(ctx, GaugeWidget::class.java))
        for (wid in ids5) {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_gauge)
            val t0 = times[0]
            val gspan = (times[5] - t0).coerceAtLeast(1L).toFloat()
            val marks = FloatArray(6) { (times[it] - t0).toFloat() / gspan }
            val pos = (now - t0).toFloat() / gspan
            rv.setImageViewBitmap(R.id.wg_img, WidgetArt.gauge(marks, pos, n.index))
            rv.setTextViewText(R.id.wg_label, "${Names.DATIVE[n.index]} kalan")
            countdown(rv, R.id.wg_chrono, remain)
            val gn = intArrayOf(R.id.wg_n0, R.id.wg_n1, R.id.wg_n2, R.id.wg_n3, R.id.wg_n4, R.id.wg_n5)
            val gt = intArrayOf(R.id.wg_t0, R.id.wg_t1, R.id.wg_t2, R.id.wg_t3, R.id.wg_t4, R.id.wg_t5)
            val gc = intArrayOf(R.id.wg_c0, R.id.wg_c1, R.id.wg_c2, R.id.wg_c3, R.id.wg_c4, R.id.wg_c5)
            for (i in 0 until 6) {
                rv.setTextViewText(gn[i], Names.SHORT[i])
                rv.setTextViewText(gt[i], Fmt.hm(times[i]))
                val active = i == n.index
                rv.setInt(gc[i], "setBackgroundResource", if (active) R.drawable.widget_cell_active else 0)
                rv.setTextColor(gn[i], if (active) ACCENT else SUB)
                rv.setTextColor(gt[i], if (active) GOLD else WHITE)
            }
            applyBg(ctx, rv, R.id.wg_root, wid, R.drawable.widget_bg)
            applyText(ctx, rv, wid, intArrayOf(R.id.wg_label, R.id.wg_chrono))
            rv.setOnClickPendingIntent(R.id.wg_root, pi)
            mgr.updateAppWidget(wid, rv)
        }

        // 3) Serit (4x1)
        val ids3 = mgr.getAppWidgetIds(ComponentName(ctx, BarWidget::class.java))
        for (wid in ids3) {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_bar)
            rv.setTextViewText(R.id.wb_name, "${Names.SHORT[n.index]} ${Fmt.hm(n.timeMs)}")
            rv.setTextViewText(R.id.wb_sub, "${s.cityName} • $hijri")
            countdown(rv, R.id.wb_chrono, remain)
            applyBg(ctx, rv, R.id.wb_root, wid, R.drawable.widget_bg)
            applyText(ctx, rv, wid, intArrayOf(R.id.wb_name, R.id.wb_sub, R.id.wb_chrono))
            rv.setOnClickPendingIntent(R.id.wb_root, pi)
            mgr.updateAppWidget(wid, rv)
        }

        // 7) Gunun hadisi (4x2)
        val ids7 = mgr.getAppWidgetIds(ComponentName(ctx, HadisWidget::class.java))
        for (wid in ids7) {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_hadis)
            val h = try {
                com.vakitpro.app.data.Hadis.daily(ctx, java.time.LocalDate.now().toEpochDay())
            } catch (_: Exception) { null }
            if (h != null) {
                rv.setTextViewText(R.id.wh_text, h.turkish.trim())
                val book = try { com.vakitpro.app.data.Hadis.bookName(ctx, h.bookId) } catch (_: Exception) { "" }
                val src = listOf(book, h.numberLabel).filter { it.isNotBlank() }.joinToString(" • ")
                rv.setTextViewText(R.id.wh_src, src)
            } else {
                rv.setTextViewText(R.id.wh_text, "Hadis verisi yüklenemedi. Uygulamayı açın.")
                rv.setTextViewText(R.id.wh_src, "")
            }
            applyBg(ctx, rv, R.id.wh_root, wid, R.drawable.widget_hadis_bg)
            applyText(ctx, rv, wid, intArrayOf(R.id.wh_text, R.id.wh_src), R.id.wh_title)
            rv.setOnClickPendingIntent(R.id.wh_root, pi)
            mgr.updateAppWidget(wid, rv)
        }

        // 8) Gunun ayeti (4x2)
        val ids8 = mgr.getAppWidgetIds(ComponentName(ctx, AyetWidget::class.java))
        for (wid in ids8) {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_ayet)
            val sec = try {
                DailyContent.build(ctx).pick("ayah").firstOrNull()
            } catch (_: Exception) { null }
            if (sec != null) {
                rv.setTextViewText(R.id.wa_text, sec.text.trim())
                rv.setTextViewText(R.id.wa_src, sec.source)
            } else {
                rv.setTextViewText(R.id.wa_text, "Ayet verisi yüklenemedi. Uygulamayı açın.")
                rv.setTextViewText(R.id.wa_src, "")
            }
            applyBg(ctx, rv, R.id.wa_root, wid, R.drawable.widget_ayet_bg)
            applyText(ctx, rv, wid, intArrayOf(R.id.wa_text, R.id.wa_src), R.id.wa_title)
            rv.setOnClickPendingIntent(R.id.wa_root, pi)
            mgr.updateAppWidget(wid, rv)
        }
    }
}
