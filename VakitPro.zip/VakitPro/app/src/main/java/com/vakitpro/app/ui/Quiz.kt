package com.vakitpro.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.json.JSONArray

class QuizItem(val q: String, val a: List<String>, val c: Int, val topic: String, val level: Int)

private class Run(val item: QuizItem, val order: List<Int>)

private fun loadQuiz(ctx: android.content.Context): List<QuizItem> = try {
    val txt = ctx.assets.open("quiz.json").bufferedReader().use { it.readText() }
    val arr = JSONArray(txt)
    List(arr.length()) { i ->
        val o = arr.getJSONObject(i)
        val a = o.getJSONArray("a")
        QuizItem(o.getString("q"), List(a.length()) { k -> a.getString(k) }, o.getInt("c"), o.getString("t"), o.getInt("d"))
    }
} catch (e: Exception) {
    emptyList()
}

private fun topicTitle(t: String) = t.replaceFirstChar { it.uppercase() }

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun QuizScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val all = remember { loadQuiz(ctx) }
    val topics = remember(all) { all.map { it.topic }.distinct().sorted() }
    val cs = MaterialTheme.colorScheme

    var stage by remember { mutableIntStateOf(0) }          // 0 ayar, 1 soru, 2 sonuc
    var topic by remember { mutableStateOf("") }            // bos = hepsi
    var level by remember { mutableIntStateOf(-1) }         // -1 karisik
    var count by remember { mutableIntStateOf(10) }
    var run by remember { mutableStateOf<List<Run>>(emptyList()) }
    var i by remember { mutableIntStateOf(0) }
    var picked by remember { mutableIntStateOf(-1) }
    var score by remember { mutableIntStateOf(0) }
    var wrong by remember { mutableStateOf<List<Pair<QuizItem, String>>>(emptyList()) }

    fun begin(items: List<QuizItem>) {
        run = items.map { Run(it, (0 until it.a.size).shuffled()) }
        i = 0; picked = -1; score = 0; wrong = emptyList(); stage = 1
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenHeader("Bilgi yarışması", "${all.size} soru • ödül yok, sadece öğrenme", onBack)
        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            when (stage) {
                0 -> {
                    ProCard {
                        Text("Konu", fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.size(6.dp))
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(selected = topic.isEmpty(), onClick = { topic = "" }, label = { Text("Hepsi") })
                            topics.forEach { t ->
                                FilterChip(selected = topic == t, onClick = { topic = t }, label = { Text(topicTitle(t)) })
                            }
                        }
                    }
                    ProCard {
                        Text("Zorluk", fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.size(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(-1 to "Karışık", 0 to "Kolay", 1 to "Orta", 2 to "Zor").forEach { (v, t) ->
                                FilterChip(selected = level == v, onClick = { level = v }, label = { Text(t) })
                            }
                        }
                        Spacer(Modifier.size(10.dp))
                        Text("Soru sayısı", fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.size(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(10, 20, 30).forEach { n ->
                                FilterChip(selected = count == n, onClick = { count = n }, label = { Text("$n") })
                            }
                        }
                    }
                    val pool = all.filter { (topic.isEmpty() || it.topic == topic) && (level < 0 || it.level == level) }
                    Text("Uygun ${pool.size} soru bulundu", color = cs.onSurfaceVariant)
                    Button(
                        onClick = { begin(pool.shuffled().take(count)) },
                        enabled = pool.isNotEmpty(),
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Başla") }
                }
                1 -> {
                    val r = run[i]
                    val q = r.item
                    LinearProgressIndicator(progress = { (i + 1f) / run.size }, modifier = Modifier.fillMaxWidth())
                    Text("Soru ${i + 1} / ${run.size}   •   Doğru $score", color = cs.onSurfaceVariant)
                    ProCard { Text(q.q, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold) }
                    r.order.forEach { k ->
                        val bg = when {
                            picked < 0 -> cs.surfaceContainerHigh
                            k == q.c -> Color(0xFF2E7D32).copy(alpha = 0.35f)
                            k == picked -> Color(0xFFC62828).copy(alpha = 0.35f)
                            else -> cs.surfaceContainerHigh
                        }
                        Surface(
                            onClick = {
                                if (picked < 0) {
                                    picked = k
                                    if (k == q.c) score++ else wrong = wrong + (q to q.a[k])
                                }
                            },
                            shape = RoundedCornerShape(18.dp), color = bg,
                            border = BorderStroke(1.dp, cs.outlineVariant), modifier = Modifier.fillMaxWidth()
                        ) { Text(q.a[k], Modifier.padding(16.dp), fontWeight = FontWeight.Medium) }
                    }
                    if (picked >= 0) {
                        val ok = picked == q.c
                        val tone = if (ok) Color(0xFF2E7D32) else Color(0xFFC62828)
                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            color = tone.copy(alpha = 0.15f),
                            border = BorderStroke(1.dp, tone),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(Modifier.padding(14.dp)) {
                                Text(if (ok) "Doğru bildin!" else "Yanlış", fontWeight = FontWeight.Bold, color = tone)
                                if (!ok) Text("Doğru cevap: ${q.a[q.c]}", fontWeight = FontWeight.Medium)
                            }
                        }
                    }
                    if (picked >= 0) {
                        Button(onClick = {
                            if (i >= run.size - 1) stage = 2 else { i++; picked = -1 }
                        }, modifier = Modifier.fillMaxWidth()) {
                            Text(if (i >= run.size - 1) "Sonucu gör" else "Sonraki soru")
                        }
                    }
                }
                else -> {
                    ProCard {
                        Text("Sonuç", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
                        Text("$score / ${run.size}", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold)
                        Text(if (wrong.isEmpty()) "Hepsini bildin, Allah razı olsun." else "${wrong.size} soruyu yanlış cevapladın. Aşağıda doğrularını görebilirsin.")
                    }
                    if (wrong.isNotEmpty()) {
                        Button(onClick = { begin(wrong.map { it.first }) }, modifier = Modifier.fillMaxWidth()) {
                            Text("Yanlışları tekrar çöz")
                        }
                        SectionTitle("Yanlış cevapların")
                        wrong.forEach { (q, given) ->
                            ProCard {
                                Text(q.q, fontWeight = FontWeight.SemiBold)
                                Spacer(Modifier.size(6.dp))
                                Text("Senin cevabın: $given", color = Color(0xFFC62828))
                                Text("Doğru cevap: ${q.a[q.c]}", color = Color(0xFF2E7D32), fontWeight = FontWeight.Medium)
                            }
                        }
                    }
                    OutlinedButton(onClick = { begin(run.map { it.item }.shuffled()) }, modifier = Modifier.fillMaxWidth()) { Text("Aynı soruları yeniden çöz") }
                    OutlinedButton(onClick = { stage = 0 }, modifier = Modifier.fillMaxWidth()) { Text("Yeni yarışma ayarla") }
                }
            }
        }
        Spacer(Modifier.size(24.dp))
    }
}
