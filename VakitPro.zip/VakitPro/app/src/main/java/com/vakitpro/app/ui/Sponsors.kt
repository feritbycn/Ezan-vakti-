package com.vakitpro.app.ui

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vakitpro.app.data.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate

/** Uzaktan okunan sponsor kaydi. Tarih ve yer bilgisi uygulama tarafinda kontrol edilir. */
data class Sponsor(
    val ad: String,
    val gorsel: String,
    val baslik: String,
    val link: String,
    val baslangic: LocalDate,
    val bitis: LocalDate,
    val aktif: Boolean,
    val oncelik: Int,
    val yerler: Set<String>
)

object Sponsors {
    /**
     * Sponsor listesinin adresi (JSON). Bos ise hicbir sponsor gosterilmez.
     * Test surecinde bos birakildigi icin uygulamada reklam gorunmez.
     */
    const val URL_JSON = ""

    /** Sponsor yoksa Google reklamina donulsun mu. Yayina gecerken true yapilir. */
    const val GOOGLE_FALLBACK = false

    private const val KEY = "sponsor_json"

    @Volatile
    var list: List<Sponsor> = emptyList()
        private set

    /** Son bilinen listeyi yerel kayittan yukler; agdan once bile calisir. */
    fun loadCached(ctx: Context) {
        parse(Prefs.getStr(ctx, KEY, ""))
    }

    /** Listeyi arka planda ceker, yerel kaydi gunceller. Adres bossa hicbir sey yapmaz. */
    fun refresh(ctx: Context) {
        if (URL_JSON.isBlank()) return
        val app = ctx.applicationContext
        Thread {
            try {
                val c = URL(URL_JSON).openConnection() as HttpURLConnection
                c.connectTimeout = 8000
                c.readTimeout = 8000
                val body = c.inputStream.bufferedReader().use { it.readText() }
                Prefs.putStr(app, KEY, body)
                parse(body)
            } catch (_: Exception) {
                // Ag yoksa son bilinen liste kullanilir
            }
        }.start()
    }

    private fun parse(text: String) {
        list = try {
            if (text.isBlank()) emptyList() else {
                val arr = JSONObject(text).optJSONArray("sponsorlar")
                val out = ArrayList<Sponsor>()
                if (arr != null) {
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        val yerArr = o.optJSONArray("yer")
                        val yerler = HashSet<String>()
                        if (yerArr != null) for (k in 0 until yerArr.length()) yerler.add(yerArr.getString(k))
                        out.add(
                            Sponsor(
                                ad = o.optString("ad"),
                                gorsel = o.optString("gorsel"),
                                baslik = o.optString("baslik"),
                                link = o.optString("link"),
                                baslangic = LocalDate.parse(o.getString("baslangic")),
                                bitis = LocalDate.parse(o.getString("bitis")),
                                aktif = o.optBoolean("aktif", true),
                                oncelik = o.optInt("oncelik", 1),
                                yerler = yerler
                            )
                        )
                    }
                }
                out
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    /**
     * Verilen yer ("ana", "hikaye") icin bugun gosterilecek sponsoru secer.
     * Tarih disindakiler ve pasif olanlar elenir. Ayni oncelikte olanlar gunde donusumlu gosterilir.
     */
    fun pick(yer: String, today: LocalDate = LocalDate.now()): Sponsor? {
        val c = list.filter {
            it.aktif && yer in it.yerler && !today.isBefore(it.baslangic) && !today.isAfter(it.bitis)
        }
        if (c.isEmpty()) return null
        val top = c.maxOf { it.oncelik }
        val best = c.filter { it.oncelik == top }
        return best[(today.toEpochDay() % best.size).toInt()]
    }
}

/** Yer icin sponsor varsa onu, yoksa (acikça izin verilmisse) Google banner'ini gosterir. */
@Composable
fun SponsorOrBanner(yer: String) {
    val sp = if (Pro.unlocked) null else Sponsors.pick(yer)
    when {
        sp != null -> SponsorCard(sp, Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp))
        Sponsors.GOOGLE_FALLBACK && !Pro.unlocked -> AdBanner()
        else -> Unit
    }
}

@Composable
private fun rememberRemoteBitmap(url: String): Bitmap? {
    var bmp by remember(url) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(url) {
        if (url.isBlank()) return@LaunchedEffect
        bmp = withContext(Dispatchers.IO) {
            try {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 8000
                c.readTimeout = 8000
                c.inputStream.use { BitmapFactory.decodeStream(it) }
            } catch (_: Exception) {
                null
            }
        }
    }
    return bmp
}

/** Sponsor kartı: gorsel, baslik ve "Sponsorlu" etiketi. Dokununca baglanti tarayicida acilir. */
@Composable
fun SponsorCard(s: Sponsor, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val bmp = rememberRemoteBitmap(s.gorsel)
    Column(
        modifier
            .clip(RoundedCornerShape(20.dp))
            .background(Color(0x14FFFFFF))
            .clickable {
                runCatching {
                    ctx.startActivity(
                        Intent(Intent.ACTION_VIEW, Uri.parse(s.link)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
            }
    ) {
        if (bmp != null) {
            Image(
                bitmap = bmp.asImageBitmap(),
                contentDescription = s.baslik,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxWidth().height(160.dp)
            )
        }
        Column(Modifier.padding(12.dp)) {
            Text(
                "Sponsorlu",
                color = Color(0xFFF2C26B),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                s.baslik,
                color = Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}
