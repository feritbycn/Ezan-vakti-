package com.vakitpro.app.data

import java.time.LocalDate
import java.time.chrono.HijrahDate
import java.time.temporal.ChronoField

data class HDate(val year: Int, val month: Int, val day: Int) {
    fun text(): String = "$day ${Hijri.MONTHS[(month - 1).coerceIn(0, 11)]} $year"
}

object Hijri {
    val MONTHS = arrayOf(
        "Muharrem", "Safer", "Rebiülevvel", "Rebiülahir", "Cemaziyelevvel", "Cemaziyelahir",
        "Recep", "Şaban", "Ramazan", "Şevval", "Zilkade", "Zilhicce"
    )

    /** adj: kullanicinin gun duzeltmesi (-2..+2). Hicri gun aksam namazinda degisir; cagiran taraf bunu adj'ye ekleyebilir. */
    fun of(date: LocalDate, adj: Int = 0): HDate {
        val d = date.plusDays(adj.toLong())
        return try {
            val h = HijrahDate.from(d)
            HDate(
                h.get(ChronoField.YEAR_OF_ERA),
                h.get(ChronoField.MONTH_OF_YEAR),
                h.get(ChronoField.DAY_OF_MONTH)
            )
        } catch (e: Exception) {
            tabular(d)
        }
    }

    /** Yedek: Kuveyt algoritmasi (tablo tabanli). */
    private fun tabular(date: LocalDate): HDate {
        val jd = (date.toEpochDay() + 2440588L).toInt()
        var l = jd - 1948440 + 10632
        val n = (l - 1) / 10631
        l = l - 10631 * n + 354
        val j = ((10985 - l) / 5316) * ((50 * l) / 17719) + (l / 5670) * ((43 * l) / 15238)
        l = l - ((30 - j) / 15) * ((17719 * j) / 50) - (j / 16) * ((15238 * j) / 43) + 29
        val m = (24 * l) / 709
        val d = l - (709 * m) / 24
        val y = 30 * n + j - 30
        return HDate(y, m, d)
    }
}

enum class EventKind { BAYRAM, KANDIL, OZEL }

data class ReligiousEvent(
    val name: String,
    val date: LocalDate,
    val night: Boolean, // kandil / gece ise tarih "gecesi"nin aksam tarihidir
    val kind: EventKind,
    val info: String,
    val hijri: String = ""
)

object ReligiousDays {
    /** [from] tarihinden itibaren [days] gun icindeki dini gun ve geceleri bulur. */
    fun upcoming(from: LocalDate, hijriAdj: Int, days: Int = 400): List<ReligiousEvent> {
        val out = ArrayList<ReligiousEvent>()
        var d = from
        val end = from.plusDays(days.toLong())
        while (!d.isAfter(end)) {
            val h = Hijri.of(d, hijriAdj)
            val m = h.month
            val dd = h.day
            if (m == 7 && dd <= 7 && d.dayOfWeek == java.time.DayOfWeek.FRIDAY) {
                out.add(ev("Regaib Kandili", d.minusDays(1), true, EventKind.KANDIL, "Recep'in ilk Cuma gecesi"))
            }
            when {
                m == 1 && dd == 1 -> out.add(ev("Hicri Yılbaşı", d, false, EventKind.OZEL, "Hicri ${h.year} yılının ilk günü"))
                m == 1 && dd == 10 -> out.add(ev("Aşure Günü", d, false, EventKind.OZEL, "Muharrem'in 10. günü"))
                m == 3 && dd == 12 -> out.add(ev("Mevlid Kandili", d.minusDays(1), true, EventKind.KANDIL, "Peygamberimiz'in doğum gecesi"))
                m == 7 && dd == 1 -> out.add(ev("Üç Ayların Başlangıcı", d, false, EventKind.OZEL, "Recep, Şaban, Ramazan"))
                m == 7 && dd == 27 -> out.add(ev("Miraç Kandili", d.minusDays(1), true, EventKind.KANDIL, "Recep'in 27. gecesi"))
                m == 8 && dd == 15 -> out.add(ev("Berat Kandili", d.minusDays(1), true, EventKind.KANDIL, "Şaban'ın 15. gecesi"))
                m == 9 && dd == 1 -> out.add(ev("Ramazan Başlangıcı", d, false, EventKind.OZEL, "Oruç ibadetinin ilk günü"))
                m == 9 && dd == 27 -> out.add(ev("Kadir Gecesi", d.minusDays(1), true, EventKind.KANDIL, "Ramazan'ın 27. gecesi"))
                m == 10 && dd == 1 -> {
                    out.add(ev("Ramazan Bayramı Arefesi", d.minusDays(1), false, EventKind.OZEL, "Bayramdan önceki gün"))
                    out.add(ev("Ramazan Bayramı", d, false, EventKind.BAYRAM, "3 gün sürer"))
                }
                m == 12 && dd == 9 -> out.add(ev("Kurban Bayramı Arefesi", d, false, EventKind.OZEL, "Bayramdan önceki gün"))
                m == 12 && dd == 10 -> out.add(ev("Kurban Bayramı", d, false, EventKind.BAYRAM, "4 gün sürer"))
            }
            d = d.plusDays(1)
        }
        return out.sortedBy { it.date }.map {
            // gece ise Hicri gun ertesi gundur (gece, onceki aksamla baslar)
            val hd = Hijri.of(if (it.night) it.date.plusDays(1) else it.date, hijriAdj)
            it.copy(hijri = hd.text())
        }
    }

    private fun ev(name: String, date: LocalDate, night: Boolean, kind: EventKind, info: String) =
        ReligiousEvent(name, date, night, kind, info)
}
