package com.vakitpro.app.notif

import android.app.Activity
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Bundle
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.FileProvider
import com.vakitpro.app.MainActivity
import com.vakitpro.app.R
import com.vakitpro.app.data.DuaData
import com.vakitpro.app.data.Hadis
import com.vakitpro.app.data.HadisItem
import com.vakitpro.app.data.Prefs
import com.vakitpro.app.data.Quran
import java.io.File
import java.util.Calendar

/** Gunun ayeti / hadisi / duasi: icerik, gorsel kart ve paylasim. */
class DailySection(val title: String, val arabic: String?, val text: String, val source: String)

class DailyContent(val sections: List<DailySection>, val hadis: HadisItem?) {
    companion object {
        fun build(ctx: Context, day: Long = java.time.LocalDate.now().toEpochDay()): DailyContent {
            val out = ArrayList<DailySection>()
            try {
                val q = Quran.load(ctx)
                val total = Quran.COUNTS.sum()
                var pos = Math.floorMod(day * 31L, total.toLong()).toInt()
                var s = 0
                while (pos >= Quran.COUNTS[s]) { pos -= Quran.COUNTS[s]; s++ }
                out.add(DailySection("Günün ayeti", q.ar[s][pos], q.tr[s][pos], "${Quran.NAMES[s]} Sûresi, ${pos + 1}. âyet"))
            } catch (e: Exception) {
            }
            var h: HadisItem? = null
            try {
                h = Hadis.daily(ctx, day)
                if (h != null) {
                    val b = Hadis.bookName(ctx, h.bookId)
                    out.add(DailySection("Günün hadisi", h.arabic.takeIf { it.isNotBlank() }, h.turkish, "$b ${h.numberLabel}".trim()))
                }
            } catch (e: Exception) {
            }
            val d = DuaData.ALL[Math.floorMod(day, DuaData.ALL.size.toLong()).toInt()]
            out.add(DailySection("Günün duası", d.arabic, d.okunus + "\n\n" + d.anlam, d.title))
            return DailyContent(out, h)
        }
    }

    /** Her gun tek tur gelir: ayet, hadis ve dua gunler arasi doner. */
    fun todayOnly(day: Long = java.time.LocalDate.now().toEpochDay()): DailyContent {
        val kind = listOf("ayah", "hadis", "dua")[Math.floorMod(day, 3L).toInt()]
        val picked = pick(kind)
        return DailyContent(if (picked.isEmpty()) sections else picked, hadis)
    }

    fun pick(what: String): List<DailySection> = when (what) {
        "ayah" -> sections.filter { it.title == "Günün ayeti" }
        "hadis" -> sections.filter { it.title == "Günün hadisi" }
        "dua" -> sections.filter { it.title == "Günün duası" }
        else -> sections
    }
}

object DailyShare {
    private const val W = 1080

    /** Tek bolum: hazir panelli arka planin icine ortalanmis yazi. */
    fun renderOne(ctx: Context, sec: DailySection, outW: Int = 2160): Bitmap {
        val res = PanelArt.res(
            when (sec.title) {
                "Günün ayeti" -> com.vakitpro.app.data.Inspire.AYET
                "Günün hadisi" -> com.vakitpro.app.data.Inspire.HADIS
                else -> com.vakitpro.app.data.Inspire.DUA
            }
        )
        val (sw, sh) = PanelArt.size(ctx, res)
        val w = minOf(outW, sw)
        val h = Math.round(sh * w / sw.toFloat())
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        PanelArt.draw(ctx, Canvas(bmp), w, h, res, sec.arabic, sec.text, sec.source, false)
        return bmp
    }

    /** Tek bolum -> tek cerceve; birden cok bolum -> cerceveler alt alta tek PNG. */
    fun render(ctx: Context, secs: List<DailySection>): Bitmap {
        val parts = secs.map { renderOne(ctx, it, if (secs.size == 1) 2160 else 1080) }
        if (parts.size == 1) return parts[0]
        val w = parts[0].width
        val out = Bitmap.createBitmap(w, parts.sumOf { it.height }, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        var y = 0f
        for (p in parts) { c.drawBitmap(p, 0f, y, null); y += p.height; p.recycle() }
        return out
    }

    /** Gorsel gunluk onbellekte tutulur; ilk uretimden sonra paylasim aninda hazirdir. */
    @Synchronized
    fun file(ctx: Context, what: String): File? {
        val day = java.time.LocalDate.now().toEpochDay()
        val dir = File(ctx.cacheDir, "stories").apply { mkdirs() }
        dir.listFiles()?.filter { it.name.startsWith("daily_") && !it.name.endsWith("_$day.png") }?.forEach { it.delete() }
        val f = File(dir, "daily_${what}_v2_$day.png")
        if (f.exists() && f.length() > 0) return f
        val secs = DailyContent.build(ctx).pick(what)
        if (secs.isEmpty()) return null
        val bmp = render(ctx, secs)
        val tmp = File(dir, "daily_${what}_v2_$day.tmp")
        tmp.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bmp.recycle()
        tmp.renameTo(f)
        return f
    }

    /** Arka planda onceden hazirla. */
    fun prewarm(ctx: Context) {
        val app = ctx.applicationContext
        Thread {
            for (w in listOf("ayah", "hadis", "dua", "all")) {
                try { file(app, w) } catch (e: Throwable) { }
            }
        }.start()
    }

    fun share(ctx: Context, what: String, whatsapp: Boolean = false) {
        val f = file(ctx, what) ?: return
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
        val send = Intent(Intent.ACTION_SEND).setType("image/png")
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            Toast.makeText(ctx.applicationContext, "Ezan Vakti Plus ile paylaşıldı", Toast.LENGTH_SHORT).show()
        }
        if (whatsapp) {
            for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b")) {
                try {
                    ctx.startActivity(Intent(send).setPackage(pkg))
                    return
                } catch (e: Exception) {
                }
            }
        }
        ctx.startActivity(Intent.createChooser(send, "Paylaş").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

/** Bildirimdeki paylas dugmeleri icin saydam aktivite: gorseli uretir, paylasim penceresini acar. */
class DailyShareActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val what = intent.getStringExtra("what") ?: "all"
        val app = applicationContext
        Thread {
            try {
                DailyShare.share(this, what)
            } catch (e: Exception) {
            }
            runOnUiThread { finish() }
        }.start()
    }
}

object DailyAlarm {
    const val CH = "daily_v2"
    const val NID = 4300
    private const val REQ = 7300

    fun enabled(ctx: Context) = Prefs.getInt(ctx, "daily_on", 1) == 1
    fun minutes(ctx: Context) = Prefs.getInt(ctx, "daily_min", 8 * 60)

    private fun pi(ctx: Context) = PendingIntent.getBroadcast(
        ctx, REQ, Intent(ctx, DailyReceiver::class.java).setAction("com.vakitpro.app.DAILY"),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    fun schedule(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (!enabled(ctx)) { am.cancel(pi(ctx)); return }
        val m = minutes(ctx)
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, m / 60); set(Calendar.MINUTE, m % 60)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis() + 5000) add(Calendar.DAY_OF_YEAR, 1)
        }
        val p = pi(ctx)
        try {
            val can = Build_canExact(ctx, am)
            if (can) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, p)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, p)
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, p)
        }
    }

    private fun Build_canExact(ctx: Context, am: AlarmManager): Boolean =
        if (android.os.Build.VERSION.SDK_INT >= 31) am.canScheduleExactAlarms() else true

    fun show(ctx: Context) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CH) == null) {
            val c = NotificationChannel(CH, "Günün ayeti, hadisi, duası", NotificationManager.IMPORTANCE_HIGH)
            c.description = "Her gün seçtiğin saatte ayet, hadis ve dua gönderir."
            nm.createNotificationChannel(c)
        }
        // Her gun tek bir icerik: ayet, hadis ya da dua donerek gelir. Tam ekran acilmaz, bildirim olarak gelir.
        val sec = DailyContent.build(ctx).todayOnly().sections.firstOrNull() ?: return
        val kind = when (sec.title) {
            "Günün hadisi" -> "hadis"
            "Günün duası" -> "dua"
            else -> "ayah"
        }
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        // Dokununca gunun ayet/hadis/dua ekrani acilir
        val open = PendingIntent.getActivity(
            ctx, 7310, Intent(ctx, MainActivity::class.java).putExtra("open", "daily")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP), flags
        )
        val share = PendingIntent.getActivity(
            ctx, 7311, Intent(ctx, DailyShareActivity::class.java).putExtra("what", kind)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_HISTORY), flags
        )
        val text = sec.text.trim()
        val summary = if (sec.source.isNotBlank()) "$text\n— ${sec.source}" else text
        val b = NotificationCompat.Builder(ctx, CH)
            .setSmallIcon(Notifier.baseIcon(ctx))
            .setContentTitle(sec.title)
            .setContentText(text.take(90))
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(open)
            .setAutoCancel(true)
            .setOnlyAlertOnce(true)
            .setTimeoutAfter(30 * 60_000L)
            .addAction(0, "Paylaş", share)
        if (kind == "hadis") {
            b.addAction(
                0, "Favoriye ekle",
                PendingIntent.getBroadcast(
                    ctx, 7313, Intent(ctx, DailyReceiver::class.java).setAction("com.vakitpro.app.DAILY_FAV"), flags
                )
            )
        }
        // Resimli bildirim: kart gorseli, ustunde "Günün ayeti" / "Günün hadisi" basligi
        val bmp = try { DailyShare.renderOne(ctx, sec, 1080) } catch (e: Throwable) { null }
        if (bmp != null) {
            b.setLargeIcon(bmp)
            b.setStyle(NotificationCompat.BigPictureStyle().bigPicture(bmp).setSummaryText(summary))
        } else {
            b.setStyle(NotificationCompat.BigTextStyle().bigText(summary))
        }
        nm.notify(NID, b.build())
    }
}

class DailyReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pr = goAsync()
        Thread {
            try {
                if (intent.action == "com.vakitpro.app.DAILY_FAV") {
                    val h = Hadis.daily(context, java.time.LocalDate.now().toEpochDay())
                    if (h != null) Hadis.setFlag(context, h, "fav", true)
                    (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(DailyAlarm.NID)
                    android.os.Handler(android.os.Looper.getMainLooper()).post {
                        Toast.makeText(context, "Hadis favorilere eklendi", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    if (DailyAlarm.enabled(context)) DailyAlarm.show(context)
                    DailyAlarm.schedule(context)
                }
            } catch (e: Exception) {
            } finally {
                pr.finish()
            }
        }.start()
    }
}
