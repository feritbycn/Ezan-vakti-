package com.vakitpro.app.notif

import android.app.Activity
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Bundle
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.FileProvider
import com.vakitpro.app.MainActivity
import com.vakitpro.app.R
import com.vakitpro.app.data.DuaData
import com.vakitpro.app.data.Hadis
import com.vakitpro.app.data.HadisItem
import com.vakitpro.app.data.Prefs
import com.vakitpro.app.data.Quran
import java.io.File
import java.util.Calendar

/** Gunun ayeti / hadisi / duasi: icerik, gorsel kart ve paylasim. */
class DailySection(val title: String, val arabic: String?, val text: String, val source: String)

class DailyContent(val sections: List<DailySection>, val hadis: HadisItem?) {
    companion object {
        fun build(ctx: Context, day: Long = java.time.LocalDate.now().toEpochDay()): DailyContent {
            val out = ArrayList<DailySection>()
            try {
                val q = Quran.load(ctx)
                val total = Quran.COUNTS.sum()
                var pos = Math.floorMod(day * 31L, total.toLong()).toInt()
                var s = 0
                while (pos >= Quran.COUNTS[s]) { pos -= Quran.COUNTS[s]; s++ }
                out.add(DailySection("Günün ayeti", q.ar[s][pos], q.tr[s][pos], "${Quran.NAMES[s]} Sûresi, ${pos + 1}. âyet"))
            } catch (e: Exception) {
            }
            var h: HadisItem? = null
            try {
                h = Hadis.daily(ctx, day)
                if (h != null) {
                    val b = Hadis.bookName(ctx, h.bookId)
                    out.add(DailySection("Günün hadisi", h.arabic.takeIf { it.isNotBlank() }, h.turkish, "$b ${h.numberLabel}".trim()))
                }
            } catch (e: Exception) {
            }
            val d = DuaData.ALL[Math.floorMod(day, DuaData.ALL.size.toLong()).toInt()]
            out.add(DailySection("Günün duası", d.arabic, d.okunus + "\n\n" + d.anlam, d.title))
            return DailyContent(out, h)
        }
    }

    fun pick(what: String): List<DailySection> = when (what) {
        "ayah" -> sections.filter { it.title == "Günün ayeti" }
        "hadis" -> sections.filter { it.title == "Günün hadisi" }
        "dua" -> sections.filter { it.title == "Günün duası" }
        else -> sections
    }
}

object DailyShare {
    private const val W = 1080

    /** Logo + baslik, altta alt alta bolumler; tek PNG. */
    fun render(ctx: Context, secs: List<DailySection>): Bitmap {
        val pad = 64f
        val inner = (W - 2 * pad).toInt()
        fun tp(size: Float, color: Int, bold: Boolean = false) = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size; this.color = color
            typeface = Typeface.create("sans-serif", if (bold) Typeface.BOLD else Typeface.NORMAL)
        }
        fun lay(t: String, p: TextPaint, sp: Float = 1.2f) =
            StaticLayout.Builder.obtain(t, 0, t.length, p, inner)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL).setLineSpacing(0f, sp).build()

        val gold = Color.rgb(232, 196, 112)
        val cream = Color.rgb(248, 244, 232)
        val soft = Color.argb(190, 248, 244, 232)
        class Blk(val t: StaticLayout, val a: StaticLayout?, val b: StaticLayout, val s: StaticLayout?)
        val blocks = secs.map {
            Blk(
                lay(it.title, tp(36f, gold, true)),
                it.arabic?.takeIf { x -> x.isNotBlank() }?.let { x -> lay(x, tp(46f, cream), 1.5f) },
                lay(it.text, tp(34f, cream), 1.3f),
                it.source.takeIf { x -> x.isNotBlank() }?.let { x -> lay("— $x", tp(28f, soft)) }
            )
        }
        val head = 190f
        val foot = 110f
        var total = head
        for (b in blocks) {
            total += b.t.height + 16f
            if (b.a != null) total += b.a.height + 20f
            total += b.b.height + 12f
            if (b.s != null) total += b.s.height + 12f
            total += 56f
        }
        total += foot
        val bmp = Bitmap.createBitmap(W, total.toInt(), Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val bg = Paint()
        bg.shader = LinearGradient(0f, 0f, 0f, total, Color.rgb(8, 52, 46), Color.rgb(5, 24, 30), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, W.toFloat(), total, bg)

        try {
            val logo = BitmapFactory.decodeResource(ctx.resources, R.drawable.ic_launcher_logo)
            if (logo != null) {
                val r = android.graphics.RectF(pad, 50f, pad + 96f, 146f)
                val clip = android.graphics.Path().apply { addRoundRect(r, 24f, 24f, android.graphics.Path.Direction.CW) }
                c.save(); c.clipPath(clip)
                c.drawBitmap(logo, null, r, Paint(Paint.FILTER_BITMAP_FLAG))
                c.restore()
            }
        } catch (e: Exception) {
        }
        c.drawText("Ezan Vakti – NurVakit", pad + 120f, 112f, tp(44f, cream, true))
        val line = Paint().apply { color = Color.argb(70, 232, 196, 112); strokeWidth = 2f }
        c.drawLine(pad, head - 20f, W - pad, head - 20f, line)

        var y = head
        for (b in blocks) {
            fun put(l: StaticLayout, gap: Float) {
                c.save(); c.translate(pad, y); l.draw(c); c.restore(); y += l.height + gap
            }
            put(b.t, 16f)
            b.a?.let { put(it, 20f) }
            put(b.b, 12f)
            b.s?.let { put(it, 12f) }
            y += 56f - 0f
            c.drawLine(pad + 200f, y - 28f, W - pad - 200f, y - 28f, line)
        }
        val f = tp(28f, soft)
        c.drawText("NurVakit ile paylaşıldı", pad, total - 44f, f)
        return bmp
    }

    fun share(ctx: Context, what: String) {
        val secs = DailyContent.build(ctx).pick(what)
        if (secs.isEmpty()) return
        val bmp = render(ctx, secs)
        val dir = File(ctx.cacheDir, "stories").apply { mkdirs() }
        dir.listFiles()?.filter { it.name.startsWith("daily_") }?.forEach { it.delete() }
        val f = File(dir, "daily_${what}_${System.currentTimeMillis()}.png")
        f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
        val text = secs.joinToString("\n\n") { it.title + "\n" + it.text + (if (it.source.isNotBlank()) "\n— " + it.source else "") } + "\n\n— NurVakit"
        val send = Intent(Intent.ACTION_SEND).setType("image/png")
            .putExtra(Intent.EXTRA_STREAM, uri)
            .putExtra(Intent.EXTRA_TEXT, text)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        val ch = Intent.createChooser(send, "Paylaş").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(ch)
    }
}

/** Bildirimdeki paylas dugmeleri icin saydam aktivite: gorseli uretir, paylasim penceresini acar. */
class DailyShareActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val what = intent.getStringExtra("what") ?: "all"
        val app = applicationContext
        Thread {
            try {
                DailyShare.share(this, what)
            } catch (e: Exception) {
            }
            runOnUiThread { finish() }
        }.start()
    }
}

object DailyAlarm {
    const val CH = "daily_v1"
    const val NID = 4300
    private const val REQ = 7300

    fun enabled(ctx: Context) = Prefs.getInt(ctx, "daily_on", 1) == 1
    fun minutes(ctx: Context) = Prefs.getInt(ctx, "daily_min", 8 * 60)

    private fun pi(ctx: Context) = PendingIntent.getBroadcast(
        ctx, REQ, Intent(ctx, DailyReceiver::class.java).setAction("com.vakitpro.app.DAILY"),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    fun schedule(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (!enabled(ctx)) { am.cancel(pi(ctx)); return }
        val m = minutes(ctx)
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, m / 60); set(Calendar.MINUTE, m % 60)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis() + 5000) add(Calendar.DAY_OF_YEAR, 1)
        }
        val p = pi(ctx)
        try {
            val can = Build_canExact(ctx, am)
            if (can) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, p)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, p)
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, p)
        }
    }

    private fun Build_canExact(ctx: Context, am: AlarmManager): Boolean =
        if (android.os.Build.VERSION.SDK_INT >= 31) am.canScheduleExactAlarms() else true

    fun show(ctx: Context) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CH) == null) {
            val c = NotificationChannel(CH, "Günün ayeti, hadisi, duası", NotificationManager.IMPORTANCE_DEFAULT)
            c.description = "Her gün seçtiğin saatte ayet, hadis ve dua gönderir."
            nm.createNotificationChannel(c)
        }
        val dc = DailyContent.build(ctx)
        val big = dc.sections.joinToString("\n\n") { it.title + "\n" + it.text.trim() + (if (it.source.isNotBlank()) "\n— " + it.source else "") }
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val open = PendingIntent.getActivity(
            ctx, 7310, Intent(ctx, MainActivity::class.java).putExtra("open", "daily")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP), flags
        )
        fun shareIntent(code: Int, what: String) = PendingIntent.getActivity(
            ctx, code, Intent(ctx, DailyShareActivity::class.java).putExtra("what", what)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_HISTORY), flags
        )
        val b = NotificationCompat.Builder(ctx, CH)
            .setSmallIcon(Notifier.baseIcon(ctx))
            .setContentTitle("Günün ayeti, hadisi ve duası")
            .setContentText(dc.sections.firstOrNull()?.text?.take(90) ?: "")
            .setStyle(NotificationCompat.BigTextStyle().bigText(big))
            .setContentIntent(open)
            .setAutoCancel(true)
            .addAction(0, "Hepsini paylaş", shareIntent(7311, "all"))
        if (dc.hadis != null) {
            b.addAction(0, "Hadisi paylaş", shareIntent(7312, "hadis"))
            b.addAction(
                0, "Hadisi favoriye ekle",
                PendingIntent.getBroadcast(
                    ctx, 7313, Intent(ctx, DailyReceiver::class.java).setAction("com.vakitpro.app.DAILY_FAV"), flags
                )
            )
        }
        nm.notify(NID, b.build())
    }
}

class DailyReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pr = goAsync()
        Thread {
            try {
                if (intent.action == "com.vakitpro.app.DAILY_FAV") {
                    val h = Hadis.daily(context, java.time.LocalDate.now().toEpochDay())
                    if (h != null) Hadis.setFlag(context, h, "fav", true)
                    (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(DailyAlarm.NID)
                    android.os.Handler(android.os.Looper.getMainLooper()).post {
                        Toast.makeText(context, "Hadis favorilere eklendi", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    if (DailyAlarm.enabled(context)) DailyAlarm.show(context)
                    DailyAlarm.schedule(context)
                }
            } catch (e: Exception) {
            } finally {
                pr.finish()
            }
        }.start()
    }
}
