package com.vakitpro.app.notif

import android.app.Activity
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Bundle
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.FileProvider
import com.vakitpro.app.MainActivity
import com.vakitpro.app.R
import com.vakitpro.app.data.DuaData
import com.vakitpro.app.data.Hadis
import com.vakitpro.app.data.HadisItem
import com.vakitpro.app.data.Prefs
import com.vakitpro.app.data.Quran
import java.io.File
import java.util.Calendar

/** Gunun ayeti / hadisi / duasi: icerik, gorsel kart ve paylasim. */
class DailySection(val title: String, val arabic: String?, val text: String, val source: String)

class DailyContent(val sections: List<DailySection>, val hadis: HadisItem?) {
    companion object {
        fun build(ctx: Context, day: Long = java.time.LocalDate.now().toEpochDay()): DailyContent {
            val out = ArrayList<DailySection>()
            try {
                val q = Quran.load(ctx)
                val total = Quran.COUNTS.sum()
                var pos = Math.floorMod(day * 31L, total.toLong()).toInt()
                var s = 0
                while (pos >= Quran.COUNTS[s]) { pos -= Quran.COUNTS[s]; s++ }
                out.add(DailySection("Günün ayeti", q.ar[s][pos], q.tr[s][pos], "${Quran.NAMES[s]} Sûresi, ${pos + 1}. âyet"))
            } catch (e: Exception) {
            }
            var h: HadisItem? = null
            try {
                h = Hadis.daily(ctx, day)
                if (h != null) {
                    val b = Hadis.bookName(ctx, h.bookId)
                    out.add(DailySection("Günün hadisi", h.arabic.takeIf { it.isNotBlank() }, h.turkish, "$b ${h.numberLabel}".trim()))
                }
            } catch (e: Exception) {
            }
            val d = DuaData.ALL[Math.floorMod(day, DuaData.ALL.size.toLong()).toInt()]
            out.add(DailySection("Günün duası", d.arabic, d.okunus + "\n\n" + d.anlam, d.title))
            return DailyContent(out, h)
        }
    }

    fun pick(what: String): List<DailySection> = when (what) {
        "ayah" -> sections.filter { it.title == "Günün ayeti" }
        "hadis" -> sections.filter { it.title == "Günün hadisi" }
        "dua" -> sections.filter { it.title == "Günün duası" }
        else -> sections
    }
}

object DailyShare {
    private const val W = 1080

    private var frameCache: Bitmap? = null
    private fun frame(ctx: Context): Bitmap {
        frameCache?.let { return it }
        val f = BitmapFactory.decodeResource(ctx.resources, R.drawable.share_frame)
        frameCache = f
        return f
    }

    /** Tek bolum: cerceve gorselinin icine ortalanmis yazi. */
    private fun renderOne(ctx: Context, sec: DailySection): Bitmap {
        val fr = frame(ctx)
        val w = fr.width
        val h = fr.height
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawBitmap(fr, 0f, 0f, null)

        val gold = Color.rgb(236, 200, 120)
        val white = Color.rgb(250, 247, 238)
        fun tp(size: Float, color: Int, bold: Boolean = false, serif: Boolean = true) = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size; this.color = color
            typeface = if (serif) Typeface.create("serif", if (bold) Typeface.BOLD else Typeface.NORMAL)
            else Typeface.create("sans-serif", Typeface.NORMAL)
            setShadowLayer(8f, 0f, 3f, Color.argb(190, 0, 0, 0))
        }
        val tw = (w * 0.64f).toInt()
        val left = (w - tw) / 2f
        val top = h * 0.165f
        val maxH = h * 0.34f
        fun lay(t: CharSequence, p: TextPaint, sp: Float, maxLines: Int = Int.MAX_VALUE): StaticLayout =
            StaticLayout.Builder.obtain(t, 0, t.length, p, tw)
                .setAlignment(Layout.Alignment.ALIGN_CENTER).setLineSpacing(0f, sp)
                .setMaxLines(maxLines).setEllipsize(android.text.TextUtils.TruncateAt.END).build()

        val title = sec.title.uppercase(java.util.Locale("tr", "TR"))
        val body = "“" + sec.text.trim() + "”"
        val src = if (sec.source.isNotBlank()) "— " + sec.source else ""
        val gap = h * 0.022f
        var scale = 1f
        var tl: StaticLayout; var al: StaticLayout?; var bl: StaticLayout; var sl: StaticLayout?
        while (true) {
            tl = lay(title, tp(66f * w / 1080f * scale, gold, true), 1.0f)
            al = sec.arabic?.takeIf { it.isNotBlank() }?.let { lay(it, tp(54f * w / 1080f * scale, white, false), 1.35f) }
            bl = lay(body, tp(56f * w / 1080f * scale, white, false), 1.18f)
            sl = if (src.isNotEmpty()) lay(src, tp(46f * w / 1080f * scale, gold, false), 1.0f) else null
            val tot = tl.height + gap + (al?.let { it.height + gap } ?: 0f) + bl.height + gap + (sl?.height ?: 0)
            if (tot <= maxH || scale <= 0.42f) break
            scale -= 0.04f
        }
        // Hala sigmiyorsa metni kirp
        val used = tl.height + gap + (al?.let { it.height + gap } ?: 0f) + gap + (sl?.height ?: 0)
        val room = maxH - used
        if (bl.height > room) {
            val lh = bl.height / bl.lineCount.toFloat()
            bl = lay(body, tp(56f * w / 1080f * scale, white, false), 1.18f, maxOf(2, (room / lh).toInt()))
        }
        var y = top
        fun put(l: StaticLayout) { c.save(); c.translate(left, y); l.draw(c); c.restore(); y += l.height + gap }
        put(tl)
        al?.let { put(it) }
        put(bl)
        sl?.let { put(it) }

        // Logo + imza
        try {
            val logo = BitmapFactory.decodeResource(ctx.resources, R.drawable.ic_launcher_logo)
            if (logo != null) {
                val sz = w * 0.09f
                val cx = w / 2f
                val ly = h * 0.855f
                val r = android.graphics.RectF(cx - sz / 2, ly, cx + sz / 2, ly + sz)
                val clip = android.graphics.Path().apply { addRoundRect(r, sz * 0.22f, sz * 0.22f, android.graphics.Path.Direction.CW) }
                c.save(); c.clipPath(clip)
                c.drawBitmap(logo, null, r, Paint(Paint.FILTER_BITMAP_FLAG))
                c.restore()
            }
        } catch (e: Exception) {
        }
        val f = tp(40f * w / 1080f, white)
        f.textAlign = Paint.Align.CENTER
        c.drawText("NurVakit ile paylaşıldı", w / 2f, h * 0.855f + w * 0.09f + 62f * w / 1080f, f)
        return bmp
    }

    /** Tek bolum -> tek cerceve; birden cok bolum -> cerceveler alt alta tek PNG. */
    fun render(ctx: Context, secs: List<DailySection>): Bitmap {
        val parts = secs.map { renderOne(ctx, it) }
        if (parts.size == 1) return parts[0]
        val w = parts[0].width
        val out = Bitmap.createBitmap(w, parts.sumOf { it.height }, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        var y = 0f
        for (p in parts) { c.drawBitmap(p, 0f, y, null); y += p.height; p.recycle() }
        return out
    }

    fun share(ctx: Context, what: String) {
        val secs = DailyContent.build(ctx).pick(what)
        if (secs.isEmpty()) return
        val bmp = render(ctx, secs)
        val dir = File(ctx.cacheDir, "stories").apply { mkdirs() }
        dir.listFiles()?.filter { it.name.startsWith("daily_") }?.forEach { it.delete() }
        val f = File(dir, "daily_${what}_${System.currentTimeMillis()}.png")
        f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
        val send = Intent(Intent.ACTION_SEND).setType("image/png")
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        val ch = Intent.createChooser(send, "Paylaş").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(ch)
    }
}

/** Bildirimdeki paylas dugmeleri icin saydam aktivite: gorseli uretir, paylasim penceresini acar. */
class DailyShareActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val what = intent.getStringExtra("what") ?: "all"
        val app = applicationContext
        Thread {
            try {
                DailyShare.share(this, what)
            } catch (e: Exception) {
            }
            runOnUiThread { finish() }
        }.start()
    }
}

object DailyAlarm {
    const val CH = "daily_v2"
    const val NID = 4300
    private const val REQ = 7300

    fun enabled(ctx: Context) = Prefs.getInt(ctx, "daily_on", 1) == 1
    fun minutes(ctx: Context) = Prefs.getInt(ctx, "daily_min", 8 * 60)

    private fun pi(ctx: Context) = PendingIntent.getBroadcast(
        ctx, REQ, Intent(ctx, DailyReceiver::class.java).setAction("com.vakitpro.app.DAILY"),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    fun schedule(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (!enabled(ctx)) { am.cancel(pi(ctx)); return }
        val m = minutes(ctx)
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, m / 60); set(Calendar.MINUTE, m % 60)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis() + 5000) add(Calendar.DAY_OF_YEAR, 1)
        }
        val p = pi(ctx)
        try {
            val can = Build_canExact(ctx, am)
            if (can) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, p)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, p)
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, p)
        }
    }

    private fun Build_canExact(ctx: Context, am: AlarmManager): Boolean =
        if (android.os.Build.VERSION.SDK_INT >= 31) am.canScheduleExactAlarms() else true

    fun show(ctx: Context) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CH) == null) {
            val c = NotificationChannel(CH, "Günün ayeti, hadisi, duası", NotificationManager.IMPORTANCE_HIGH)
            c.description = "Her gün seçtiğin saatte ayet, hadis ve dua gönderir."
            nm.createNotificationChannel(c)
        }
        val dc = DailyContent.build(ctx)
        val big = dc.sections.joinToString("\n\n") { it.title + "\n" + it.text.trim() + (if (it.source.isNotBlank()) "\n— " + it.source else "") }
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val open = PendingIntent.getActivity(
            ctx, 7310, Intent(ctx, MainActivity::class.java).putExtra("open", "daily")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP), flags
        )
        fun shareIntent(code: Int, what: String) = PendingIntent.getActivity(
            ctx, code, Intent(ctx, DailyShareActivity::class.java).putExtra("what", what)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_HISTORY), flags
        )
        val b = NotificationCompat.Builder(ctx, CH)
            .setSmallIcon(Notifier.baseIcon(ctx))
            .setContentTitle("Günün ayeti, hadisi ve duası")
            .setContentText(dc.sections.firstOrNull()?.text?.take(90) ?: "")
            .setStyle(NotificationCompat.BigTextStyle().bigText(big))
            .setContentIntent(open)
            .setAutoCancel(true)
            .addAction(0, "Hepsini paylaş", shareIntent(7311, "all"))
        if (dc.hadis != null) {
            b.addAction(0, "Hadisi paylaş", shareIntent(7312, "hadis"))
            b.addAction(
                0, "Hadisi favoriye ekle",
                PendingIntent.getBroadcast(
                    ctx, 7313, Intent(ctx, DailyReceiver::class.java).setAction("com.vakitpro.app.DAILY_FAV"), flags
                )
            )
        }
        if (Prefs.load(ctx).popup) {
            val pop = PendingIntent.getActivity(
                ctx, 7320, Intent(ctx, DailyPopupActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NO_ANIMATION), flags
            )
            b.setFullScreenIntent(pop, true)
            b.setPriority(NotificationCompat.PRIORITY_HIGH)
            try {
                if (Notifier.canOverlay(ctx)) ctx.startActivity(
                    Intent(ctx, DailyPopupActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                )
            } catch (e: Exception) {
            }
        }
        nm.notify(NID, b.build())
    }
}

class DailyReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pr = goAsync()
        Thread {
            try {
                if (intent.action == "com.vakitpro.app.DAILY_FAV") {
                    val h = Hadis.daily(context, java.time.LocalDate.now().toEpochDay())
                    if (h != null) Hadis.setFlag(context, h, "fav", true)
                    (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(DailyAlarm.NID)
                    android.os.Handler(android.os.Looper.getMainLooper()).post {
                        Toast.makeText(context, "Hadis favorilere eklendi", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    if (DailyAlarm.enabled(context)) DailyAlarm.show(context)
                    DailyAlarm.schedule(context)
                }
            } catch (e: Exception) {
            } finally {
                pr.finish()
            }
        }.start()
    }
}
