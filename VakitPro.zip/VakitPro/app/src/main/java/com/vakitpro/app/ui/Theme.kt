package com.vakitpro.app.ui

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.vakitpro.app.R
import com.vakitpro.app.data.Settings

val ACCENTS = listOf(
    Color(0xFF14B8A6),
    Color(0xFF6366F1),
    Color(0xFFF59E0B),
    Color(0xFF10B981),
    Color(0xFFEC4899),
    Color(0xFF3B82F6)
)
val ACCENT_NAMES = listOf("Turkuaz", "İndigo", "Kehribar", "Zümrüt", "Gül", "Mavi")

val Gold = Color(0xFFF5C26B)

/** Renk paleti: koyu ve acik varyantlari. */
class Pal(
    val id: String, val name: String, val pro: Boolean,
    val dBg: Color, val dSurf: Color, val dAcc: Color,
    val lBg: Color, val lSurf: Color, val lAcc: Color
)

val PALETTES = listOf(
    // Varsayilan: onceki klasik gorunum (koyuda lacivert, acikta beyaz; vurgu = secilen vurgu rengi)
    Pal("auto", "Klasik (varsayılan)", false,
        Color(0xFF0B1220), Color(0xFF111A2B), Color(0xFF14B8A6),
        Color(0xFFF4F7FB), Color(0xFFFFFFFF), Color(0xFF14B8A6)),
    Pal("gece", "Gece Moru", false,
        Color(0xFF0E0A24), Color(0xFF181235), Color(0xFFF2C26B),
        Color(0xFFFBF7EE), Color(0xFFFFFFFF), Color(0xFF3A2A86)),
    Pal("siyah", "Siyah & Gümüş", false,
        Color(0xFF0A0A0C), Color(0xFF1C1C21), Color(0xFFD9DEE7),
        Color(0xFFF5F6F8), Color(0xFFFFFFFF), Color(0xFF1C1C21)),
    Pal("lacivert", "Lacivert & Altın", true,
        Color(0xFF0B1A36), Color(0xFF13305E), Color(0xFFE9C46A),
        Color(0xFFF3F7FC), Color(0xFFFFFFFF), Color(0xFF13305E)),
    Pal("zumrut", "Zümrüt Gece", true,
        Color(0xFF062320), Color(0xFF0E3D36), Color(0xFF6EE7B7),
        Color(0xFFF2FAF7), Color(0xFFFFFFFF), Color(0xFF0E7A62)),
    Pal("bordo", "Bordo & Gül", true,
        Color(0xFF2A0E1E), Color(0xFF4A1A34), Color(0xFFF4B6C2),
        Color(0xFFFDF5F7), Color(0xFFFFFFFF), Color(0xFF8A2A4D))
)

/** Ucretsiz kullanicinin secebilecegi palet kimlikleri. "auto" = koyuda gece, acikta siyah. */
private val FREE_PALETTES = setOf("auto", "gece", "siyah")

/** Ucretsiz gorsel: 11. gorsel. Digerleri PRO. */
private const val FREE_BG = 11

/** Iftar kartinin gorselleri (1-15. secenekler, ram_bg01..ram_bg15). */
val RAM_BG_RES: List<Int> = listOf(
    R.drawable.ram_bg01, R.drawable.ram_bg02, R.drawable.ram_bg03, R.drawable.ram_bg04,
    R.drawable.ram_bg05, R.drawable.ram_bg06, R.drawable.ram_bg07, R.drawable.ram_bg08,
    R.drawable.ram_bg09, R.drawable.ram_bg10, R.drawable.ram_bg11, R.drawable.ram_bg12,
    R.drawable.ram_bg13, R.drawable.ram_bg14, R.drawable.ram_bg15
)

/** Iftar arka plani secenek sayisi (gorseller). */
val RAM_BG_COUNT: Int get() = RAM_BG_RES.size

/** PRO kilidi: mevcut Pro sistemindeki kilit. */
private val proOn: Boolean get() = Pro.unlocked

/** PRO degilse yalnizca serbest gorsel (11) kullanilir. */
fun effectiveRamBg(s: Settings): Int {
    val v = s.ramBg.coerceIn(1, RAM_BG_COUNT)
    return if (proOn || v == FREE_BG) v else FREE_BG
}

fun isPaletteLocked(id: String): Boolean = !proOn && id !in FREE_PALETTES

/** n: 1..15 gorsel. PRO degilken yalnizca 11. gorsel serbest. */
fun isBgLocked(n: Int): Boolean = !proOn && n != FREE_BG

fun isDarkTheme(s: Settings, systemDark: Boolean): Boolean = when (s.theme) {
    "light" -> false
    "dark", "amoled" -> true
    else -> systemDark
}

/** Aktif palet. PRO kilitli palet ise varsayilana (klasik) duser. */
fun activePalette(s: Settings, dark: Boolean): Pal {
    val want = if (isPaletteLocked(s.palette)) "auto" else s.palette
    return PALETTES.firstOrNull { it.id == want } ?: PALETTES[0]
}

private fun buildScheme(pal: Pal, accent: Color?, dark: Boolean, amoled: Boolean): ColorScheme {
    return if (dark) {
        val bg = if (amoled) Color.Black else pal.dBg
        val surf = if (amoled) Color(0xFF0B0B0C) else pal.dSurf
        val primary = accent ?: pal.dAcc
        val onPrimary = if (primary.luminance() > 0.4f) Color(0xFF1A1200) else Color.White
        val surfHi = lerp(surf, Color.White, 0.06f)
        val surfHighest = lerp(surf, Color.White, 0.12f)
        darkColorScheme(
            primary = primary,
            onPrimary = onPrimary,
            primaryContainer = lerp(surf, primary, 0.28f),
            onPrimaryContainer = Color.White,
            secondary = Gold,
            onSecondary = Color(0xFF241800),
            background = bg,
            onBackground = Color(0xFFE6EDF7),
            surface = surf,
            onSurface = Color(0xFFE6EDF7),
            surfaceVariant = surfHi,
            onSurfaceVariant = Color(0xFFA9B6CC),
            surfaceContainerLowest = bg,
            surfaceContainerLow = surf,
            surfaceContainer = surf,
            surfaceContainerHigh = surfHi,
            surfaceContainerHighest = surfHighest,
            outline = Color(0xFF3A4A6B),
            outlineVariant = Color(0xFF26324D)
        )
    } else {
        val primary = accent ?: pal.lAcc
        val onPrimary = if (primary.luminance() > 0.4f) Color(0xFF0F172A) else Color.White
        lightColorScheme(
            primary = primary,
            onPrimary = onPrimary,
            primaryContainer = lerp(pal.lSurf, primary, 0.18f),
            onPrimaryContainer = Color(0xFF0F172A),
            secondary = Color(0xFFB7791F),
            onSecondary = Color.White,
            background = pal.lBg,
            onBackground = Color(0xFF0F172A),
            surface = pal.lSurf,
            onSurface = Color(0xFF0F172A),
            surfaceVariant = lerp(pal.lBg, Color.Black, 0.05f),
            onSurfaceVariant = Color(0xFF52607A),
            surfaceContainerLowest = pal.lSurf,
            surfaceContainerLow = lerp(pal.lSurf, pal.lBg, 0.4f),
            surfaceContainer = pal.lSurf,
            surfaceContainerHigh = lerp(pal.lSurf, pal.lBg, 0.7f),
            surfaceContainerHighest = lerp(pal.lSurf, pal.lBg, 0.85f),
            outline = Color(0xFF9AA8C2),
            outlineVariant = Color(0xFFD5DDEB)
        )
    }
}

@Composable
fun VakitTheme(s: Settings, content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    // Ramazan modu artik temayi zorlamaz; tema yalnizca ayarlara gore secilir.
    val dark = isDarkTheme(s, isSystemInDarkTheme())
    val pal = activePalette(s, dark)
    // Vurgu rengi yalnizca kullanici sectiyse palet vurgusunun yerine gecer.
    // Klasik palette ve kullanici vurgu sectiginde secilen vurgu rengi kullanilir
    val accent = if (s.palette == "auto" || s.accentPicked) ACCENTS[s.accent.coerceIn(0, ACCENTS.lastIndex)] else null
    val scheme = if (s.dynamicColor && Build.VERSION.SDK_INT >= 31) {
        if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
    } else {
        buildScheme(pal, accent, dark, s.theme == "amoled")
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                val c = WindowCompat.getInsetsController(window, view)
                c.isAppearanceLightStatusBars = !dark
                c.isAppearanceLightNavigationBars = !dark
            }
        }
    }

    MaterialTheme(colorScheme = scheme, content = content)
}
