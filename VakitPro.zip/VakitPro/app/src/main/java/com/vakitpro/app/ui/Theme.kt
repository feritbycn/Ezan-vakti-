package com.vakitpro.app.ui

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.vakitpro.app.data.Settings

val ACCENTS = listOf(
    Color(0xFF14B8A6),
    Color(0xFF6366F1),
    Color(0xFFF59E0B),
    Color(0xFF10B981),
    Color(0xFFEC4899),
    Color(0xFF3B82F6)
)
val ACCENT_NAMES = listOf("Turkuaz", "İndigo", "Kehribar", "Zümrüt", "Gül", "Mavi")

val Gold = Color(0xFFF5C26B)

fun isDarkTheme(s: Settings, systemDark: Boolean): Boolean = when (s.theme) {
    "light" -> false
    "dark", "amoled" -> true
    else -> systemDark
}

private fun buildScheme(accent: Color, dark: Boolean, amoled: Boolean, ramadan: Boolean = false): ColorScheme {
    val onAccent = if (accent.luminance() > 0.4f) Color(0xFF06110F) else Color.White
    return if (dark) {
        val bg = if (amoled) Color.Black else if (ramadan) Color(0xFF0E0A24) else Color(0xFF0B1220)
        val surf = if (amoled) Color(0xFF0B0B0C) else if (ramadan) Color(0xFF181235) else Color(0xFF111A2B)
        val surfHi = if (amoled) Color(0xFF151517) else if (ramadan) Color(0xFF221A48) else Color(0xFF18233A)
        val surfHighest = if (amoled) Color(0xFF1D1D20) else if (ramadan) Color(0xFF2B2260) else Color(0xFF1F2C48)
        darkColorScheme(
            primary = accent,
            onPrimary = onAccent,
            primaryContainer = lerp(surf, accent, 0.28f),
            onPrimaryContainer = Color.White,
            secondary = Gold,
            onSecondary = Color(0xFF241800),
            background = bg,
            onBackground = Color(0xFFE6EDF7),
            surface = surf,
            onSurface = Color(0xFFE6EDF7),
            surfaceVariant = surfHi,
            onSurfaceVariant = Color(0xFFA9B6CC),
            surfaceContainerLowest = bg,
            surfaceContainerLow = surf,
            surfaceContainer = surf,
            surfaceContainerHigh = surfHi,
            surfaceContainerHighest = surfHighest,
            outline = Color(0xFF3A4A6B),
            outlineVariant = Color(0xFF26324D)
        )
    } else {
        lightColorScheme(
            primary = accent,
            onPrimary = onAccent,
            primaryContainer = lerp(Color.White, accent, 0.18f),
            onPrimaryContainer = Color(0xFF0F172A),
            secondary = Color(0xFFB7791F),
            onSecondary = Color.White,
            background = Color(0xFFF4F7FB),
            onBackground = Color(0xFF0F172A),
            surface = Color.White,
            onSurface = Color(0xFF0F172A),
            surfaceVariant = Color(0xFFE9EEF7),
            onSurfaceVariant = Color(0xFF52607A),
            surfaceContainerLowest = Color.White,
            surfaceContainerLow = Color(0xFFF8FAFD),
            surfaceContainer = Color.White,
            surfaceContainerHigh = Color(0xFFEDF2FA),
            surfaceContainerHighest = Color(0xFFE5EBF5),
            outline = Color(0xFF9AA8C2),
            outlineVariant = Color(0xFFD5DDEB)
        )
    }
}

@Composable
fun VakitTheme(s: Settings, content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val ramadan = com.vakitpro.app.data.Ramadan.state(s, java.time.LocalDate.now()).active
    // Ramazan'da tema her zaman gece moru (koyu) olur
    val dark = ramadan || isDarkTheme(s, isSystemInDarkTheme())
    val accent = if (ramadan) Color(0xFFF2C26B) else ACCENTS[s.accent.coerceIn(0, ACCENTS.lastIndex)]
    val scheme = if (s.dynamicColor && !ramadan && Build.VERSION.SDK_INT >= 31) {
        if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
    } else {
        buildScheme(accent, dark, s.theme == "amoled", ramadan)
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                val c = WindowCompat.getInsetsController(window, view)
                c.isAppearanceLightStatusBars = !dark
                c.isAppearanceLightNavigationBars = !dark
            }
        }
    }

    MaterialTheme(colorScheme = scheme, content = content)
}
