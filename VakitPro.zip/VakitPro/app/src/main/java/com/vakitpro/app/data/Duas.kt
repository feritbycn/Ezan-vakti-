package com.vakitpro.app.data

data class Dua(
    val title: String,
    val arabic: String,
    val okunus: String,
    val anlam: String
)

object DuaData {
    val ALL: List<Dua> = listOf(
        Dua(
            "Fâtiha Sûresi",
            "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ\n" +
                "الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ\n" +
                "الرَّحْمَٰنِ الرَّحِيمِ\n" +
                "مَالِكِ يَوْمِ الدِّينِ\n" +
                "إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ\n" +
                "اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ\n" +
                "صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ",
            "Bismillâhirrahmânirrahîm. Elhamdü lillâhi rabbil'âlemîn. Errahmânirrahîm. Mâliki yevmiddîn. " +
                "İyyâke na'büdü ve iyyâke neste'în. İhdinessırâtal müstakîm. " +
                "Sırâtallezîne en'amte aleyhim gayril mağdûbi aleyhim ve leddâllîn.",
            "Rahman ve Rahim olan Allah'ın adıyla. Hamd, âlemlerin Rabbi Allah'a mahsustur. " +
                "O, Rahman'dır, Rahim'dir; din gününün sahibidir. Yalnız sana kulluk eder, yalnız senden yardım isteriz. " +
                "Bizi doğru yola ilet; kendilerine nimet verdiklerinin yoluna, gazaba uğrayanların ve sapkınların yoluna değil."
        ),
        Dua(
            "İhlâs Sûresi",
            "قُلْ هُوَ اللَّهُ أَحَدٌ\n" +
                "اللَّهُ الصَّمَدُ\n" +
                "لَمْ يَلِدْ وَلَمْ يُولَدْ\n" +
                "وَلَمْ يَكُنْ لَهُ كُفُوًا أَحَدٌ",
            "Kul hüvallâhü ehad. Allâhüssamed. Lem yelid ve lem yûled. Ve lem yekün lehû küfüven ehad.",
            "De ki: O, Allah'tır, tektir. Allah Samed'dir (her şey ona muhtaçtır). Doğurmamış ve doğmamıştır. " +
                "Hiçbir şey O'na denk değildir."
        ),
        Dua(
            "Felâk Sûresi",
            "قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ\n" +
                "مِنْ شَرِّ مَا خَلَقَ\n" +
                "وَمِنْ شَرِّ غَاسِقٍ إِذَا وَقَبَ\n" +
                "وَمِنْ شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ\n" +
                "وَمِنْ شَرِّ حَاسِدٍ إِذَا حَسَدَ",
            "Kul e'ûzü birabbil felak. Min şerri mâ halak. Ve min şerri gâsikın izâ vekab. " +
                "Ve min şerrin neffâsâti fil ukad. Ve min şerri hâsidin izâ hased.",
            "De ki: Yarattığı şeylerin şerrinden, karanlığı çöktüğü zaman gecenin şerrinden, " +
                "düğümlere üfleyenlerin şerrinden ve haset ettiği zaman hasetçinin şerrinden " +
                "sabahın Rabbine sığınırım."
        ),
        Dua(
            "Nâs Sûresi",
            "قُلْ أَعُوذُ بِرَبِّ النَّاسِ\n" +
                "مَلِكِ النَّاسِ\n" +
                "إِلَٰهِ النَّاسِ\n" +
                "مِنْ شَرِّ الْوَسْوَاسِ الْخَنَّاسِ\n" +
                "الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ\n" +
                "مِنَ الْجِنَّةِ وَالنَّاسِ",
            "Kul e'ûzü birabbin nâs. Melikin nâs. İlâhin nâs. Min şerril vesvâsil hannâs. " +
                "Ellezî yüvesvisü fî sudûrin nâs. Minel cinneti ven nâs.",
            "De ki: İnsanların Rabbine, insanların Melik'ine, insanların İlâh'ına; " +
                "cinlerden ve insanlardan olup insanların kalplerine vesvese veren sinsi vesvesecinin şerrinden sığınırım."
        ),
        Dua(
            "Kevser Sûresi",
            "إِنَّا أَعْطَيْنَاكَ الْكَوْثَرَ\n" +
                "فَصَلِّ لِرَبِّكَ وَانْحَرْ\n" +
                "إِنَّ شَانِئَكَ هُوَ الْأَبْتَرُ",
            "İnnâ a'taynâkel kevser. Fesalli lirabbike venhar. İnne şânieke hüvel ebter.",
            "Şüphesiz biz sana Kevser'i verdik. Öyleyse Rabbin için namaz kıl ve kurban kes. " +
                "Asıl soyu kesik olan, sana kin besleyendir."
        ),
        Dua(
            "Asr Sûresi",
            "وَالْعَصْرِ\n" +
                "إِنَّ الْإِنسَانَ لَفِي خُسْرٍ\n" +
                "إِلَّا الَّذِينَ آمَنُوا وَعَمِلُوا الصَّالِحَاتِ وَتَوَاصَوْا بِالْحَقِّ وَتَوَاصَوْا بِالصَّبْرِ",
            "Vel asr. İnnel insâne le fî husr. İllellezîne âmenû ve amilüssâlihâti ve tevâsav bilhakkı ve tevâsav bissabr.",
            "Zamana andolsun ki insan gerçekten ziyandadır. Ancak iman edip salih amel işleyenler, " +
                "birbirlerine hakkı ve sabrı tavsiye edenler hariç."
        ),
        Dua(
            "Âyetel Kürsî",
            "اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۚ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ ۚ " +
                "لَهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ ۗ مَنْ ذَا الَّذِي يَشْفَعُ عِنْدَهُ إِلَّا بِإِذْنِهِ ۚ " +
                "يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ ۖ وَلَا يُحِيطُونَ بِشَيْءٍ مِنْ عِلْمِهِ إِلَّا بِمَا شَاءَ ۚ " +
                "وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ ۖ وَلَا يَئُودُهُ حِفْظُهُمَا ۚ وَهُوَ الْعَلِيُّ الْعَظِيمُ",
            "Allâhü lâ ilâhe illâ hüve'l-hayyü'l-kayyûm. Lâ te'huzühû sinetün ve lâ nevm. " +
                "Lehû mâ fîs-semâvâti ve mâ fîl-ard. Men zellezî yeşfeu indehû illâ bi-iznih. " +
                "Ya'lemü mâ beyne eydîhim ve mâ halfehüm. Ve lâ yühîtûne bi-şey'in min ilmihî illâ bi-mâ şâ'. " +
                "Vesia kürsiyyühüs-semâvâti vel-ard. Ve lâ yeûdühû hıfzuhümâ ve hüvel-aliyyül-azîm.",
            "Allah, kendisinden başka ilâh olmayandır; diridir, her şeyi ayakta tutandır. Onu ne uyuklama tutar ne uyku. " +
                "Göklerdeki ve yerdeki her şey O'nundur. İzni olmadan katında kim şefaat edebilir? " +
                "O, kulların önlerindekini ve arkalarındakini bilir. Onlar, O'nun dilediği kadarından başka ilminden hiçbir şeyi kavrayamazlar. " +
                "Kürsüsü gökleri ve yeri kuşatmıştır; bunları korumak O'na ağır gelmez. O, çok yücedir, pek büyüktür."
        ),
        Dua(
            "Tesbihat",
            "سُبْحَانَ اللَّهِ  ×33\nالْحَمْدُ لِلَّهِ  ×33\nاللَّهُ أَكْبَرُ  ×33\n" +
                "لَا إِلَٰهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ",
            "Sübhânallah (33), Elhamdülillâh (33), Allâhü ekber (33). Ardından: " +
                "Lâ ilâhe illallâhü vahdehû lâ şerîke leh.",
            "Farz namazlardan sonra okunan klasik tesbihat. Zikirmatik ekranında hazır sayaçlarla sayabilirsiniz."
        )
    )
}

data class ZikirPreset(val title: String, val arabic: String, val target: Int)

object ZikirData {
    val PRESETS: List<ZikirPreset> = listOf(
        ZikirPreset("Sübhânallah", "سُبْحَانَ اللَّهِ", 33),
        ZikirPreset("Elhamdülillâh", "الْحَمْدُ لِلَّهِ", 33),
        ZikirPreset("Allâhü ekber", "اللَّهُ أَكْبَرُ", 33),
        ZikirPreset("Estağfirullah", "أَسْتَغْفِرُ اللَّهَ", 100),
        ZikirPreset("Lâ ilâhe illallah", "لَا إِلَٰهَ إِلَّا اللَّهُ", 100),
        ZikirPreset("Salavat", "اللَّهُمَّ صَلِّ عَلَىٰ مُحَمَّدٍ", 100),
        ZikirPreset("Serbest", "", 0)
    )
}
