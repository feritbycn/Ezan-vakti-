package com.vakitpro.app.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * PRO rozeti: parildayan pill + iki halkanin cift nabiz dalgasi.
 * Kilitli palet / arka plan kutularinda kullanilir.
 */
@Composable
fun ProBadge(modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "proBadge")
    val p by t.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1800, easing = LinearEasing)),
        label = "proPulse"
    )
    Box(modifier, contentAlignment = Alignment.Center) {
        repeat(2) { i ->
            val f = (p + i * 0.5f) % 1f
            Box(
                Modifier
                    .matchParentSize()
                    .graphicsLayer {
                        scaleX = 1f + f * 0.9f
                        scaleY = 1f + f * 0.9f
                        alpha = 0.9f * (1f - f)
                    }
                    .border(2.dp, Color(0xFFF2C26B), RoundedCornerShape(50))
            )
        }
        Row(
            Modifier
                .clip(RoundedCornerShape(50))
                .background(
                    Brush.linearGradient(listOf(Color(0xFFFFF3C4), Color(0xFFE0B453), Color(0xFFFFF3C4)))
                )
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("✦", color = Color(0xFF5B3D00), fontSize = 9.sp)
            Spacer(Modifier.width(3.dp))
            Text("PRO", color = Color(0xFF3A2300), fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
    }
}
