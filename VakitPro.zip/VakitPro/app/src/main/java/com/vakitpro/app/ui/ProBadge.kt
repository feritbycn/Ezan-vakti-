package com.vakitpro.app.ui

import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin

private val NeonTurquoise = Color(0xFF34F5C5)

/**
 * PRO rozeti: turkuaz neon cerceve + merkezden disari saçilan kivilcimlar.
 * Kilitli palet ve arka plan kutularinda kullanilir.
 */
@Composable
fun ProBadge(modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "proSpark")
    val p by t.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1400, easing = LinearOutSlowInEasing)),
        label = "proSparkP"
    )
    Box(modifier, contentAlignment = Alignment.Center) {
        repeat(8) { i ->
            val a = Math.toRadians(i * 45.0)
            val f = (p + (i % 3) * 0.12f) % 1f
            val r = 26f * f
            Box(
                Modifier
                    .size(4.dp)
                    .offset(x = (cos(a) * r).dp, y = (sin(a) * r).dp)
                    .alpha(1f - f)
                    .background(NeonTurquoise, CircleShape)
            )
        }
        Row(
            Modifier
                .clip(RoundedCornerShape(50))
                .border(1.5.dp, NeonTurquoise, RoundedCornerShape(50))
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("✦ PRO", color = NeonTurquoise, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)
        }
    }
}
