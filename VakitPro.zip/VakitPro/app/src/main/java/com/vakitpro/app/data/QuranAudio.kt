package com.vakitpro.app.data

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.PowerManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Ayet ayet sesli okuma (everyayah.com kayitlari, internetten akis). */
object QuranAudio {
    class Reciter(val name: String, val folder: String)

    val RECITERS = listOf(
        Reciter("Mişari Raşid el-Afasî", "Alafasy_128kbps"),
        Reciter("Abdülbasit Abdussamed (Mürettel)", "Abdul_Basit_Murattal_192kbps"),
        Reciter("Abdülbasit Abdussamed (Mücevved)", "Abdul_Basit_Mujawwad_128kbps"),
        Reciter("Abdurrahman es-Sudeys", "Abdurrahmaan_As-Sudais_192kbps"),
        Reciter("Suud eş-Şureym", "Saood_ash-Shuraym_128kbps"),
        Reciter("Mahir el-Muaykılî", "Maher_AlMuaiqly_128kbps"),
        Reciter("Mahmud Halîl el-Husarî", "Husary_128kbps"),
        Reciter("Muhammed Sıddık el-Minşâvî", "Minshawy_Murattal_128kbps"),
        Reciter("Ali el-Huzeyfî", "Hudhaify_128kbps"),
        Reciter("Ebû Bekir eş-Şâtırî", "Abu_Bakr_Ash-Shaatree_128kbps"),
        Reciter("Ahmed el-Acemî", "Ahmed_ibn_Ali_al-Ajamy_128kbps_ketab.net"),
        Reciter("Hani er-Rifaî", "Hani_Rifai_192kbps"),
        Reciter("Muhammed Eyyûb", "Muhammad_Ayyoub_128kbps"),
        Reciter("Nâsır el-Katâmî", "Nasser_Alqatami_128kbps"),
        Reciter("Yasir ed-Devsarî", "Yasser_Ad-Dussary_128kbps")
    )

    var reciter by mutableIntStateOf(0)
    var surah by mutableIntStateOf(-1)   // 0 tabanli
    var verse by mutableIntStateOf(0)    // 1 tabanli
    var playing by mutableStateOf(false)
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)

    private var mp: MediaPlayer? = null
    private var appCtx: Context? = null
    private var gen = 0

    fun init(ctx: Context) {
        appCtx = ctx.applicationContext
        reciter = Prefs.getInt(ctx, "q_reciter", 0).coerceIn(0, RECITERS.lastIndex)
    }

    fun setReciter(ctx: Context, i: Int) {
        reciter = i.coerceIn(0, RECITERS.lastIndex)
        Prefs.putInt(ctx, "q_reciter", reciter)
        if (surah >= 0 && (playing || loading)) play(surah, verse)
    }

    private fun url(s: Int, v: Int) =
        "https://everyayah.com/data/${RECITERS[reciter].folder}/%03d%03d.mp3".format(s + 1, v)

    fun play(s: Int, v: Int) {
        val ctx = appCtx ?: return
        release()
        val my = ++gen
        surah = s
        verse = v.coerceIn(1, Quran.COUNTS[s])
        error = null
        loading = true
        playing = true
        try {
            val p = MediaPlayer()
            p.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            p.setWakeMode(ctx, PowerManager.PARTIAL_WAKE_LOCK)
            p.setDataSource(url(s, verse))
            p.setOnPreparedListener {
                if (my == gen) {
                    loading = false
                    it.start()
                }
            }
            p.setOnCompletionListener {
                if (my == gen) {
                    if (verse < Quran.COUNTS[surah]) play(surah, verse + 1)
                    else stop()
                }
            }
            p.setOnErrorListener { _, _, _ ->
                if (my == gen) {
                    loading = false
                    playing = false
                    error = "Ses yüklenemedi. İnternet bağlantını kontrol et."
                }
                true
            }
            mp = p
            p.prepareAsync()
        } catch (e: Exception) {
            loading = false
            playing = false
            error = "Ses başlatılamadı."
        }
    }

    fun toggle() {
        val p = mp
        if (p == null) {
            if (surah >= 0) play(surah, verse)
            return
        }
        try {
            if (p.isPlaying) {
                p.pause()
                playing = false
            } else if (!loading) {
                p.start()
                playing = true
            }
        } catch (_: Exception) {
        }
    }

    fun next() {
        if (surah >= 0 && verse < Quran.COUNTS[surah]) play(surah, verse + 1)
    }

    fun prev() {
        if (surah >= 0 && verse > 1) play(surah, verse - 1)
    }

    private fun release() {
        try {
            mp?.release()
        } catch (_: Exception) {
        }
        mp = null
    }

    fun stop() {
        gen++
        release()
        playing = false
        loading = false
        surah = -1
    }
}
