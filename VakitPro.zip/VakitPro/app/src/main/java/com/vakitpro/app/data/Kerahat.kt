package com.vakitpro.app.data

/** Kerahat vakitleri: namaz kılınması mekruh olan üç zaman dilimi (her biri varsayılan 45 dk). */
object Kerahat {
    const val MIN = 45

    class Window(val name: String, val startMs: Long, val endMs: Long)

    /** [times]: İmsak, Güneş, Öğle, İkindi, Akşam, Yatsı (bugün). */
    fun windows(times: LongArray): List<Window> {
        val m = MIN * 60_000L
        return listOf(
            Window("Güneş doğarken", times[1], times[1] + m),
            Window("İstiva (öğle)", times[2] - m, times[2]),
            Window("Güneş batarken", times[4] - m, times[4])
        )
    }

    fun current(times: LongArray, now: Long): Window? =
        windows(times).firstOrNull { now >= it.startMs && now < it.endMs }
}
