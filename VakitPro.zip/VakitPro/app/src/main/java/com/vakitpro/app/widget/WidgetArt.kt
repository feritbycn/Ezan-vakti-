package com.vakitpro.app.widget

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.SweepGradient
import kotlin.math.cos
import kotlin.math.sin

/** Widget arka resimleri (halka ve yarim kadran). Sayac yazisi ustte canli Chronometer ile cizilir. */
object WidgetArt {
    private val ACCENT = Color.parseColor("#5EEAD4")
    private val GOLD = Color.parseColor("#F5C26B")
    private val TRACK = Color.argb(60, 255, 255, 255)

    private fun paint(w: Float, style: Paint.Style = Paint.Style.STROKE, color: Int = Color.WHITE) =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.style = style
            strokeWidth = w
            this.color = color
            strokeCap = Paint.Cap.ROUND
        }

    /** Tam halka: [frac] 0..1 onceki vakitten sonrakine ilerleme. */
    fun ring(frac: Float): Bitmap {
        val size = 420
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val sw = 26f
        val r = size / 2f - sw
        val cx = size / 2f
        val rect = RectF(cx - r, cx - r, cx + r, cx + r)
        c.drawCircle(cx, cx, r, paint(sw, color = TRACK))
        val f = frac.coerceIn(0.005f, 1f)
        val p = paint(sw)
        val sg = SweepGradient(cx, cx, intArrayOf(ACCENT, GOLD, ACCENT), floatArrayOf(0f, 0.75f, 1f))
        val m = Matrix()
        m.postRotate(-90f, cx, cx)
        sg.setLocalMatrix(m)
        p.shader = sg
        c.drawArc(rect, -90f, 360f * f, false, p)
        // ucta isaret
        val a = Math.toRadians((-90f + 360f * f).toDouble())
        val kx = cx + r * cos(a).toFloat()
        val ky = cx + r * sin(a).toFloat()
        c.drawCircle(kx, ky, 20f, paint(1f, Paint.Style.FILL, Color.WHITE))
        c.drawCircle(kx, ky, 9f, paint(1f, Paint.Style.FILL, GOLD))
        return bmp
    }

    /**
     * Yarim kadran. [marks] 6 vaktin 0..1 konumu (Imsak=0, Yatsi=1), [pos] simdiki konum,
     * [next] siradaki vaktin indeksi.
     */
    fun gauge(marks: FloatArray, pos: Float, next: Int): Bitmap {
        val w = 760
        val h = 400
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val sw = 26f
        val r = 330f
        val cx = w / 2f
        val cy = 372f
        val rect = RectF(cx - r, cy - r, cx + r, cy + r)
        c.drawArc(rect, 180f, 180f, false, paint(sw, color = TRACK))
        val f = pos.coerceIn(0.004f, 1f)
        val p = paint(sw)
        val sg = SweepGradient(cx, cy, intArrayOf(ACCENT, GOLD, ACCENT), floatArrayOf(0f, 0.5f, 1f))
        val m = Matrix()
        m.postRotate(180f, cx, cy)
        sg.setLocalMatrix(m)
        p.shader = sg
        c.drawArc(rect, 180f, 180f * f, false, p)
        for (i in marks.indices) {
            val a = Math.toRadians((180f + 180f * marks[i].coerceIn(0f, 1f)).toDouble())
            val x = cx + r * cos(a).toFloat()
            val y = cy + r * sin(a).toFloat()
            if (i == next) {
                c.drawCircle(x, y, 22f, paint(1f, Paint.Style.FILL, GOLD))
                c.drawCircle(x, y, 9f, paint(1f, Paint.Style.FILL, Color.parseColor("#0B1220")))
            } else {
                c.drawCircle(x, y, 10f, paint(1f, Paint.Style.FILL, Color.argb(230, 255, 255, 255)))
            }
        }
        // simdiki konum
        val a = Math.toRadians((180f + 180f * f).toDouble())
        val kx = cx + r * cos(a).toFloat()
        val ky = cy + r * sin(a).toFloat()
        c.drawCircle(kx, ky, 17f, paint(1f, Paint.Style.FILL, Color.WHITE))
        return bmp
    }
}
