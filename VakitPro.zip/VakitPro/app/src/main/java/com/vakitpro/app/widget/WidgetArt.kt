package com.vakitpro.app.widget

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.SweepGradient
import kotlin.math.cos
import kotlin.math.sin

/** Widget arka resimleri (halka ve yarim kadran). Sayac yazisi ustte canli Chronometer ile cizilir. */
object WidgetArt {
    private val ACCENT = Color.parseColor("#5EEAD4")
    private val GOLD = Color.parseColor("#F5C26B")
    private val TRACK = Color.argb(60, 255, 255, 255)

    private fun paint(w: Float, style: Paint.Style = Paint.Style.STROKE, color: Int = Color.WHITE) =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.style = style
            strokeWidth = w
            this.color = color
            strokeCap = Paint.Cap.ROUND
        }

    /** Ramazan widget arka plani: mor gradyan, hilal, yildizlar, cami silueti. */
    fun ramadan(clear: Boolean = false): Bitmap {
        val w = 800; val h = 400
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val clip = android.graphics.Path().apply { addRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()), 56f, 56f, android.graphics.Path.Direction.CW) }
        c.clipPath(clip)
        // Saydam modda mor zemin cizilmez; yildiz, hilal ve cami kalir
        if (!clear) {
            val bg = Paint(Paint.ANTI_ALIAS_FLAG)
            bg.shader = android.graphics.LinearGradient(0f, 0f, w.toFloat(), h.toFloat(),
                intArrayOf(Color.parseColor("#3A2A86"), Color.parseColor("#1A1245"), Color.parseColor("#0E0A24")),
                floatArrayOf(0f, 0.55f, 1f), android.graphics.Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), bg)
        }
        // yildizlar
        val st = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(200, 255, 236, 190) }
        val pts = floatArrayOf(520f,60f,3f, 600f,120f,2f, 700f,50f,3.5f, 470f,150f,2f, 740f,170f,2.5f, 640f,200f,2f, 560f,40f,2f, 430f,70f,2.5f)
        var i = 0
        while (i < pts.size) { c.drawCircle(pts[i], pts[i+1], pts[i+2], st); i += 3 }
        // hilal
        val gold = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#F2C26B") }
        c.drawCircle(660f, 110f, 54f, gold)
        val cut = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#2A1F6B") }
        c.drawCircle(682f, 98f, 46f, cut)
        c.drawCircle(724f, 84f, 6f, gold)
        // cami silueti (alt, sag)
        val sil = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(95, 242, 194, 107) }
        val base = h.toFloat()
        c.drawRect(450f, base - 60f, 800f, base, sil)
        val dome = RectF(570f, base - 150f, 690f, base - 30f)
        c.drawArc(dome, 180f, 180f, true, sil)
        c.drawRect(570f, base - 90f, 690f, base - 60f, sil)
        c.drawRect(528f, base - 190f, 546f, base - 60f, sil)
        c.drawRect(714f, base - 190f, 732f, base - 60f, sil)
        val tip = android.graphics.Path()
        tip.moveTo(522f, base - 190f); tip.lineTo(537f, base - 225f); tip.lineTo(552f, base - 190f); tip.close()
        c.drawPath(tip, sil)
        val tip2 = android.graphics.Path()
        tip2.moveTo(708f, base - 190f); tip2.lineTo(723f, base - 225f); tip2.lineTo(738f, base - 190f); tip2.close()
        c.drawPath(tip2, sil)
        return bmp
    }

    /** Tam halka: [frac] 0..1 onceki vakitten sonrakine ilerleme. */
    fun ring(frac: Float): Bitmap {
        val size = 420
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val sw = 26f
        val r = size / 2f - sw
        val cx = size / 2f
        val rect = RectF(cx - r, cx - r, cx + r, cx + r)
        c.drawCircle(cx, cx, r, paint(sw, color = TRACK))
        val f = frac.coerceIn(0.005f, 1f)
        val p = paint(sw)
        val sg = SweepGradient(cx, cx, intArrayOf(ACCENT, GOLD, ACCENT), floatArrayOf(0f, 0.75f, 1f))
        val m = Matrix()
        m.postRotate(-90f, cx, cx)
        sg.setLocalMatrix(m)
        p.shader = sg
        c.drawArc(rect, -90f, 360f * f, false, p)
        // ucta isaret
        val a = Math.toRadians((-90f + 360f * f).toDouble())
        val kx = cx + r * cos(a).toFloat()
        val ky = cx + r * sin(a).toFloat()
        c.drawCircle(kx, ky, 20f, paint(1f, Paint.Style.FILL, Color.WHITE))
        c.drawCircle(kx, ky, 9f, paint(1f, Paint.Style.FILL, GOLD))
        return bmp
    }

    /**
     * Yarim kadran. [marks] 6 vaktin 0..1 konumu (Imsak=0, Yatsi=1), [pos] simdiki konum,
     * [next] siradaki vaktin indeksi.
     */
    fun gauge(marks: FloatArray, pos: Float, next: Int): Bitmap {
        val w = 760
        val h = 400
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val sw = 26f
        val r = 330f
        val cx = w / 2f
        val cy = 372f
        val rect = RectF(cx - r, cy - r, cx + r, cy + r)
        c.drawArc(rect, 180f, 180f, false, paint(sw, color = TRACK))
        val f = pos.coerceIn(0.004f, 1f)
        val p = paint(sw)
        val sg = SweepGradient(cx, cy, intArrayOf(ACCENT, GOLD, ACCENT), floatArrayOf(0f, 0.5f, 1f))
        val m = Matrix()
        m.postRotate(180f, cx, cy)
        sg.setLocalMatrix(m)
        p.shader = sg
        c.drawArc(rect, 180f, 180f * f, false, p)
        for (i in marks.indices) {
            val a = Math.toRadians((180f + 180f * marks[i].coerceIn(0f, 1f)).toDouble())
            val x = cx + r * cos(a).toFloat()
            val y = cy + r * sin(a).toFloat()
            if (i == next) {
                c.drawCircle(x, y, 22f, paint(1f, Paint.Style.FILL, GOLD))
                c.drawCircle(x, y, 9f, paint(1f, Paint.Style.FILL, Color.parseColor("#0B1220")))
            } else {
                c.drawCircle(x, y, 10f, paint(1f, Paint.Style.FILL, Color.argb(230, 255, 255, 255)))
            }
        }
        // simdiki konum
        val a = Math.toRadians((180f + 180f * f).toDouble())
        val kx = cx + r * cos(a).toFloat()
        val ky = cy + r * sin(a).toFloat()
        c.drawCircle(kx, ky, 17f, paint(1f, Paint.Style.FILL, Color.WHITE))
        return bmp
    }
}
