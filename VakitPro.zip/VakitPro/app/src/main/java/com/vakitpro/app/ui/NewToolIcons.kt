package com.vakitpro.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val TOOL_GRADS = listOf(
    listOf(Color(0xFFEF6C57), Color(0xFFB83A4B)), // kaza
    listOf(Color(0xFF2BB39A), Color(0xFF0F7A6B)), // namaz rehberi
    listOf(Color(0xFFFFB347), Color(0xFFE0762B)), // yarisma
    listOf(Color(0xFF6C8CFF), Color(0xFF4B4FD1)), // harfler
    listOf(Color(0xFF9B6BFF), Color(0xFF6A3FD0)), // kelime
    listOf(Color(0xFF4FB6E8), Color(0xFF2A78C2)), // notlar
    listOf(Color(0xFF5C6B7A), Color(0xFF2E3A47)), // namaz modu
    listOf(Color(0xFFFFB300), Color(0xFFE65100)), // degerlendir
    listOf(Color(0xFF3FA796), Color(0xFF1B5E7A)), // siyer ve sahabe
    listOf(Color(0xFFC9A24B), Color(0xFF7A4A12))  // hadis
)

/** Yeni araclar icin cizilmis, gradyanli kare ikonlar (emoji yok). */
@Composable
fun ToolIcon(kind: Int, size: Dp = 52.dp) {
    val k = kind.coerceIn(0, 9)
    val grad = TOOL_GRADS[k]
    Box(
        Modifier
            .size(size)
            .clip(RoundedCornerShape(size * 0.30f))
            .background(Brush.linearGradient(grad)),
        contentAlignment = Alignment.Center
    ) {
        if (k == 3) {
            Text("أ ب", color = Color.White, fontSize = (size.value * 0.34f).sp, fontWeight = FontWeight.Bold)
        } else {
            Canvas(Modifier.size(size * 0.62f)) { drawToolGlyph(k, grad[0]) }
        }
    }
}

private fun DrawScope.drawToolGlyph(k: Int, hole: Color) {
    val u = size.width / 100f
    val w = Color.White
    fun o(x: Float, y: Float) = Offset(x * u, y * u)
    fun sz(a: Float, b: Float) = Size(a * u, b * u)
    when (k) {
        0 -> { // kaza: geri donen ok + onay
            drawArc(w, 40f, 280f, false, o(14f, 14f), sz(72f, 72f), style = Stroke(width = 9f * u, cap = StrokeCap.Round))
            val a = Path().apply { moveTo(70f * u, 6f * u); lineTo(90f * u, 24f * u); lineTo(66f * u, 30f * u); close() }
            drawPath(a, w)
            val c = Path().apply { moveTo(36f * u, 52f * u); lineTo(46f * u, 62f * u); lineTo(66f * u, 40f * u) }
            drawPath(c, w, style = Stroke(width = 8f * u, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        1 -> { // namaz rehberi: ayakta duran figur
            drawCircle(w, 11f * u, o(50f, 16f))
            drawLine(w, o(50f, 30f), o(50f, 64f), strokeWidth = 10f * u, cap = StrokeCap.Round)
            drawLine(w, o(50f, 64f), o(40f, 92f), strokeWidth = 9f * u, cap = StrokeCap.Round)
            drawLine(w, o(50f, 64f), o(60f, 92f), strokeWidth = 9f * u, cap = StrokeCap.Round)
            drawLine(w, o(50f, 38f), o(66f, 52f), strokeWidth = 8f * u, cap = StrokeCap.Round)
            drawLine(w, o(66f, 52f), o(46f, 54f), strokeWidth = 8f * u, cap = StrokeCap.Round)
        }
        2 -> { // yarisma: ampul
            drawCircle(w, 30f * u, o(50f, 40f))
            drawRoundRect(w, o(36f, 68f), sz(28f, 12f), CornerRadius(5f * u))
            drawRoundRect(w, o(40f, 84f), sz(20f, 9f), CornerRadius(4f * u))
            drawLine(hole.copy(alpha = 0.6f), o(42f, 44f), o(50f, 54f), strokeWidth = 4f * u, cap = StrokeCap.Round)
            drawLine(hole.copy(alpha = 0.6f), o(50f, 54f), o(58f, 44f), strokeWidth = 4f * u, cap = StrokeCap.Round)
            drawLine(w, o(50f, 4f), o(50f, 0f), strokeWidth = 5f * u, cap = StrokeCap.Round)
            drawLine(w, o(12f, 18f), o(18f, 24f), strokeWidth = 5f * u, cap = StrokeCap.Round)
            drawLine(w, o(88f, 18f), o(82f, 24f), strokeWidth = 5f * u, cap = StrokeCap.Round)
        }
        4 -> { // kelime: 2x2 harf karosu
            for (r in 0 until 2) for (c in 0 until 2) {
                val filled = (r + c) % 2 == 0
                drawRoundRect(
                    w.copy(alpha = if (filled) 1f else 0.45f),
                    o(8f + c * 44f, 8f + r * 44f), sz(38f, 38f), CornerRadius(9f * u)
                )
            }
            drawLine(hole.copy(alpha = 0.8f), o(18f, 27f), o(36f, 27f), strokeWidth = 5f * u, cap = StrokeCap.Round)
            drawLine(hole.copy(alpha = 0.8f), o(62f, 71f), o(80f, 71f), strokeWidth = 5f * u, cap = StrokeCap.Round)
        }
        5 -> { // notlar: sayfa + kalem
            drawRoundRect(w, o(16f, 8f), sz(56f, 84f), CornerRadius(10f * u))
            for (i in 0 until 4) {
                drawLine(hole.copy(alpha = 0.6f), o(26f, 30f + i * 14f), o(60f, 30f + i * 14f), strokeWidth = 4f * u, cap = StrokeCap.Round)
            }
            drawLine(w, o(90f, 40f), o(62f, 80f), strokeWidth = 11f * u, cap = StrokeCap.Round)
            drawLine(hole, o(90f, 40f), o(62f, 80f), strokeWidth = 3f * u, cap = StrokeCap.Round)
        }
        9 -> { // hadis: acik kitap
            val l = Path().apply { moveTo(48f * u, 22f * u); lineTo(48f * u, 88f * u); lineTo(8f * u, 80f * u); lineTo(8f * u, 14f * u); close() }
            val r = Path().apply { moveTo(52f * u, 22f * u); lineTo(52f * u, 88f * u); lineTo(92f * u, 80f * u); lineTo(92f * u, 14f * u); close() }
            drawPath(l, w); drawPath(r, w.copy(alpha = 0.8f))
            for (i in 0 until 3) {
                drawLine(hole.copy(alpha = 0.55f), o(16f, 30f + i * 14f), o(40f, 34f + i * 14f), strokeWidth = 4f * u, cap = StrokeCap.Round)
                drawLine(hole.copy(alpha = 0.55f), o(60f, 34f + i * 14f), o(84f, 30f + i * 14f), strokeWidth = 4f * u, cap = StrokeCap.Round)
            }
        }
        7 -> { // degerlendir: yildiz
            val p = Path()
            for (i in 0 until 10) {
                val a = Math.toRadians(-90.0 + i * 36.0)
                val r = if (i % 2 == 0) 46f else 20f
                val x = 50f + r * Math.cos(a).toFloat(); val y = 54f + r * Math.sin(a).toFloat()
                if (i == 0) p.moveTo(x * u, y * u) else p.lineTo(x * u, y * u)
            }
            p.close()
            drawPath(p, w)
        }
        8 -> { // siyer: iki kisi
            drawCircle(w, 14f * u, o(34f, 30f))
            drawCircle(w.copy(alpha = 0.75f), 12f * u, o(70f, 36f))
            drawArc(w, 180f, 180f, true, o(10f, 52f), sz(48f, 60f))
            drawArc(w.copy(alpha = 0.75f), 180f, 180f, true, o(48f, 56f), sz(44f, 52f))
        }
        6 -> { // namaz modu: telefon + hilal
            drawRoundRect(w, o(24f, 4f), sz(52f, 92f), CornerRadius(12f * u))
            crescent(50f * u, 50f * u, 18f * u, 8f * u, -5f * u, 15f * u, hole)
            sparkle(60f * u, 38f * u, 6f * u, hole)
        }
    }
}
