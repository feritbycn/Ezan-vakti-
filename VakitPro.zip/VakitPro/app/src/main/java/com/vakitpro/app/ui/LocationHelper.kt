package com.vakitpro.app.ui

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper

object LocationHelper {
    /** Konumun ilce adini (yoksa mahalle/sehir) bulur; bulamazsa [fallback] doner. Sonuc ana is parcacigina gelir. */
    fun districtLabel(ctx: Context, lat: Double, lng: Double, fallback: String, cb: (String) -> Unit) {
        Thread {
            var out = fallback
            try {
                if (android.location.Geocoder.isPresent()) {
                    @Suppress("DEPRECATION")
                    val a = android.location.Geocoder(ctx.applicationContext, java.util.Locale("tr", "TR"))
                        .getFromLocation(lat, lng, 1)?.firstOrNull()
                    var d = a?.subAdminArea
                    if (d.isNullOrBlank() || d == "Merkez") d = a?.locality
                    if (d.isNullOrBlank()) d = a?.subLocality
                    if (!d.isNullOrBlank()) out = d
                }
            } catch (e: Exception) {
            }
            android.os.Handler(Looper.getMainLooper()).post { cb(out) }
        }.start()
    }

    /** Cihazin son/anlik konumunu ister. Sonuc [cb] ile doner (null = alinamadi). */
    @SuppressLint("MissingPermission")
    fun request(ctx: Context, cb: (Location?) -> Unit) {
        try {
            val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val providers = lm.getProviders(true)
            var best: Location? = null
            for (p in providers) {
                val l = lm.getLastKnownLocation(p) ?: continue
                val bt = best?.time ?: 0L
                if (l.time >= bt) best = l
            }
            val fallback: Location? = best
            // Son konum yeterince tazeyse (15 dk) dogrudan kullan
            if (fallback != null && System.currentTimeMillis() - fallback.time < 15 * 60 * 1000L) {
                cb(fallback)
                return
            }
            val provider: String? = when {
                providers.contains(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
                providers.contains(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
                else -> null
            }
            if (provider == null) {
                cb(fallback)
                return
            }
            val listener = object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    cb(location)
                }

                @Deprecated("Deprecated in Java")
                override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {
                }

                override fun onProviderEnabled(provider: String) {
                }

                override fun onProviderDisabled(provider: String) {
                }
            }
            @Suppress("DEPRECATION")
            lm.requestSingleUpdate(provider, listener, Looper.getMainLooper())
        } catch (e: SecurityException) {
            cb(null)
        } catch (e: Exception) {
            cb(null)
        }
    }
}
