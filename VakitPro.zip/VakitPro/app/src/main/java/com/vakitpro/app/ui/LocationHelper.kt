package com.vakitpro.app.ui

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationManager
import androidx.core.content.ContextCompat
import androidx.core.location.LocationManagerCompat

object LocationHelper {
    /** Cihazin son/anlik konumunu ister. Sonuc ana is parcaciginda [cb] ile doner (null = alinamadi). */
    @SuppressLint("MissingPermission")
    fun request(ctx: Context, cb: (Location?) -> Unit) {
        try {
            val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val providers = lm.getProviders(true)
            var best: Location? = null
            for (p in providers) {
                val l = lm.getLastKnownLocation(p) ?: continue
                val bt = best?.time ?: 0L
                if (l.time >= bt) best = l
            }
            val fallback: Location? = best
            val provider = when {
                providers.contains(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
                providers.contains(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
                else -> null
            }
            if (provider == null) {
                cb(fallback)
                return
            }
            LocationManagerCompat.getCurrentLocation(
                lm, provider, null, ContextCompat.getMainExecutor(ctx)
            ) { loc -> cb(loc ?: fallback) }
        } catch (e: SecurityException) {
            cb(null)
        } catch (e: Exception) {
            cb(null)
        }
    }
}
