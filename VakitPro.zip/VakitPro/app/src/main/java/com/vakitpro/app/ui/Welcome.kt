package com.vakitpro.app.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private val DEEP = Color(0xFF062B26)
private val MID = Color(0xFF0E5A4B)
private val GOLD = Color(0xFFFFC94D)

private fun DrawScope.nightBackdrop(t: Float) {
    drawRect(Brush.verticalGradient(listOf(DEEP, MID, Color(0xFF127A63))))
    // Yildizlar (sabit desen, hafif parlama)
    val seeds = listOf(
        0.12f to 0.10f, 0.80f to 0.07f, 0.35f to 0.18f, 0.92f to 0.24f, 0.18f to 0.32f,
        0.66f to 0.14f, 0.50f to 0.05f, 0.06f to 0.22f, 0.74f to 0.30f, 0.28f to 0.08f
    )
    seeds.forEachIndexed { i, (x, y) ->
        val a = 0.25f + 0.55f * (0.5f + 0.5f * kotlin.math.sin(t * 6.2832f + i))
        drawCircle(Color.White.copy(alpha = a), radius = 2.2f + (i % 3), center = Offset(size.width * x, size.height * y))
    }
    // Alttan cami silueti
    val w = size.width
    val h = size.height
    val base = h * 0.90f
    val sil = Color(0x33000000)
    drawRect(sil, Offset(0f, base), androidx.compose.ui.geometry.Size(w, h - base))
    drawCircle(sil, radius = w * 0.17f, center = Offset(w * 0.5f, base))
    drawRect(sil, Offset(w * 0.12f, base - h * 0.12f), androidx.compose.ui.geometry.Size(w * 0.03f, h * 0.12f))
    drawRect(sil, Offset(w * 0.85f, base - h * 0.15f), androidx.compose.ui.geometry.Size(w * 0.03f, h * 0.15f))
}

private fun DrawScope.logoMark(cx: Float, cy: Float, r: Float) {
    drawCircle(Color.White.copy(alpha = 0.08f), radius = r * 1.5f, center = Offset(cx, cy))
    crescent(cx, cy, r, r * 0.38f, -r * 0.12f, r * 0.82f, GOLD)
    sparkle(cx + r * 0.62f, cy - r * 0.32f, r * 0.30f, GOLD)
}

/** Acilis / yukleniyor ekrani: ortada ayyildiz ve donen hilal halka. */
@Composable
fun SplashScreen(onDone: () -> Unit) {
    LaunchedEffect(Unit) {
        delay(1500)
        onDone()
    }
    val inf = rememberInfiniteTransition(label = "splash")
    val spin by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(1400, easing = LinearEasing)), label = "spin")
    val tw by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(3000, easing = LinearEasing), RepeatMode.Restart), label = "tw")
    val pulse by inf.animateFloat(0.94f, 1.04f, infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "p")
    Box(Modifier.fillMaxSize()) {
        Canvas(Modifier.fillMaxSize()) {
            nightBackdrop(tw)
            val cx = size.width / 2
            val cy = size.height * 0.42f
            val r = size.width * 0.17f * pulse
            logoMark(cx, cy, r)
            // donen halka
            rotate(spin, Offset(cx, cy)) {
                drawArc(
                    GOLD, 0f, 110f, false,
                    topLeft = Offset(cx - r * 1.55f, cy - r * 1.55f),
                    size = androidx.compose.ui.geometry.Size(r * 3.1f, r * 3.1f),
                    style = Stroke(width = 6f, cap = StrokeCap.Round)
                )
            }
        }
        Column(
            Modifier
                .align(Alignment.Center)
                .padding(top = 250.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Vakit Pro", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.size(6.dp))
            Text("Namaz vakitleri • Kıble • Zikir", color = Color(0xCCFFFFFF), fontSize = 13.sp)
        }
    }
}

/** Ilk karsilama sayfasi. */
@Composable
fun WelcomeStep(onNext: () -> Unit) {
    val inf = rememberInfiniteTransition(label = "wel")
    val tw by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(3500, easing = LinearEasing)), label = "tw")
    Box(Modifier.fillMaxSize()) {
        Canvas(Modifier.fillMaxSize()) {
            nightBackdrop(tw)
            logoMark(size.width / 2, size.height * 0.26f, size.width * 0.16f)
        }
        Column(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Bottom
        ) {
            Text("Es-selâmü aleyküm", color = GOLD, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.size(6.dp))
            Text("Hoş geldin", color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.size(12.dp))
            Text(
                "Bulunduğun yere göre ezan vakitleri, vakitten önce hatırlatma, kıble, zikir, kaza takibi ve daha fazlası tek yerde.",
                color = Color(0xDDFFFFFF), fontSize = 15.sp, textAlign = TextAlign.Center, lineHeight = 22.sp
            )
            Spacer(Modifier.size(18.dp))
            Text("Bismillâhirrahmânirrahîm", color = GOLD, fontSize = 14.sp)
            Spacer(Modifier.size(22.dp))
            Button(
                onClick = onNext,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = GOLD, contentColor = DEEP)
            ) { Text("Devam et", fontWeight = FontWeight.Bold, fontSize = 17.sp) }
            Spacer(Modifier.size(40.dp))
        }
    }
}
