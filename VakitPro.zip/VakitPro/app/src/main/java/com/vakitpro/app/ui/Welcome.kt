package com.vakitpro.app.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private val DEEP = Color(0xFF062B26)
private val MID = Color(0xFF0E5A4B)
private val GOLD = Color(0xFFFFC94D)

private fun DrawScope.nightBackdrop(t: Float) {
    drawRect(Brush.verticalGradient(listOf(DEEP, MID, Color(0xFF127A63))))
    // Yildizlar (sabit desen, hafif parlama)
    val seeds = listOf(
        0.12f to 0.10f, 0.80f to 0.07f, 0.35f to 0.18f, 0.92f to 0.24f, 0.18f to 0.32f,
        0.66f to 0.14f, 0.50f to 0.05f, 0.06f to 0.22f, 0.74f to 0.30f, 0.28f to 0.08f
    )
    seeds.forEachIndexed { i, (x, y) ->
        val a = 0.25f + 0.55f * (0.5f + 0.5f * kotlin.math.sin(t * 6.2832f + i))
        drawCircle(Color.White.copy(alpha = a), radius = 2.2f + (i % 3), center = Offset(size.width * x, size.height * y))
    }
    // Alttan cami silueti
    val w = size.width
    val h = size.height
    val base = h * 0.90f
    val sil = Color(0x33000000)
    drawRect(sil, Offset(0f, base), androidx.compose.ui.geometry.Size(w, h - base))
    drawCircle(sil, radius = w * 0.17f, center = Offset(w * 0.5f, base))
    drawRect(sil, Offset(w * 0.12f, base - h * 0.12f), androidx.compose.ui.geometry.Size(w * 0.03f, h * 0.12f))
    drawRect(sil, Offset(w * 0.85f, base - h * 0.15f), androidx.compose.ui.geometry.Size(w * 0.03f, h * 0.15f))
}

private fun DrawScope.logoMark(cx: Float, cy: Float, r: Float) {
    drawCircle(Color.White.copy(alpha = 0.08f), radius = r * 1.5f, center = Offset(cx, cy))
    crescent(cx, cy, r, r * 0.38f, -r * 0.12f, r * 0.82f, GOLD)
    sparkle(cx + r * 0.62f, cy - r * 0.32f, r * 0.30f, GOLD)
}

/** Videoyu TextureView uzerinde ekrani dolduracak (center-crop) sekilde oynatir. */
private class IntroVideoView(
    ctx: android.content.Context,
    private val onEnd: () -> Unit,
    private val onFail: () -> Unit
) : android.view.TextureView(ctx), android.view.TextureView.SurfaceTextureListener {
    private var mp: android.media.MediaPlayer? = null
    private var vw = 0
    private var vh = 0

    init { surfaceTextureListener = this }

    override fun onSurfaceTextureAvailable(st: android.graphics.SurfaceTexture, w: Int, h: Int) {
        try {
            val p = android.media.MediaPlayer()
            mp = p
            val afd = resources.openRawResourceFd(com.vakitpro.app.R.raw.intro)
            p.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
            afd.close()
            p.setSurface(android.view.Surface(st))
            p.setVolume(0f, 0f)
            p.isLooping = false
            p.setOnVideoSizeChangedListener { _, vW, vH -> vw = vW; vh = vH; fit() }
            p.setOnCompletionListener { onEnd() }
            p.setOnErrorListener { _, _, _ -> onFail(); true }
            p.setOnPreparedListener { it.start() }
            p.prepareAsync()
        } catch (_: Throwable) { onFail() }
    }

    private fun fit() {
        if (vw <= 0 || vh <= 0 || width <= 0 || height <= 0) return
        val sx = width.toFloat() / vw
        val sy = height.toFloat() / vh
        val sc = maxOf(sx, sy)
        val m = android.graphics.Matrix()
        m.setScale(vw * sc / width, vh * sc / height, width / 2f, height / 2f)
        setTransform(m)
    }

    override fun onSurfaceTextureSizeChanged(st: android.graphics.SurfaceTexture, w: Int, h: Int) { fit() }
    override fun onSurfaceTextureDestroyed(st: android.graphics.SurfaceTexture): Boolean { release(); return true }
    override fun onSurfaceTextureUpdated(st: android.graphics.SurfaceTexture) {}

    fun release() {
        try { mp?.release() } catch (_: Throwable) {}
        mp = null
    }
}

/** Acilis ekrani: uygulama acilisinda intro videosu (dokununca gecilir). */
@Composable
fun SplashScreen(onDone: () -> Unit) {
    var finished by remember { mutableStateOf(false) }
    var failed by remember { mutableStateOf(false) }
    val finish: () -> Unit = { if (!finished) { finished = true; onDone() } }
    // Guvenlik: video hic bitmezse en gec 9.5 sn'de gec; hata olursa 1.8 sn'lik resim goster
    LaunchedEffect(failed) {
        if (failed) delay(1800) else delay(9500)
        finish()
    }
    val alpha = remember { androidx.compose.animation.core.Animatable(0f) }
    LaunchedEffect(Unit) { alpha.animateTo(1f, tween(300)) }
    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xFF000C2A))
            .clickable(
                interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                indication = null
            ) { finish() }
    ) {
        if (failed) {
            androidx.compose.foundation.Image(
                painter = androidx.compose.ui.res.painterResource(com.vakitpro.app.R.drawable.splash_art),
                contentDescription = null,
                contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            var view by remember { mutableStateOf<IntroVideoView?>(null) }
            androidx.compose.runtime.DisposableEffect(Unit) { onDispose { view?.release() } }
            androidx.compose.ui.viewinterop.AndroidView(
                factory = { c ->
                    IntroVideoView(c, onEnd = { finish() }, onFail = { failed = true }).also { view = it }
                },
                modifier = Modifier.fillMaxSize().graphicsLayer { this.alpha = alpha.value }
            )
            Text(
                "Geç ›",
                color = Color(0x99FFFFFF),
                fontSize = 13.sp,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .navigationBarsPadding()
                    .padding(20.dp)
            )
        }
    }
}

/** Ilk karsilama sayfasi. */
@Composable
fun WelcomeStep(onNext: () -> Unit) {
    val inf = rememberInfiniteTransition(label = "wel")
    val tw by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(3500, easing = LinearEasing)), label = "tw")
    Box(Modifier.fillMaxSize()) {
        Canvas(Modifier.fillMaxSize()) {
            nightBackdrop(tw)
            logoMark(size.width / 2, size.height * 0.26f, size.width * 0.16f)
        }
        Column(
            Modifier
                .fillMaxSize()
                .navigationBarsPadding()
                .padding(horizontal = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Bottom
        ) {
            Text(Lang.tr("Es-selâmü aleyküm"), color = GOLD, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.size(6.dp))
            Text(Lang.tr("Hoş geldin"), color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.size(12.dp))
            Text(
                Lang.tr("Bulunduğun yere göre ezan vakitleri, vakitten önce hatırlatma, kıble, zikir, kaza takibi ve daha fazlası tek yerde."),
                color = Color(0xDDFFFFFF), fontSize = 15.sp, textAlign = TextAlign.Center, lineHeight = 22.sp
            )
            Spacer(Modifier.size(18.dp))
            Text("Bismillâhirrahmânirrahîm", color = GOLD, fontSize = 14.sp)
            Spacer(Modifier.size(22.dp))
            Button(
                onClick = onNext,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = GOLD, contentColor = DEEP)
            ) { Text(Lang.tr("Devam et"), fontWeight = FontWeight.Bold, fontSize = 17.sp) }
            Spacer(Modifier.size(28.dp))
        }
    }
}
