package com.vakitpro.app.data

import android.content.Context
import java.text.Normalizer

/** Kur'an metni: Arapca (Tanzil, Osmani) + Turkce meal (Kuran Ansiklopedisi / Rowwad). Assets'ten okunur, internet gerekmez. */
object Quran {
    val NAMES = arrayOf(
        "Fâtiha", "Bakara", "Âl-i İmrân", "Nisâ", "Mâide", "En'âm", "A'râf", "Enfâl", "Tevbe", "Yûnus",
        "Hûd", "Yûsuf", "Ra'd", "İbrâhîm", "Hicr", "Nahl", "İsrâ", "Kehf", "Meryem", "Tâhâ",
        "Enbiyâ", "Hac", "Mü'minûn", "Nûr", "Furkân", "Şuarâ", "Neml", "Kasas", "Ankebût", "Rûm",
        "Lokmân", "Secde", "Ahzâb", "Sebe'", "Fâtır", "Yâsîn", "Sâffât", "Sâd", "Zümer", "Mü'min",
        "Fussilet", "Şûrâ", "Zuhruf", "Duhân", "Câsiye", "Ahkâf", "Muhammed", "Fetih", "Hucurât", "Kâf",
        "Zâriyât", "Tûr", "Necm", "Kamer", "Rahmân", "Vâkıa", "Hadîd", "Mücâdele", "Haşr", "Mümtehine",
        "Saff", "Cuma", "Münâfikûn", "Teğâbün", "Talâk", "Tahrîm", "Mülk", "Kalem", "Hâkka", "Meâric",
        "Nûh", "Cin", "Müzzemmil", "Müddessir", "Kıyâme", "İnsân", "Mürselât", "Nebe'", "Nâzi'ât", "Abese",
        "Tekvîr", "İnfitâr", "Mutaffifîn", "İnşikâk", "Bürûc", "Târık", "A'lâ", "Gâşiye", "Fecr", "Beled",
        "Şems", "Leyl", "Duhâ", "İnşirâh", "Tîn", "Alak", "Kadir", "Beyyine", "Zilzâl", "Âdiyât",
        "Kâria", "Tekâsür", "Asr", "Hümeze", "Fîl", "Kureyş", "Mâûn", "Kevser", "Kâfirûn", "Nasr",
        "Tebbet", "İhlâs", "Felak", "Nâs"
    )

    val COUNTS = intArrayOf(
        7, 286, 200, 176, 120, 165, 206, 75, 129, 109, 123, 111, 43, 52, 99, 128, 111, 110, 98, 135,
        112, 78, 118, 64, 77, 227, 93, 88, 69, 60, 34, 30, 73, 54, 45, 83, 182, 88, 75, 85,
        54, 53, 89, 59, 37, 35, 38, 29, 18, 45, 60, 49, 62, 55, 78, 96, 29, 22, 24, 13,
        14, 11, 11, 18, 12, 12, 30, 52, 52, 44, 28, 28, 20, 56, 40, 31, 50, 40, 46, 42,
        29, 19, 36, 25, 22, 17, 19, 26, 30, 20, 15, 21, 11, 8, 8, 19, 5, 8, 8, 11,
        11, 8, 3, 9, 5, 4, 7, 3, 6, 3, 5, 4, 5, 6
    )

    const val BASMALA = "بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ"

    class Data(val ar: Array<Array<String>>, val tr: Array<Array<String>>)

    @Volatile
    private var cache: Data? = null

    private fun read(ctx: Context, file: String): Array<Array<String>> {
        val out = Array(114) { Array(COUNTS[it]) { "" } }
        ctx.applicationContext.assets.open(file).bufferedReader(Charsets.UTF_8).useLines { lines ->
            for (line in lines) {
                if (line.isEmpty()) continue
                val a = line.indexOf('|')
                val b = line.indexOf('|', a + 1)
                if (a < 0 || b < 0) continue
                val s = line.substring(0, a).toIntOrNull() ?: continue
                val v = line.substring(a + 1, b).toIntOrNull() ?: continue
                if (s in 1..114 && v in 1..COUNTS[s - 1]) out[s - 1][v - 1] = line.substring(b + 1)
            }
        }
        return out
    }

    /** Agir is: arka planda cagir. */
    fun load(ctx: Context): Data {
        cache?.let { return it }
        val d = Data(read(ctx, "quran_ar.txt"), read(ctx, "quran_tr.txt"))
        cache = d
        return d
    }

    /** 1,2,3 -> ١,٢,٣ */
    fun arabicNum(n: Int): String {
        val sb = StringBuilder()
        for (ch in n.toString()) sb.append('٠' + (ch - '0'))
        return sb.toString()
    }

    /** Arama icin: kucuk harf + aksan/sapka kaldir. */
    fun fold(s: String): String {
        val n = Normalizer.normalize(s.lowercase(java.util.Locale("tr")), Normalizer.Form.NFD)
        return n.replace(Regex("\\p{Mn}+"), "").replace('ı', 'i').replace("'", "").replace("’", "")
    }
}
