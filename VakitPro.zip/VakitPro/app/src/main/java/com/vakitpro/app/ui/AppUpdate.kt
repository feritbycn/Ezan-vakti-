package com.vakitpro.app.ui

import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.google.android.play.core.appupdate.AppUpdateInfo
import com.google.android.play.core.appupdate.AppUpdateManager
import com.google.android.play.core.appupdate.AppUpdateManagerFactory
import com.google.android.play.core.appupdate.AppUpdateOptions
import com.google.android.play.core.install.InstallStateUpdatedListener
import com.google.android.play.core.install.model.AppUpdateType
import com.google.android.play.core.install.model.InstallStatus
import com.google.android.play.core.install.model.UpdateAvailability

/**
 * Play uzerinden yeni surum var mi kontrol eder ve esnek (arka planda indirilen) guncellemeyi yonetir.
 * Sadece Play'den kurulmus surumlerde calisir (dahili/kapali test ya da uretim). Debug ve dogrudan APK'da kart gorunmez.
 */
object AppUpdate {
    var available by mutableStateOf<AppUpdateInfo?>(null)
    var downloaded by mutableStateOf(false)
    private var manager: AppUpdateManager? = null

    private val listener = InstallStateUpdatedListener { state ->
        if (state.installStatus() == InstallStatus.DOWNLOADED) downloaded = true
    }

    fun check(ctx: Context) {
        val m = manager ?: AppUpdateManagerFactory.create(ctx.applicationContext).also {
            manager = it
            it.registerListener(listener)
        }
        m.appUpdateInfo.addOnSuccessListener { info ->
            when {
                info.installStatus() == InstallStatus.DOWNLOADED -> {
                    downloaded = true
                    available = null
                }
                info.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE &&
                    info.isUpdateTypeAllowed(AppUpdateType.FLEXIBLE) -> {
                    available = info
                }
                else -> available = null
            }
        }
    }

    fun start(launcher: ActivityResultLauncher<IntentSenderRequest>) {
        val info = available ?: return
        manager?.startUpdateFlowForResult(
            info,
            launcher,
            AppUpdateOptions.newBuilder(AppUpdateType.FLEXIBLE).build()
        )
    }

    fun complete() {
        manager?.completeUpdate()
    }
}

/** Ana ekranin ustunde cikan guncelleme karti. Guncelleme yoksa hicbir sey gostermez. */
@Composable
fun UpdateBanner() {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val lifecycleOwner = LocalLifecycleOwner.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { }

    LaunchedEffect(Unit) { AppUpdate.check(ctx) }
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) AppUpdate.check(ctx)
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val isDownloaded = AppUpdate.downloaded
    val hasUpdate = AppUpdate.available != null
    if (!isDownloaded && !hasUpdate) return

    Surface(
        shape = RoundedCornerShape(20.dp),
        color = cs.primaryContainer,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                if (isDownloaded) "Güncelleme hazır" else "Yeni sürüm var",
                fontWeight = FontWeight.Bold,
                color = cs.onPrimaryContainer
            )
            Text(
                if (isDownloaded) "Güncellemeyi uygulamak için uygulamayı yeniden başlat."
                else "Ezan Vakti Plus'ın yeni sürümü hazır. Arka planda indirip kurabilirsin.",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onPrimaryContainer
            )
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (isDownloaded) {
                    Button(onClick = { AppUpdate.complete() }) { Text("Yeniden başlat") }
                } else {
                    Button(onClick = { AppUpdate.start(launcher) }) { Text("Güncelle") }
                }
                TextButton(onClick = {
                    if (isDownloaded) AppUpdate.downloaded = false else AppUpdate.available = null
                }) { Text("Sonra") }
            }
        }
    }
}
