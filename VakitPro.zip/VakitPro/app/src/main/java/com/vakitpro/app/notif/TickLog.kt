package com.vakitpro.app.notif

import android.content.Context
import com.vakitpro.app.data.Prefs
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Dakika ikonu hatasini bulmak icin kucuk olay gunlugu (son 80 kayit, kalici). */
object TickLog {
    private const val KEY = "tick_log"
    private const val MAX = 200

    /** Siradaki bildirim yenilemesini kimin tetikledigi (gunluge yazilir). */
    @Volatile
    var source: String = "?"

    @Synchronized
    fun add(ctx: Context, msg: String) {
        val t = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date())
        val old = Prefs.getStr(ctx, KEY, "")
        val lines = if (old.isEmpty()) ArrayList() else ArrayList(old.split("\n"))
        lines.add("$t  $msg")
        while (lines.size > MAX) lines.removeAt(0)
        Prefs.putStr(ctx, KEY, lines.joinToString("\n"))
    }

    @Synchronized
    fun read(ctx: Context): List<String> {
        val s = Prefs.getStr(ctx, KEY, "")
        return if (s.isEmpty()) emptyList() else s.split("\n")
    }

    @Synchronized
    fun clear(ctx: Context) {
        Prefs.putStr(ctx, KEY, "")
    }
}
