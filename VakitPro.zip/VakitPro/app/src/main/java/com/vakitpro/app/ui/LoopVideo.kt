package com.vakitpro.app.ui

import android.content.Context
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.view.Surface
import android.view.TextureView
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView

/** Raw kaynaktan sessiz, sonsuz dongude video (kapla / ortala). */
@Composable
fun LoopVideo(resId: Int, modifier: Modifier = Modifier) {
    AndroidView(
        modifier = modifier,
        factory = { c -> makeLoopTexture(c, resId) }
    )
}

private fun makeLoopTexture(c: Context, resId: Int): TextureView {
    lateinit var tv: TextureView
    tv = TextureView(c).apply {
        isOpaque = false
        surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            private var mp: MediaPlayer? = null

            override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
                try {
                    val afd = c.resources.openRawResourceFd(resId) ?: return
                    val p = MediaPlayer()
                    p.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                    afd.close()
                    p.setSurface(Surface(st))
                    p.isLooping = true
                    p.setVolume(0f, 0f)
                    p.setOnVideoSizeChangedListener { _, vw, vh -> cover(tv, vw, vh) }
                    p.setOnPreparedListener { it.start() }
                    p.prepareAsync()
                    mp = p
                } catch (e: Exception) {
                }
            }

            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}

            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
                try { mp?.stop() } catch (e: Exception) {}
                mp?.release()
                mp = null
                return true
            }

            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }
    }
    return tv
}

/** Video kutuyu tasmadan dolduracak sekilde olcekle. */
private fun cover(tv: TextureView, vw: Int, vh: Int) {
    val w = tv.width.toFloat()
    val h = tv.height.toFloat()
    if (w <= 0f || h <= 0f || vw <= 0 || vh <= 0) return
    val sc = maxOf(w / vw, h / vh)
    val m = Matrix()
    m.setScale((vw * sc) / w, (vh * sc) / h, w / 2f, h / 2f)
    tv.setTransform(m)
}
