package com.vakitpro.app.data

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

data class NextInfo(
    val index: Int,        // siradaki vaktin indeksi (0..5)
    val timeMs: Long,      // siradaki vaktin zamani
    val prevIndex: Int,    // icinde bulunulan vaktin indeksi
    val prevMs: Long       // icinde bulunulan vaktin baslangici
)

object PrayerRepo {
    private var cacheKey: String? = null
    private val cache = HashMap<LocalDate, LongArray>()

    fun times(s: Settings, date: LocalDate, zone: ZoneId = ZoneId.systemDefault()): LongArray {
        val key = "${s.lat}|${s.lng}|${s.method}|${s.hanafi}|${s.adj}|${zone.id}"
        synchronized(this) {
            if (key != cacheKey) {
                cache.clear()
                cacheKey = key
            }
            return cache.getOrPut(date) {
                PrayerCalc.compute(date, s.lat, s.lng, zone, CalcMethod.of(s.method), s.hanafi, s.adj)
            }
        }
    }

    fun today(nowMs: Long, zone: ZoneId = ZoneId.systemDefault()): LocalDate =
        Instant.ofEpochMilli(nowMs).atZone(zone).toLocalDate()

    fun next(s: Settings, nowMs: Long): NextInfo {
        val zone = ZoneId.systemDefault()
        val today = today(nowMs, zone)
        val all = ArrayList<Long>(24)
        for (off in -1..2) {
            all.addAll(times(s, today.plusDays(off.toLong()), zone).toList())
        }
        var i = 0
        while (i < all.size && all[i] <= nowMs) i++
        if (i >= all.size) i = all.size - 1
        if (i == 0) i = 1
        return NextInfo(
            index = i % 6,
            timeMs = all[i],
            prevIndex = (i - 1) % 6,
            prevMs = all[i - 1]
        )
    }

    /** [fromMs]'den sonraki ilk [count] vakit (zaman, indeks). */
    fun upcoming(s: Settings, fromMs: Long, count: Int): List<Pair<Long, Int>> {
        val zone = ZoneId.systemDefault()
        val today = today(fromMs, zone)
        val out = ArrayList<Pair<Long, Int>>()
        var off = -1L
        while (out.size < count && off < 10) {
            val t = times(s, today.plusDays(off), zone)
            for (i in 0 until 6) {
                if (t[i] > fromMs && out.size < count) out.add(Pair(t[i], i))
            }
            off++
        }
        return out
    }
}

object Fmt {
    private val TR: Locale = Locale.forLanguageTag("tr-TR")
    private val hmFmt = DateTimeFormatter.ofPattern("HH:mm")

    fun hm(ms: Long, zone: ZoneId = ZoneId.systemDefault()): String =
        hmFmt.format(Instant.ofEpochMilli(ms).atZone(zone))

    fun dayLong(date: LocalDate): String =
        date.format(DateTimeFormatter.ofPattern("d MMMM yyyy, EEEE", TR))

    fun dayShort(date: LocalDate): String =
        date.format(DateTimeFormatter.ofPattern("d MMM", TR))

    fun dayWeek(date: LocalDate): String =
        date.format(DateTimeFormatter.ofPattern("EEE", TR))

    fun monthYear(date: LocalDate): String =
        date.format(DateTimeFormatter.ofPattern("LLLL yyyy", TR))

    fun hms(remainMs: Long): String {
        val total = if (remainMs < 0) 0 else remainMs / 1000
        val h = total / 3600
        val m = (total % 3600) / 60
        val sec = total % 60
        return String.format(Locale.US, "%02d:%02d:%02d", h, m, sec)
    }

    /** "2 sa 15 dk" / "12 dk" / "45 sn" */
    fun human(remainMs: Long): String {
        val total = if (remainMs < 0) 0 else remainMs / 1000
        val h = total / 3600
        val m = (total % 3600) / 60
        return when {
            h > 0 -> "$h sa $m dk"
            m > 0 -> "$m dk"
            else -> "${total} sn"
        }
    }
}
