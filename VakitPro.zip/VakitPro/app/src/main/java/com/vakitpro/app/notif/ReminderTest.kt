package com.vakitpro.app.notif

import android.app.Notification
import android.app.NotificationManager
import android.content.Context
import com.vakitpro.app.data.Prefs
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * GECICI TEST: "45 dk kala" hatirlatmasinin acilista / bildirimler temizlenince tekrar cikmasini bulmak icin.
 * Hata duzelince bu dosya ve Ayarlar'daki test karti kaldirilacak.
 */
object ReminderTest {
    private fun nm(ctx: Context) = ctx.getSystemService(NotificationManager::class.java)

    /** Su an cubukta duran tum bildirimler (id ve baslik). */
    fun activeList(ctx: Context): String {
        val list = nm(ctx).activeNotifications
        if (list.isEmpty()) return "Aktif bildirim yok"
        return list.joinToString("\n") { sbn ->
            val title = sbn.notification.extras?.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: "-"
            val surekli = if (sbn.notification.flags and Notification.FLAG_ONGOING_EVENT != 0) " [sürekli]" else ""
            "id=${sbn.id}$surekli $title"
        }
    }

    /** Siradaki planli alarm (hatirlatma ya da vakit). */
    fun nextPlan(ctx: Context): String {
        val at = Prefs.getLong(ctx, "dbg_next_at", 0L)
        val kind = Prefs.getInt(ctx, "dbg_next_kind", -1)
        if (at == 0L) return "Planlı alarm yok"
        val t = SimpleDateFormat("dd.MM HH:mm:ss", Locale.US).format(Date(at))
        return "Sıradaki alarm: $t (tür=$kind)"
    }

    /** Uygulama acilisini taklit eder: once ve sonra aktif bildirimleri kaydeder, tanilama gunlugune yazar. */
    fun simulateOpen(ctx: Context): String {
        val before = activeList(ctx)
        DebugLog.add(ctx, "TEST açılış öncesi aktif: ${before.replace("\n", " | ")}")
        Refresher.refreshAll(ctx, false)
        val after = activeList(ctx)
        DebugLog.add(ctx, "TEST açılış sonrası aktif: ${after.replace("\n", " | ")}")
        return "Önce:\n$before\n\nSonra:\n$after\n\n${nextPlan(ctx)}"
    }

    /** 45 dk kala hatirlatmayi test modunda gosterir (Ogle icin). */
    fun fakeReminder(ctx: Context): String {
        val s = Prefs.load(ctx)
        Notifier.showReminder(ctx, s, 2, true)
        DebugLog.add(ctx, "TEST 45 dk hatırlatma gönderildi (Öğle)")
        return "Test hatırlatması gönderildi. Bildirim çubuğunu kontrol et."
    }
}
