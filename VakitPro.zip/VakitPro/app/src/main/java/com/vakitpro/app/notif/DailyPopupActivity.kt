package com.vakitpro.app.notif

import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vakitpro.app.data.Hadis
import com.vakitpro.app.data.Prefs
import com.vakitpro.app.ui.VakitTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Gunluk ayet / hadis / dua: vakit penceresi gibi ekranda acilan kart. */
class DailyPopupActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        }
        val s = Prefs.load(this)
        setContent {
            VakitTheme(s) {
                var dc by remember { mutableStateOf<DailyContent?>(null) }
                var fav by remember { mutableStateOf(false) }
                LaunchedEffect(Unit) {
                    withContext(Dispatchers.IO) {
                        val d = DailyContent.build(applicationContext)
                        val h = d.hadis
                        if (h != null) fav = Hadis.favIds(applicationContext).contains(h.id)
                        dc = d
                    }
                }
                val cs = MaterialTheme.colorScheme
                CompositionLocalProvider(LocalContentColor provides cs.onSurface) {
                    Box(
                        Modifier.fillMaxSize().background(Color(0x99000000))
                            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { finishAndRemoveTask() },
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            Modifier.padding(16.dp).fillMaxWidth()
                                .clip(RoundedCornerShape(28.dp)).background(cs.surface)
                                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
                        ) {
                            Text(
                                "Günün ayeti, hadisi ve duası",
                                Modifier.padding(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 6.dp),
                                color = cs.primary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium
                            )
                            Column(
                                Modifier.weight(1f, fill = false).heightIn(max = 560.dp)
                                    .verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                val d = dc
                                if (d == null) Text("…")
                                else d.sections.forEach { sec ->
                                    val what = when (sec.title) { "Günün ayeti" -> "ayah"; "Günün hadisi" -> "hadis"; else -> "dua" }
                                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text(sec.title, color = cs.primary, fontWeight = FontWeight.SemiBold)
                                        if (!sec.arabic.isNullOrBlank()) {
                                            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                                                Text(sec.arabic, Modifier.fillMaxWidth(), fontSize = 20.sp, lineHeight = 34.sp)
                                            }
                                        }
                                        Text(sec.text, style = MaterialTheme.typography.bodyMedium)
                                        if (sec.source.isNotBlank()) Text("— " + sec.source, color = cs.onSurfaceVariant, fontSize = 12.sp)
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            OutlinedButton(onClick = { DailyShareHelper.go(this@DailyPopupActivity, what) }) { Text("Paylaş") }
                                            if (what == "hadis" && d.hadis != null) {
                                                OutlinedButton(onClick = {
                                                    val nv = !fav
                                                    fav = nv
                                                    Thread { Hadis.setFlag(applicationContext, d.hadis, "fav", nv) }.start()
                                                }) { Text(if (fav) "Favoride ✓" else "Favoriye ekle") }
                                            }
                                        }
                                    }
                                }
                            }
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
                                horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically
                            ) {
                                TextButton(onClick = { finishAndRemoveTask() }) { Text("Kapat") }
                                Spacer(Modifier.size(8.dp))
                                Button(onClick = { DailyShareHelper.go(this@DailyPopupActivity, "all") }) { Text("Hepsini paylaş") }
                            }
                        }
                    }
                }
            }
        }
    }
}

object DailyShareHelper {
    fun go(ctx: android.content.Context, what: String) {
        val app = ctx.applicationContext
        Thread { try { DailyShare.share(app, what) } catch (e: Exception) { } }.start()
    }
}
