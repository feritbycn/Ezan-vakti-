package com.vakitpro.app.notif

import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vakitpro.app.data.Hadis
import com.vakitpro.app.data.Prefs
import com.vakitpro.app.ui.VakitTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Gunluk ayet / hadis / dua: vakit penceresi gibi ekranda acilan kart. */
class DailyPopupActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        }
        val s = Prefs.load(this)
        setContent {
            VakitTheme(s) {
                var dc by remember { mutableStateOf<DailyContent?>(null) }
                var fav by remember { mutableStateOf(false) }
                var tab by remember { mutableStateOf(0) }
                var imgs by remember { mutableStateOf<Map<Int, androidx.compose.ui.graphics.ImageBitmap>>(emptyMap()) }
                LaunchedEffect(Unit) {
                    withContext(Dispatchers.IO) {
                        val d = DailyContent.build(applicationContext)
                        val h = d.hadis
                        if (h != null) fav = Hadis.favIds(applicationContext).contains(h.id)
                        dc = d
                    }
                }
                LaunchedEffect(dc, tab) {
                    val d = dc ?: return@LaunchedEffect
                    if (imgs.containsKey(tab)) return@LaunchedEffect
                    val sec = d.pick(TABS[tab].second).firstOrNull() ?: return@LaunchedEffect
                    val bmp = withContext(Dispatchers.Default) { DailyShare.renderOne(applicationContext, sec, 1080).asImageBitmap() }
                    imgs = imgs + (tab to bmp)
                }
                val cs = MaterialTheme.colorScheme
                CompositionLocalProvider(LocalContentColor provides cs.onSurface) {
                    Box(
                        Modifier.fillMaxSize().background(Color(0x99000000))
                            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { finishAndRemoveTask() },
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            Modifier.padding(14.dp).fillMaxWidth()
                                .clip(RoundedCornerShape(28.dp)).background(cs.surface)
                                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
                                .padding(12.dp)
                        ) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                TABS.forEachIndexed { i, t ->
                                    val mod = Modifier.weight(1f)
                                    if (i == tab) Button(onClick = { tab = i }, modifier = mod, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp)) {
                                        Text(t.first, fontSize = 12.sp, maxLines = 1)
                                    } else OutlinedButton(onClick = { tab = i }, modifier = mod, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp)) {
                                        Text(t.first, fontSize = 12.sp, maxLines = 1)
                                    }
                                }
                            }
                            Spacer(Modifier.size(10.dp))
                            Box(Modifier.fillMaxWidth().heightIn(min = 200.dp, max = 540.dp), contentAlignment = Alignment.Center) {
                                val img = imgs[tab]
                                if (img != null) Image(img, null, Modifier.fillMaxSize().clip(RoundedCornerShape(16.dp)), contentScale = ContentScale.Fit)
                                else Text("…")
                            }
                            Spacer(Modifier.size(10.dp))
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically
                            ) {
                                TextButton(onClick = { finishAndRemoveTask() }) { Text("Kapat") }
                                Spacer(Modifier.weight(1f))
                                val d = dc
                                if (tab == 1 && d?.hadis != null) {
                                    OutlinedButton(onClick = {
                                        val nv = !fav
                                        fav = nv
                                        Thread { Hadis.setFlag(applicationContext, d.hadis, "fav", nv) }.start()
                                    }) { Text(if (fav) "Favoride ✓" else "Favoriye ekle", fontSize = 13.sp) }
                                }
                                Button(onClick = { DailyShareHelper.go(this@DailyPopupActivity, TABS[tab].second) }) { Text("Paylaş") }
                            }
                            TextButton(onClick = { DailyShareHelper.go(this@DailyPopupActivity, "all") }, modifier = Modifier.align(Alignment.End)) {
                                Text("Hepsini tek görselde paylaş", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }

    companion object {
        val TABS = listOf("Günün ayeti" to "ayah", "Günün hadisi" to "hadis", "Günün duası" to "dua")
    }
}

object DailyShareHelper {
    fun go(ctx: android.content.Context, what: String) {
        val app = ctx.applicationContext
        Thread { try { DailyShare.share(app, what) } catch (e: Exception) { } }.start()
    }
}
