package com.vakitpro.app.data

import java.time.LocalDate
import java.time.ZoneId
import java.time.ZoneOffset
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.roundToLong
import kotlin.math.sin
import kotlin.math.tan

enum class CalcMethod(
    val label: String,
    val fajr: Double,
    val isha: Double,
    val ishaIntervalMin: Int,
    val adj: IntArray
) {
    DIYANET("Diyanet (Türkiye)", 18.0, 17.0, 0, intArrayOf(0, -7, 5, 4, 7, 0)),
    MWL("Dünya İslam Birliği (MWL)", 18.0, 17.0, 0, intArrayOf(0, 0, 0, 0, 0, 0)),
    UMM("Ümmü'l-Kurâ (Mekke)", 18.5, 0.0, 90, intArrayOf(0, 0, 0, 0, 0, 0)),
    EGYPT("Mısır Genel Otoritesi", 19.5, 17.5, 0, intArrayOf(0, 0, 0, 0, 0, 0)),
    KARACHI("Karaçi", 18.0, 18.0, 0, intArrayOf(0, 0, 0, 0, 0, 0)),
    ISNA("ISNA (Kuzey Amerika)", 15.0, 15.0, 0, intArrayOf(0, 0, 0, 0, 0, 0));

    companion object {
        fun of(key: String): CalcMethod = values().firstOrNull { it.name == key } ?: DIYANET
    }
}

/**
 * Tamamen cevrimdisi astronomik vakit hesabi (praytimes.org / Adhan yontemleri).
 * Donen dizi: [imsak, gunes, ogle, ikindi, aksam, yatsi] -> epoch milisaniye.
 */
object PrayerCalc {

    private fun sind(x: Double) = sin(Math.toRadians(x))
    private fun cosd(x: Double) = cos(Math.toRadians(x))
    private fun tand(x: Double) = tan(Math.toRadians(x))

    private fun fixAngle(a: Double): Double {
        val r = a % 360.0
        return if (r < 0) r + 360.0 else r
    }

    private fun fixHour(a: Double): Double {
        val r = a % 24.0
        return if (r < 0) r + 24.0 else r
    }

    private fun julian(y0: Int, m0: Int, d: Int): Double {
        var y = y0
        var m = m0
        if (m <= 2) {
            y -= 1
            m += 12
        }
        val a = floor(y / 100.0)
        val b = 2 - a + floor(a / 4.0)
        return floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + d + b - 1524.5
    }

    /** returns (declination, equation of time) */
    private fun sunPosition(jd: Double): Pair<Double, Double> {
        val dd = jd - 2451545.0
        val g = fixAngle(357.529 + 0.98560028 * dd)
        val q = fixAngle(280.459 + 0.98564736 * dd)
        val l = fixAngle(q + 1.915 * sind(g) + 0.020 * sind(2 * g))
        val e = 23.439 - 0.00000036 * dd
        val ra = Math.toDegrees(atan2(cosd(e) * sind(l), cosd(l))) / 15.0
        val eqt = q / 15.0 - fixHour(ra)
        val decl = Math.toDegrees(asin(sind(e) * sind(l)))
        return Pair(decl, eqt)
    }

    fun compute(
        date: LocalDate,
        lat: Double,
        lng: Double,
        zone: ZoneId,
        method: CalcMethod,
        hanafi: Boolean,
        userAdj: List<Int>
    ): LongArray {
        val jd = julian(date.year, date.monthValue, date.dayOfMonth) - lng / 360.0

        fun angleTime(angle: Double, t: Double, ccw: Boolean): Double {
            val (decl, eqt) = sunPosition(jd + t)
            val mid = fixHour(12 - eqt)
            val v = (-sind(angle) - sind(decl) * sind(lat)) / (cosd(decl) * cosd(lat))
            if (v > 1.0 || v < -1.0) return Double.NaN
            val h = Math.toDegrees(acos(v)) / 15.0
            return if (ccw) mid - h else mid + h
        }

        fun asrTime(factor: Double, t: Double): Double {
            val (decl, _) = sunPosition(jd + t)
            val ang = -Math.toDegrees(atan(1.0 / (factor + tand(abs(lat - decl)))))
            return angleTime(ang, t, false)
        }

        var t = doubleArrayOf(5.0 / 24, 6.0 / 24, 12.0 / 24, 13.0 / 24, 18.0 / 24, 18.0 / 24)
        val r = DoubleArray(6)
        val asrFactor = if (hanafi) 2.0 else 1.0
        for (iter in 0 until 2) {
            val (_, eqt) = sunPosition(jd + t[2])
            r[0] = angleTime(method.fajr, t[0], true)
            r[1] = angleTime(0.833, t[1], true)
            r[2] = fixHour(12 - eqt)
            r[3] = asrTime(asrFactor, t[3])
            r[4] = angleTime(0.833, t[4], false)
            r[5] = if (method.ishaIntervalMin > 0) Double.NaN else angleTime(method.isha, t[5], false)
            val prev = t
            t = DoubleArray(6) { i -> if (r[i].isNaN()) prev[i] else r[i] / 24.0 }
        }

        // Kutup bolgesi / gecersiz sonuclar icin guvenli yedekler
        if (r[1].isNaN()) r[1] = r[2] - 6.0
        if (r[4].isNaN()) r[4] = r[2] + 6.0
        if (r[3].isNaN()) r[3] = r[2] + 3.5
        val night = 24.0 - (r[4] - r[1])
        if (r[0].isNaN()) r[0] = r[1] - night / 7.0
        if (method.ishaIntervalMin > 0) {
            r[5] = r[4] + method.ishaIntervalMin / 60.0
        } else if (r[5].isNaN()) {
            r[5] = r[4] + night / 7.0
        }

        val base = date.atStartOfDay(ZoneOffset.UTC).toEpochSecond() * 1000L
        val out = LongArray(6)
        for (i in 0 until 6) {
            // r[i], "UTC + boylam/15" cinsinden; UTC'ye cevirmek icin boylam duzeltmesi cikarilir
            val hUtc = r[i] - lng / 15.0
            val adjMin = method.adj[i] + (userAdj.getOrNull(i) ?: 0)
            val ms = base + (hUtc * 3_600_000.0).roundToLong() + adjMin * 60_000L
            out[i] = Math.floorDiv(ms + 30_000L, 60_000L) * 60_000L // dakikaya yuvarla
        }
        return out
    }
}
