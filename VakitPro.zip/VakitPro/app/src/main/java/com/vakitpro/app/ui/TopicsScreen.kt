package com.vakitpro.app.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vakitpro.app.data.Inspire
import com.vakitpro.app.data.Quran
import com.vakitpro.app.data.Topics
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Konulara gore ayetler: konu listesi -> konunun ayetleri -> ayet detayi (paylas, WhatsApp, indir). */
@Composable
fun TopicsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    var index by remember { mutableStateOf<Map<String, List<Topics.TopicHit>>?>(null) }
    var open by remember { mutableStateOf<String?>(null) }
    var detail by remember { mutableStateOf<Topics.TopicHit?>(null) }

    LaunchedEffect(Unit) {
        index = withContext(Dispatchers.IO) { Topics.index(ctx) }
    }

    val idx = index
    val hits = open?.let { idx?.get(it) }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        ScreenHeader(
            title = open ?: "Konulara göre ayetler",
            subtitle = if (open == null) "Meal içinde konu kelimelerine göre" else "${hits?.size ?: 0} ayet",
            onBack = { if (open != null) open = null else onBack() }
        )
        Spacer(Modifier.size(8.dp))
        if (idx == null) {
            Text("Yükleniyor…", color = cs.onSurfaceVariant, fontSize = 14.sp, modifier = Modifier.padding(8.dp))
        } else if (open == null) {
            LazyColumn(Modifier.fillMaxWidth()) {
                items(Topics.LIST) { t ->
                    TopicRow(t.name, idx[t.name]?.size ?: 0) { open = t.name }
                }
            }
        } else {
            LazyColumn(Modifier.fillMaxWidth()) {
                items(hits ?: emptyList()) { h ->
                    VerseRow(h) { detail = h }
                }
            }
        }
    }

    detail?.let { h -> VerseDetail(h) { detail = null } }
}

@Composable
private fun TopicRow(name: String, count: Int, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(cs.surfaceVariant)
            .clickable { onClick() }
            .padding(horizontal = 18.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            name,
            color = cs.onSurface,
            fontSize = 17.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.weight(1f)
        )
        Text("$count ayet", color = cs.onSurfaceVariant, fontSize = 13.sp)
    }
}

@Composable
private fun VerseRow(h: Topics.TopicHit, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(cs.surfaceVariant)
            .clickable { onClick() }
            .padding(horizontal = 18.dp, vertical = 14.dp)
    ) {
        Text(
            "${Quran.NAMES[h.surah]} • ${h.verse + 1}",
            color = cs.primary,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(Modifier.size(4.dp))
        Text(
            h.text,
            color = cs.onSurface,
            fontSize = 15.sp,
            maxLines = 3,
            overflow = TextOverflow.Ellipsis
        )
    }
}

/** Ayet detayi: metin ve paylasim butonlari. Paylasim kartlari hikayelerle ayni kurallarla uretilir. */
@Composable
private fun VerseDetail(h: Topics.TopicHit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()
    val item = remember(h) {
        Inspire(Inspire.AYET, h.text, "${Quran.NAMES[h.surah]} Sûresi, ${h.verse + 1}")
    }
    val themeIdx = h.verse

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xCC000000))
            .clickable { onClose() },
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(cs.surface)
                .clickable(enabled = false) { }
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "${Quran.NAMES[h.surah]} Sûresi, ${h.verse + 1}",
                color = cs.primary,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.size(10.dp))
            Text(h.text, color = cs.onSurface, fontSize = 16.sp)
            Spacer(Modifier.size(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PillBtn(Glyph.SHARE, "Paylaş", Color(0x33FFFFFF), cs.onSurface) {
                    Toast.makeText(ctx, "Görsel hazırlanıyor…", Toast.LENGTH_SHORT).show()
                    scope.launch { shareStory(ctx, item, themeIdx, false) }
                }
                PillBtn(null, "WhatsApp", Color(0xFF25D366), Color.White, green = true) {
                    Toast.makeText(ctx, "Görsel hazırlanıyor…", Toast.LENGTH_SHORT).show()
                    scope.launch { shareStory(ctx, item, themeIdx, true) }
                }
                PillBtn(Glyph.DOWNLOAD, "İndir", Color(0x33FFFFFF), cs.onSurface) {
                    scope.launch { saveStory(ctx, item, themeIdx) }
                }
            }
        }
    }
}
