package com.vakitpro.app.ui

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback

/**
 * Reklamlar (AdMob). Pro kullanicilara gosterilmez.
 * Kimlikler AdMob'daki gercek birimler; uygulama kimligi AndroidManifest.xml icinde.
 * Kapatmak icin ENABLED = false.
 */
object Ads {
    const val ENABLED = true
    /** Kac hikayede bir reklam sayfasi araya girsin. */
    const val EVERY_N_STORIES = 3

    /** Ana ekran banner birimi. */
    const val BANNER_ID = "ca-app-pub-4446596500153010/1536919198"
    /** Hikaye arasi tam sayfa (Geçiş) birimi. */
    const val STORY_ID = "ca-app-pub-4446596500153010/6557632387"

    private var initialized = false

    fun init(ctx: Context) {
        if (initialized) return
        initialized = true
        MobileAds.initialize(ctx.applicationContext) {}
    }
}

@Composable
fun AdBanner(modifier: Modifier = Modifier) {
    if (!Ads.ENABLED || Pro.unlocked) return
    AndroidView(
        modifier = modifier.fillMaxWidth(),
        factory = { c ->
            Ads.init(c)
            AdView(c).apply {
                setAdSize(AdSize.BANNER)
                adUnitId = Ads.BANNER_ID
                loadAd(AdRequest.Builder().build())
            }
        },
        onRelease = { it.destroy() }
    )
}

/** Hikayeler arasina giren sayfa. Tam sayfa geçiş reklamı yuklenince otomatik gosterilir. */
@Composable
fun AdStoryPage() {
    val ctx = LocalContext.current
    LaunchedEffect(Unit) {
        if (!Ads.ENABLED || Pro.unlocked) return@LaunchedEffect
        val act = ctx.findActivity() ?: return@LaunchedEffect
        Ads.init(ctx)
        InterstitialAd.load(
            ctx,
            Ads.STORY_ID,
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    ad.show(act)
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    // Reklam yuklenemezse sayfa sade kalir, hikaye akisi devam eder.
                }
            }
        )
    }
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF0E1630), Color(0xFF1B2B5A)))),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier
                .padding(28.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(28.dp))
                .background(Color(0x22FFFFFF))
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                "REKLAM",
                color = Color(0xFFF2C26B),
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
            )
            Text(
                "Devam etmek için dokun.",
                color = Color.White.copy(alpha = 0.75f),
                fontSize = 14.sp
            )
        }
    }
}
