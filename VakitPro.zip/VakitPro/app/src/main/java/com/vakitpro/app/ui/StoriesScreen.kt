package com.vakitpro.app.ui

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.vakitpro.app.data.Inspire
import com.vakitpro.app.data.Prefs
import com.vakitpro.app.data.StoryPlan
import com.vakitpro.app.notif.CardArt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private class Slide(val item: Inspire?, val n: Int, val kind: Int)

/**
 * Reels tarzi hikayeler. Ekrana dokununca sonraki hikaye; bir tur (ayet, hadis...) bitince
 * siradaki tura gecilir. Iki hikayede bir reklam sayfasi girer.
 */
@Composable
fun StoriesScreen(initialKind: Int = -1, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val today = remember { java.time.LocalDate.now().toEpochDay() }
    var start by remember { mutableIntStateOf(if (initialKind >= 0) initialKind else Inspire.AYET) }
    val slides = remember(start) {
        val out = ArrayList<Slide>()
        var n = 0
        for (k in StoryPlan.order(start)) {
            for (it0 in StoryPlan.group(k, today)) {
                out.add(Slide(it0, n, k))
                n++
                if (Ads.ENABLED && n % Ads.EVERY_N_STORIES == 0) out.add(Slide(null, -1, k))
            }
        }
        if (out.isNotEmpty() && out.last().item == null) out.removeAt(out.size - 1)
        out
    }
    val pager = rememberPagerState(pageCount = { slides.size })
    LaunchedEffect(start) { pager.scrollToPage(0) }
    val cur = slides.getOrNull(pager.currentPage)

    // Turun son hikayesine gelince o tur "okundu" sayilir (ana ekrandaki halka solar)
    LaunchedEffect(pager.currentPage, slides) {
        val s0 = slides.getOrNull(pager.currentPage) ?: return@LaunchedEffect
        if (s0.item != null) {
            val last = slides.lastOrNull { it.kind == s0.kind && it.item != null }
            if (last === s0) Prefs.putInt(ctx, StoryPlan.seenKey(s0.kind, today), 1)
        }
    }
    val go = { d: Int ->
        scope.launch {
            val n = slides.size
            val target = pager.currentPage + d
            if (target >= n) onBack()
            else if (target >= 0) pager.animateScrollToPage(target)
        }
        Unit
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        VerticalPager(state = pager, modifier = Modifier.fillMaxSize()) { page ->
            val sl = slides[page]
            Box(
                Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) {
                        detectTapGestures { off -> go(if (off.x < size.width * 0.3f) -1 else 1) }
                    }
            ) {
                val it0 = sl.item
                if (it0 != null) StoryPage(it0, sl.n) else AdStoryPage()
            }
        }

        Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)) {
            // Tur icindeki ilerleme cizgileri
            val groupStories = slides.filter { it.kind == cur?.kind && it.item != null }
            val pos = groupStories.indexOfFirst { it === cur }
            Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                groupStories.forEachIndexed { i, _ ->
                    Box(
                        Modifier
                            .weight(1f)
                            .height(3.dp)
                            .clip(RoundedCornerShape(50))
                            .background(if (i <= pos || (cur?.item == null && i < groupStories.size) ) Color.White else Color(0x55FFFFFF))
                    )
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                BackButton(onClick = onBack, glass = true)
                Spacer(Modifier.size(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    StoryPlan.ORDER.forEach { k ->
                        val sel = cur?.kind == k
                        Box(
                            Modifier
                                .clip(RoundedCornerShape(50))
                                .background(if (sel) Color(0xFFF2C26B) else Color(0x40FFFFFF))
                                .border(1.dp, if (sel) Color(0xFFF2C26B) else Color(0x55FFFFFF), RoundedCornerShape(50))
                                .clickable { start = k }
                                .padding(horizontal = 12.dp, vertical = 7.dp)
                        ) {
                            Text(
                                StoryPlan.NAMES[k] ?: "",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (sel) Color(0xFF1B1B1B) else Color.White
                            )
                        }
                    }
                }
            }
        }

        val curItem = cur?.item
        if (curItem != null) {
            Row(
                Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 18.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                val themeIdx = cur.n
                PillBtn("↗", "Paylaş", Color(0x33FFFFFF), Color.White) {
                    scope.launch { shareStory(ctx, curItem, themeIdx, false) }
                }
                PillBtn("💬", "WhatsApp", Color(0xFF25D366), Color.White) {
                    scope.launch { shareStory(ctx, curItem, themeIdx, true) }
                }
                PillBtn("⬇", "İndir", Color(0x33FFFFFF), Color.White) {
                    scope.launch { saveStory(ctx, curItem, themeIdx) }
                }
            }
        }
    }
}

/** Ana ekran hikaye halkalari. Okunan turun renkli halkasi soluklasir. */
@Composable
fun StoryRow(onOpen: (String) -> Unit) {
    val ctx = LocalContext.current
    val today = remember { java.time.LocalDate.now().toEpochDay() }
    val ring = Brush.sweepGradient(
        listOf(Color(0xFFF2C26B), Color(0xFFE0613F), Color(0xFFC13584), Color(0xFFF2C26B))
    )
    val seenRing = Brush.sweepGradient(listOf(Color(0x33FFFFFF), Color(0x33FFFFFF)))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
        StoryPlan.ORDER.forEach { k ->
            val seen = Prefs.getInt(ctx, StoryPlan.seenKey(k, today), 0) == 1
            var bmp by remember { mutableStateOf<ImageBitmap?>(null) }
            LaunchedEffect(k) {
                bmp = withContext(Dispatchers.Default) { CardArt.badge(k, 240).asImageBitmap() }
            }
            Column(
                Modifier.clickable { onOpen("stories$k") },
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    Modifier
                        .size(74.dp)
                        .border(if (seen) 1.5.dp else 3.dp, if (seen) seenRing else ring, CircleShape)
                        .padding(5.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF16302C))
                        .alpha(if (seen) 0.6f else 1f)
                ) {
                    val b = bmp
                    if (b != null) {
                        Image(
                            bitmap = b,
                            contentDescription = null,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }
                }
                Spacer(Modifier.size(6.dp))
                Text(
                    StoryPlan.NAMES[k] ?: "",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.alpha(if (seen) 0.6f else 1f)
                )
            }
        }
    }
}

@Composable
private fun PillBtn(icon: String, label: String, bg: Color, fg: Color, onClick: () -> Unit) {
    Row(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(bg)
            .border(1.dp, Color(0x40FFFFFF), RoundedCornerShape(50))
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(icon, color = fg, fontSize = 16.sp)
        Spacer(Modifier.size(6.dp))
        Text(label, color = fg, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun StoryPage(item: Inspire, themeIdx: Int) {
    val th = CardArt.STORY_THEMES[Math.floorMod(themeIdx, CardArt.STORY_THEMES.size)]
    var bmp by remember(item) { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(item) {
        bmp = withContext(Dispatchers.Default) { CardArt.story(item, themeIdx, 720, 1280).asImageBitmap() }
    }
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(th.top), Color(th.bottom)))),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) {
            Image(
                bitmap = b,
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Fit
            )
        }
    }
}

@Composable
private fun RoundBtn(label: String, size: Int, onClick: () -> Unit) {
    Box(
        Modifier
            .size(size.dp)
            .clip(CircleShape)
            .background(Color(0x66000000))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) { Text(label, color = Color.White, fontSize = 20.sp) }
}

private suspend fun renderFull(item: Inspire, themeIdx: Int): Bitmap =
    withContext(Dispatchers.Default) { CardArt.story(item, themeIdx) }

private suspend fun shareStory(ctx: Context, item: Inspire, themeIdx: Int, whatsapp: Boolean) {
    try {
        val uri = withContext(Dispatchers.IO) {
            val bmp = renderFull(item, themeIdx)
            val dir = File(ctx.cacheDir, "stories").apply { mkdirs() }
            dir.listFiles()?.forEach { it.delete() }
            val f = File(dir, "vakitpro_${System.currentTimeMillis()}.png")
            f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)
        }
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, item.withSource + "\n\nVakit Pro")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        if (whatsapp) {
            send.setPackage("com.whatsapp")
            try {
                ctx.startActivity(send.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) {
                send.setPackage(null)
                Toast.makeText(ctx, "WhatsApp bulunamadı, paylaşma menüsü açılıyor", Toast.LENGTH_SHORT).show()
                ctx.startActivity(Intent.createChooser(send, "Paylaş").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        } else {
            ctx.startActivity(Intent.createChooser(send, "Paylaş").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    } catch (e: Exception) {
        Toast.makeText(ctx, "Paylaşılamadı", Toast.LENGTH_SHORT).show()
    }
}

private suspend fun saveStory(ctx: Context, item: Inspire, themeIdx: Int) {
    val ok = withContext(Dispatchers.IO) {
        try {
            val bmp = renderFull(item, themeIdx)
            val name = "VakitPro_${System.currentTimeMillis()}.png"
            if (Build.VERSION.SDK_INT >= 29) {
                val cv = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/VakitPro")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
                val r = ctx.contentResolver
                val uri = r.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
                    ?: return@withContext false
                r.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                cv.clear()
                cv.put(MediaStore.Images.Media.IS_PENDING, 0)
                r.update(uri, cv, null, null)
            } else {
                @Suppress("DEPRECATION")
                val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "VakitPro")
                dir.mkdirs()
                val f = File(dir, name)
                f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                android.media.MediaScannerConnection.scanFile(ctx, arrayOf(f.absolutePath), null, null)
            }
            true
        } catch (e: Exception) {
            false
        }
    }
    Toast.makeText(
        ctx,
        if (ok) "Galeriye kaydedildi (Pictures/VakitPro)" else "Kaydedilemedi",
        Toast.LENGTH_SHORT
    ).show()
}
