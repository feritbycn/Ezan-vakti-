package com.vakitpro.app.ui

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.vakitpro.app.data.Inspire
import com.vakitpro.app.data.Prefs
import com.vakitpro.app.data.StoryPlan
import com.vakitpro.app.notif.CardArt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private class Slide(val item: Inspire?, val n: Int, val kind: Int)

/**
 * Reels tarzi hikayeler. Ekrana dokununca sonraki hikaye; bir tur (ayet, hadis...) bitince
 * siradaki tura gecilir. Iki hikayede bir reklam sayfasi girer.
 */
@Composable
fun StoriesScreen(initialKind: Int = -1, onBack: () -> Unit, focus: Inspire? = null) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val today = remember { java.time.LocalDate.now().toEpochDay() }
    var start by remember { mutableIntStateOf(if (initialKind >= 0) initialKind else Inspire.AYET) }
    val focusOnce = remember { focus }
    LaunchedEffect(Unit) { com.vakitpro.app.OpenRequest.focus.value = null }
    val single = focusOnce != null
    val slides = remember(start, focusOnce) {
        if (focusOnce != null) return@remember arrayListOf(Slide(focusOnce, 0, focusOnce.kind))
        val out = ArrayList<Slide>()
        var n = 0
        for (k in StoryPlan.order(start)) {
            for (it0 in StoryPlan.group(k, today)) {
                out.add(Slide(it0, n, k))
                n++
                if (Ads.ENABLED && !Pro.unlocked && n % Ads.EVERY_N_STORIES == 0 && (Sponsors.pick("hikaye") != null || Sponsors.GOOGLE_FALLBACK)) out.add(Slide(null, -1, k))
            }
        }
        if (out.isNotEmpty() && out.last().item == null) out.removeAt(out.size - 1)
        if (focusOnce != null && out.none { it.item?.text == focusOnce.text }) out.add(0, Slide(focusOnce, 0, focusOnce.kind))
        out
    }
    val pager = rememberPagerState(pageCount = { slides.size })
    LaunchedEffect(start, focusOnce) {
        val fp = if (focusOnce != null) slides.indexOfFirst { it.item?.text == focusOnce.text } else -1
        pager.scrollToPage(if (fp >= 0) fp else 0)
    }
    val cur = slides.getOrNull(pager.currentPage)

    // Turun son hikayesine gelince o tur "okundu" sayilir (ana ekrandaki halka solar)
    LaunchedEffect(pager.currentPage, slides) {
        val s0 = slides.getOrNull(pager.currentPage) ?: return@LaunchedEffect
        if (s0.item != null) {
            val last = slides.lastOrNull { it.kind == s0.kind && it.item != null }
            if (last === s0) Prefs.putInt(ctx, StoryPlan.seenKey(s0.kind, today), 1)
        }
    }
    val go = { d: Int ->
        scope.launch {
            if (single) return@launch
            val n = slides.size
            val target = pager.currentPage + d
            if (target >= n) onBack()
            else if (target >= 0) pager.animateScrollToPage(target)
        }
        Unit
    }

    // Yatay kaydirma: sola = sonraki tur (orn. Ayet -> Hadis), saga = onceki tur
    var dragX by remember { mutableFloatStateOf(0f) }
    val switchKind = { d: Int ->
        val ords = StoryPlan.ORDER
        val i = ords.indexOf(start) + d
        if (!single && i in ords.indices) start = ords[i]
    }

    // Isik sizmasi: tur degisince sicak bir isik bandi soldan saga gecer
    val leak = remember { androidx.compose.animation.core.Animatable(1f) }
    LaunchedEffect(start) {
        leak.snapTo(0f)
        leak.animateTo(1f, androidx.compose.animation.core.tween(800, easing = androidx.compose.animation.core.FastOutSlowInEasing))
    }

    var paused by remember { mutableStateOf(false) }
    var pressAt by remember { mutableStateOf(0L) }
    var progress by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(pager.currentPage, slides) {
        if (single) return@LaunchedEffect
        progress = 0f
        val total = 7000f
        while (progress < 1f) {
            kotlinx.coroutines.delay(50)
            if (!paused && !pager.isScrollInProgress) progress += 50f / total
        }
        go(1)
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        VerticalPager(state = pager, modifier = Modifier.fillMaxSize()) { page ->
            val sl = slides[page]
            Box(
                Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) {
                        detectHorizontalDragGestures(
                            onDragStart = { dragX = 0f },
                            onDragCancel = { dragX = 0f },
                            onDragEnd = {
                                if (dragX < -120f) switchKind(1) else if (dragX > 120f) switchKind(-1)
                                dragX = 0f
                            },
                            onHorizontalDrag = { _, amount -> dragX += amount }
                        )
                    }
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onPress = {
                                pressAt = System.currentTimeMillis()
                                paused = true
                                tryAwaitRelease()
                                paused = false
                            },
                            onTap = { off ->
                                if (System.currentTimeMillis() - pressAt < 250) go(if (off.x < size.width * 0.3f) -1 else 1)
                            }
                        )
                    }
            ) {
                val it0 = sl.item
                if (it0 != null) StoryPage(it0, sl.n) else {
                    val sp = Sponsors.pick("hikaye")
                    if (sp != null) SponsorCard(sp, Modifier.fillMaxSize().padding(28.dp))
                    else if (Sponsors.GOOGLE_FALLBACK) AdStoryPage()
                }
            }
        }

        val lp = leak.value
        if (lp < 1f) {
            androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
                val x = size.width * (-0.6f + 2.2f * lp)
                drawRect(
                    Brush.linearGradient(
                        colors = listOf(Color.Transparent, Color(0xD9FFE6A0), Color.Transparent),
                        start = androidx.compose.ui.geometry.Offset(x - size.width * 0.35f, 0f),
                        end = androidx.compose.ui.geometry.Offset(x + size.width * 0.35f, size.height)
                    )
                )
                drawRect(Color(0xFFFFE6A0).copy(alpha = 0.25f * (1f - lp)))
            }
        }

        if (single) {
            Box(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)) {
                BackButton(onClick = onBack, glass = true)
            }
        } else Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)) {
            // Tur icindeki ilerleme cizgileri
            val groupStories = slides.filter { it.kind == cur?.kind && it.item != null }
            val pos = groupStories.indexOfFirst { it === cur }
            Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                groupStories.forEachIndexed { i, _ ->
                    val frac = if (cur?.item == null) 1f else if (i < pos) 1f else if (i == pos) progress.coerceIn(0f, 1f) else 0f
                    Box(
                        Modifier
                            .weight(1f)
                            .height(3.dp)
                            .clip(RoundedCornerShape(50))
                            .background(Color(0x55FFFFFF))
                    ) {
                        Box(Modifier.fillMaxHeight().fillMaxWidth(frac).background(Color.White))
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                BackButton(onClick = onBack, glass = true)
                Spacer(Modifier.size(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    StoryPlan.ORDER.forEach { k ->
                        val sel = cur?.kind == k
                        Box(
                            Modifier
                                .clip(RoundedCornerShape(50))
                                .background(if (sel) Color(0xFFF2C26B) else Color(0x40FFFFFF))
                                .border(1.dp, if (sel) Color(0xFFF2C26B) else Color(0x55FFFFFF), RoundedCornerShape(50))
                                .clickable { start = k }
                                .padding(horizontal = 12.dp, vertical = 7.dp)
                        ) {
                            Text(
                                StoryPlan.NAMES[k] ?: "",
                                maxLines = 1,
                                softWrap = false,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (sel) Color(0xFF1B1B1B) else Color.White
                            )
                        }
                    }
                }
            }
        }

        val curItem = cur?.item
        LaunchedEffect(curItem, cur?.n) {
            val it0 = curItem ?: return@LaunchedEffect
            val n0 = cur?.n ?: 0
            withContext(Dispatchers.IO) { try { storyFile(ctx, it0, n0) } catch (e: Throwable) { } }
        }
        if (curItem != null) {
            Row(
                Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 18.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                val themeIdx = cur.n
                PillBtn(Glyph.SHARE, "Paylaş", Color(0x33FFFFFF), Color.White) {
                    Toast.makeText(ctx, "Görsel hazırlanıyor…", Toast.LENGTH_SHORT).show(); scope.launch { shareStory(ctx, curItem, themeIdx, false) }
                }
                PillBtn(null, "WhatsApp", Color(0xFF25D366), Color.White, green = true) {
                    Toast.makeText(ctx, "Görsel hazırlanıyor…", Toast.LENGTH_SHORT).show(); scope.launch { shareStory(ctx, curItem, themeIdx, true) }
                }
                PillBtn(Glyph.DOWNLOAD, "İndir", Color(0x33FFFFFF), Color.White) {
                    scope.launch { saveStory(ctx, curItem, themeIdx) }
                }
            }
        }
    }
}

/** Ana ekran hikaye halkalarinin kapak gorselleri. */
private fun storyCoverRes(kind: Int): Int = when (kind) {
    Inspire.AYET -> com.vakitpro.app.R.drawable.story_cover_ayet
    Inspire.HADIS -> com.vakitpro.app.R.drawable.story_cover_hadis
    Inspire.SOZ -> com.vakitpro.app.R.drawable.story_cover_soz
    else -> com.vakitpro.app.R.drawable.story_cover_dua
}

/** Ana ekran hikaye halkalari. Okunan turun renkli halkasi soluklasir. */
@Composable
fun StoryRow(onOpen: (String) -> Unit) {
    val ctx = LocalContext.current
    val today = remember { java.time.LocalDate.now().toEpochDay() }
    val ring = Brush.sweepGradient(
        listOf(Color(0xFFF2C26B), Color(0xFFE0613F), Color(0xFFC13584), Color(0xFFF2C26B))
    )
    val seenRing = Brush.sweepGradient(listOf(Color(0x33FFFFFF), Color(0x33FFFFFF)))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
        StoryPlan.ORDER.forEach { k ->
            val seen = Prefs.getInt(ctx, StoryPlan.seenKey(k, today), 0) == 1
            var bmp by remember { mutableStateOf<ImageBitmap?>(null) }
            LaunchedEffect(k) {
                bmp = withContext(Dispatchers.Default) {
                    android.graphics.BitmapFactory.decodeResource(ctx.resources, storyCoverRes(k))?.asImageBitmap()
                }
            }
            Column(
                Modifier.clickable { onOpen("stories$k") },
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    Modifier
                        .size(74.dp)
                        .border(if (seen) 1.5.dp else 3.dp, if (seen) seenRing else ring, CircleShape)
                        .padding(5.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF16302C))
                        .alpha(if (seen) 0.6f else 1f)
                ) {
                    val b = bmp
                    if (b != null) {
                        Image(
                            bitmap = b,
                            contentDescription = null,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }
                }
                Spacer(Modifier.size(6.dp))
                Text(
                    StoryPlan.NAMES[k] ?: "",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.alpha(if (seen) 0.6f else 1f)
                )
            }
        }
    }
}

@Composable
fun WaIcon(size: androidx.compose.ui.unit.Dp) {
    androidx.compose.foundation.Canvas(Modifier.size(size)) {
        val k = this.size.width / 24f
        val ring = androidx.compose.ui.graphics.vector.PathParser().parsePathString(
            "M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2zm0 18.2a8.2 8.2 0 0 1-4.2-1.2l-.3-.2-3 .8.8-2.9-.2-.3A8.2 8.2 0 1 1 12 20.2z"
        ).toPath()
        val phone = androidx.compose.ui.graphics.vector.PathParser().parsePathString(
            "M16.6 14.2c-.2-.1-1.4-.7-1.6-.8-.2-.1-.4-.1-.5.1l-.8 1c-.1.2-.3.2-.5.1-1.4-.7-2.3-1.2-3.3-2.8-.2-.4.2-.4.7-1.3.1-.2 0-.3 0-.5l-.7-1.7c-.2-.5-.4-.4-.5-.4h-.5c-.2 0-.5.1-.7.3-.7.7-1 1.5-.9 2.4.2 1.2.8 2.3 1.7 3.2 1.1 1.2 2.4 2 3.9 2.5.9.3 1.5.3 2.2.2.7-.1 1.5-.6 1.7-1.2.2-.6.2-1.1.1-1.2-.1-.1-.2-.2-.4-.3z"
        ).toPath()
        ring.fillType = androidx.compose.ui.graphics.PathFillType.EvenOdd
        scale(k, k, pivot = androidx.compose.ui.geometry.Offset.Zero) {
            drawPath(ring, Color.White)
            drawPath(phone, Color.White)
        }
    }
}

@Composable
internal fun PillBtn(icon: Glyph?, label: String, bg: Color, fg: Color, green: Boolean = false, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    val fill = if (green) Brush.linearGradient(listOf(Color(0xFF2BE074), Color(0xFF0F9D58)))
    else Brush.linearGradient(listOf(Color(0xA60C222C), Color(0xA60C222C)))
    Row(
        Modifier
            .shadow(8.dp, shape)
            .clip(shape)
            .background(fill)
            .border(1.dp, if (green) Color(0x59FFFFFF) else Color(0x38FFFFFF), shape)
            .clickable { onClick() }
            .padding(horizontal = 13.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) GlyphIcon(icon, fg, 19.dp) else WaIcon(21.dp)
        Spacer(Modifier.size(6.dp))
        Text(label, color = fg, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false)
    }
}

@Composable
private fun StoryPage(item: Inspire, themeIdx: Int) {
    val ctx = LocalContext.current
    val th = CardArt.STORY_THEMES[Math.floorMod(themeIdx, CardArt.STORY_THEMES.size)]
    var bmp by remember(item) { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(item) {
        bmp = withContext(Dispatchers.Default) { CardArt.story(item, themeIdx, 720, 1280, ctx).asImageBitmap() }
    }
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(th.top), Color(th.bottom)))),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) {
            Image(
                bitmap = b,
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Fit
            )
        }
    }
}

@Composable
private fun RoundBtn(label: String, size: Int, onClick: () -> Unit) {
    Box(
        Modifier
            .size(size.dp)
            .clip(CircleShape)
            .background(Color(0x66000000))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) { Text(label, color = Color.White, fontSize = 20.sp) }
}

private val storyLock = Any()

/** Hikaye gorselini (4K) bir kez uretip onbellekte tutar; paylasimda aninda hazir olur. */
private fun storyFile(ctx: Context, item: Inspire, themeIdx: Int): File = synchronized(storyLock) {
    val dir = File(ctx.cacheDir, "stories").apply { mkdirs() }
    val f = File(dir, "story_${(item.text + item.source).hashCode()}_${Math.floorMod(themeIdx, 4)}.png")
    if (f.exists() && f.length() > 0) return f
    // 1080x1920: 2160x3840 bellek sinirini asip eski telefonlarda sessizce duruyordu
    val bmp = CardArt.story(item, themeIdx, 1080, 1920, ctx, true)
    val tmp = File(dir, f.name + ".tmp")
    tmp.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
    bmp.recycle()
    tmp.renameTo(f)
    dir.listFiles()?.filter { it.name.startsWith("story_") && it.name.endsWith(".png") }
        ?.sortedByDescending { it.lastModified() }?.drop(12)?.forEach { it.delete() }
    f
}

internal suspend fun shareStory(ctx: Context, item: Inspire, themeIdx: Int, whatsapp: Boolean) {
    try {
        val uri = withContext(Dispatchers.IO) {
            FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", storyFile(ctx, item, themeIdx))
        }
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        if (whatsapp) {
            send.setPackage("com.whatsapp")
            try {
                ctx.startActivity(send.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) {
                send.setPackage(null)
                Toast.makeText(ctx, "WhatsApp bulunamadı, paylaşma menüsü açılıyor", Toast.LENGTH_SHORT).show()
                ctx.startActivity(Intent.createChooser(send, "Paylaş").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        } else {
            ctx.startActivity(Intent.createChooser(send, "Paylaş").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    } catch (e: Throwable) {
        Toast.makeText(ctx, "Paylaşılamadı", Toast.LENGTH_SHORT).show()
    }
}

internal suspend fun saveStory(ctx: Context, item: Inspire, themeIdx: Int) {
    val ok = withContext(Dispatchers.IO) {
        try {
            val srcFile = storyFile(ctx, item, themeIdx)
            val name = "VakitPro_${System.currentTimeMillis()}.png"
            if (Build.VERSION.SDK_INT >= 29) {
                val cv = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/VakitPro")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
                val r = ctx.contentResolver
                val uri = r.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
                    ?: return@withContext false
                r.openOutputStream(uri)?.use { o -> srcFile.inputStream().use { i -> i.copyTo(o) } }
                cv.clear()
                cv.put(MediaStore.Images.Media.IS_PENDING, 0)
                r.update(uri, cv, null, null)
            } else {
                @Suppress("DEPRECATION")
                val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "VakitPro")
                dir.mkdirs()
                val f = File(dir, name)
                f.outputStream().use { o -> srcFile.inputStream().use { i -> i.copyTo(o) } }
                android.media.MediaScannerConnection.scanFile(ctx, arrayOf(f.absolutePath), null, null)
            }
            true
        } catch (e: Exception) {
            false
        }
    }
    Toast.makeText(
        ctx,
        if (ok) "Galeriye kaydedildi (Pictures/VakitPro)" else "Kaydedilemedi",
        Toast.LENGTH_SHORT
    ).show()
}
