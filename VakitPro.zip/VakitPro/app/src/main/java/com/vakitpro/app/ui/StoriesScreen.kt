package com.vakitpro.app.ui

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.vakitpro.app.data.Inspire
import com.vakitpro.app.data.InspireData
import com.vakitpro.app.notif.CardArt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** Reels tarzi: dikey kaydirmali ayet / hadis / dua / guzel soz kartlari. */
@Composable
fun StoriesScreen(initialKind: Int = -1, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var filter by remember { mutableIntStateOf(initialKind) }
    val items = remember(filter) {
        InspireData.ALL
            .filter { filter < 0 || it.kind == filter }
            .shuffled(kotlin.random.Random(java.time.LocalDate.now().toEpochDay()))
    }
    val pager = rememberPagerState(pageCount = { items.size })
    LaunchedEffect(filter) { pager.scrollToPage(0) }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        VerticalPager(state = pager, modifier = Modifier.fillMaxSize()) { page ->
            StoryPage(items[page], page)
        }

        // Ust: geri + filtre
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RoundBtn("←", 40) { onBack() }
            Spacer(Modifier.size(10.dp))
            val names = listOf("Tümü", "Ayet", "Hadis", "Dua", "Söz")
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                names.forEachIndexed { i, n ->
                    val sel = filter == i - 1
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(50))
                            .background(if (sel) Color(0xFFF2C26B) else Color(0x40FFFFFF))
                            .border(1.dp, if (sel) Color(0xFFF2C26B) else Color(0x55FFFFFF), RoundedCornerShape(50))
                            .clickable { filter = i - 1 }
                            .padding(horizontal = 12.dp, vertical = 7.dp)
                    ) {
                        Text(
                            n,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (sel) Color(0xFF1B1B1B) else Color.White
                        )
                    }
                }
            }
        }

        // Alt: cam efektli, yuvarlak butonlar
        Row(
            Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 18.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            val cur = items.getOrNull(pager.currentPage)
            val themeIdx = pager.currentPage
            PillBtn("↗", "Paylaş", Color(0x33FFFFFF), Color.White) {
                if (cur != null) scope.launch { shareStory(ctx, cur, themeIdx, false) }
            }
            PillBtn("💬", "WhatsApp", Color(0xFF25D366), Color.White) {
                if (cur != null) scope.launch { shareStory(ctx, cur, themeIdx, true) }
            }
            PillBtn("⬇", "İndir", Color(0x33FFFFFF), Color.White) {
                if (cur != null) scope.launch { saveStory(ctx, cur, themeIdx) }
            }
        }
    }
}

/** Ana ekran hikaye halkalari (Ayet, Hadis, Ozlu Sozler, Dua). */
@Composable
fun StoryRow(onOpen: (String) -> Unit) {
    val order = listOf(0, 1, 3, 2)
    val names = listOf("Ayet", "Hadis", "Dua", "Özlü Sözler")
    val ring = Brush.sweepGradient(
        listOf(Color(0xFFF2C26B), Color(0xFFE0613F), Color(0xFFC13584), Color(0xFFF2C26B))
    )
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
        order.forEach { k ->
            var bmp by remember { mutableStateOf<ImageBitmap?>(null) }
            LaunchedEffect(k) {
                bmp = withContext(Dispatchers.Default) { CardArt.badge(k, 240).asImageBitmap() }
            }
            Column(
                Modifier.clickable { onOpen("stories$k") },
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    Modifier
                        .size(74.dp)
                        .border(3.dp, ring, CircleShape)
                        .padding(5.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF16302C))
                ) {
                    val b = bmp
                    if (b != null) {
                        Image(
                            bitmap = b,
                            contentDescription = null,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }
                }
                Spacer(Modifier.size(6.dp))
                Text(names[k], fontSize = 12.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
private fun PillBtn(icon: String, label: String, bg: Color, fg: Color, onClick: () -> Unit) {
    Row(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(bg)
            .border(1.dp, Color(0x40FFFFFF), RoundedCornerShape(50))
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(icon, color = fg, fontSize = 16.sp)
        Spacer(Modifier.size(6.dp))
        Text(label, color = fg, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun StoryPage(item: Inspire, themeIdx: Int) {
    val th = CardArt.STORY_THEMES[Math.floorMod(themeIdx, CardArt.STORY_THEMES.size)]
    var bmp by remember(item) { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(item) {
        bmp = withContext(Dispatchers.Default) { CardArt.story(item, themeIdx, 720, 1280).asImageBitmap() }
    }
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(th.top), Color(th.bottom)))),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) {
            Image(
                bitmap = b,
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Fit
            )
        }
    }
}

@Composable
private fun RoundBtn(label: String, size: Int, onClick: () -> Unit) {
    Box(
        Modifier
            .size(size.dp)
            .clip(CircleShape)
            .background(Color(0x66000000))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) { Text(label, color = Color.White, fontSize = 20.sp) }
}

private suspend fun renderFull(item: Inspire, themeIdx: Int): Bitmap =
    withContext(Dispatchers.Default) { CardArt.story(item, themeIdx) }

private suspend fun shareStory(ctx: Context, item: Inspire, themeIdx: Int, whatsapp: Boolean) {
    try {
        val uri = withContext(Dispatchers.IO) {
            val bmp = renderFull(item, themeIdx)
            val dir = File(ctx.cacheDir, "stories").apply { mkdirs() }
            dir.listFiles()?.forEach { it.delete() }
            val f = File(dir, "vakitpro_${System.currentTimeMillis()}.png")
            f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)
        }
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, item.withSource + "\n\nVakit Pro")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        if (whatsapp) {
            send.setPackage("com.whatsapp")
            try {
                ctx.startActivity(send.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) {
                send.setPackage(null)
                Toast.makeText(ctx, "WhatsApp bulunamadı, paylaşma menüsü açılıyor", Toast.LENGTH_SHORT).show()
                ctx.startActivity(Intent.createChooser(send, "Paylaş").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        } else {
            ctx.startActivity(Intent.createChooser(send, "Paylaş").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    } catch (e: Exception) {
        Toast.makeText(ctx, "Paylaşılamadı", Toast.LENGTH_SHORT).show()
    }
}

private suspend fun saveStory(ctx: Context, item: Inspire, themeIdx: Int) {
    val ok = withContext(Dispatchers.IO) {
        try {
            val bmp = renderFull(item, themeIdx)
            val name = "VakitPro_${System.currentTimeMillis()}.png"
            if (Build.VERSION.SDK_INT >= 29) {
                val cv = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/VakitPro")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
                val r = ctx.contentResolver
                val uri = r.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
                    ?: return@withContext false
                r.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                cv.clear()
                cv.put(MediaStore.Images.Media.IS_PENDING, 0)
                r.update(uri, cv, null, null)
            } else {
                @Suppress("DEPRECATION")
                val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "VakitPro")
                dir.mkdirs()
                val f = File(dir, name)
                f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                android.media.MediaScannerConnection.scanFile(ctx, arrayOf(f.absolutePath), null, null)
            }
            true
        } catch (e: Exception) {
            false
        }
    }
    Toast.makeText(
        ctx,
        if (ok) "Galeriye kaydedildi (Pictures/VakitPro)" else "Kaydedilemedi",
        Toast.LENGTH_SHORT
    ).show()
}
