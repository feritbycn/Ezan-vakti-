package com.vakitpro.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.Dp
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.drawscope.DrawScope

/** Modern geri dugmesi: yuvarlak zemin + cizilmis ince ok (chevron). */
@Composable
fun BackButton(onClick: () -> Unit, glass: Boolean = false) {
    val cs = MaterialTheme.colorScheme
    val fg = if (glass) Color.White else cs.onSurface
    Box(
        Modifier
            .size(42.dp)
            .clip(CircleShape)
            .background(if (glass) Color(0x55000000) else cs.surfaceContainerHigh)
            .border(1.dp, if (glass) Color(0x44FFFFFF) else cs.outlineVariant.copy(alpha = 0.6f), CircleShape)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(20.dp)) {
            val w = size.width
            val h = size.height
            val p = Path()
            p.moveTo(w * 0.62f, h * 0.18f)
            p.lineTo(w * 0.30f, h * 0.50f)
            p.lineTo(w * 0.62f, h * 0.82f)
            drawPath(
                p, fg,
                style = Stroke(width = 2.6.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
            )
        }
    }
}

private const val BELL_PATH =
    "M12 22c1.1 0 2-.9 2-2h-4c0 1.1.89 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5" +
        "s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z"

/** Modern zil dugmesi: acikken dolu zil, kapaliyken ustu cizili soluk zil. */
@Composable
fun BellToggle(on: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val bell = remember { PathParser().parsePathString(BELL_PATH).toPath() }
    val fg = if (on) cs.primary else cs.onSurfaceVariant.copy(alpha = 0.55f)
    Box(
        Modifier
            .size(32.dp)
            .clip(CircleShape)
            .background(if (on) cs.primary.copy(alpha = 0.16f) else cs.surfaceVariant.copy(alpha = 0.45f))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(17.dp)) {
            val sc = size.width / 24f
            withTransform({ scale(sc, sc, Offset.Zero) }) {
                drawPath(bell, fg)
            }
            if (!on) {
                drawLine(
                    fg, Offset(3.5f * sc, 3.5f * sc), Offset(20.5f * sc, 20.5f * sc),
                    strokeWidth = 2.2f * sc, cap = StrokeCap.Round
                )
            }
        }
    }
}


private val PRAYER_GRADS = listOf(
    listOf(Color(0xFF4F46E5), Color(0xFF1E1B4B)),
    listOf(Color(0xFFFBBF24), Color(0xFFF0603B)),
    listOf(Color(0xFFFCD34D), Color(0xFFF59E0B)),
    listOf(Color(0xFF38BDF8), Color(0xFF2563EB)),
    listOf(Color(0xFFFB7185), Color(0xFF7C3AED)),
    listOf(Color(0xFF4338CA), Color(0xFF0F172A))
)

/** Vakit simgesi (emoji yerine): gradyan yuvarlak kare + cizilmis ikon. 0=Imsak ... 5=Yatsi */
@Composable
fun PrayerIcon(idx: Int, size: Dp = 38.dp) {
    Box(
        Modifier
            .size(size)
            .clip(RoundedCornerShape(size * 0.30f))
            .background(Brush.linearGradient(PRAYER_GRADS[idx.coerceIn(0, 5)])),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(size * 0.66f)) { drawPrayerGlyph(idx.coerceIn(0, 5)) }
    }
}

private fun DrawScope.crescent(cx: Float, cy: Float, r: Float, ox: Float, oy: Float, r2: Float, color: Color) {
    val a = Path().apply { addOval(Rect(cx - r, cy - r, cx + r, cy + r)) }
    val b = Path().apply { addOval(Rect(cx + ox - r2, cy + oy - r2, cx + ox + r2, cy + oy + r2)) }
    drawPath(Path.combine(PathOperation.Difference, a, b), color)
}

private fun DrawScope.sparkle(cx: Float, cy: Float, r: Float, color: Color) {
    val p = Path().apply {
        moveTo(cx, cy - r)
        quadraticBezierTo(cx, cy, cx + r, cy)
        quadraticBezierTo(cx, cy, cx, cy + r)
        quadraticBezierTo(cx, cy, cx - r, cy)
        quadraticBezierTo(cx, cy, cx, cy - r)
        close()
    }
    drawPath(p, color)
}

private fun DrawScope.drawPrayerGlyph(idx: Int) {
    val u = size.width / 100f
    val w = Color.White
    val sun = Color(0xFFFFF3C4)
    fun line(x1: Float, y1: Float, x2: Float, y2: Float, c: Color = w, sw: Float = 6f) =
        drawLine(c, Offset(x1 * u, y1 * u), Offset(x2 * u, y2 * u), strokeWidth = sw * u, cap = StrokeCap.Round)
    fun rays(cx: Float, cy: Float, r1: Float, r2: Float, n: Int, startDeg: Float, sweep: Float, c: Color) {
        for (k in 0 until n) {
            val a = Math.toRadians((startDeg + if (n > 1) sweep * k / (n - 1) else 0f).toDouble())
            val cs = Math.cos(a).toFloat(); val sn = Math.sin(a).toFloat()
            line(cx + r1 * cs, cy + r1 * sn, cx + r2 * cs, cy + r2 * sn, c, 6f)
        }
    }
    when (idx) {
        0 -> { // imsak: hilal + yildiz + ufuk
            crescent(36f * u, 36f * u, 22f * u, 10f * u, -5f * u, 18f * u, w)
            sparkle(72f * u, 26f * u, 9f * u, w)
            sparkle(76f * u, 52f * u, 5f * u, w.copy(alpha = 0.8f))
            line(10f, 74f, 90f, 74f)
            line(30f, 88f, 70f, 88f, w.copy(alpha = 0.55f))
        }
        1 -> { // gunes: dogan gunes
            drawArc(sun, 180f, 180f, true, Offset(28f * u, 46f * u), Size(44f * u, 44f * u))
            rays(50f, 68f, 30f, 40f, 5, 200f, 140f, w)
            line(10f, 74f, 90f, 74f)
            line(30f, 88f, 70f, 88f, w.copy(alpha = 0.55f))
        }
        2 -> { // ogle: tam gunes
            drawCircle(sun, 17f * u, Offset(50f * u, 50f * u))
            rays(50f, 50f, 27f, 38f, 8, 0f, 315f, w)
        }
        3 -> { // ikindi: bulutlu gunes
            drawCircle(sun, 16f * u, Offset(64f * u, 36f * u))
            rays(64f, 36f, 24f, 33f, 6, -150f, 200f, sun)
            drawCircle(w, 13f * u, Offset(40f * u, 62f * u))
            drawCircle(w, 17f * u, Offset(60f * u, 58f * u))
            drawRoundRect(w, Offset(22f * u, 62f * u), Size(60f * u, 20f * u), androidx.compose.ui.geometry.CornerRadius(10f * u))
        }
        4 -> { // aksam: batan gunes
            drawArc(sun, 180f, 180f, true, Offset(26f * u, 40f * u), Size(48f * u, 48f * u))
            line(10f, 64f, 90f, 64f)
            line(24f, 77f, 76f, 77f, w.copy(alpha = 0.7f))
            line(38f, 89f, 62f, 89f, w.copy(alpha = 0.45f))
        }
        else -> { // yatsi: hilal + yildiz
            crescent(42f * u, 52f * u, 28f * u, 13f * u, -7f * u, 23f * u, w)
            sparkle(74f * u, 28f * u, 11f * u, w)
            sparkle(80f * u, 62f * u, 6f * u, w.copy(alpha = 0.8f))
        }
    }
}


/** Alt menu simgeleri (emoji yerine): 0 Vakitler, 1 Kible, 2 Zikir, 3 Kesfet, 4 Ayarlar. */
@Composable
fun NavIcon(idx: Int, tint: Color, size: Dp = 24.dp) {
    Canvas(Modifier.size(size)) {
        val u = this.size.width / 100f
        fun o(x: Float, y: Float) = Offset(x * u, y * u)
        fun line(x1: Float, y1: Float, x2: Float, y2: Float, sw: Float = 7f, a: Float = 1f) =
            drawLine(tint.copy(alpha = a), o(x1, y1), o(x2, y2), strokeWidth = sw * u, cap = StrokeCap.Round)
        when (idx) {
            0 -> { // cami
                drawArc(tint, 180f, 180f, true, o(26f, 24f), androidx.compose.ui.geometry.Size(48f * u, 48f * u))
                drawRect(tint, o(26f, 48f), androidx.compose.ui.geometry.Size(48f * u, 38f * u))
                line(50f, 8f, 50f, 24f, 5f)
                for (x in floatArrayOf(8f, 80f)) {
                    drawRect(tint, o(x + 1f, 46f), androidx.compose.ui.geometry.Size(10f * u, 40f * u))
                    val tip = Path().apply {
                        moveTo(x * u, 46f * u); lineTo((x + 6f) * u, 16f * u); lineTo((x + 12f) * u, 46f * u); close()
                    }
                    drawPath(tip, tint)
                }
                drawRect(tint, o(4f, 84f), androidx.compose.ui.geometry.Size(92f * u, 6f * u))
            }
            1 -> { // kible pusulasi
                drawCircle(tint, 38f * u, o(50f, 50f), style = Stroke(width = 6f * u))
                val n = Path().apply {
                    moveTo(50f * u, 22f * u); lineTo(61f * u, 50f * u); lineTo(39f * u, 50f * u); close()
                }
                drawPath(n, tint)
                val sPath = Path().apply {
                    moveTo(50f * u, 78f * u); lineTo(61f * u, 50f * u); lineTo(39f * u, 50f * u); close()
                }
                drawPath(sPath, tint.copy(alpha = 0.4f))
            }
            2 -> { // tesbih
                for (k in 0 until 11) {
                    val a = Math.toRadians(-90.0 + 360.0 * k / 11)
                    drawCircle(tint, 6f * u, o(50f + 29f * Math.cos(a).toFloat(), 40f + 29f * Math.sin(a).toFloat()))
                }
                line(50f, 70f, 50f, 88f, 5f, 0.8f)
                drawCircle(tint, 6f * u, o(50f, 77f))
                drawCircle(tint, 7f * u, o(50f, 90f))
            }
            3 -> { // kesfet: kivilcim
                fun spark(cx: Float, cy: Float, r: Float) {
                    val sp = Path().apply {
                        moveTo(cx * u, (cy - r) * u)
                        quadraticBezierTo(cx * u, cy * u, (cx + r) * u, cy * u)
                        quadraticBezierTo(cx * u, cy * u, cx * u, (cy + r) * u)
                        quadraticBezierTo(cx * u, cy * u, (cx - r) * u, cy * u)
                        quadraticBezierTo(cx * u, cy * u, cx * u, (cy - r) * u)
                        close()
                    }
                    drawPath(sp, tint)
                }
                spark(44f, 56f, 34f)
                spark(76f, 22f, 15f)
                spark(80f, 78f, 10f)
            }
            else -> { // ayarlar: kaydiricilar
                line(12f, 26f, 88f, 26f, 6f, 0.55f)
                line(12f, 50f, 88f, 50f, 6f, 0.55f)
                line(12f, 74f, 88f, 74f, 6f, 0.55f)
                drawCircle(tint, 11f * u, o(34f, 26f))
                drawCircle(tint, 11f * u, o(68f, 50f))
                drawCircle(tint, 11f * u, o(44f, 74f))
            }
        }
    }
}


/** Izin ekrani simgeleri: 0 zil, 1 pil, 2 pencere (ustte goster), 3 onay. */
@Composable
fun PermIcon(kind: Int, tint: Color, size: Dp = 22.dp, mark: Color = Color.White) {
    Canvas(Modifier.size(size)) {
        val u = this.size.width / 100f
        fun o(x: Float, y: Float) = Offset(x * u, y * u)
        fun sz(w: Float, h: Float) = androidx.compose.ui.geometry.Size(w * u, h * u)
        when (kind) {
            0 -> {
                drawArc(tint, 180f, 180f, true, o(26f, 16f), sz(48f, 48f))
                val body = Path().apply {
                    moveTo(26f * u, 40f * u); lineTo(74f * u, 40f * u)
                    lineTo(84f * u, 70f * u); lineTo(16f * u, 70f * u); close()
                }
                drawPath(body, tint)
                drawRoundRect(tint, o(12f, 66f), sz(76f, 8f), CornerRadius(4f * u))
                drawCircle(tint, 8f * u, o(50f, 84f))
                drawCircle(tint, 5f * u, o(50f, 12f))
            }
            1 -> {
                drawRoundRect(tint, o(8f, 28f), sz(76f, 44f), CornerRadius(10f * u), style = Stroke(width = 7f * u))
                drawRoundRect(tint, o(86f, 42f), sz(8f, 16f), CornerRadius(3f * u))
                drawRoundRect(tint, o(18f, 38f), sz(44f, 24f), CornerRadius(4f * u))
            }
            2 -> {
                drawRoundRect(tint.copy(alpha = 0.55f), o(8f, 8f), sz(58f, 48f), CornerRadius(10f * u), style = Stroke(width = 7f * u))
                drawRoundRect(tint, o(32f, 36f), sz(60f, 56f), CornerRadius(12f * u))
                drawRoundRect(mark, o(42f, 48f), sz(40f, 6f), CornerRadius(3f * u))
                drawRoundRect(mark.copy(alpha = 0.7f), o(42f, 62f), sz(28f, 6f), CornerRadius(3f * u))
            }
            else -> {
                drawCircle(tint, 44f * u, o(50f, 50f))
                val c = Path().apply {
                    moveTo(30f * u, 52f * u); lineTo(44f * u, 66f * u); lineTo(71f * u, 36f * u)
                }
                drawPath(c, mark, style = Stroke(width = 9f * u, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
        }
    }
}


private val DISCOVER_GRADS = listOf(
    listOf(Color(0xFFEC4899), Color(0xFF7C3AED)),
    listOf(Color(0xFF10B981), Color(0xFF047857)),
    listOf(Color(0xFF38BDF8), Color(0xFF2563EB)),
    listOf(Color(0xFF6366F1), Color(0xFF1E1B4B)),
    listOf(Color(0xFFF59E0B), Color(0xFFEA580C)),
    listOf(Color(0xFF34D399), Color(0xFF0D9488)),
    listOf(Color(0xFFFBBF24), Color(0xFFB45309)),
    listOf(Color(0xFFFB7185), Color(0xFFBE185D)),
    listOf(Color(0xFFF87171), Color(0xFFDC2626))
)

/** Kesfet kutucuklari (emoji yerine): 0 Hikaye, 1 Kuran, 2 Esma, 3 Dini gunler, 4 Aylik, 5 Takip, 6 Zekat, 7 Dua, 8 Camiler */
@Composable
fun DiscoverIcon(kind: Int, size: Dp = 52.dp) {
    val k = kind.coerceIn(0, 8)
    val grad = DISCOVER_GRADS[k]
    Box(
        Modifier
            .size(size)
            .clip(RoundedCornerShape(size * 0.30f))
            .background(Brush.linearGradient(grad)),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(size * 0.62f)) { drawDiscoverGlyph(k, grad[0]) }
    }
}

private fun DrawScope.drawDiscoverGlyph(k: Int, hole: Color) {
    val u = size.width / 100f
    val w = Color.White
    fun o(x: Float, y: Float) = Offset(x * u, y * u)
    fun sz(a: Float, b: Float) = Size(a * u, b * u)
    fun line(x1: Float, y1: Float, x2: Float, y2: Float, sw: Float = 6f, a: Float = 1f) =
        drawLine(w.copy(alpha = a), o(x1, y1), o(x2, y2), strokeWidth = sw * u, cap = StrokeCap.Round)
    when (k) {
        0 -> { // hikaye: halka + kivilcim
            drawCircle(w, 42f * u, o(50f, 50f), style = Stroke(width = 7f * u))
            sparkle(50f * u, 50f * u, 24f * u, w)
            sparkle(76f * u, 26f * u, 7f * u, w.copy(alpha = 0.85f))
        }
        1 -> { // kuran: acik kitap
            val l = Path().apply {
                moveTo(48f * u, 26f * u); quadraticBezierTo(28f * u, 14f * u, 8f * u, 22f * u)
                lineTo(8f * u, 76f * u); quadraticBezierTo(28f * u, 68f * u, 48f * u, 80f * u); close()
            }
            val r = Path().apply {
                moveTo(52f * u, 26f * u); quadraticBezierTo(72f * u, 14f * u, 92f * u, 22f * u)
                lineTo(92f * u, 76f * u); quadraticBezierTo(72f * u, 68f * u, 52f * u, 80f * u); close()
            }
            drawPath(l, w); drawPath(r, w.copy(alpha = 0.85f))
            line(18f, 36f, 38f, 40f, 4f, 0.0f)
            for (i in 0 until 3) {
                val y = 36f + i * 11f
                drawLine(hole.copy(alpha = 0.55f), o(17f, y), o(39f, y + 4f), strokeWidth = 3.5f * u, cap = StrokeCap.Round)
                drawLine(hole.copy(alpha = 0.55f), o(61f, y + 4f), o(83f, y), strokeWidth = 3.5f * u, cap = StrokeCap.Round)
            }
        }
        2 -> { // esma: 8 kollu yildiz
            val p = Path()
            for (i in 0 until 16) {
                val a = Math.toRadians(-90.0 + i * 22.5)
                val r = if (i % 2 == 0) 44f else 24f
                val x = 50f + r * Math.cos(a).toFloat(); val y = 50f + r * Math.sin(a).toFloat()
                if (i == 0) p.moveTo(x * u, y * u) else p.lineTo(x * u, y * u)
            }
            p.close()
            drawPath(p, w)
            drawCircle(hole, 10f * u, o(50f, 50f))
        }
        3 -> { // dini gunler: hilal + yildiz
            crescent(42f * u, 52f * u, 34f * u, 15f * u, -8f * u, 28f * u, w)
            sparkle(74f * u, 28f * u, 12f * u, w)
            sparkle(80f * u, 64f * u, 6f * u, w.copy(alpha = 0.8f))
        }
        4 -> { // aylik: takvim
            drawRoundRect(w, o(10f, 18f), sz(80f, 72f), androidx.compose.ui.geometry.CornerRadius(14f * u))
            drawRect(hole.copy(alpha = 0.35f), o(10f, 38f), sz(80f, 4f))
            line(32f, 8f, 32f, 26f, 7f)
            line(68f, 8f, 68f, 26f, 7f)
            for (r in 0 until 2) for (c in 0 until 4) {
                drawCircle(hole.copy(alpha = 0.75f), 4f * u, o(26f + c * 16f, 56f + r * 17f))
            }
        }
        5 -> { // takip: ilerleme halkasi + onay
            drawCircle(w.copy(alpha = 0.3f), 40f * u, o(50f, 50f), style = Stroke(width = 8f * u))
            drawArc(w, -90f, 250f, false, o(10f, 10f), sz(80f, 80f), style = Stroke(width = 8f * u, cap = StrokeCap.Round))
            val c = Path().apply { moveTo(34f * u, 52f * u); lineTo(46f * u, 64f * u); lineTo(68f * u, 38f * u) }
            drawPath(c, w, style = Stroke(width = 8f * u, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        6 -> { // zekat: bozuk paralar
            drawCircle(w.copy(alpha = 0.55f), 28f * u, o(36f, 60f))
            drawCircle(w, 30f * u, o(60f, 42f))
            drawCircle(hole.copy(alpha = 0.6f), 18f * u, o(60f, 42f), style = Stroke(width = 4f * u))
            sparkle(60f * u, 42f * u, 9f * u, hole.copy(alpha = 0.8f))
        }
        7 -> { // dua: acik eller + kivilcim
            val left = Path().apply {
                moveTo(50f * u, 86f * u); quadraticBezierTo(10f * u, 66f * u, 22f * u, 30f * u)
                quadraticBezierTo(46f * u, 44f * u, 50f * u, 86f * u); close()
            }
            val right = Path().apply {
                moveTo(50f * u, 86f * u); quadraticBezierTo(90f * u, 66f * u, 78f * u, 30f * u)
                quadraticBezierTo(54f * u, 44f * u, 50f * u, 86f * u); close()
            }
            drawPath(left, w); drawPath(right, w.copy(alpha = 0.85f))
            sparkle(50f * u, 20f * u, 11f * u, w)
        }
        else -> { // camiler: konum igne
            val pin = Path().apply {
                moveTo(50f * u, 92f * u); lineTo(22f * u, 52f * u)
                arcTo(Rect(22f * u, 8f * u, 78f * u, 64f * u), 160f, 220f, false)
                lineTo(50f * u, 92f * u); close()
            }
            drawPath(pin, w)
            drawCircle(hole, 11f * u, o(50f, 36f))
        }
    }
}
