package com.vakitpro.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.dp

/** Modern geri dugmesi: yuvarlak zemin + cizilmis ince ok (chevron). */
@Composable
fun BackButton(onClick: () -> Unit, glass: Boolean = false) {
    val cs = MaterialTheme.colorScheme
    val fg = if (glass) Color.White else cs.onSurface
    Box(
        Modifier
            .size(42.dp)
            .clip(CircleShape)
            .background(if (glass) Color(0x55000000) else cs.surfaceContainerHigh)
            .border(1.dp, if (glass) Color(0x44FFFFFF) else cs.outlineVariant.copy(alpha = 0.6f), CircleShape)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(20.dp)) {
            val w = size.width
            val h = size.height
            val p = Path()
            p.moveTo(w * 0.62f, h * 0.18f)
            p.lineTo(w * 0.30f, h * 0.50f)
            p.lineTo(w * 0.62f, h * 0.82f)
            drawPath(
                p, fg,
                style = Stroke(width = 2.6.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
            )
        }
    }
}

private const val BELL_PATH =
    "M12 22c1.1 0 2-.9 2-2h-4c0 1.1.89 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5" +
        "s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z"

/** Modern zil dugmesi: acikken dolu zil, kapaliyken ustu cizili soluk zil. */
@Composable
fun BellToggle(on: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val bell = remember { PathParser().parsePathString(BELL_PATH).toPath() }
    val fg = if (on) cs.primary else cs.onSurfaceVariant.copy(alpha = 0.55f)
    Box(
        Modifier
            .size(32.dp)
            .clip(CircleShape)
            .background(if (on) cs.primary.copy(alpha = 0.16f) else cs.surfaceVariant.copy(alpha = 0.45f))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(17.dp)) {
            val sc = size.width / 24f
            withTransform({ scale(sc, sc, Offset.Zero) }) {
                drawPath(bell, fg)
            }
            if (!on) {
                drawLine(
                    fg, Offset(3.5f * sc, 3.5f * sc), Offset(20.5f * sc, 20.5f * sc),
                    strokeWidth = 2.2f * sc, cap = StrokeCap.Round
                )
            }
        }
    }
}
